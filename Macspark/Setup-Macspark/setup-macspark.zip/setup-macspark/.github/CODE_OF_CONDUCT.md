# Código de Conduta - MacSpark

## Nosso Compromisso

No interesse de promover um ambiente aberto e acolhedor, nós, como contribuidores e mantenedores, nos comprometemos a tornar a participação em nosso projeto e em nossa comunidade uma experiência livre de assédio para todos, independentemente de idade, tamanho corporal, deficiência, etnia, características sexuais, identidade e expressão de gênero, nível de experiência, educação, status socioeconômico, nacionalidade, aparência pessoal, raça, religião ou identidade e orientação sexual.

## Nossos Padrões

Exemplos de comportamento que contribuem para criar um ambiente positivo incluem:

* Usar linguagem acolhedora e inclusiva
* Respeitar pontos de vista e experiências diferentes
* Aceitar críticas construtivas com elegância
* Focar no que é melhor para a comunidade
* Mostrar empatia com outros membros da comunidade

Exemplos de comportamento inaceitável incluem:

* Uso de linguagem ou imagens sexualizadas e atenção ou avanços sexuais indesejados
* Trolling, comentários insultuosos/depreciativos e ataques pessoais ou políticos
* Assédio público ou privado
* Publicar informações privadas de outros sem permissão explícita
* Outra conduta que poderia ser considerada inadequada em um ambiente profissional

## Nossas Responsabilidades

Os mantenedores do projeto são responsáveis por esclarecer os padrões de comportamento aceitável e devem tomar medidas corretivas apropriadas e justas em resposta a quaisquer instâncias de comportamento inaceitável.

## Escopo

Este Código de Conduta se aplica tanto aos espaços do projeto quanto aos espaços públicos quando um indivíduo está representando o projeto ou sua comunidade.

## Aplicação

Instâncias de comportamento abusivo, de assédio ou de outra forma inaceitável podem ser relatadas entrando em contato com a equipe do projeto em conduct@macspark.dev. Todas as reclamações serão revisadas e investigadas e resultarão em uma resposta considerada necessária e apropriada às circunstâncias.

## Atribuição

Este Código de Conduta é adaptado do [Contributor Covenant](https://www.contributor-covenant.org), versão 2.0.

---

**Data de Vigência**: Janeiro 2025  
**Contato**: conduct@macspark.dev