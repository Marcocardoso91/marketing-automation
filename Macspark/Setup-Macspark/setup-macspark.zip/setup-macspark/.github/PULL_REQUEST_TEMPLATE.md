## 📋 Descrição
<!-- Descreva claramente as mudanças propostas -->

## 🎯 Tipo de Mudança
<!-- Marque com 'x' o tipo apropriado -->

- [ ] 🐛 Correção de bug (mudança que corrige um problema)
- [ ] ✨ Nova funcionalidade (mudança que adiciona funcionalidade)
- [ ] 🔧 Configuração (mudança em arquivos de configuração)
- [ ] 📚 Documentação (mudanças apenas na documentação)
- [ ] ♻️ Refatoração (mudança que não corrige bug nem adiciona funcionalidade)
- [ ] 🚀 Performance (mudança que melhora performance)
- [ ] 🔒 Segurança (correção ou melhoria de segurança)
- [ ] 🏗️ Infraestrutura (mudanças em Docker, CI/CD, scripts)

## 🔗 Issue Relacionada
<!-- Link para a issue relacionada, se houver -->
Closes #

## 📝 Checklist de Mudanças na Infraestrutura
<!-- Para mudanças em stacks/serviços -->

### Pre-Deploy
- [ ] Configurações de ambiente atualizadas (`environments/`)
- [ ] Secrets configurados no Vault ou Docker Secrets
- [ ] Volumes e networks definidos corretamente
- [ ] Health checks configurados
- [ ] Resource limits definidos (CPU/Memory)

### Validação
- [ ] `docker-compose config` validado sem erros
- [ ] Scripts de deploy testados localmente
- [ ] Compatibilidade com ambiente de homolog verificada
- [ ] Rollback plan documentado

### Segurança
- [ ] Sem secrets hardcoded
- [ ] Imagens Docker escaneadas para vulnerabilidades
- [ ] Configurações de rede revisadas
- [ ] Middlewares de segurança do Traefik configurados

### Monitoramento
- [ ] Métricas Prometheus configuradas
- [ ] Dashboard Grafana criado/atualizado
- [ ] Alertas configurados
- [ ] Logs centralizados (Loki/Promtail)

## 🧪 Testes Realizados
<!-- Descreva os testes realizados -->

### Ambiente Local
- [ ] Deploy local bem-sucedido
- [ ] Funcionalidade testada manualmente
- [ ] Sem erros nos logs

### Ambiente Homolog
- [ ] Deploy em homolog bem-sucedido
- [ ] Testes de integração passaram
- [ ] Performance aceitável

## 📊 Impacto
<!-- Descreva o impacto das mudanças -->

### Serviços Afetados
<!-- Liste os serviços que serão impactados -->
- 

### Downtime Esperado
<!-- Informe se haverá downtime e duração estimada -->
- [ ] Sem downtime (rolling update)
- [ ] Downtime mínimo (< 5 min)
- [ ] Downtime planejado: ___ minutos

### Recursos Necessários
<!-- Mudanças em recursos (CPU, RAM, Storage) -->
- 

## 📸 Screenshots/Logs
<!-- Se aplicável, adicione screenshots ou logs relevantes -->

## 📚 Documentação
<!-- Marque as documentações atualizadas -->

- [ ] README.md atualizado
- [ ] Documentação técnica em `docs/`
- [ ] CHANGELOG.md atualizado
- [ ] Runbook de operação criado/atualizado

## ⚠️ Breaking Changes
<!-- Liste qualquer breaking change -->

## 📋 Notas Adicionais
<!-- Qualquer informação adicional relevante -->

## 🔄 Rollback Plan
<!-- Descreva o plano de rollback caso necessário -->

---

### Reviewer Checklist
<!-- Para uso do reviewer -->

- [ ] Código revisado
- [ ] Configurações de segurança verificadas
- [ ] Impacto em produção avaliado
- [ ] Documentação adequada
- [ ] Testes suficientes