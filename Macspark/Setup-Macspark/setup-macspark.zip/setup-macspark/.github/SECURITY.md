# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 2.x.x   | :white_check_mark: |
| 1.x.x   | :x:                |

## Reporting a Vulnerability

**DO NOT** create a public issue for security vulnerabilities.

### How to Report

1. **Email**: Send details to security@macspark.dev
2. **Encrypted**: Use our PGP key (available at https://macspark.dev/pgp)
3. **Response Time**: Within 48 hours
4. **Fix Timeline**: Critical issues within 7 days

### What to Include

- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Suggested fix (if any)

### Our Commitment

- Acknowledge receipt within 48 hours
- Provide regular updates on progress
- Credit researchers in advisories (unless anonymity requested)
- No legal action against good-faith researchers

## Security Measures

- All commits are signed
- Dependencies regularly updated via Dependabot
- Automated security scanning with CodeQL
- Container image scanning with Trivy
- Secret scanning enabled

## Bug Bounty

Currently, we don't have a bug bounty program, but we deeply appreciate security research contributions.