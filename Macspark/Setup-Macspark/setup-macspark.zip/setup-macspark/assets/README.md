# 📁 Assets - Setup Macspark

Este diretório contém recursos visuais e de documentação para o projeto Setup-Macspark.

## 📂 Estrutura de Diretórios

```
assets/
├── diagrams/           # Diagramas de arquitetura e fluxos
│   ├── architecture-overview.md    # Visão geral da arquitetura
│   └── network-topology.md        # Topologia de rede
├── images/            # Screenshots e imagens do sistema
│   └── PLACEHOLDER.md # Guia para adicionar imagens
└── README.md         # Este arquivo
```

## 🎨 Diagrams

### Conteúdo Disponível

#### architecture-overview.md
- **Arquitetura Geral**: Visão completa do sistema Docker Swarm
- **Fluxo CI/CD**: Pipeline de deployment automatizado
- **Stack de Monitoramento**: Prometheus, Grafana, Loki
- **Arquitetura de Segurança**: Camadas de proteção
- **Arquitetura AI/ML**: Serviços de IA integrados
- **Backup e Recovery**: Fluxo de backup com Restic
- **Estrutura de Rede**: Docker overlay networks
- **Pipeline de Deployment**: Estados e transições

#### network-topology.md
- **Topologia Física e Lógica**: Layout completo da rede
- **Configuração de VLANs**: Segmentação de rede
- **Docker Overlay Networks**: Redes virtuais do Swarm
- **Fluxo de Tráfego**: Sequência de requisições
- **Configuração de Firewall**: Regras iptables
- **Tabela de Portas**: Mapeamento de serviços
- **Configuração DNS**: Zonas externas e internas

### Como Visualizar Diagramas

Os diagramas estão em formato **Mermaid** e podem ser visualizados:

1. **GitHub**: Renderização automática em arquivos Markdown
2. **Mermaid Live Editor**: [mermaid.live](https://mermaid.live)
3. **VS Code**: Extensão "Markdown Preview Mermaid Support"
4. **Exportação**: 
   ```bash
   # Instalar CLI
   npm install -g @mermaid-js/mermaid-cli
   
   # Exportar como PNG
   mmdc -i diagram.mmd -o diagram.png
   
   # Exportar como SVG
   mmdc -i diagram.mmd -o diagram.svg
   ```

## 🖼️ Images

### Organização Planejada

```
images/
├── dashboards/        # Screenshots de dashboards
│   ├── grafana/      # Dashboards Grafana
│   ├── traefik/      # Interface Traefik
│   └── portainer/    # Portainer UI
├── applications/      # Interfaces de aplicações
│   ├── n8n/         # Workflows N8N
│   ├── chatwoot/    # Chat interface
│   └── bookstack/   # Documentação
├── monitoring/       # Gráficos e métricas
│   ├── metrics/     # CPU, RAM, Network
│   ├── logs/        # Loki/Promtail
│   └── alerts/      # Alertmanager
├── security/        # Interfaces de segurança
│   ├── vault/       # HashiCorp Vault
│   └── vaultwarden/ # Password manager
├── architecture/    # Diagramas exportados
│   ├── png/        # Formato PNG
│   └── svg/        # Formato SVG
├── logos/          # Logos de serviços
└── icons/          # Ícones do sistema
```

### Padrões de Nomenclatura

- **Dashboards**: `dashboard-[serviço]-[view].png`
  - Exemplo: `dashboard-grafana-overview.png`
- **Aplicações**: `app-[nome]-[tela].png`
  - Exemplo: `app-n8n-workflow.png`
- **Monitoramento**: `monitoring-[tipo]-[métrica].png`
  - Exemplo: `monitoring-cpu-usage.png`
- **Segurança**: `security-[serviço]-[função].png`
  - Exemplo: `security-vault-secrets.png`

### Requisitos de Imagem

| Tipo | Resolução | Formato | Tamanho Máximo |
|------|-----------|---------|----------------|
| Screenshot | 1920x1080 | PNG/WebP | 500KB |
| Thumbnail | 400x300 | JPG/WebP | 50KB |
| Logo | 512x512 | SVG/PNG | 100KB |
| Icon | 64x64 | SVG/PNG | 20KB |
| Diagram | 2560x1440 | SVG/PNG | 1MB |

## 🛠️ Ferramentas Recomendadas

### Criação de Diagramas
- **Mermaid**: Diagramas como código
- **Draw.io**: Editor visual online
- **Excalidraw**: Diagramas desenhados à mão
- **PlantUML**: Diagramas UML detalhados
- **Lucidchart**: Diagramas profissionais

### Captura de Tela
- **Linux**: `gnome-screenshot`, `scrot`, `flameshot`
- **Windows**: Snipping Tool, ShareX, Greenshot
- **Mac**: Cmd+Shift+4, CleanShot X
- **Browser**: Full Page Screen Capture

### Otimização de Imagens
```bash
# PNG Optimization
optipng -o5 image.png
pngquant --quality=65-80 image.png

# JPG Optimization
jpegoptim --size=200k image.jpg

# WebP Conversion
cwebp -q 80 image.png -o image.webp

# Batch Processing
for img in *.png; do
    convert "$img" -resize 1920x\> "optimized-$img"
done
```

## 📝 Diretrizes de Contribuição

### Ao Adicionar Novos Assets

1. **Verifique Duplicatas**: Não adicione imagens duplicadas
2. **Otimize Sempre**: Use ferramentas de compressão
3. **Nome Descritivo**: Siga os padrões de nomenclatura
4. **Documente**: Atualize este README se adicionar nova categoria
5. **Licença**: Certifique-se de ter direitos sobre a imagem

### Checklist para Screenshots

- [ ] Remover informações sensíveis (senhas, tokens, IPs)
- [ ] Destacar área importante (caixas, setas)
- [ ] Resolução adequada (legível mas não excessiva)
- [ ] Formato otimizado (WebP > PNG > JPG)
- [ ] Nome descritivo seguindo padrão

## 📄 Licenciamento

- Screenshots do projeto: MIT License
- Logos de terceiros: Respectivas licenças dos proprietários
- Ícones: Verificar fonte original (geralmente MIT ou Apache)
- Diagramas criados: MIT License

## 🔗 Recursos Úteis

### Bibliotecas de Ícones
- [Simple Icons](https://simpleicons.org/) - Logos de marcas
- [Heroicons](https://heroicons.com/) - Ícones UI
- [Tabler Icons](https://tabler-icons.io/) - 3000+ ícones
- [Lucide](https://lucide.dev/) - Fork do Feather Icons
- [Phosphor Icons](https://phosphoricons.com/) - Ícones flexíveis

### Bancos de Imagens
- [Unsplash](https://unsplash.com/) - Fotos gratuitas
- [Pexels](https://www.pexels.com/) - Fotos e vídeos
- [Pixabay](https://pixabay.com/) - Imagens domínio público
- [unDraw](https://undraw.co/) - Ilustrações open source

### Paletas de Cores
- [Coolors](https://coolors.co/) - Gerador de paletas
- [Color Hunt](https://colorhunt.co/) - Paletas populares
- [Material Design Colors](https://materialui.co/colors/) - Cores Material

---

*Última atualização: Janeiro 2025*