# Diagramas de Arquitetura - Setup Macspark

## 1. Arquitetura Geral do Sistema

```mermaid
graph TB
    subgraph "Internet"
        CF[Cloudflare]
        Users[Usuários]
    end
    
    subgraph "Docker Swarm Cluster"
        subgraph "Core Services"
            T[Traefik v3<br/>Load Balancer]
            DB[(PostgreSQL HA)]
            R[(Redis Cache)]
        end
        
        subgraph "Applications"
            AI[AI Services<br/>Ollama/MCP]
            PROD[Productivity<br/>N8N/BookStack]
            COMM[Communication<br/>Chatwoot]
            DEV[Development<br/>Code Server]
        end
        
        subgraph "Infrastructure"
            MON[Monitoring<br/>Prometheus/Grafana]
            SEC[Security<br/>Vault/VaultWarden]
            BKP[Backup<br/>Restic]
            LOG[Logging<br/>Loki/Promtail]
        end
    end
    
    Users --> CF
    CF --> T
    T --> AI
    T --> PROD
    T --> COMM
    T --> DEV
    
    AI --> DB
    PROD --> DB
    COMM --> DB
    DEV --> DB
    
    AI --> R
    PROD --> R
    COMM --> R
    
    MON --> T
    MON --> DB
    MON --> R
    MON --> AI
    MON --> PROD
    
    LOG --> T
    LOG --> AI
    LOG --> PROD
    
    BKP --> DB
    BKP --> PROD
    
    SEC -.->|Secrets| T
    SEC -.->|Credentials| DB
    SEC -.->|API Keys| AI
```

## 2. Fluxo de Deploy (CI/CD)

```mermaid
graph LR
    subgraph "GitHub"
        Code[Source Code]
        GHA[GitHub Actions]
    end
    
    subgraph "Environments"
        LOCAL[Local Dev]
        HOMOLOG[Homologação]
        STAGING[Staging]
        PROD[Produção]
    end
    
    Code -->|Push| GHA
    GHA -->|Tests| GHA
    GHA -->|Build| GHA
    GHA -->|Deploy| HOMOLOG
    HOMOLOG -->|Manual Approval| STAGING
    STAGING -->|Manual Approval| PROD
    
    LOCAL -->|Docker Compose| LOCAL
    HOMOLOG -->|Docker Swarm| HOMOLOG
    STAGING -->|Docker Swarm| STAGING
    PROD -->|Docker Swarm| PROD
```

## 3. Stack de Monitoramento

```mermaid
graph TB
    subgraph "Data Sources"
        DS1[Docker Metrics]
        DS2[Application Logs]
        DS3[System Metrics]
        DS4[Custom Metrics]
    end
    
    subgraph "Collection"
        PROM[Prometheus]
        PROMTAIL[Promtail]
        NETDATA[Netdata]
    end
    
    subgraph "Storage"
        TSDB[(Prometheus TSDB)]
        LOKI[(Loki)]
    end
    
    subgraph "Visualization"
        GRAF[Grafana]
        ALERT[Alertmanager]
    end
    
    subgraph "Notification"
        EMAIL[Email]
        SLACK[Slack]
        PAGER[PagerDuty]
    end
    
    DS1 --> PROM
    DS3 --> PROM
    DS4 --> PROM
    DS2 --> PROMTAIL
    DS3 --> NETDATA
    
    PROM --> TSDB
    PROMTAIL --> LOKI
    
    TSDB --> GRAF
    LOKI --> GRAF
    NETDATA --> GRAF
    
    GRAF --> ALERT
    ALERT --> EMAIL
    ALERT --> SLACK
    ALERT --> PAGER
```

## 4. Arquitetura de Segurança

```mermaid
graph TB
    subgraph "External Access"
        INET[Internet]
        VPN[VPN Access]
    end
    
    subgraph "Edge Security"
        CF[Cloudflare WAF]
        FW[Firewall]
    end
    
    subgraph "Application Security"
        TRAEFIK[Traefik<br/>Rate Limiting<br/>Auth Middleware]
        VAULT[HashiCorp Vault<br/>Secrets Management]
        VAULTW[VaultWarden<br/>Password Manager]
    end
    
    subgraph "Data Security"
        ENC[Encryption at Rest]
        TLS[TLS/SSL]
        BACKUP[Encrypted Backups]
    end
    
    INET --> CF
    CF --> FW
    FW --> TRAEFIK
    VPN --> FW
    
    TRAEFIK -->|Auth| VAULT
    TRAEFIK -->|TLS| TLS
    
    VAULT --> ENC
    VAULTW --> ENC
    
    ENC --> BACKUP
```

## 5. Arquitetura de IA/ML

```mermaid
graph LR
    subgraph "AI Services"
        OLLAMA[Ollama<br/>Local LLMs]
        MCP[MCP Orchestrator<br/>Agent Coordination]
        QWEN[Qwen<br/>Chinese LLM]
        SPARK[SparkOne<br/>Custom Agent]
    end
    
    subgraph "Integration Layer"
        N8N[N8N<br/>Workflow Automation]
        API[Evolution API<br/>WhatsApp]
    end
    
    subgraph "Data Layer"
        VDB[(Vector Database)]
        PG[(PostgreSQL)]
        REDIS[(Redis Cache)]
    end
    
    subgraph "Frontend"
        WEB[Web Interface]
        CHAT[Chatwoot]
    end
    
    WEB --> MCP
    CHAT --> API
    API --> N8N
    N8N --> MCP
    
    MCP --> OLLAMA
    MCP --> QWEN
    MCP --> SPARK
    
    OLLAMA --> VDB
    MCP --> PG
    MCP --> REDIS
```

## 6. Fluxo de Backup e Recovery

```mermaid
sequenceDiagram
    participant CRON as Cron Job
    participant SCRIPT as Backup Script
    participant RESTIC as Restic
    participant DB as Database
    participant FILES as File System
    participant S3 as S3 Storage
    participant ALERT as Alerting
    
    CRON->>SCRIPT: Trigger backup (daily 2AM)
    SCRIPT->>DB: Create snapshot
    DB-->>SCRIPT: Snapshot ready
    SCRIPT->>FILES: Collect files
    FILES-->>SCRIPT: Files ready
    SCRIPT->>RESTIC: Initialize backup
    RESTIC->>RESTIC: Deduplicate & Encrypt
    RESTIC->>S3: Upload incremental
    S3-->>RESTIC: Upload complete
    RESTIC-->>SCRIPT: Backup successful
    SCRIPT->>ALERT: Send success notification
    
    Note over SCRIPT,RESTIC: Recovery Process
    SCRIPT->>RESTIC: Request restore
    RESTIC->>S3: Download backup
    S3-->>RESTIC: Data retrieved
    RESTIC->>RESTIC: Decrypt & Decompress
    RESTIC->>DB: Restore database
    RESTIC->>FILES: Restore files
    RESTIC-->>SCRIPT: Restore complete
```

## 7. Estrutura de Rede Docker Swarm

```mermaid
graph TB
    subgraph "Docker Networks"
        subgraph "traefik-public"
            TR[Traefik]
            direction LR
        end
        
        subgraph "internal"
            DB[(Database)]
            CACHE[(Cache)]
            direction LR
        end
        
        subgraph "monitoring"
            PROM[Prometheus]
            GRAF[Grafana]
            direction LR
        end
        
        subgraph "apps"
            APP1[App 1]
            APP2[App 2]
            APP3[App 3]
            direction LR
        end
    end
    
    TR -.->|overlay| APP1
    TR -.->|overlay| APP2
    TR -.->|overlay| APP3
    
    APP1 -.->|overlay| DB
    APP2 -.->|overlay| DB
    APP3 -.->|overlay| CACHE
    
    PROM -.->|overlay| TR
    PROM -.->|overlay| APP1
    PROM -.->|overlay| DB
    
    GRAF -.->|overlay| PROM
```

## 8. Pipeline de Deployment

```mermaid
stateDiagram-v2
    [*] --> CodeCommit: Developer Push
    CodeCommit --> CI: GitHub Actions Trigger
    
    CI --> Tests: Run Tests
    Tests --> Build: Tests Pass
    Tests --> [*]: Tests Fail
    
    Build --> SecurityScan: Build Image
    SecurityScan --> PushRegistry: Scan Pass
    SecurityScan --> [*]: Vulnerabilities Found
    
    PushRegistry --> DeployHomolog: Push to Registry
    DeployHomolog --> HealthCheck: Deploy Stack
    
    HealthCheck --> SmokeTests: Service Healthy
    HealthCheck --> Rollback: Service Unhealthy
    
    SmokeTests --> ApprovalStaging: Tests Pass
    SmokeTests --> Rollback: Tests Fail
    
    ApprovalStaging --> DeployStaging: Manual Approval
    DeployStaging --> ValidationStaging: Deploy Stack
    
    ValidationStaging --> ApprovalProd: Validation Pass
    ValidationStaging --> Rollback: Validation Fail
    
    ApprovalProd --> DeployProd: Manual Approval
    DeployProd --> MonitorProd: Deploy Stack
    
    MonitorProd --> [*]: Success
    Rollback --> [*]: Rolled Back
```

## Como Usar Estes Diagramas

1. **Visualização Online**: Copie o código Mermaid para [mermaid.live](https://mermaid.live) para visualizar e exportar
2. **GitHub**: Os diagramas são renderizados automaticamente em arquivos Markdown no GitHub
3. **Exportação**: Use ferramentas como mermaid-cli para exportar como PNG/SVG
4. **Documentação**: Inclua estes diagramas na documentação técnica do projeto

## Ferramentas Recomendadas

- **Mermaid Live Editor**: Para edição e exportação online
- **Draw.io**: Para diagramas mais complexos
- **PlantUML**: Alternativa para diagramas UML detalhados
- **Excalidraw**: Para diagramas de arquitetura desenhados à mão