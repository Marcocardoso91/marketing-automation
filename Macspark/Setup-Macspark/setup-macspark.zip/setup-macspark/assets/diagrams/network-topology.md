# Topologia de Rede - Setup Macspark

## Diagrama de Rede Física e Lógica

```mermaid
graph TB
    subgraph "Internet Layer"
        INTERNET[Internet]
        CF[Cloudflare<br/>DDoS Protection<br/>WAF]
    end
    
    subgraph "Edge Network - 200.123.45.0/24"
        ROUTER[Router/Firewall<br/>200.123.45.1]
        VPN[VPN Server<br/>200.123.45.10]
    end
    
    subgraph "DMZ - 10.0.1.0/24"
        TRAEFIK[Traefik Proxy<br/>10.0.1.10-11<br/>HA Cluster]
        BASTION[Bastion Host<br/>10.0.1.5]
    end
    
    subgraph "Application Network - 10.0.2.0/24"
        subgraph "Node 1 - 10.0.2.10"
            APP1[Applications]
            AI1[AI Services]
        end
        
        subgraph "Node 2 - 10.0.2.11"
            APP2[Applications]
            AI2[AI Services]
        end
        
        subgraph "Node 3 - 10.0.2.12"
            APP3[Applications]
            MON[Monitoring]
        end
    end
    
    subgraph "Data Network - 10.0.3.0/24"
        subgraph "Database Cluster"
            PG1[PostgreSQL Primary<br/>10.0.3.10]
            PG2[PostgreSQL Replica<br/>10.0.3.11]
            PG3[PostgreSQL Replica<br/>10.0.3.12]
        end
        
        subgraph "Cache Layer"
            REDIS1[Redis Master<br/>10.0.3.20]
            REDIS2[Redis Slave<br/>10.0.3.21]
        end
    end
    
    subgraph "Storage Network - 10.0.4.0/24"
        NFS[NFS Server<br/>10.0.4.10]
        BACKUP[Backup Server<br/>10.0.4.20]
        S3[S3 Storage<br/>10.0.4.30]
    end
    
    INTERNET --> CF
    CF --> ROUTER
    ROUTER --> VPN
    ROUTER --> TRAEFIK
    VPN --> BASTION
    
    TRAEFIK --> APP1
    TRAEFIK --> APP2
    TRAEFIK --> APP3
    
    APP1 --> PG1
    APP2 --> PG1
    APP3 --> PG1
    
    PG1 --> PG2
    PG1 --> PG3
    
    APP1 --> REDIS1
    APP2 --> REDIS1
    REDIS1 --> REDIS2
    
    APP1 --> NFS
    APP2 --> NFS
    APP3 --> NFS
    
    PG1 --> BACKUP
    NFS --> BACKUP
    BACKUP --> S3
    
    MON -.->|Monitor| APP1
    MON -.->|Monitor| APP2
    MON -.->|Monitor| PG1
    MON -.->|Monitor| REDIS1
```

## Configuração de VLANs

```mermaid
graph LR
    subgraph "Switch Core"
        subgraph "VLAN 10 - Management"
            MGMT[Management<br/>10.0.0.0/24]
        end
        
        subgraph "VLAN 20 - DMZ"
            DMZ_VLAN[DMZ Services<br/>10.0.1.0/24]
        end
        
        subgraph "VLAN 30 - Applications"
            APP_VLAN[Applications<br/>10.0.2.0/24]
        end
        
        subgraph "VLAN 40 - Database"
            DB_VLAN[Database<br/>10.0.3.0/24]
        end
        
        subgraph "VLAN 50 - Storage"
            STOR_VLAN[Storage<br/>10.0.4.0/24]
        end
        
        subgraph "VLAN 100 - Guest"
            GUEST[Guest Network<br/>192.168.100.0/24]
        end
    end
    
    MGMT -.->|Tagged| DMZ_VLAN
    DMZ_VLAN -.->|Tagged| APP_VLAN
    APP_VLAN -.->|Tagged| DB_VLAN
    APP_VLAN -.->|Tagged| STOR_VLAN
    GUEST -.->|Isolated| GUEST
```

## Docker Overlay Networks

```mermaid
graph TB
    subgraph "Docker Swarm Overlay Networks"
        subgraph "traefik-public (10.10.0.0/24)"
            TR_NET[Traefik Service<br/>10.10.0.10]
            APP_PUB1[App Frontend 1<br/>10.10.0.20]
            APP_PUB2[App Frontend 2<br/>10.10.0.21]
        end
        
        subgraph "internal (10.11.0.0/24)"
            APP_INT1[App Backend 1<br/>10.11.0.20]
            APP_INT2[App Backend 2<br/>10.11.0.21]
            DB_INT[Database<br/>10.11.0.30]
            CACHE_INT[Cache<br/>10.11.0.40]
        end
        
        subgraph "monitoring (10.12.0.0/24)"
            PROM_NET[Prometheus<br/>10.12.0.10]
            GRAF_NET[Grafana<br/>10.12.0.11]
            LOKI_NET[Loki<br/>10.12.0.12]
            ALERT_NET[Alertmanager<br/>10.12.0.13]
        end
        
        subgraph "ai-network (10.13.0.0/24)"
            OLLAMA_NET[Ollama<br/>10.13.0.10]
            MCP_NET[MCP<br/>10.13.0.11]
            QWEN_NET[Qwen<br/>10.13.0.12]
        end
    end
    
    TR_NET --> APP_PUB1
    TR_NET --> APP_PUB2
    
    APP_PUB1 --> APP_INT1
    APP_PUB2 --> APP_INT2
    
    APP_INT1 --> DB_INT
    APP_INT2 --> DB_INT
    APP_INT1 --> CACHE_INT
    
    PROM_NET --> APP_INT1
    PROM_NET --> DB_INT
    PROM_NET --> OLLAMA_NET
    
    GRAF_NET --> PROM_NET
    GRAF_NET --> LOKI_NET
    
    MCP_NET --> OLLAMA_NET
    MCP_NET --> QWEN_NET
```

## Fluxo de Tráfego e Segurança

```mermaid
sequenceDiagram
    participant User as User
    participant CF as Cloudflare
    participant FW as Firewall
    participant TRAEFIK as Traefik
    participant AUTH as Auth Service
    participant APP as Application
    participant DB as Database
    participant LOG as Logging
    
    User->>CF: HTTPS Request
    CF->>CF: DDoS Check
    CF->>CF: WAF Rules
    CF->>FW: Filtered Request
    
    FW->>FW: Port Check (443)
    FW->>FW: Rate Limiting
    FW->>TRAEFIK: Forward to Traefik
    
    TRAEFIK->>TRAEFIK: SSL Termination
    TRAEFIK->>AUTH: Auth Middleware
    AUTH->>AUTH: Validate Token
    AUTH-->>TRAEFIK: Auth OK
    
    TRAEFIK->>APP: Route Request
    APP->>DB: Query Data
    DB-->>APP: Return Data
    
    APP-->>TRAEFIK: Response
    TRAEFIK-->>FW: Response
    FW-->>CF: Response
    CF-->>User: HTTPS Response
    
    Note over LOG: Async Logging
    TRAEFIK-)LOG: Access Log
    APP-)LOG: App Log
    AUTH-)LOG: Auth Log
```

## Configuração de Firewall (iptables)

```mermaid
graph TD
    subgraph "INPUT Chain"
        IN_START[Incoming Packet]
        IN_ESTABLISHED[Established?]
        IN_LOCALHOST[From Localhost?]
        IN_SSH[SSH Port 22?]
        IN_HTTP[HTTP/HTTPS?]
        IN_DOCKER[Docker Ports?]
        IN_DROP[DROP]
        IN_ACCEPT[ACCEPT]
    end
    
    subgraph "FORWARD Chain"
        FW_START[Forward Packet]
        FW_DOCKER[Docker Network?]
        FW_VLAN[VLAN Routing?]
        FW_DROP[DROP]
        FW_ACCEPT[ACCEPT]
    end
    
    subgraph "OUTPUT Chain"
        OUT_START[Outgoing Packet]
        OUT_ACCEPT[ACCEPT ALL]
    end
    
    IN_START --> IN_ESTABLISHED
    IN_ESTABLISHED -->|Yes| IN_ACCEPT
    IN_ESTABLISHED -->|No| IN_LOCALHOST
    IN_LOCALHOST -->|Yes| IN_ACCEPT
    IN_LOCALHOST -->|No| IN_SSH
    IN_SSH -->|Yes + IP OK| IN_ACCEPT
    IN_SSH -->|No| IN_HTTP
    IN_HTTP -->|Yes| IN_ACCEPT
    IN_HTTP -->|No| IN_DOCKER
    IN_DOCKER -->|Yes + Authorized| IN_ACCEPT
    IN_DOCKER -->|No| IN_DROP
    
    FW_START --> FW_DOCKER
    FW_DOCKER -->|Yes| FW_ACCEPT
    FW_DOCKER -->|No| FW_VLAN
    FW_VLAN -->|Allowed| FW_ACCEPT
    FW_VLAN -->|Denied| FW_DROP
    
    OUT_START --> OUT_ACCEPT
```

## Tabela de Portas e Serviços

| Serviço | Porta Externa | Porta Interna | Protocolo | Rede |
|---------|--------------|---------------|-----------|------|
| SSH | 22 | 22 | TCP | Management |
| HTTP | 80 | 80 | TCP | DMZ |
| HTTPS | 443 | 443 | TCP | DMZ |
| PostgreSQL | - | 5432 | TCP | Data |
| Redis | - | 6379 | TCP | Data |
| Prometheus | - | 9090 | TCP | Monitoring |
| Grafana | 3000 | 3000 | TCP | Monitoring |
| Traefik Admin | 8080 | 8080 | TCP | DMZ |
| Docker API | - | 2377 | TCP | Internal |
| Docker Swarm | - | 7946 | TCP/UDP | Internal |
| Overlay Network | - | 4789 | UDP | Internal |
| Ollama | - | 11434 | TCP | AI |
| N8N | 5678 | 5678 | TCP | Applications |
| Chatwoot | 3333 | 3000 | TCP | Applications |
| VPN | 1194 | 1194 | UDP | Edge |

## Configuração DNS

```mermaid
graph LR
    subgraph "External DNS (Cloudflare)"
        EXT_ZONE[macspark.dev]
        EXT_A[A Records]
        EXT_CNAME[CNAME Records]
    end
    
    subgraph "Internal DNS (CoreDNS)"
        INT_ZONE[internal.macspark.dev]
        INT_SRV[Service Discovery]
        INT_A[Internal A Records]
    end
    
    EXT_ZONE --> EXT_A
    EXT_ZONE --> EXT_CNAME
    
    EXT_A -->|app.macspark.dev| 200.123.45.100
    EXT_A -->|api.macspark.dev| 200.123.45.101
    EXT_CNAME -->|www.macspark.dev| app.macspark.dev
    
    INT_ZONE --> INT_SRV
    INT_ZONE --> INT_A
    
    INT_SRV -->|_http._tcp.traefik| 10.0.1.10:80
    INT_A -->|postgres.internal| 10.0.3.10
    INT_A -->|redis.internal| 10.0.3.20
```

## Notas de Implementação

1. **Segmentação de Rede**: Cada camada tem sua própria sub-rede para isolamento
2. **Redundância**: Serviços críticos em HA com múltiplas instâncias
3. **Monitoramento**: Todas as redes são monitoradas pelo stack Prometheus/Grafana
4. **Backup**: Rede dedicada para backup sem impacto na performance
5. **Segurança**: Firewall em múltiplas camadas + WAF Cloudflare