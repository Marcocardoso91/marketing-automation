# Placeholder para Imagens

Este diretório deve conter as seguintes imagens e screenshots:

## Screenshots Necessários

### Dashboard Principal
- [ ] Grafana Dashboard Overview
- [ ] Prometheus Targets
- [ ] Traefik Dashboard
- [ ] Portainer Overview

### Aplicações
- [ ] N8N Workflow Example
- [ ] Chatwoot Interface
- [ ] BookStack Documentation
- [ ] Code Server IDE

### Monitoramento
- [ ] CPU/Memory Metrics
- [ ] Network Traffic
- [ ] Application Performance
- [ ] Alert Manager

### Segurança
- [ ] Vault UI
- [ ] VaultWarden Interface
- [ ] SSL Certificates Status
- [ ] Security Scan Results

## Como Adicionar Screenshots

1. **Captura de Tela**:
   ```bash
   # Linux/Mac
   gnome-screenshot -a  # Área selecionada
   scrot -s             # Alternativa
   
   # Windows
   Win + Shift + S      # Snipping tool
   ```

2. **Otimização**:
   ```bash
   # Redimensionar para web (max 1920px largura)
   convert input.png -resize 1920x\> output.png
   
   # Comprimir PNG
   optipng -o5 screenshot.png
   pngquant --quality=65-80 screenshot.png
   
   # Converter para WebP (melhor compressão)
   cwebp -q 80 screenshot.png -o screenshot.webp
   ```

3. **Nomenclatura**:
   - `dashboard-grafana-overview.png`
   - `app-n8n-workflow.png`
   - `monitoring-cpu-metrics.png`
   - `security-vault-ui.png`

4. **Tamanho Recomendado**:
   - Screenshots: 1920x1080 max
   - Thumbnails: 400x300
   - Icons: 64x64 ou 128x128
   - Logos: SVG quando possível

## Estrutura de Organização

```
images/
├── dashboards/          # Screenshots de dashboards
├── applications/        # Interfaces de aplicações
├── monitoring/         # Gráficos e métricas
├── security/           # Interfaces de segurança
├── architecture/       # Diagramas exportados
├── logos/              # Logos de serviços
└── icons/              # Ícones do sistema
```

## Formatos Aceitos

- **PNG**: Screenshots com transparência
- **JPG**: Fotos e imagens sem transparência
- **WebP**: Melhor compressão para web
- **SVG**: Logos e ícones vetoriais
- **GIF**: Animações curtas (sparingly)

## Licença de Imagens

Certifique-se de que todas as imagens adicionadas:
1. São de sua autoria ou
2. Têm licença apropriada (Creative Commons, etc) ou
3. São screenshots de software open source

## Recursos para Ícones e Logos

- [Simple Icons](https://simpleicons.org/) - Logos de marcas
- [Heroicons](https://heroicons.com/) - Ícones UI
- [Tabler Icons](https://tabler-icons.io/) - Ícones diversos
- [Lucide](https://lucide.dev/) - Ícones modernos