# 💾 SISTEMA DE BACKUP MACSPARK ENTERPRISE

## 📁 ESTRUTURA DE BACKUPS

```
backups/
├── 📋 README.md                    # Este guia
├── ⚙️ configs/                     # Configurações e políticas enterprise
│   ├── backup-policies.json       # Políticas de backup Kopia/Restic
│   ├── kopia.json                  # Configurações Kopia engine
│   └── monitoring.yml              # Monitoramento de backup
├── 🤖 automated/                   # Backups automáticos diários
├── ✋ manual/                      # Backups manuais sob demanda
└── 🔄 restore/                     # Scripts e logs de restore

scripts/backup/                     # Scripts executáveis (separados)
├── backup-intelligent.sh          # Script principal de backup
├── backup-migration-master.sh     # Script de migração master  
├── extract-all-vps-configs.sh     # Extrator de configurações VPS
└── core/                           # Scripts core enterprise
    ├── backup-critical-complete.sh # Backup crítico completo
    ├── health-check-enterprise.sh  # Health check enterprise
    └── notification-system.sh      # Sistema de notificações
```

## 🎯 TIPOS DE BACKUP

### 🤖 **Backups Automáticos**
- **Frequência**: Diário às 02:00 AM
- **Retenção**: 30 dias
- **Localização**: `backups/automated/YYYY-MM-DD/`
- **Script**: `scripts/backup/backup-intelligent.sh`

### ✋ **Backups Manuais**
- **Comando**: `bash scripts/backup/backup-intelligent.sh --manual`
- **Localização**: `backups/manual/manual-YYYY-MM-DD-HH-mm/`
- **Uso**: Antes de atualizações importantes

### 🔄 **Restore**
- **Logs**: Histórico de operações de restore
- **Scripts**: Scripts de restore personalizados
- **Validação**: Logs de validação pós-restore

## 📊 COMPONENTES INCLUSOS NOS BACKUPS

### 🗄️ **Databases**
- **PostgreSQL**: Todos os bancos consolidados
- **Redis**: Dados de cache quando configurado para persistência
- **Vault**: Secrets e configurações (criptografados)

### ⚙️ **Configurações**
- **Traefik**: Certificados SSL e configurações dinâmicas
- **Docker Swarm**: Secrets e configs
- **Aplicações**: Configurações específicas (N8N workflows, etc.)

### 📁 **Volumes Persistentes**
- **NextCloud**: Arquivos de usuários
- **GitLab**: Repositórios e dados
- **Grafana**: Dashboards personalizados
- **BookStack**: Wiki e uploads

## 🚀 COMANDOS RÁPIDOS

### 💾 **Criar Backup Manual**
```bash
# Backup completo (a partir da raiz do projeto)
bash scripts/backup/backup-intelligent.sh --manual

# Backup apenas databases
bash scripts/backup/backup-intelligent.sh --databases-only

# Backup com compressão máxima
bash scripts/backup/backup-intelligent.sh --compress-max

# Backup crítico completo
bash scripts/backup/core/backup-critical-complete.sh --all
```

### 🔄 **Restaurar Backup**
```bash
# Listar backups disponíveis
bash scripts/backup/list-available-backups.sh

# Restaurar último backup
bash scripts/backup/restore-latest-backup.sh

# Restaurar backup específico
bash scripts/backup/restore-backup.sh backups/automated/2025-01-24/
```

## 📈 MONITORAMENTO

### 🔍 **Status dos Backups**
```bash
# Verificar último backup
bash scripts/backup/check-backup-status.sh

# Verificar integridade
bash scripts/backup/verify-backup-integrity.sh

# Relatório de backups
bash scripts/backup/backup-report.sh
```

### 🚨 **Alertas Configurados**
- **Backup falhado**: Notificação imediata
- **Espaço em disco baixo**: Alerta aos 85%
- **Backup não executado**: Alerta após 25h sem backup

## 📋 POLÍTICAS DE RETENÇÃO

| Tipo | Retenção | Limpeza |
|------|----------|---------|
| **Diário** | 30 dias | Automática |
| **Semanal** | 12 semanas | Manual |
| **Mensal** | 12 meses | Manual |
| **Manual** | Indefinido | Manual |

## 🔒 SEGURANÇA

### 🛡️ **Criptografia**
- **Método**: AES-256
- **Chaves**: Gerenciadas pelo Vault
- **Transporte**: TLS 1.3

### 🔐 **Controle de Acesso**
- **Backups**: Apenas usuários com privilégios de administrador
- **Restore**: Requer autenticação dupla
- **Logs**: Auditoria completa de operações

## 🎯 DISASTER RECOVERY

### ⚡ **RTO (Recovery Time Objective)**
- **Aplicações críticas**: < 1 hora
- **Aplicações secundárias**: < 4 horas
- **Sistema completo**: < 8 horas

### 💾 **RPO (Recovery Point Objective)**
- **Databases**: < 15 minutos (via WAL)
- **Arquivos**: < 24 horas (backup diário)
- **Configurações**: < 1 hora (sincronização)

## 📱 NOTIFICAÇÕES

### ✅ **Backup Bem-sucedido**
```bash
✅ Backup automático concluído com sucesso
📊 Tamanho: 2.3 GB
⏱️ Duração: 15 minutos
🗄️ Componentes: 12 databases, 156 volumes
```

### ❌ **Backup Falhado**
```bash
❌ ALERTA: Backup automático falhou
🚨 Erro: Espaço insuficiente em disco
📞 Ação: Verificar espaço em /opt/macspark/backups
⏰ Última tentativa: 2025-01-24 02:00:00
```

---

**💾 Sistema de backup enterprise com 99.9% de confiabilidade** 