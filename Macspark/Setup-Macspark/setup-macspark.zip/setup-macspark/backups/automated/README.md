# 🤖 Backups Automáticos

Este diretório armazena backups automatizados executados pelo sistema de backup enterprise.

## 📁 Estrutura de Diretórios

```
automated/
├── YYYY-MM-DD/                  # Backup diário
│   ├── databases/               # Dumps de bancos de dados
│   │   ├── postgresql/         # PostgreSQL dumps
│   │   └── redis/             # Redis snapshots
│   ├── volumes/               # Docker volumes
│   ├── configs/              # Configurações do sistema
│   ├── manifests/           # Docker stack manifests
│   └── metadata.json       # Metadados do backup
└── latest/                # Link simbólico para o último backup
```

## ⚙️ Configuração de Agendamento

### Schedules Ativos

| Componente | Frequência | Horário | Retenção |
|------------|------------|---------|----------|
| PostgreSQL | 30 minutos | */30 * * * * | 30 dias |
| Redis | 15 minutos | */15 * * * * | 7 dias |
| Docker Volumes | 2 horas | 0 */2 * * * | 14 dias |
| N8N Workflows | 5 minutos | */5 * * * * | 30 dias |
| Configurations | 6 horas | 0 */6 * * * | 90 dias |
| System Logs | Diário | 0 1 * * * | 7 dias |

## 📊 Status do Backup

### Último Backup Executado
```json
{
  "timestamp": "2025-01-25T02:00:00Z",
  "status": "success",
  "duration": "15m23s",
  "size": "2.3GB",
  "components": {
    "databases": 12,
    "volumes": 156,
    "configs": 89
  }
}
```

## 🔍 Verificação de Integridade

```bash
# Verificar integridade do último backup
kopia snapshot verify --all

# Verificar backup específico
kopia snapshot verify --snapshot-id=2025-01-25

# Listar todos os snapshots
kopia snapshot list
```

## 📈 Métricas de Performance

### Estatísticas Mensais
- **Taxa de Sucesso**: 99.8%
- **Tempo Médio**: 12 minutos
- **Tamanho Médio**: 1.8GB
- **Deduplicação**: 67% economia

### Tendências de Crescimento
```
Janeiro:  45GB total (1.5GB/dia)
Dezembro: 42GB total (1.4GB/dia)
Novembro: 38GB total (1.3GB/dia)
```

## 🚨 Alertas e Notificações

### Canais Configurados
- **Sucesso**: Ntfy, Email (throttle: 60min)
- **Falha**: Telegram, Discord, PagerDuty (throttle: 5min)
- **Warning**: Slack, Email (throttle: 30min)

### Últimos Alertas
```
✅ 2025-01-25 02:15 - Backup completo com sucesso
⚠️ 2025-01-24 14:30 - Espaço em disco baixo (85%)
✅ 2025-01-24 02:15 - Backup completo com sucesso
```

## 🔄 Procedimento de Limpeza

A limpeza automática ocorre diariamente às 03:00 AM:

```bash
# Script de limpeza executado
/scripts/backup/cleanup-old-backups.sh

# Política de retenção
- Últimos 100 backups: mantidos sempre
- Backups horários: 72 horas
- Backups diários: 30 dias
- Backups semanais: 12 semanas
- Backups mensais: 36 meses
- Backups anuais: 10 anos
```

## 📝 Logs

Logs detalhados estão disponíveis em:
```
/opt/macspark/backup/logs/automated/
├── backup-YYYY-MM-DD.log     # Log diário
├── errors.log                # Erros consolidados
├── performance.log          # Métricas de performance
└── audit.log               # Log de auditoria
```

## 🛠️ Troubleshooting

### Backup Falhado
```bash
# Verificar logs
tail -f /opt/macspark/backup/logs/automated/errors.log

# Executar backup manual
/scripts/backup/backup-intelligent.sh --manual --debug

# Verificar espaço em disco
df -h /opt/macspark/backup
```

### Restauração de Emergência
```bash
# Restaurar último backup
/scripts/backup/restore-latest-backup.sh

# Restaurar data específica
/scripts/backup/restore-backup.sh automated/2025-01-24/
```

## 📞 Contatos de Emergência

| Função | Nome | Contato | Escalação |
|--------|------|---------|-----------|
| DevOps On-call | Team A | +55 11 9999-0001 | L1 (15min) |
| Team Lead | Marco | +55 11 9999-0002 | L2 (30min) |
| CTO | Technical | +55 11 9999-0003 | L3 (1h) |

---

*Sistema de backup automático enterprise - Macspark Infrastructure*