# ✋ Backups Manuais

Este diretório armazena backups manuais executados sob demanda por administradores.

## 📁 Estrutura de Diretórios

```
manual/
├── manual-YYYY-MM-DD-HHmm/      # Backup manual com timestamp
│   ├── reason.txt              # Motivo do backup manual
│   ├── operator.txt           # Quem executou o backup
│   ├── databases/            # Dumps de bancos de dados
│   ├── volumes/             # Docker volumes
│   ├── configs/            # Configurações
│   └── metadata.json      # Metadados completos
├── pre-update/           # Backups antes de atualizações
├── pre-migration/       # Backups antes de migrações
└── emergency/          # Backups de emergência
```

## 🎯 Quando Executar Backup Manual

### Situações Recomendadas

1. **Antes de Atualizações Críticas**
   ```bash
   ./scripts/backup/backup-intelligent.sh --manual --tag "pre-update-v2.0"
   ```

2. **Antes de Migrações de Dados**
   ```bash
   ./scripts/backup/backup-intelligent.sh --manual --tag "pre-migration-postgresql17"
   ```

3. **Mudanças em Produção**
   ```bash
   ./scripts/backup/backup-intelligent.sh --manual --tag "prod-change-traefik"
   ```

4. **Requisição de Compliance**
   ```bash
   ./scripts/backup/backup-intelligent.sh --manual --tag "compliance-audit-2025Q1"
   ```

## 📝 Registro de Backups Manuais

### Últimos Backups Executados

| Data | Operador | Motivo | Tamanho | Status |
|------|----------|--------|---------|--------|
| 2025-01-24 15:30 | marco | Pre-update Traefik v3.0 | 2.1GB | ✅ Success |
| 2025-01-23 10:15 | admin | Database migration | 3.4GB | ✅ Success |
| 2025-01-22 18:45 | marco | Emergency - Service failure | 1.9GB | ✅ Success |
| 2025-01-20 09:00 | devops | Compliance audit Q1 | 2.8GB | ✅ Success |

## 🚀 Comandos de Backup Manual

### Backup Completo
```bash
# Backup completo com todas as opções
./scripts/backup/backup-intelligent.sh \
  --manual \
  --full \
  --compress-max \
  --verify \
  --tag "complete-backup-$(date +%Y%m%d)"
```

### Backup Seletivo
```bash
# Apenas databases
./scripts/backup/backup-intelligent.sh --manual --databases-only

# Apenas volumes Docker
./scripts/backup/backup-intelligent.sh --manual --volumes-only

# Apenas configurações
./scripts/backup/backup-intelligent.sh --manual --configs-only

# Componente específico
./scripts/backup/backup-intelligent.sh --manual --component n8n
```

### Backup com Metadados
```bash
# Com descrição detalhada
./scripts/backup/backup-intelligent.sh \
  --manual \
  --description "Backup antes da atualização do PostgreSQL 16 para 17" \
  --operator "$(whoami)" \
  --ticket "JIRA-1234"
```

## 📊 Templates de Backup

### Pre-Update Template
```bash
#!/bin/bash
# Template para backup antes de atualizações

COMPONENT=$1
VERSION=$2

./scripts/backup/backup-intelligent.sh \
  --manual \
  --tag "pre-update-${COMPONENT}-${VERSION}" \
  --description "Backup before updating ${COMPONENT} to ${VERSION}" \
  --operator "$(whoami)" \
  --compress-max \
  --verify
```

### Emergency Template
```bash
#!/bin/bash
# Template para backup de emergência

INCIDENT_ID=$1
SEVERITY=$2

./scripts/backup/backup-intelligent.sh \
  --manual \
  --tag "emergency-${INCIDENT_ID}" \
  --description "Emergency backup for incident ${INCIDENT_ID} (Severity: ${SEVERITY})" \
  --operator "$(whoami)" \
  --priority critical \
  --no-throttle
```

## 🔍 Validação de Backups Manuais

### Verificação Imediata
```bash
# Verificar integridade após backup
kopia snapshot verify --snapshot-id=$(cat latest-snapshot-id.txt)

# Testar restauração parcial
./scripts/backup/test-restore.sh --source manual/manual-2025-01-24-1530 --component postgresql
```

### Checklist Pós-Backup
- [ ] Backup completado sem erros
- [ ] Tamanho do backup dentro do esperado
- [ ] Metadados registrados corretamente
- [ ] Verificação de integridade passou
- [ ] Notificação enviada para equipe
- [ ] Documentação atualizada no wiki

## 📈 Estatísticas de Uso

### Métricas Mensais
```
Total de Backups Manuais: 23
Taxa de Sucesso: 100%
Tamanho Total: 48GB
Tempo Médio: 18 minutos

Por Categoria:
- Pre-update: 8 (35%)
- Pre-migration: 5 (22%)
- Emergency: 3 (13%)
- Compliance: 7 (30%)
```

## 🗂️ Política de Retenção

### Backups Manuais
- **Padrão**: Retenção indefinida
- **Pre-update**: Manter por 90 dias após update bem-sucedido
- **Pre-migration**: Manter por 180 dias
- **Emergency**: Manter por 1 ano
- **Compliance**: Manter por 7 anos

### Processo de Arquivamento
```bash
# Arquivar backups antigos
./scripts/backup/archive-old-manual-backups.sh

# Mover para storage de longo prazo
./scripts/backup/move-to-cold-storage.sh --older-than 90d
```

## 🔄 Restauração de Backup Manual

### Comando de Restauração
```bash
# Listar backups manuais disponíveis
ls -la backups/manual/

# Restaurar backup específico
./scripts/backup/restore-backup.sh manual/manual-2025-01-24-1530/

# Restaurar com opções
./scripts/backup/restore-backup.sh \
  --source manual/manual-2025-01-24-1530/ \
  --target /recovery/ \
  --component postgresql \
  --dry-run
```

## 📝 Documentação de Incidentes

### Formato de Documentação
```markdown
## Incident Report - [ID]

**Date**: YYYY-MM-DD HH:MM
**Operator**: [name]
**Severity**: [P1/P2/P3/P4]

### Reason for Manual Backup
[Detailed explanation]

### Components Affected
- [ ] PostgreSQL
- [ ] Redis
- [ ] Docker Volumes
- [ ] Configurations

### Actions Taken
1. Step 1
2. Step 2
3. Step 3

### Verification
- Backup Size: XGB
- Duration: X minutes
- Integrity Check: PASSED/FAILED

### Follow-up Required
- [ ] Task 1
- [ ] Task 2
```

## 🚨 Procedimentos de Emergência

### Quick Emergency Backup
```bash
# Backup rápido de emergência (sem verificação)
./scripts/backup/emergency-backup.sh --fast

# Backup crítico com prioridade máxima
./scripts/backup/backup-intelligent.sh \
  --manual \
  --priority critical \
  --no-throttle \
  --parallel 5
```

## 📞 Autorização e Aprovações

### Níveis de Autorização
| Tipo de Backup | Autorização Necessária | Aprovador |
|----------------|------------------------|-----------|
| Rotina | Nenhuma | - |
| Pre-update | Team Lead | Marco |
| Pre-migration | Tech Lead | DevOps |
| Emergency | Qualquer Admin | - |
| Compliance | CTO | Technical |

---

*Sistema de backup manual enterprise - Execute com responsabilidade*