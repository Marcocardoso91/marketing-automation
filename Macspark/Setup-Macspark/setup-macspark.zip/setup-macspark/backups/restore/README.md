# 🔄 Procedimentos de Restore

Este diretório contém scripts, logs e documentação para operações de restauração.

## 📁 Estrutura de Diretórios

```
restore/
├── scripts/                     # Scripts de restauração
│   ├── restore-complete.sh     # Restauração completa
│   ├── restore-selective.sh    # Restauração seletiva
│   ├── restore-point-in-time.sh # Point-in-time recovery
│   └── validate-restore.sh     # Validação pós-restore
├── logs/                       # Logs de restaurações
│   ├── restore-YYYY-MM-DD.log # Log por data
│   └── validation/            # Logs de validação
├── templates/                # Templates de restore
└── recovery-tests/         # Testes de recovery
```

## 🎯 Tipos de Restauração

### 1. Restauração Completa
Restaura todo o ambiente para um ponto específico no tempo.

```bash
# Restaurar último backup completo
./scripts/restore-complete.sh --latest

# Restaurar de data específica
./scripts/restore-complete.sh --date 2025-01-24

# Restaurar com verificação
./scripts/restore-complete.sh --latest --verify --dry-run
```

### 2. Restauração Seletiva
Restaura apenas componentes específicos.

```bash
# Restaurar apenas PostgreSQL
./scripts/restore-selective.sh --component postgresql

# Restaurar apenas N8N workflows
./scripts/restore-selective.sh --component n8n-workflows

# Restaurar múltiplos componentes
./scripts/restore-selective.sh --components "postgresql,redis,n8n"
```

### 3. Point-in-Time Recovery (PITR)
Restaura para um momento exato no tempo.

```bash
# PITR para PostgreSQL
./scripts/restore-point-in-time.sh \
  --component postgresql \
  --timestamp "2025-01-24 14:30:00"

# PITR com WAL replay
./scripts/restore-point-in-time.sh \
  --component postgresql \
  --timestamp "2025-01-24 14:30:00" \
  --wal-replay
```

## 📊 Cenários de Restauração

### Cenário 1: Corrupção de Dados
```bash
#!/bin/bash
# Restauração após corrupção de dados detectada

# 1. Parar serviços afetados
docker service scale n8n=0 postgresql=0

# 2. Backup do estado corrompido (para análise)
./scripts/backup/backup-intelligent.sh --manual --tag "corrupted-state"

# 3. Restaurar último backup válido
./scripts/restore-selective.sh \
  --component postgresql \
  --snapshot-id "last-known-good"

# 4. Validar integridade
./scripts/validate-restore.sh --component postgresql

# 5. Reiniciar serviços
docker service scale postgresql=1 n8n=3
```

### Cenário 2: Rollback de Update
```bash
#!/bin/bash
# Rollback após update problemático

# 1. Identificar backup pre-update
BACKUP_ID=$(ls -1 backups/manual/ | grep "pre-update" | tail -1)

# 2. Executar rollback
./scripts/restore-complete.sh \
  --source "backups/manual/$BACKUP_ID" \
  --rollback-mode

# 3. Verificar serviços
./scripts/health-check-enterprise.sh --all

# 4. Notificar equipe
./scripts/notification-system.sh --event "rollback-completed"
```

### Cenário 3: Disaster Recovery
```bash
#!/bin/bash
# Recovery completo após desastre

# 1. Preparar novo ambiente
./scripts/prepare-dr-environment.sh

# 2. Restaurar infraestrutura base
./scripts/restore-complete.sh \
  --source "s3://macspark-dr/latest" \
  --target "/opt/macspark-recovery"

# 3. Reconfigurar networking
./scripts/reconfigure-networking.sh --dr-mode

# 4. Validar todos os componentes
./scripts/validate-restore.sh --full --generate-report

# 5. Switch DNS para novo ambiente
./scripts/update-dns-cloudflare.sh --dr-failover
```

## 🔍 Validação de Restore

### Checklist de Validação
```yaml
validation_checklist:
  infrastructure:
    - [ ] Docker Swarm cluster operacional
    - [ ] Traefik proxy respondendo
    - [ ] Redes overlay funcionando
    - [ ] Volumes montados corretamente
  
  databases:
    - [ ] PostgreSQL acessível
    - [ ] Replicação funcionando
    - [ ] Redis respondendo
    - [ ] Dados íntegros
  
  applications:
    - [ ] N8N workflows carregados
    - [ ] Chatwoot operacional
    - [ ] BookStack acessível
    - [ ] Todos os serviços healthy
  
  security:
    - [ ] Certificados SSL válidos
    - [ ] Secrets restaurados
    - [ ] Vault operacional
    - [ ] Autenticação funcionando
```

### Script de Validação Automatizada
```bash
#!/bin/bash
# validate-restore.sh

echo "🔍 Iniciando validação de restore..."

# Verificar serviços Docker
docker service ls --format "table {{.Name}}\t{{.Replicas}}" | grep -v "0/"

# Testar conectividade PostgreSQL
docker exec postgres-master pg_isready

# Verificar integridade de dados
docker exec postgres-master psql -c "SELECT COUNT(*) FROM n8n.workflow_entity;"

# Testar endpoints
curl -f https://n8n.macspark.dev/healthz
curl -f https://chatwoot.macspark.dev/api/v1/health

# Gerar relatório
./scripts/generate-validation-report.sh > validation-$(date +%Y%m%d-%H%M).html
```

## 📈 Métricas de Recovery

### SLA de Restauração
| Tipo | Target (RTO) | Média Atual | Best | Worst |
|------|--------------|-------------|------|-------|
| Service Recovery | 15 min | 12 min | 8 min | 18 min |
| Database Recovery | 30 min | 25 min | 15 min | 45 min |
| Complete Recovery | 60 min | 48 min | 35 min | 72 min |
| DR Failover | 2 hours | 1.5 hours | 1 hour | 2.5 hours |

### Histórico de Restaurações
```
2025-01 (5 restaurações):
- 3x Service Recovery (100% sucesso)
- 1x Database Recovery (100% sucesso)  
- 1x Test Drill (100% sucesso)

2024-12 (3 restaurações):
- 2x Service Recovery (100% sucesso)
- 1x Complete Recovery (100% sucesso)
```

## 🛠️ Scripts de Restore

### restore-complete.sh
```bash
#!/bin/bash
# Restauração completa do ambiente

set -euo pipefail

SOURCE=${1:-latest}
TARGET=${2:-/opt/macspark}
VERIFY=${3:-true}

echo "🔄 Iniciando restauração completa..."
echo "Source: $SOURCE"
echo "Target: $TARGET"

# Parar todos os serviços
docker stack rm $(docker stack ls --format "{{.Name}}")

# Restaurar com Kopia
kopia restore $SOURCE $TARGET

# Recriar stacks
for stack in traefik monitoring apps databases; do
  docker stack deploy -c stacks/$stack.yml $stack
done

# Verificar restore
if [ "$VERIFY" = "true" ]; then
  ./scripts/validate-restore.sh --full
fi

echo "✅ Restauração completa finalizada"
```

### restore-selective.sh
```bash
#!/bin/bash
# Restauração seletiva de componentes

COMPONENT=$1
SNAPSHOT=$2

case $COMPONENT in
  postgresql)
    docker service scale postgresql=0
    kopia restore $SNAPSHOT/databases/postgresql /var/lib/postgresql
    docker service scale postgresql=1
    ;;
  n8n)
    docker service scale n8n=0
    kopia restore $SNAPSHOT/n8n-workflows /opt/n8n
    docker service scale n8n=3
    ;;
  *)
    echo "Componente desconhecido: $COMPONENT"
    exit 1
    ;;
esac
```

## 📝 Templates de Restore

### Template para Database Recovery
```yaml
# database-recovery.yml
recovery:
  type: database
  component: postgresql
  steps:
    - stop_service: postgresql
    - backup_current: /backup/pre-recovery
    - restore_data: 
        from: ${SNAPSHOT_ID}
        to: /var/lib/postgresql
    - verify_permissions: postgres:postgres
    - start_service: postgresql
    - run_validation:
        - check_connectivity
        - verify_data_integrity
        - test_replication
    - notify_team: recovery_complete
```

## 🚨 Procedimentos de Emergência

### Recovery Rápido (< 5 minutos)
```bash
# Para falhas de serviço simples
docker service update --force $FAILED_SERVICE

# Para problemas de rede
docker network rm $(docker network ls -q -f driver=overlay)
docker stack deploy -c stacks/networking.yml networking
```

### Recovery Médio (< 30 minutos)
```bash
# Para corrupção de dados localizada
./scripts/restore-selective.sh --component affected_component --fast
```

### Recovery Completo (< 60 minutos)
```bash
# Para falha catastrófica
./scripts/disaster-recovery.sh --emergency --no-confirmation
```

## 📊 Relatórios de Recovery

### Geração de Relatórios
```bash
# Relatório de última restauração
./scripts/generate-recovery-report.sh --latest

# Relatório mensal
./scripts/generate-recovery-report.sh --month 2025-01

# Relatório de compliance
./scripts/generate-recovery-report.sh --compliance --format pdf
```

### Formato do Relatório
```markdown
# Recovery Report - [DATE]

## Summary
- Recovery Type: [Complete/Selective/PITR]
- Start Time: [timestamp]
- End Time: [timestamp]
- Duration: [minutes]
- Status: [Success/Partial/Failed]

## Components Restored
- PostgreSQL: ✅
- Redis: ✅
- Docker Volumes: ✅
- Configurations: ✅

## Validation Results
- Data Integrity: PASSED
- Service Health: PASSED
- Performance: NORMAL

## Issues Encountered
- None

## Recommendations
- Continue monitoring for 24h
- Schedule follow-up validation
```

## 🔐 Segurança durante Restore

### Checklist de Segurança
- [ ] Verificar origem do backup
- [ ] Validar assinaturas digitais
- [ ] Descriptografar com chaves corretas
- [ ] Verificar permissões de arquivos
- [ ] Atualizar secrets se necessário
- [ ] Rotacionar credenciais após restore
- [ ] Auditar acessos durante recovery

## 📞 Contatos para Recovery

| Função | Nome | Telefone | Responsabilidade |
|--------|------|----------|------------------|
| Recovery Lead | DevOps Team | +55 11 9999-1111 | Coordenação geral |
| Database Admin | DBA Team | +55 11 9999-2222 | PostgreSQL/Redis |
| Network Admin | Network Team | +55 11 9999-3333 | Networking/DNS |
| Security | Security Team | +55 11 9999-4444 | Validação segurança |

---

*Procedimentos de restore enterprise - Recuperação rápida e confiável*