# 📝 Logs de Restauração

Este diretório contém os logs de todas as operações de restauração executadas.

## Estrutura de Logs

```
logs/
├── restore-YYYY-MM-DD-HHMMSS.log   # Log detalhado de cada restauração
├── validation/                      # Logs de validação pós-restore
│   └── validation-YYYY-MM-DD.log
├── errors/                         # Logs de erros separados
│   └── error-YYYY-MM-DD.log
└── summary/                       # Resumos mensais
    └── summary-YYYY-MM.log
```

## Exemplo de Log

```
[2025-01-25 14:30:00] 🔄 Iniciando restauração completa do ambiente Macspark
[2025-01-25 14:30:01] Source: latest
[2025-01-25 14:30:01] Verify: true
[2025-01-25 14:30:02] ⏹️ Parando todos os serviços Docker...
[2025-01-25 14:30:15] 📦 Restaurando dados com Kopia...
[2025-01-25 14:35:00]   Restaurando databases...
[2025-01-25 14:40:00]   Restaurando volumes Docker...
[2025-01-25 14:45:00] 🚀 Recriando stacks Docker...
[2025-01-25 14:50:00] ✅ Validando restauração...
[2025-01-25 14:55:00] ✅ Restauração finalizada com sucesso!
```