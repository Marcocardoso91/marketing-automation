#!/bin/bash
# ============================================================================
# MACSPARK RESTORE TEST SCRIPT
# ============================================================================
# Script para testar procedimentos de restore periodicamente
# Versão: 2025.1.0
# ============================================================================

set -euo pipefail

# Carregar configurações
source ../../backup.config

# Configurações do teste
TEST_ENV="${1:-staging}"
TEST_TYPE="${2:-basic}"  # basic | full | stress
TEST_DATE=$(date +"%Y%m%d-%H%M%S")
TEST_LOG="${BACKUP_LOGS_DIR}/test-restore-${TEST_DATE}.log"

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Função de log
log() {
    echo -e "$1" | tee -a "$TEST_LOG"
}

# Banner inicial
log "${BLUE}=============================================${NC}"
log "${BLUE}     MACSPARK RESTORE TEST SUITE${NC}"
log "${BLUE}=============================================${NC}"
log "📅 Data: $(date)"
log "🔧 Ambiente: $TEST_ENV"
log "📝 Tipo: $TEST_TYPE"
log ""

# Verificações iniciais
log "${YELLOW}🔍 Verificações iniciais...${NC}"

# 1. Verificar se é ambiente de teste
if [[ "$TEST_ENV" == "production" ]]; then
    log "${RED}❌ ERRO: Não execute testes em produção!${NC}"
    exit 1
fi

# 2. Verificar espaço em disco
if ! check_disk_space "$BACKUP_ROOT" 20; then
    log "${RED}❌ Espaço em disco insuficiente${NC}"
    exit 1
fi

# 3. Verificar backups disponíveis
log "📦 Verificando backups disponíveis..."
if [[ "$PRIMARY_ENGINE" == "kopia" ]]; then
    SNAPSHOTS=$(kopia snapshot list --json 2>/dev/null | jq -r '.[] | .id' | head -5)
else
    SNAPSHOTS=$(restic snapshots --json 2>/dev/null | jq -r '.[] | .short_id' | head -5)
fi

if [[ -z "$SNAPSHOTS" ]]; then
    log "${RED}❌ Nenhum backup encontrado${NC}"
    exit 1
fi

log "✅ Backups disponíveis encontrados"
log ""

# Executar testes baseado no tipo
case "$TEST_TYPE" in
    basic)
        log "${BLUE}📋 Executando teste básico...${NC}"
        
        # Teste 1: Restore de arquivo único
        log "1️⃣ Testando restore de arquivo único..."
        TEST_FILE="/tmp/test-restore-file-${TEST_DATE}"
        if $PRIMARY_ENGINE restore latest "$TEST_FILE" 2>/dev/null; then
            log "  ✅ Restore de arquivo: OK"
            rm -f "$TEST_FILE"
        else
            log "  ❌ Restore de arquivo: FALHOU"
        fi
        
        # Teste 2: Listagem de snapshots
        log "2️⃣ Testando listagem de snapshots..."
        if $PRIMARY_ENGINE snapshot list >/dev/null 2>&1; then
            log "  ✅ Listagem de snapshots: OK"
        else
            log "  ❌ Listagem de snapshots: FALHOU"
        fi
        
        # Teste 3: Verificação de integridade
        log "3️⃣ Testando verificação de integridade..."
        if $PRIMARY_ENGINE verify >/dev/null 2>&1; then
            log "  ✅ Verificação de integridade: OK"
        else
            log "  ❌ Verificação de integridade: FALHOU"
        fi
        ;;
        
    full)
        log "${BLUE}📋 Executando teste completo...${NC}"
        
        # Criar ambiente de teste isolado
        TEST_DIR="/tmp/macspark-restore-test-${TEST_DATE}"
        mkdir -p "$TEST_DIR"
        
        log "1️⃣ Criando ambiente de teste em $TEST_DIR..."
        
        # Teste 1: Restore completo
        log "2️⃣ Executando restore completo..."
        ../scripts/restore-complete.sh latest "$TEST_DIR" --dry-run
        
        # Teste 2: Validação de dados
        log "3️⃣ Validando dados restaurados..."
        ../scripts/validate-restore.sh "$TEST_DIR"
        
        # Teste 3: Restore seletivo
        log "4️⃣ Testando restore seletivo..."
        ../scripts/restore-selective.sh --component postgresql --target "$TEST_DIR"
        
        # Cleanup
        log "5️⃣ Limpando ambiente de teste..."
        rm -rf "$TEST_DIR"
        ;;
        
    stress)
        log "${BLUE}📋 Executando teste de stress...${NC}"
        
        # Teste de restore paralelo
        log "1️⃣ Testando restore paralelo (3 jobs)..."
        for i in {1..3}; do
            (
                TEST_FILE="/tmp/stress-test-${TEST_DATE}-${i}"
                $PRIMARY_ENGINE restore latest "$TEST_FILE" 2>/dev/null
                rm -f "$TEST_FILE"
            ) &
        done
        wait
        log "  ✅ Restore paralelo: OK"
        
        # Teste de restore grande
        log "2️⃣ Testando restore de volume grande..."
        # Implementar teste de volume grande
        
        # Teste de failover
        log "3️⃣ Testando failover para engine secundário..."
        if $FALLBACK_ENGINE snapshot list >/dev/null 2>&1; then
            log "  ✅ Failover: OK"
        else
            log "  ⚠️ Failover: Engine secundário não disponível"
        fi
        ;;
        
    *)
        log "${RED}❌ Tipo de teste inválido: $TEST_TYPE${NC}"
        exit 1
        ;;
esac

# Relatório final
log ""
log "${BLUE}=============================================${NC}"
log "${BLUE}     RELATÓRIO FINAL${NC}"
log "${BLUE}=============================================${NC}"

# Calcular métricas
END_TIME=$(date +%s)
START_TIME=$(date +%s -d "$(head -1 $TEST_LOG | cut -d' ' -f2-3)")
DURATION=$((END_TIME - START_TIME))

log "⏱️ Duração total: ${DURATION} segundos"
log "📊 Testes executados: $(grep -c "✅\|❌" $TEST_LOG || true)"
log "✅ Sucessos: $(grep -c "✅" $TEST_LOG || true)"
log "❌ Falhas: $(grep -c "❌" $TEST_LOG || true)"
log "⚠️ Avisos: $(grep -c "⚠️" $TEST_LOG || true)"

# Determinar resultado
FAILURES=$(grep -c "❌" $TEST_LOG || true)
if [[ $FAILURES -eq 0 ]]; then
    log ""
    log "${GREEN}🎉 TODOS OS TESTES PASSARAM!${NC}"
    send_notification "success" "Teste de restore concluído" "Todos os testes passaram em ${DURATION}s"
    exit 0
else
    log ""
    log "${RED}😞 ALGUNS TESTES FALHARAM${NC}"
    send_notification "error" "Teste de restore falhou" "${FAILURES} testes falharam. Verifique $TEST_LOG"
    exit 1
fi