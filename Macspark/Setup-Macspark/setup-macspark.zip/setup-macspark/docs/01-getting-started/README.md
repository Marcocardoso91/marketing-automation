# 🚀 Getting Started

Bem-vindo ao Setup MacSpark! Este guia ajudará você a começar rapidamente com nossa infraestrutura enterprise.

## 📋 Pré-requisitos

- VPS com Ubuntu 22.04 LTS ou superior
- Mínimo 8GB RAM, 4 vCPUs
- Docker 24.0+ instalado
- Docker Swarm inicializado

## 🎯 Quick Start

1. **[Instalação](installation.md)** - Guia completo de instalação
2. **[Configuração Inicial](initial-setup.md)** - Primeiros passos após instalação
3. **[Deploy Básico](basic-deploy.md)** - Seu primeiro deploy

## 📚 Próximos Passos

Após a instalação inicial, explore:
- [Arquitetura do Sistema](../02-architecture/README.md)
- [Guia de Deploy](../03-deployment/README.md)
- [Operações](../04-operations/README.md)

## 💡 Dicas

- Sempre execute backups antes de mudanças críticas
- Use ambiente de homologação para testes
- Monitore logs durante deploys

## 🆘 Suporte

Em caso de problemas, consulte:
- [Troubleshooting](../04-operations/troubleshooting.md)
- [FAQ](../07-guides/faq.md)