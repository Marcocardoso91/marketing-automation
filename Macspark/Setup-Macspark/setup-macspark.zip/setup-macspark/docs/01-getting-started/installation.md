# 🚀 GUIA DE INSTALAÇÃO - MACSPARK 2025/2026

## ⚡ INSTALAÇÃO INTELIGENTE (RECOMENDADA)

### ✅ Pré-requisitos
Antes de iniciar a instalação, verifique:
```bash
# 1. Docker instalado e funcionando
docker --version
docker ps

# 2. Docker Swarm inicializado
docker swarm init

# 3. Permissões adequadas
sudo whoami
```

### Método 1: Instalação com IA
```bash
# 1. Clonar repositório
git clone https://github.com/Marcocardoso28/Macspark-Setup.git
cd Macspark-Setup

# 2. Criar redes Docker necessárias
sudo bash scripts/create-networks.sh

# 3. Criar volumes Docker necessários
sudo bash scripts/create-volumes.sh

# 4. Executar instalador inteligente
sudo bash install-2025.sh
```

**🤖 O instalador com IA irá:**
- Analisar automaticamente seu sistema
- Detectar recursos disponíveis (CPU, RAM, disco)
- Recomendar o melhor perfil para sua situação
- Configurar SSL automático
- Instalar stack completa em 15-30 minutos

### Método 2: Interface Web
```bash
# Iniciar interface web
sudo bash install-2025.sh --web

# Abrir no navegador
# http://localhost:8000
```

## 🎯 TEMPLATES DISPONÍVEIS

### 🆕 Startup (16GB+ RAM)
```bash
sudo bash install-2025.sh --template=startup
```
**Inclui:** AI Local, VS Code Cloud, Chat Team, Automação

### 🛒 E-commerce (32GB+ RAM)
```bash
sudo bash install-2025.sh --template=ecommerce
```
**Inclui:** WooCommerce, Analytics, CDN, Pagamentos

### 🎨 Agência (32GB+ RAM)
```bash
sudo bash install-2025.sh --template=agencia
```
**Inclui:** Penpot, Projetos, Portal Cliente

### 💻 Development (64GB+ RAM)
```bash
sudo bash install-2025.sh --template=desenvolvimento
```
**Inclui:** GitLab, Jenkins, K8s, Code Quality

## ✅ RESULTADO

Após 15-30 minutos, você terá **27+ stacks profissionais** disponíveis:

| Categoria | Principais Serviços |
|-----------|-------------------|
| **🤖 AI & ML** | Ollama, Jupyter, MLflow |
| **💼 Produtividade** | N8N, BookStack, NextCloud |
| **💬 Comunicação** | RocketChat, Jitsi, Mattermost |
| **🎨 Design** | Penpot, Excalidraw, Code-Server |
| **🔧 DevOps** | GitLab, Jenkins, Harbor |
| **📊 Monitor** | Prometheus, Grafana, Jaeger |

## 🔐 CREDENCIAIS

As senhas são geradas automaticamente e salvas em:
```
/opt/macspark/config/macspark.conf
```

## 📁 ESTRUTURA CRIADA

```
/opt/macspark/
├── data/           # Dados dos serviços
├── logs/           # Logs do sistema  
├── config/         # Configurações
├── secrets/        # Senhas seguras
└── backups/        # Backups
```

## 🔧 REQUISITOS 2025/2026

### Hardware por Perfil
- **Minimal**: 8GB RAM, 2 cores, 50GB disco
- **Development**: 16GB RAM, 8 cores, 100GB disco
- **Production**: 32GB RAM, 16 cores, 200GB disco
- **Enterprise**: 64GB RAM, 16 cores, 500GB disco

### Sistemas Operacionais
- **Ubuntu**: 22.04 LTS+ (Recomendado)
- **Debian**: 11+
- **CentOS/RHEL**: 8+
- **Fedora**: 35+
- **Arch Linux**: Suportado

### Rede
- **Portas**: 80, 443 (HTTP/HTTPS)
- **Opcional**: 8080 (Portainer), 9090 (Prometheus)
- **Domínio**: Recomendado para SSL automático

## 🌐 CONFIGURAÇÃO DNS

Aponte seus subdomínios para o IP do servidor:
```
traefik.exemplo.com    A    SEU_IP_SERVIDOR
portainer.exemplo.com  A    SEU_IP_SERVIDOR  
monitor.exemplo.com    A    SEU_IP_SERVIDOR
```

## 🚨 TROUBLESHOOTING 2025/2026

### 🤖 Diagnóstico Automático
```bash
# Verificação completa com IA
sudo bash scripts/health-monitor-ai.sh single

# Correção automática de problemas
sudo bash scripts/fix-common-issues.sh
```

### Problemas Comuns

#### Docker não instalado/funcionando
```bash
# Instalação automática
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
sudo systemctl enable docker
sudo systemctl start docker
```

#### Erro: "Docker Swarm não inicializado"
```bash
docker swarm init
sudo bash scripts/create-networks.sh
```

#### Portas em uso
```bash
# Verificar portas ocupadas
sudo netstat -tulpn | grep :80
sudo netstat -tulpn | grep :443

# Parar serviços conflitantes
sudo systemctl stop apache2 nginx
```

#### SSL não funciona
```bash
# Verificar DNS
nslookup seudominio.com

# Verificar logs Traefik
docker logs traefik -f

# Limpar certificados
docker exec traefik rm -rf /etc/traefik/acme/acme.json
docker restart traefik
```

#### Performance baixa
```bash
# Verificar recursos
sudo bash scripts/health-monitor-ai.sh single

# Limpeza automática
docker system prune -a
```

## 📞 SUPORTE 2025/2026

### 🆘 Suporte Gratuito
- **📚 Documentação**: [docs/](./docs/) - Guias completos
- **🐛 Issues**: [GitHub Issues](https://github.com/Marcocardoso28/Macspark-Setup/issues)
- **💬 Discord**: [discord.gg/macspark](https://discord.gg/macspark)
- **📧 Email**: suporte@macspark.dev

### 🏆 Suporte Enterprise
- **⚡ Setup personalizado** com consultoria
- **🔧 Customização** de templates
- **📞 Suporte 24/7** com SLA
- **🎯 Training** para equipes

**Contato**: enterprise@macspark.dev

---

## 🎉 PRÓXIMOS PASSOS

1. **🔧 Configurar domínio** para SSL automático
2. **📊 Acessar dashboards** de monitoramento
3. **🛡️ Revisar configurações** de segurança
4. **💾 Configurar backup** automático
5. **📚 Explorar documentação** completa

---

**🚀 Infraestrutura de nova geração em 15-30 minutos!** 