# 🚀 MACSPARK SETUP - GUIA DE INSTALAÇÃO

## 🎯 ESCOLHA SEU CENÁRIO DE INSTALAÇÃO

### ⭐ CENÁRIO 1: VPS LIMPA / PRIMEIRA INSTALAÇÃO (RECOMENDADO)

**👤 Para quem**: Primeira instalação com VPS completamente limpa  
**⏱️ Tempo**: 15-30 minutos  
**🎯 Resultado**: Stack enterprise completa funcionando

#### 📋 Pré-requisitos
- ✅ **VPS Linux** (Ubuntu 22.04 LTS+, Debian 11+, CentOS 8+)
- ✅ **Acesso root/sudo** no servidor
- ✅ **8GB+ RAM** (16GB+ recomendado)
- ✅ **Portas 80 e 443** liberadas no firewall
- ✅ **Domínio** (opcional, mas recomendado para SSL)

#### 🚀 Instalação Automática (3 Passos)

```bash
# 🔄 PASSO 1: PREPARAR VPS
curl -fsSL https://get.docker.com | sh && \
sudo usermod -aG docker $USER && \
sudo apt update && sudo apt install -y git && \
sudo reboot

# 🚀 PASSO 2: INSTALAR MACSPARK (após reboot)
cd /opt && \
sudo git clone https://github.com/Marcocardoso28/Macspark-Setup.git && \
cd Macspark-Setup && \
sudo chmod +x scripts/*.sh scripts/*/*.sh && \
sudo bash install-2025.sh

# ✅ PASSO 3: VERIFICAR INSTALAÇÃO
bash scripts/health-monitor-ai.sh single
```

#### 🎉 O que será instalado:
- ✅ **Docker Swarm** - Orquestração enterprise
- ✅ **Traefik** - Proxy reverso + SSL automático
- ✅ **PostgreSQL HA** - Banco de dados com alta disponibilidade
- ✅ **Redis Sentinel** - Cache distribuído
- ✅ **Monitoramento** - Prometheus + Grafana + Jaeger
- ✅ **27+ Stacks** - AI, produtividade, DevOps, comunicação

---

### 🔄 CENÁRIO 2: ATUALIZAR INSTALAÇÃO EXISTENTE

**👤 Para quem**: Já tem Macspark e quer atualizar  
**⏱️ Tempo**: 5-10 minutos  
**🎯 Resultado**: Sistema atualizado, configurações preservadas

```bash
# Atualizar repositório
cd /opt/Macspark-Setup
git pull origin main
chmod +x scripts/*.sh scripts/*/*.sh

# Sistema detecta automaticamente o que já existe
sudo bash install-2025.sh --update
```

---

### 🛠️ CENÁRIO 3: INSTALAÇÃO PERSONALIZADA

#### 🤖 Com IA Automática
```bash
# IA detecta perfil e configura automaticamente
sudo bash install-2025.sh --ai
```

#### 🎯 Templates Disponíveis
```bash
# Startup (16GB+ RAM) - AI Local + Chat + Automação
sudo bash install-2025.sh --template=startup

# E-commerce (32GB+ RAM) - WooCommerce + Analytics
sudo bash install-2025.sh --template=ecommerce

# Desenvolvimento (64GB+ RAM) - GitLab + Jenkins + K8s
sudo bash install-2025.sh --template=desenvolvimento
```

#### 📋 Menu Interativo
```bash
# Interface com todas as opções
sudo bash install-2025.sh --interactive
```

---

## 🌐 URLs DE ACESSO

Após instalação, acesse seus serviços:

```bash
# Com domínio próprio:
https://traefik.seudominio.com     # Dashboard Traefik
https://portainer.seudominio.com   # Gerenciamento Docker
https://grafana.seudominio.com     # Monitoramento
https://n8n.seudominio.com         # Automação

# Sem domínio (usando nip.io):
http://traefik.SEU_IP_VPS.nip.io
http://portainer.SEU_IP_VPS.nip.io
http://grafana.SEU_IP_VPS.nip.io
```

## 🔐 CREDENCIAIS E CONFIGURAÇÃO

As senhas são geradas automaticamente e salvas em:
```
/opt/macspark/config/macspark.conf
```

## 🚨 SOLUÇÃO DE PROBLEMAS

### Diagnóstico Automático
```bash
# Verificação completa com IA
sudo bash scripts/health-monitor-ai.sh single

# Correção automática
sudo bash scripts/fix-common-issues.sh
```

### Problemas Comuns

#### Docker não funcionando
```bash
sudo systemctl start docker
sudo systemctl enable docker
docker swarm init
```

#### Portas em uso
```bash
sudo netstat -tulpn | grep :80
sudo systemctl stop apache2 nginx
```

#### SSL não funciona
```bash
# Verificar DNS
nslookup seudominio.com

# Verificar logs Traefik
docker service logs traefik
```

## 📞 SUPORTE

- 📚 **Documentação**: [docs/README.md](../README.md)
- 🐛 **Issues**: GitHub Issues
- 💬 **Discord**: discord.gg/macspark
- 📧 **Email**: suporte@macspark.dev

---

**🚀 Infraestrutura enterprise em 15-30 minutos!** 