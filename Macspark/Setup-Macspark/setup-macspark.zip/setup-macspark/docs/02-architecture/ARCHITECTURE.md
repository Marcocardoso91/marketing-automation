# Arquitetura do Macspark Setup

## Visão Geral

O Macspark Setup é uma plataforma completa de infraestrutura baseada em containers Docker, projetada para fornecer serviços de IA, automação, monitoramento e desenvolvimento em um ambiente seguro e escalável.

## Arquitetura Geral

```mermaid
graph TB
    subgraph "Internet"
        U[Usuários]
        API[APIs Externas]
    end

    subgraph "Load Balancer & Proxy"
        T[Traefik]
    end

    subgraph "Core Services"
        S[SparkOne API]
        E[Evolution API]
        EM[Evolution Manager]
    end

    subgraph "AI & Chat Services"
        O[Ollama]
        C[Claude Interface]
        RC[RocketChat]
        CW[Chatwoot]
    end

    subgraph "Automation & Workflow"
        N[N8N]
        DR[Drone CI/CD]
    end

    subgraph "Storage & Database"
        PG[(PostgreSQL)]
        R[(Redis)]
        NC[NextCloud]
        VW[Vaultwarden]
    end

    subgraph "Monitoring & Logging"
        P[Prometheus]
        G[Grafana]
        L[Loki]
        J[Jaeger]
        ND[NetData]
    end

    subgraph "Development Tools"
        CS[Code Server]
        CC[Cursor Server]
        H[Harbor Registry]
        PT[Portainer]
    end

    subgraph "Productivity"
        BS[BookStack]
        OO[OnlyOffice]
        WK[Wekan]
        EX[Excalidraw]
        PP[Penpot]
    end

    U --> T
    API --> T
    T --> S
    T --> E
    T --> RC
    T --> CW
    T --> N
    T --> NC
    T --> PT

    S --> PG
    S --> R
    E --> PG
    EM --> E
    
    N --> PG
    RC --> PG
    CW --> PG

    S --> O
    S --> C

    P --> G
    P --> S
    P --> E
    L --> G
    J --> S

    DR --> H
    DR --> S
```

## Componentes Principais

### 1. Proxy Reverso e Load Balancer

#### Traefik
- **Função**: Proxy reverso, load balancer e terminação SSL
- **Características**:
  - Descoberta automática de serviços
  - Certificados SSL automáticos via Let's Encrypt
  - Rate limiting e middleware de segurança
  - Dashboard de monitoramento

### 2. Serviços Core

#### SparkOne API
- **Função**: API principal de IA e automação
- **Tecnologia**: FastAPI + Python 3.12
- **Características**:
  - Autenticação JWT com refresh tokens
  - Rate limiting avançado com Redis
  - Logging de auditoria estruturado
  - Métricas Prometheus integradas
  - Middleware de segurança
- **Endpoints Principais**:
  - `/auth/*` - Autenticação e autorização
  - `/agents/*` - Gerenciamento de agentes IA
  - `/workflows/*` - Automação e workflows
  - `/ai/*` - Análise e geração de conteúdo
  - `/admin/*` - Administração (superusuários)

#### Evolution API
- **Função**: Integração com WhatsApp Business
- **Características**:
  - Multi-instância
  - Webhooks para automação
  - Integração com chatwoot

#### Evolution Manager
- **Função**: Gerenciamento centralizado das instâncias Evolution
- **Características**:
  - Interface web para administração
  - Monitoramento de status
  - Backup automático

### 3. Serviços de IA

#### Ollama
- **Função**: Modelos de IA locais
- **Características**:
  - Execução local de LLMs
  - API compatível com OpenAI
  - Suporte a múltiplos modelos

#### Claude Interface
- **Função**: Interface para Claude API
- **Características**:
  - Proxy para Anthropic Claude
  - Rate limiting e cache
  - Logging de uso

### 4. Comunicação e Chat

#### RocketChat
- **Função**: Plataforma de chat interno
- **Características**:
  - Chat em tempo real
  - Integração com bots
  - Canais e mensagens diretas

#### Chatwoot
- **Função**: Customer support e helpdesk
- **Características**:
  - Multi-canal (WhatsApp, Email, Chat)
  - Automação de respostas
  - Relatórios e analytics

### 5. Automação

#### N8N
- **Função**: Automação de workflows
- **Características**:
  - Interface visual para workflows
  - Integração com 200+ serviços
  - Triggers e webhooks
  - Execução agendada

#### Drone CI/CD
- **Função**: Pipeline de CI/CD
- **Características**:
  - Build e deploy automatizado
  - Integração com Git
  - Containers como runners

### 6. Armazenamento e Banco de Dados

#### PostgreSQL
- **Função**: Banco de dados principal
- **Uso**:
  - SparkOne (usuários, sessões, logs)
  - Evolution (instâncias, mensagens)
  - N8N (workflows, execuções)
  - RocketChat (mensagens, usuários)
  - Chatwoot (conversas, contatos)

#### Redis
- **Função**: Cache e rate limiting
- **Uso**:
  - Cache de sessões JWT
  - Rate limiting distribuído
  - Cache de dados temporários
  - Pub/Sub para comunicação

#### NextCloud
- **Função**: Armazenamento de arquivos
- **Características**:
  - Sincronização de arquivos
  - Compartilhamento seguro
  - Integração com OnlyOffice

### 7. Monitoramento e Observabilidade

#### Prometheus + Grafana
- **Função**: Métricas e dashboards
- **Métricas Coletadas**:
  - Performance da aplicação
  - Uso de recursos
  - Métricas de negócio
  - SLA e uptime

#### Loki + Promtail
- **Função**: Agregação de logs
- **Características**:
  - Logs centralizados
  - Busca e análise
  - Alertas baseados em logs

#### Jaeger
- **Função**: Distributed tracing
- **Características**:
  - Rastreamento de requisições
  - Performance analysis
  - Debugging distribuído

#### NetData
- **Função**: Monitoramento em tempo real
- **Características**:
  - Métricas de sistema
  - Alertas automáticos
  - Dashboard interativo

### 8. Ferramentas de Desenvolvimento

#### Code Server / Cursor Server
- **Função**: IDE baseado em web
- **Características**:
  - VS Code no navegador
  - Desenvolvimento remoto
  - Extensões e temas

#### Harbor
- **Função**: Registry de containers
- **Características**:
  - Armazenamento seguro de imagens
  - Scanning de vulnerabilidades
  - Controle de acesso

#### Portainer
- **Função**: Gerenciamento Docker
- **Características**:
  - Interface web para Docker
  - Gerenciamento de stacks
  - Monitoramento de containers

## Fluxos de Dados

### 1. Fluxo de Autenticação

```mermaid
sequenceDiagram
    participant U as Usuário
    participant T as Traefik
    participant S as SparkOne
    participant R as Redis
    participant P as PostgreSQL

    U->>T: POST /auth/login
    T->>S: Forward request
    S->>P: Validate credentials
    P-->>S: User data
    S->>R: Check rate limit
    R-->>S: Rate limit OK
    S->>S: Generate JWT tokens
    S->>R: Store token metadata
    S-->>T: Return tokens
    T-->>U: JWT tokens

    U->>T: GET /agents (with JWT)
    T->>S: Forward with token
    S->>S: Validate JWT
    S->>R: Check if blacklisted
    R-->>S: Token valid
    S-->>T: Protected resource
    T-->>U: Response
```

### 2. Fluxo de Workflow Automation

```mermaid
sequenceDiagram
    participant U as Usuário
    participant N as N8N
    participant S as SparkOne
    participant E as Evolution
    participant C as Chatwoot

    U->>N: Create workflow
    N->>N: Save workflow
    
    Note over N: Trigger event occurs
    N->>S: Execute AI analysis
    S-->>N: Analysis result
    N->>E: Send WhatsApp message
    E-->>N: Message sent
    N->>C: Create ticket
    C-->>N: Ticket created
    N->>U: Workflow completed
```

### 3. Fluxo de Monitoramento

```mermaid
graph LR
    A[Aplicações] --> P[Prometheus]
    A --> L[Loki]
    A --> J[Jaeger]
    
    P --> G[Grafana]
    L --> G
    J --> G
    
    P --> AM[AlertManager]
    AM --> N[Notificações]
    
    G --> D[Dashboards]
    G --> A2[Alertas]
```

## Segurança

### 1. Camadas de Segurança

```mermaid
graph TB
    subgraph "Network Security"
        FW[Firewall]
        VPN[VPN Access]
        SSL[SSL/TLS]
    end

    subgraph "Application Security"
        AUTH[JWT Authentication]
        RBAC[Role-Based Access]
        RATE[Rate Limiting]
        VAL[Input Validation]
    end

    subgraph "Infrastructure Security"
        SEC[Secret Management]
        SCAN[Vulnerability Scanning]
        LOG[Audit Logging]
        ENC[Encryption at Rest]
    end

    subgraph "Monitoring Security"
        IDS[Intrusion Detection]
        SIEM[Security Monitoring]
        ALERT[Security Alerts]
    end

    FW --> AUTH
    VPN --> AUTH
    SSL --> AUTH
    
    AUTH --> SEC
    RBAC --> SEC
    RATE --> SEC
    VAL --> SEC
    
    SEC --> IDS
    SCAN --> IDS
    LOG --> IDS
    ENC --> IDS
```

### 2. Autenticação e Autorização

- **JWT com Refresh Tokens**: Tokens de acesso de curta duração com refresh tokens seguros
- **Rate Limiting**: Múltiplas estratégias (sliding window, token bucket, fixed window)
- **Blacklist de Tokens**: Tokens revogados armazenados no Redis
- **Audit Logging**: Log de todas as ações sensíveis
- **RBAC**: Controle de acesso baseado em roles (user, admin, superuser)

### 3. Segurança de Containers

- **Non-root Users**: Todos os containers executam com usuários não-privilegiados
- **Multi-stage Builds**: Imagens mínimas para produção
- **Security Scanning**: Trivy para análise de vulnerabilidades
- **Secret Management**: Docker Secrets para dados sensíveis
- **Network Isolation**: Redes Docker isoladas por função

## Escalabilidade

### 1. Horizontal Scaling

- **Load Balancing**: Traefik distribui carga entre múltiplas instâncias
- **Stateless Services**: Aplicações sem estado para facilitar scaling
- **Database Clustering**: PostgreSQL com replicação
- **Cache Distribuído**: Redis Cluster para alta disponibilidade

### 2. Vertical Scaling

- **Resource Limits**: Containers com limites de CPU e memória
- **Auto-scaling**: Baseado em métricas do Prometheus
- **Performance Monitoring**: NetData e Grafana para otimização

## Backup e Disaster Recovery

### 1. Estratégia de Backup

- **Database Backups**: PostgreSQL com backup incremental
- **File Backups**: NextCloud e volumes Docker
- **Configuration Backups**: Git para configurações
- **Automated Backups**: Scripts automatizados com Restic

### 2. Recovery Procedures

- **RTO (Recovery Time Objective)**: < 4 horas
- **RPO (Recovery Point Objective)**: < 1 hora
- **Testing**: Testes regulares de restore
- **Documentation**: Procedimentos documentados

## Deployment

### 1. Environments

- **Development**: Ambiente local com Docker Compose
- **Staging**: Ambiente de testes com dados sintéticos
- **Production**: Ambiente de produção com alta disponibilidade

### 2. CI/CD Pipeline

```mermaid
graph LR
    DEV[Development] --> TEST[Tests]
    TEST --> BUILD[Build Images]
    BUILD --> SCAN[Security Scan]
    SCAN --> DEPLOY[Deploy to Staging]
    DEPLOY --> VALIDATE[Validation Tests]
    VALIDATE --> PROD[Deploy to Production]
    PROD --> MONITOR[Monitor & Alert]
```

### 3. Infrastructure as Code

- **Docker Compose**: Definição de serviços
- **Environment Variables**: Configuração via .env
- **Scripts**: Automação de deploy e manutenção
- **Version Control**: Todas as configurações versionadas

## Performance

### 1. Otimizações

- **Caching**: Redis para cache de dados frequentes
- **Connection Pooling**: Pool de conexões para PostgreSQL
- **Async Processing**: FastAPI com async/await
- **CDN**: Traefik com cache de assets estáticos

### 2. Métricas de Performance

- **Response Time**: < 200ms para endpoints críticos
- **Throughput**: > 1000 req/s por instância
- **Availability**: 99.9% uptime SLA
- **Error Rate**: < 0.1% de errors

## Configuração e Variáveis

### 1. Variáveis de Ambiente Principais

```bash
# Segurança
JWT_SECRET_KEY=<secure_random_key>
ADMIN_USERNAME=admin
ADMIN_PASSWORD=<secure_password>

# Database
POSTGRES_PASSWORD=<secure_password>
DATABASE_URL=postgresql://user:pass@host:port/db

# Redis
REDIS_PASSWORD=<secure_password>
REDIS_HOST=redis
REDIS_PORT=6379

# Aplicação
ENVIRONMENT=production
ALLOWED_ORIGINS=https://yourdomain.com
TRUSTED_HOSTS=yourdomain.com

# Rate Limiting
RATE_LIMIT_REQUESTS=100
RATE_LIMIT_WINDOW=60

# Tokens
ACCESS_TOKEN_EXPIRE_MINUTES=30
REFRESH_TOKEN_EXPIRE_DAYS=7
```

### 2. Configuração de Produção

- **SSL/TLS**: Certificados automáticos via Let's Encrypt
- **Monitoring**: Alertas configurados para métricas críticas
- **Backup**: Backups automáticos diários
- **Logging**: Logs centralizados com retenção de 30 dias
- **Security**: Firewall configurado, acesso VPN obrigatório

## Troubleshooting

### 1. Problemas Comuns

- **High CPU Usage**: Verificar métricas no Grafana, escalar horizontalmente
- **Database Slow**: Analisar queries lentas, otimizar índices
- **Memory Leaks**: Monitorar via NetData, restart automático se necessário
- **Network Issues**: Verificar conectividade entre containers

### 2. Logs e Debugging

- **Application Logs**: Loki + Grafana para análise
- **System Logs**: NetData para métricas de sistema
- **Tracing**: Jaeger para debugging de performance
- **Health Checks**: Endpoints de saúde para todos os serviços

## Roadmap

### 1. Melhorias Planejadas

- **Kubernetes Migration**: Migração para Kubernetes para melhor orquestração
- **Multi-region**: Deploy em múltiplas regiões para redundância
- **Advanced AI**: Integração com mais modelos de IA
- **Mobile Apps**: Aplicativos móveis para gerenciamento

### 2. Próximas Versões

- **v1.1**: Melhorias de performance e novos endpoints
- **v1.2**: Interface web para administração
- **v2.0**: Arquitetura baseada em microserviços
- **v2.1**: Machine Learning para otimização automática

---

Esta arquitetura foi projetada para ser robusta, segura e escalável, atendendo às necessidades de uma plataforma de produção moderna com foco em IA e automação. 