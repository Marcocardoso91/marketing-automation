# 🏗️ CONTEXT-7 STANDARD - MACSPARK 2025

## 📋 **SOBRE O CONTEXT-7**

O **Context-7** é o padrão oficial de excelência em engenharia de software adotado pelo projeto Macspark-Setup. Define os 7 pilares fundamentais para desenvolvimento, arquitetura e manutenção de código de classe mundial.

---

## 🎯 **OS 7 PILARES DO CONTEXT-7**

### **1. 🏗️ ARQUITETURA LIMPA (Clean Architecture)**
- **FHS Compliance**: Separação clara entre código fonte e runtime
- **Separação de Responsabilidades**: Cada componente tem função específica
- **Modularidade**: Sistema dividido em módulos independentes e reutilizáveis

### **2. 📁 ESTRUTURA ORGANIZACIONAL (Structure Standards)**
- **Diretórios Semânticos**: Nomes autoexplicativos e padronizados
- **Hierarquia Lógica**: Organização que reflete o fluxo de trabalho
- **Documentação Estruturada**: `docs/` com subdivisões por contexto

### **3. 🔒 SEGURANÇA POR DESIGN (Security First)**
- **Secrets Management**: Nunca versionar dados sensíveis
- **Permissões FHS**: Controle de acesso baseado em função
- **Scanning Automático**: Detecção de vulnerabilidades no pipeline

### **4. ⚡ AUTOMAÇÃO INTELIGENTE (Smart Automation)**
- **AI-Powered**: Detecção inteligente de ambiente
- **Zero-Touch**: Instalação sem intervenção manual
- **Self-Healing**: Capacidade de auto-correção

### **5. 🧪 QUALIDADE GARANTIDA (Quality Assurance)**
- **Testes Automatizados**: Cobertura de código e funcionalidade
- **Linting**: Verificação automática de estilo e padrões
- **Pre-commit Hooks**: Validação antes de cada commit

### **6. 📊 OBSERVABILIDADE TOTAL (Full Observability)**
- **Logging Estruturado**: Logs categorizados e pesquisáveis
- **Métricas em Tempo Real**: Monitoramento proativo
- **Rastreabilidade**: Capacidade de debugar qualquer problema

### **7. 🚀 CONTINUOUS EVOLUTION (Evolução Contínua)**
- **Versionamento Semântico**: Mudanças controladas e previsíveis
- **Deprecation Management**: Gestão de transições e legado
- **Innovation Ready**: Preparado para novas tecnologias

---

## 📐 **PADRÕES DE ESTRUTURA DE DIRETÓRIOS**

### **Estrutura Fonte (Development)**
```
Macspark-Setup/
├── README-2025.md           # Documentação principal
├── install-2025.sh          # Instalador principal
├── LICENSE                  # Licença do projeto
├── .env.example             # Template de configuração
├── .pre-commit-config.yaml  # Hooks de qualidade
├── bin/                     # Scripts executáveis principais
│   ├── maintenance.sh
│   ├── ai-assistant.sh
│   └── health-monitor.sh
├── docs/                    # Documentação estruturada
│   ├── architecture/        # Documentos de arquitetura
│   ├── guides/             # Guias de uso
│   └── api/                # Documentação de APIs
├── scripts/                # Scripts auxiliares
├── stacks/                 # Definições de serviços
│   ├── ai/                 # Stacks de IA
│   ├── infra/              # Infraestrutura base
│   ├── monitoring/         # Observabilidade
│   └── security/           # Segurança
├── services/               # Código fonte de aplicações
├── monitoring/             # Configurações de monitoramento
├── templates/              # Templates de configuração
├── tests/                  # Testes automatizados
└── web-installer/          # Interface web
```

### **Estrutura Runtime (FHS Production)**
```
/opt/macspark/              # Código instalado (imutável)
/etc/macspark/              # Configurações específicas do host
/var/lib/macspark/          # Dados persistentes
/var/log/macspark/          # Logs da aplicação
/usr/local/bin/macspark-*   # Comandos globais
```

---

## 🔧 **PADRÕES DE DESENVOLVIMENTO**

### **Convenções de Nomenclatura**
- **Arquivos de Script**: `kebab-case.sh`
- **Variáveis**: `SNAKE_CASE` para globais, `camelCase` para locais
- **Funções**: `snake_case_functions`
- **Diretórios**: `lowercase-with-hyphens`

### **Estrutura de Scripts**
```bash
#!/bin/bash

# ============================================================================
# NOME DO SCRIPT - DESCRIÇÃO
# ============================================================================
# Versão: X.Y.Z
# Autor: Nome
# Descrição: Funcionalidade do script
# ============================================================================

set -euo pipefail

# Configurações
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Funções de logging padronizadas
log_info() { echo -e "\\033[0;34m[INFO]\\033[0m $1"; }
log_success() { echo -e "\\033[0;32m[SUCCESS]\\033[0m $1"; }
log_error() { echo -e "\\033[0;31m[ERROR]\\033[0m $1"; }

# Lógica principal
main() {
    # Implementação
}

# Execução
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi
```

### **Documentação de Função**
```bash
# ============================================================================
# NOME_DA_FUNÇÃO
# ============================================================================
# Descrição: O que a função faz
# Parâmetros:
#   $1 - Descrição do primeiro parâmetro
#   $2 - Descrição do segundo parâmetro (opcional)
# Retorna: O que a função retorna
# Exemplo: exemplo_da_funcao "param1" "param2"
# ============================================================================
exemplo_da_funcao() {
    local param1="$1"
    local param2="${2:-default}"
    # Implementação
}
```

---

## 🧪 **PADRÕES DE QUALIDADE**

### **Pre-commit Hooks Obrigatórios**
```yaml
- repo: https://github.com/pre-commit/pre-commit-hooks
  hooks:
    - id: check-yaml
    - id: end-of-file-fixer
    - id: trailing-whitespace
- repo: https://github.com/koalaman/shellcheck-precommit
  hooks:
    - id: shellcheck
- repo: https://github.com/adrienverge/yamllint
  hooks:
    - id: yamllint
```

### **Estrutura de Testes**
```
tests/
├── unit/                   # Testes unitários
├── integration/            # Testes de integração
├── e2e/                   # Testes end-to-end
└── fixtures/              # Dados de teste
```

### **Cobertura de Testes**
- **Mínimo**: 80% de cobertura para scripts críticos
- **Obrigatório**: Testes para todas as funções públicas
- **Recomendado**: Testes de integração para workflows completos

---

## 🔒 **PADRÕES DE SEGURANÇA**

### **Gestão de Secrets**
- ❌ **NUNCA**: Commitar senhas, chaves, tokens
- ✅ **SEMPRE**: Usar templates `.example`
- 🔐 **PROTEÇÃO**: `.gitignore` com padrões de segurança

### **Permissões FHS**
```bash
# Código da aplicação (imutável)
/opt/macspark/              → root:root 755/644

# Configurações (editáveis)
/etc/macspark/              → root:macspark 750/640

# Dados persistentes
/var/lib/macspark/          → macspark:macspark 750

# Logs
/var/log/macspark/          → macspark:macspark 750
```

---

## 📊 **PADRÕES DE OBSERVABILIDADE**

### **Logging Estruturado**
- **Níveis**: ERROR, WARN, INFO, DEBUG
- **Formato**: `[TIMESTAMP] [LEVEL] [COMPONENT] MESSAGE`
- **Destino**: `/var/log/macspark/component.log`

### **Métricas Essenciais**
- **Sistema**: CPU, RAM, Disco, Rede
- **Aplicação**: Latência, Throughput, Errors
- **Negócio**: KPIs específicos do domínio

---

## 🚀 **PROCESSO DE COMPLIANCE**

### **Checklist Context-7**
- [ ] Estrutura de diretórios conforme padrão
- [ ] Pre-commit hooks configurados
- [ ] Testes automatizados implementados
- [ ] Documentação atualizada
- [ ] Segurança validada (sem secrets)
- [ ] FHS compliance verificado
- [ ] Observabilidade implementada

### **Validação Automatizada**
```bash
# Executar validação completa
bash tests/context-7-compliance.sh

# Resultado esperado: 100% compliance
```

---

## 📈 **EVOLUÇÃO DO PADRÃO**

### **Versionamento**
- **Context-7.0**: Versão inicial (2025)
- **Context-7.1**: Melhorias baseadas em feedback
- **Context-7.x**: Evolução contínua

### **Processo de Mudança**
1. **Proposta**: Issue com justificativa técnica
2. **Discussão**: Review pela equipe
3. **Implementação**: PR com testes
4. **Validação**: Compliance check
5. **Adoção**: Atualização da documentação

---

## 🎯 **BENEFÍCIOS DO CONTEXT-7**

### **Para Desenvolvedores**
- ✅ **Clareza**: Padrões bem definidos
- ✅ **Produtividade**: Menos decisões, mais código
- ✅ **Qualidade**: Erros reduzidos

### **Para Operações**
- ✅ **Confiabilidade**: Sistema previsível
- ✅ **Manutenibilidade**: Estrutura conhecida
- ✅ **Observabilidade**: Debugging eficiente

### **Para o Negócio**
- ✅ **Time-to-Market**: Deploy mais rápido
- ✅ **Custo**: Menos bugs, menos retrabalho
- ✅ **Escalabilidade**: Crescimento sustentável

---

**Context-7**: *Onde a excelência técnica encontra a pragmaticidade empresarial.* 🚀

---

*Documento v1.0 - Julho 2025*  
*Próxima revisão: Janeiro 2026*