# 📁 ESTRUTURA DO PROJETO MACSPARK SETUP

## 🎯 Visão Geral

Este documento define a estrutura padronizada do projeto Macspark Setup, organizando todos os componentes de forma modular e escalável.

## 📂 Estrutura Recomendada

### 🏠 **Estrutura Local (Desenvolvimento)**
```
Macspark-Setup/
├── stacks/                    # Stacks Docker Swarm
│   ├── traefik/
│   │   └── traefik.yml
│   ├── infra/
│   │   ├── postgresql.yml
│   │   └── redis.yml
│   ├── monitoring/
│   │   ├── monitoring-stack.yml
│   │   └── netdata.yml
│   ├── dashboard/
│   │   ├── heimdall.yml
│   │   └── portainer.yml
│   ├── apps/
│   │   ├── n8n.yml
│   │   └── chatwoot.yml
│   ├── ai/
│   │   ├── claude-interface.yml
│   │   ├── ollama.yml
│   │   └── localai.yml
│   ├── agents/               # Agentes próprios
│   │   ├── sparkone.yml
│   │   ├── evolution-api.yml
│   │   └── gateway.yml
│   ├── security/
│   │   ├── vaultwarden.yml
│   │   └── crowdsec.yml
│   ├── storage/
│   │   └── nextcloud.yml
│   ├── communication/
│   │   ├── rocketchat.yml
│   │   └── evolution.yml
│   ├── productivity/
│   │   ├── bookstack.yml
│   │   ├── wekan.yml
│   │   └── onlyoffice.yml
│   ├── design/
│   │   ├── penpot.yml
│   │   └── excalidraw.yml
│   ├── development/
│   │   ├── cursor-server.yml
│   │   └── code-server.yml
│   ├── ci-cd/
│   │   └── drone.yml
│   └── registry/
│       └── harbor.yml
├── services/                 # Serviços próprios
│   ├── sparkone/
│   │   ├── Dockerfile
│   │   ├── main.py
│   │   ├── requirements.txt
│   │   └── README.md
│   ├── evolution-api/
│   │   ├── Dockerfile
│   │   ├── main.py
│   │   └── requirements.txt
│   └── gateway/
│       ├── Dockerfile
│       ├── main.py
│       └── requirements.txt
├── scripts/                  # Scripts de automação
│   ├── deploy.sh
│   ├── backup_all.sh
│   ├── backup_git.sh
│   ├── backup_postgres.sh
│   ├── notify.sh
│   ├── optimize-docker.sh
│   ├── performance-extreme.sh
│   ├── security-hardening-final.sh
│   ├── pre-install-check.sh
│   └── add-extra-services.sh
├── docs/                     # Documentação interativa
│   ├── index.md
│   ├── installation.md
│   ├── configuration.md
│   ├── services.md
│   ├── agents.md
│   ├── troubleshooting.md
│   └── api/
│       ├── sparkone.md
│       ├── evolution-api.md
│       └── gateway.md
├── configs/                  # Configurações
│   ├── traefik/
│   │   ├── traefik.yml
│   │   └── dynamic.yml
│   ├── monitoring/
│   │   ├── prometheus.yml
│   │   ├── grafana/
│   │   └── alertmanager.yml
│   └── security/
│       ├── crowdsec.yml
│       └── fail2ban.yml
├── templates/                # Templates
│   ├── docker-compose.yml
│   ├── .env.example
│   └── nginx.conf
├── tests/                    # Testes
│   ├── unit/
│   ├── integration/
│   └── e2e/
├── .env.example
├── README.md
├── AGENTS.md
├── SERVICES_COMPLETE.md
├── DOMAIN_CONFIG.md
├── IMPROVEMENTS.md
├── INDEX.md
└── PROJECT_STRUCTURE.md
```

### 🚀 **Estrutura de Produção (/opt/macspark)**
```
/opt/macspark/
├── stacks/                   # Stacks Docker Swarm
│   ├── traefik/
│   ├── infra/
│   ├── monitoring/
│   ├── dashboard/
│   ├── apps/
│   ├── ai/
│   ├── agents/
│   ├── security/
│   ├── storage/
│   ├── communication/
│   ├── productivity/
│   ├── design/
│   ├── development/
│   ├── ci-cd/
│   └── registry/
├── services/                 # Serviços próprios
│   ├── sparkone/
│   ├── evolution-api/
│   └── gateway/
├── data/                     # Dados persistentes
│   ├── postgres/
│   ├── redis/
│   ├── nextcloud/
│   ├── sparkone/
│   ├── evolution-api/
│   ├── gateway/
│   ├── traefik/
│   ├── monitoring/
│   └── logs/
├── logs/                     # Logs centralizados
│   ├── system/
│   ├── applications/
│   ├── security/
│   ├── performance/
│   └── backups/
├── backups/                  # Backups
│   ├── daily/
│   ├── weekly/
│   ├── monthly/
│   ├── postgres/
│   ├── files/
│   └── git/
├── configs/                  # Configurações
│   ├── traefik/
│   ├── monitoring/
│   ├── security/
│   └── applications/
├── scripts/                  # Scripts de automação
│   ├── deploy.sh
│   ├── backup_all.sh
│   ├── backup_git.sh
│   ├── backup_postgres.sh
│   ├── notify.sh
│   ├── optimize-docker.sh
│   ├── performance-extreme.sh
│   ├── security-hardening-final.sh
│   ├── pre-install-check.sh
│   └── add-extra-services.sh
├── docs/                     # Documentação
│   ├── api/
│   ├── guides/
│   └── troubleshooting/
├── temp/                     # Arquivos temporários
│   ├── uploads/
│   ├── cache/
│   └── downloads/
├── .env                      # Variáveis de ambiente
├── docker-compose.yml        # Compose para desenvolvimento
└── README.md
```

## 🔧 **Configuração de Volumes**

### **Volumes Padronizados**
```yaml
# Exemplo de volume padronizado
volumes:
  service_data:
    driver: local
    driver_opts:
      type: none
      o: bind
      device: /opt/macspark/data/service_name
  service_logs:
    driver: local
    driver_opts:
      type: none
      o: bind
      device: /opt/macspark/logs/service_name
```

### **Estrutura de Dados**
```
/opt/macspark/data/
├── postgres/                 # Banco de dados PostgreSQL
│   ├── base/
│   ├── global/
│   └── pg_wal/
├── redis/                    # Cache Redis
│   └── dump.rdb
├── nextcloud/                # Armazenamento NextCloud
│   ├── data/
│   ├── config/
│   └── themes/
├── sparkone/                 # Dados do SparkOne
│   ├── agents/
│   ├── workflows/
│   └── cache/
├── evolution-api/            # Dados da Evolution API
│   ├── instances/
│   ├── webhooks/
│   └── media/
├── gateway/                  # Dados do Gateway
│   ├── routes/
│   ├── policies/
│   └── cache/
├── traefik/                  # Configurações Traefik
│   ├── acme/
│   ├── config/
│   └── logs/
└── monitoring/               # Dados de monitoramento
    ├── prometheus/
    ├── grafana/
    └── loki/
```

## 📊 **Estrutura de Logs**

### **Logs Centralizados**
```
/opt/macspark/logs/
├── system/                   # Logs do sistema
│   ├── docker/
│   ├── swarm/
│   └── kernel/
├── applications/             # Logs das aplicações
│   ├── sparkone/
│   ├── evolution-api/
│   ├── gateway/
│   ├── nextcloud/
│   └── n8n/
├── security/                 # Logs de segurança
│   ├── crowdsec/
│   ├── fail2ban/
│   └── audit/
├── performance/              # Logs de performance
│   ├── monitoring/
│   ├── metrics/
│   └── alerts/
└── backups/                  # Logs de backup
    ├── daily/
    ├── weekly/
    └── monthly/
```

## 🔄 **Estrutura de Backups**

### **Backups Organizados**
```
/opt/macspark/backups/
├── daily/                    # Backups diários
│   ├── 2024-01-15/
│   ├── 2024-01-16/
│   └── 2024-01-17/
├── weekly/                   # Backups semanais
│   ├── week-01-2024/
│   ├── week-02-2024/
│   └── week-03-2024/
├── monthly/                  # Backups mensais
│   ├── 2024-01/
│   ├── 2024-02/
│   └── 2024-03/
├── postgres/                 # Backups do PostgreSQL
│   ├── full/
│   ├── incremental/
│   └── wal/
├── files/                    # Backups de arquivos
│   ├── nextcloud/
│   ├── configs/
│   └── logs/
└── git/                      # Backups do Git
    ├── repositories/
    ├── configs/
    └── scripts/
```

## 🛠️ **Scripts de Configuração**

### **Script de Setup da Estrutura**
```bash
#!/bin/bash
# setup-structure.sh

# Criar estrutura base
sudo mkdir -p /opt/macspark/{stacks,services,data,logs,backups,configs,scripts,docs,temp}

# Criar subdiretórios de stacks
sudo mkdir -p /opt/macspark/stacks/{traefik,infra,monitoring,dashboard,apps,ai,agents,security,storage,communication,productivity,design,development,ci-cd,registry}

# Criar subdiretórios de serviços
sudo mkdir -p /opt/macspark/services/{sparkone,evolution-api,gateway}

# Criar subdiretórios de dados
sudo mkdir -p /opt/macspark/data/{postgres,redis,nextcloud,sparkone,evolution-api,gateway,traefik,monitoring}

# Criar subdiretórios de logs
sudo mkdir -p /opt/macspark/logs/{system,applications,security,performance,backups}

# Criar subdiretórios de backups
sudo mkdir -p /opt/macspark/backups/{daily,weekly,monthly,postgres,files,git}

# Configurar permissões
sudo chown -R $USER:$USER /opt/macspark
sudo chmod -R 755 /opt/macspark

echo "Estrutura /opt/macspark criada com sucesso!"
```

## 📋 **Variáveis de Ambiente**

### **.env Padronizado**
```bash
# Configurações do Projeto
PROJECT_NAME=macspark
PROJECT_VERSION=1.0.0
PROJECT_ENV=production

# Domínio
DOMAIN=macspark.dev
SUBDOMAIN=www

# Paths
MACSPARK_HOME=/opt/macspark
MACSPARK_DATA=/opt/macspark/data
MACSPARK_LOGS=/opt/macspark/logs
MACSPARK_BACKUPS=/opt/macspark/backups
MACSPARK_CONFIGS=/opt/macspark/configs

# Docker
DOCKER_SWARM_MODE=true
DOCKER_NETWORK_NAME=macspark_network
DOCKER_REGISTRY=harbor.macspark.dev

# Segurança
SECRET_KEY=your_secret_key_here
JWT_SECRET=your_jwt_secret_here
ENCRYPTION_KEY=your_encryption_key_here

# APIs
OPENAI_API_KEY=your_openai_key
ANTHROPIC_API_KEY=your_anthropic_key
TELEGRAM_BOT_TOKEN=your_telegram_token
TELEGRAM_CHAT_ID=your_chat_id

# Monitoramento
PROMETHEUS_ENABLED=true
GRAFANA_ENABLED=true
ALERTMANAGER_ENABLED=true

# Backup
BACKUP_ENABLED=true
BACKUP_RETENTION_DAYS=30
BACKUP_RETENTION_WEEKS=12
BACKUP_RETENTION_MONTHS=12
```

## 🚀 **Deploy e Manutenção**

### **Comandos Padronizados**
```bash
# Deploy de stack
docker stack deploy -c /opt/macspark/stacks/service/service.yml macspark

# Backup
/opt/macspark/scripts/backup_all.sh

# Logs
tail -f /opt/macspark/logs/applications/service_name/app.log

# Monitoramento
docker service ls | grep macspark
docker service logs macspark_service_name

# Manutenção
/opt/macspark/scripts/optimize-docker.sh
/opt/macspark/scripts/performance-extreme.sh
```

## 📈 **Benefícios da Estrutura**

| Benefício | Descrição |
|-----------|-----------|
| 🧹 **Organização** | Estrutura clara e lógica |
| 🔄 **Escalabilidade** | Fácil adição de novos serviços |
| 🛡️ **Segurança** | Separação de dados e logs |
| 📊 **Monitoramento** | Logs centralizados e estruturados |
| 💾 **Backup** | Estratégia de backup organizada |
| 🔧 **Manutenção** | Scripts padronizados |
| 📚 **Documentação** | Documentação integrada |
| 🚀 **Deploy** | Processo de deploy simplificado |

---

**📁 Esta estrutura garante organização, escalabilidade e facilidade de manutenção do Macspark Setup!** 