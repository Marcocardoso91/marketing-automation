# 🏗️ Arquitetura do Sistema

Documentação técnica completa da arquitetura MacSpark Enterprise.

## 📐 Design do Sistema

- **[Arquitetura Geral](system-architecture.md)** - Visão geral da arquitetura
- **[Infraestrutura](infrastructure-design.md)** - Design da infraestrutura
- **[Componentes Reutilizáveis](reusable-components.md)** - Biblioteca de componentes

## 🔧 Componentes Principais

### Docker Swarm
- Orquestração de containers
- Alta disponibilidade com 3 managers
- Load balancing automático

### Traefik v3
- Proxy reverso e load balancer
- SSL automático com Let's Encrypt
- Roteamento baseado em labels

### Stack de Monitoramento
- Prometheus para métricas
- Grafana para visualização
- Loki para logs
- Tempo para traces

## 🌐 Topologia de Rede

```
Internet → Cloudflare → Traefik → Services
                ↓
         Docker Overlay Networks:
         - traefik-public
         - apps-network
         - data-network
         - monitoring-network
```

## 📊 Diagramas

Visualizações detalhadas estão disponíveis em [diagrams/](diagrams/).

## 🔗 Integrações

- PostgreSQL 17 (cluster HA)
- Redis cluster (cache e sessões)
- MinIO (object storage)
- Vault (secrets management)