# CI/CD Guide - Setup-Macspark

**Version:** 2.0.0  
**Last Updated:** 2025-08-22  
**Status:** Production Ready

## 📋 Table of Contents

1. [Overview](#overview)
2. [Pipeline Architecture](#pipeline-architecture)
3. [Workflows](#workflows)
4. [Gate Rules](#gate-rules)
5. [Environment Strategy](#environment-strategy)
6. [Security Controls](#security-controls)
7. [Monitoring & Alerts](#monitoring--alerts)
8. [Troubleshooting](#troubleshooting)

## 🎯 Overview

The Setup-Macspark CI/CD pipeline implements enterprise-grade automation with multiple quality gates, security scanning, and automated testing. Built on GitHub Actions with support for GitLab CI and Jenkins.

### Key Features

- **Multi-stage validation** with parallel execution
- **Security-first approach** with shift-left testing
- **Automated quality gates** with strict thresholds
- **Progressive deployment** with canary and blue-green
- **Comprehensive reporting** with actionable insights
- **MCP integration** for AI-powered analysis

## 🏗️ Pipeline Architecture

```mermaid
graph TB
    subgraph "CI Pipeline"
        A[Code Push] --> B[Lint & Validate]
        B --> C[Security Scan]
        B --> D[Unit Tests]
        C --> E[Integration Tests]
        D --> E
        E --> F[Build Images]
        F --> G[Container Scan]
    end
    
    subgraph "CD Pipeline"
        G --> H{Quality Gate}
        H -->|Pass| I[Deploy Staging]
        H -->|Fail| J[Block & Alert]
        I --> K[Smoke Tests]
        K --> L[Load Tests]
        L --> M{Approval}
        M -->|Approved| N[Deploy Production]
        M -->|Rejected| O[Rollback]
        N --> P[Health Checks]
        P --> Q[Monitoring]
    end
```

## 📝 Workflows

### 1. Lint and Validate (`lint-and-validate.yml`)

**Trigger:** Every push and PR

**Jobs:**
- `terraform-validate`: Terraform format and validation
- `ansible-validate`: Ansible syntax and lint
- `docker-validate`: Dockerfile and compose validation
- `yaml-json-validate`: YAML/JSON syntax checking
- `shell-validate`: Shell script analysis with ShellCheck
- `markdown-validate`: Documentation linting

**Gate Rules:**
```yaml
fail_conditions:
  - terraform_format_errors > 0
  - ansible_lint_errors > 0
  - docker_compose_invalid > 0
  - shellcheck_errors > 0
  - yaml_syntax_errors > 0
```

### 2. Security Scanning (`security-scan.yml`)

**Trigger:** Push, PR, and daily schedule

**Jobs:**
- `trivy-scan`: Container and filesystem vulnerability scanning
- `secret-scan`: Gitleaks and TruffleHog secret detection
- `docker-bench`: Docker security best practices
- `cis-benchmark`: CIS compliance checking
- `owasp-zap`: Web application security testing

**Thresholds:**
```yaml
security_gates:
  critical_vulnerabilities: 0  # Block deployment
  high_vulnerabilities: 0      # Block deployment
  medium_vulnerabilities: 10   # Warning only
  secrets_detected: 0          # Block immediately
  cis_compliance: 80%          # Minimum score
```

### 3. Test and Validate (`test-and-validate.yml`)

**Trigger:** Push, PR, manual dispatch

**Test Levels:**
- `smoke`: Basic health checks (10 min)
- `integration`: API and E2E tests (20 min)
- `full`: Complete test suite (45 min)
- `stress`: Load and chaos testing (60 min)

**Performance Criteria:**
```yaml
performance_thresholds:
  p95_response_time: 500ms
  p99_response_time: 1000ms
  error_rate: 1%
  availability: 99.9%
  throughput: 200 req/s
```

### 4. Consolidation Pipeline (`consolidation.yml`)

**Trigger:** Manual dispatch only

**Modes:**
- `validate-only`: Check files without changes
- `dry-run`: Simulate consolidation
- `execute`: Perform actual consolidation

**Deduplication Rules:**
```yaml
deduplication:
  strategy: content_hash
  preference_order:
    - production
    - staging
    - development
  version_selection: latest
```

## 🚦 Gate Rules

### Quality Gate Configuration

```yaml
# .github/quality-gates.yml
quality_gates:
  pr_merge:
    required_checks:
      - lint-and-validate
      - security-scan
      - smoke-tests
    code_coverage:
      minimum: 80%
      delta: -5%  # Max decrease
    
  staging_deployment:
    required_checks:
      - all_pr_checks
      - integration-tests
      - no_critical_vulnerabilities
    approvals:
      minimum: 1
      teams: [devops, security]
    
  production_deployment:
    required_checks:
      - all_staging_checks
      - load-tests
      - chaos-tests
      - security-review
    approvals:
      minimum: 2
      teams: [devops, security, platform]
    change_window:
      days: [tuesday, thursday]
      hours: [10, 16]  # 10 AM - 4 PM
```

### Automatic Failure Conditions

```yaml
auto_fail:
  - critical_security_vulnerabilities > 0
  - secrets_in_code = true
  - test_coverage < 70%
  - lint_errors > 50
  - docker_build_failed = true
  - health_check_failed = true
```

## 🌍 Environment Strategy

### Environment Progression

```mermaid
graph LR
    A[Local Dev] --> B[CI Build]
    B --> C[Dev Environment]
    C --> D[Staging]
    D --> E{Manual Approval}
    E --> F[Production]
    
    style A fill:#f9f,stroke:#333
    style F fill:#9f9,stroke:#333
```

### Environment Configuration

| Environment | Auto-Deploy | Approval Required | Rollback | Monitoring |
|------------|-------------|-------------------|----------|------------|
| Development | ✅ On commit | ❌ None | Auto | Basic |
| Staging | ✅ On PR merge | ❌ None | Auto | Full |
| Production | ❌ Manual | ✅ 2 approvers | Manual | Enhanced |

### Deployment Strategies

```yaml
deployment_strategies:
  staging:
    type: rolling_update
    max_surge: 1
    max_unavailable: 0
    
  production:
    type: blue_green
    traffic_split:
      - blue: 100%
      - green: 0%
    validation_period: 30m
    auto_rollback: true
    
  experimental:
    type: canary
    steps:
      - weight: 10%
        duration: 10m
      - weight: 50%
        duration: 30m
      - weight: 100%
        duration: stable
```

## 🔒 Security Controls

### Secret Management

```yaml
# GitHub Secrets required
secrets:
  # Authentication
  DOCKER_HUB_TOKEN
  AWS_ACCESS_KEY_ID
  AWS_SECRET_ACCESS_KEY
  
  # Notifications
  SLACK_WEBHOOK_URL
  PAGERDUTY_KEY
  
  # Security
  SONAR_TOKEN
  SNYK_TOKEN
  TRIVY_TOKEN
  
  # Deployment
  STAGING_SSH_KEY
  PRODUCTION_SSH_KEY
```

### Security Scanning Integration

```bash
# Pre-commit hooks (.pre-commit-config.yaml)
repos:
  - repo: https://github.com/Yelp/detect-secrets
    rev: v1.4.0
    hooks:
      - id: detect-secrets
        args: ['--baseline', '.secrets.baseline']
  
  - repo: https://github.com/zricethezav/gitleaks
    rev: v8.18.0
    hooks:
      - id: gitleaks
  
  - repo: https://github.com/hadolint/hadolint
    rev: v2.12.0
    hooks:
      - id: hadolint
```

## 📊 Monitoring & Alerts

### Pipeline Metrics

```promql
# Prometheus queries for CI/CD metrics

# Pipeline success rate
sum(rate(github_actions_workflow_run_conclusion_success[1h])) /
sum(rate(github_actions_workflow_run_conclusion_total[1h]))

# Average pipeline duration
avg(github_actions_workflow_run_duration_seconds)

# Deployment frequency
sum(rate(deployment_success_total[1d]))

# Failed deployments
sum(increase(deployment_failed_total[1h]))

# Security vulnerabilities trend
sum(trivy_vulnerabilities_total) by (severity)
```

### Alert Configuration

```yaml
# .github/alerts.yml
alerts:
  pipeline_failure:
    condition: failed_builds > 3
    severity: warning
    notify: [slack, email]
    
  security_critical:
    condition: critical_vulnerabilities > 0
    severity: critical
    notify: [pagerduty, slack, email]
    
  deployment_failed:
    condition: production_deployment_failed
    severity: critical
    notify: [pagerduty, phone, slack]
    
  performance_degradation:
    condition: p95_latency > 1000ms
    severity: warning
    notify: [slack, email]
```

## 🔧 Troubleshooting

### Common Issues and Solutions

#### 1. Pipeline Timeout

```yaml
# Increase timeout in workflow
jobs:
  test:
    timeout-minutes: 60  # Increase from default 360
```

#### 2. Docker Rate Limiting

```yaml
# Use authenticated pulls
- name: Login to Docker Hub
  uses: docker/login-action@v3
  with:
    username: ${{ secrets.DOCKER_USERNAME }}
    password: ${{ secrets.DOCKER_TOKEN }}
```

#### 3. Flaky Tests

```yaml
# Add retry mechanism
- name: Run tests with retry
  uses: nick-invision/retry@v2
  with:
    timeout_minutes: 10
    max_attempts: 3
    command: npm test
```

#### 4. Secret Scanning False Positives

```bash
# Add to .gitleaksignore
# Example key (not a real secret)
examples/api-key-example.txt:generic-api-key:1
```

### Debug Mode

```yaml
# Enable debug logging
env:
  ACTIONS_RUNNER_DEBUG: true
  ACTIONS_STEP_DEBUG: true
```

### Manual Workflow Trigger

```bash
# Trigger workflow via API
curl -X POST \
  -H "Authorization: token $GITHUB_TOKEN" \
  -H "Accept: application/vnd.github.v3+json" \
  https://api.github.com/repos/macspark/setup-macspark/actions/workflows/security-scan.yml/dispatches \
  -d '{"ref":"main","inputs":{"scan_type":"full"}}'
```

## 📈 Best Practices

### 1. Pipeline Optimization

- **Parallelize jobs** where possible
- **Cache dependencies** aggressively
- **Use matrix builds** for multiple versions
- **Implement incremental testing**
- **Optimize Docker layers**

### 2. Security Best Practices

- **Scan early and often**
- **Rotate secrets regularly**
- **Use least privilege principle**
- **Implement SAST and DAST**
- **Monitor supply chain**

### 3. Monitoring Best Practices

- **Track key metrics** (DORA metrics)
- **Set meaningful alerts**
- **Create dashboards**
- **Regular reviews**
- **Continuous improvement**

## 🚀 Advanced Features

### MCP Integration

```yaml
# Use MCP for intelligent analysis
- name: MCP Analysis
  run: |
    mcp analyze \
      --context "security-scan-results.json" \
      --prompt "Identify critical security issues and suggest fixes" \
      --output "mcp-security-analysis.md"
```

### AI-Powered Code Review

```yaml
# Automated PR review with AI
- name: AI Code Review
  uses: macspark/ai-reviewer@v1
  with:
    model: gpt-4
    focus: [security, performance, best-practices]
```

### Predictive Failure Analysis

```yaml
# Predict pipeline failures
- name: Failure Prediction
  run: |
    python scripts/ml/predict-failure.py \
      --history "pipeline-metrics.json" \
      --threshold 0.8
```

## 📚 Resources

### Documentation

- [GitHub Actions Docs](https://docs.github.com/actions)
- [Docker Best Practices](https://docs.docker.com/develop/dev-best-practices/)
- [OWASP DevSecOps](https://owasp.org/www-project-devsecops-guideline/)

### Tools

- [act](https://github.com/nektos/act) - Run GitHub Actions locally
- [actionlint](https://github.com/rhysd/actionlint) - Lint workflow files
- [tj-actions/changed-files](https://github.com/tj-actions/changed-files) - Detect changed files

### Templates

```yaml
# Reusable workflow template
name: Reusable Security Scan
on:
  workflow_call:
    inputs:
      severity:
        required: false
        type: string
        default: 'HIGH,CRITICAL'
    secrets:
      TRIVY_TOKEN:
        required: true

jobs:
  scan:
    runs-on: ubuntu-latest
    steps:
      - uses: aquasecurity/trivy-action@master
        with:
          severity: ${{ inputs.severity }}
```

---

**Remember:** CI/CD is not just about automation, it's about delivering value safely and efficiently.

*This guide is a living document. Update it as the pipeline evolves.*