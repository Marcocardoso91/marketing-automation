# Staging MVP Validation Checklist

**Version:** 1.0.0  
**Last Updated:** 2025-08-22  
**Environment:** Staging  
**Target:** Production Readiness

## 🎯 MVP Scope

### Critical Services for Initial Deployment

| Service | Priority | Version | Status |
|---------|----------|---------|--------|
| **Traefik** | P0 - Critical | v3.5+ | ⬜ Pending |
| **PostgreSQL HA** | P0 - Critical | v17 | ⬜ Pending |
| **Redis Sentinel** | P0 - Critical | v7.4+ | ⬜ Pending |
| **N8N** | P0 - Critical | Latest | ⬜ Pending |
| **Evolution API** | P0 - Critical | Latest | ⬜ Pending |
| **Vault** | P0 - Critical | v1.17+ | ⬜ Pending |
| **Monitoring Stack** | P0 - Critical | LGTM | ⬜ Pending |

## ✅ Pre-Deployment Checklist

### 1. Infrastructure Preparation

- [ ] **Swarm Cluster Initialized**
  ```bash
  docker swarm init --advertise-addr $(hostname -I | awk '{print $1}')
  docker node ls
  # Expected: 3+ nodes (1 manager, 2+ workers)
  ```

- [ ] **Networks Created**
  ```bash
  docker network create --driver overlay --attachable traefik-public
  docker network create --driver overlay --attachable --opt encrypted internal
  docker network create --driver overlay --attachable monitoring
  docker network create --driver overlay --attachable databases
  docker network ls | grep overlay
  # Expected: All 4 networks created
  ```

- [ ] **Volumes Prepared**
  ```bash
  for volume in postgres-data redis-data n8n-data vault-data prometheus-data grafana-data loki-data; do
    docker volume create $volume
  done
  docker volume ls
  # Expected: All volumes created
  ```

- [ ] **Secrets Configured**
  ```bash
  # Create required secrets
  echo "ChangeMeStrong#2025" | docker secret create postgres_password -
  echo "RedisSecure#2025" | docker secret create redis_password -
  echo "N8nAdmin#2025" | docker secret create n8n_password -
  echo "VaultToken#2025" | docker secret create vault_token -
  docker secret ls
  # Expected: All secrets created
  ```

### 2. Core Services Deployment

- [ ] **Deploy Traefik**
  ```bash
  docker stack deploy -c stacks/core/traefik/traefik-staging.yml traefik
  
  # Validation
  curl -f https://staging.macspark.dev/health || echo "Traefik not ready"
  docker service logs traefik_traefik --tail 50
  # Expected: Service running, health check passing
  ```

- [ ] **Deploy PostgreSQL HA**
  ```bash
  docker stack deploy -c stacks/core/database/postgres-ha.yml postgres
  
  # Validation
  docker exec $(docker ps -q -f name=postgres_postgres) pg_isready
  docker exec $(docker ps -q -f name=postgres_postgres) psql -U postgres -c "SELECT version();"
  # Expected: PostgreSQL 17 running, accepting connections
  ```

- [ ] **Deploy Redis Sentinel**
  ```bash
  docker stack deploy -c stacks/core/cache/redis-sentinel.yml redis
  
  # Validation
  docker exec $(docker ps -q -f name=redis_redis) redis-cli ping
  docker exec $(docker ps -q -f name=redis_redis) redis-cli INFO replication
  # Expected: PONG response, master-slave replication active
  ```

- [ ] **Deploy Monitoring Stack**
  ```bash
  docker stack deploy -c stacks/core/monitoring/monitoring.yml monitoring
  
  # Validation
  curl -f https://grafana.staging.macspark.dev/api/health
  curl -f https://prometheus.staging.macspark.dev/-/healthy
  # Expected: All monitoring services healthy
  ```

### 3. Application Services Deployment

- [ ] **Deploy N8N**
  ```bash
  docker stack deploy -c stacks/applications/ai/n8n.yml n8n
  
  # Validation
  curl -f https://n8n.staging.macspark.dev/healthz
  # Test webhook
  curl -X POST https://n8n.staging.macspark.dev/webhook-test \
    -H "Content-Type: application/json" \
    -d '{"test": "data"}'
  # Expected: N8N running, webhooks responsive
  ```

- [ ] **Deploy Evolution API**
  ```bash
  docker stack deploy -c stacks/applications/ai/evolution.yml evolution
  
  # Validation
  curl -f https://evolution.staging.macspark.dev/health
  # Expected: Evolution API healthy
  ```

- [ ] **Deploy Vault**
  ```bash
  docker stack deploy -c stacks/infrastructure/security/vault.yml vault
  
  # Validation
  curl -f https://vault.staging.macspark.dev/v1/sys/health
  # Initialize Vault
  docker exec $(docker ps -q -f name=vault_vault) vault operator init
  # Expected: Vault initialized and unsealed
  ```

## 🔍 Smoke Tests

### 1. Health Checks (5 minutes)

```bash
#!/bin/bash
# smoke-tests.sh

SERVICES=(
  "traefik|https://staging.macspark.dev/health"
  "grafana|https://grafana.staging.macspark.dev/api/health"
  "prometheus|https://prometheus.staging.macspark.dev/-/healthy"
  "n8n|https://n8n.staging.macspark.dev/healthz"
  "evolution|https://evolution.staging.macspark.dev/health"
  "vault|https://vault.staging.macspark.dev/v1/sys/health"
)

echo "🔍 Running health checks..."
FAILED=0

for service_check in "${SERVICES[@]}"; do
  IFS='|' read -r service url <<< "$service_check"
  echo -n "Checking $service... "
  
  if curl -sf "$url" > /dev/null; then
    echo "✅ OK"
  else
    echo "❌ FAILED"
    ((FAILED++))
  fi
done

if [ $FAILED -eq 0 ]; then
  echo "✅ All health checks passed!"
else
  echo "❌ $FAILED health checks failed"
  exit 1
fi
```

- [ ] All services responding: ⬜
- [ ] No errors in logs: ⬜
- [ ] Response time < 500ms: ⬜

### 2. Database Connectivity (5 minutes)

```bash
# Test PostgreSQL
docker exec $(docker ps -q -f name=postgres_postgres) psql -U postgres <<EOF
CREATE DATABASE test_db;
\c test_db
CREATE TABLE test (id SERIAL PRIMARY KEY, data TEXT);
INSERT INTO test (data) VALUES ('test_data');
SELECT * FROM test;
DROP DATABASE test_db;
EOF

# Test Redis
docker exec $(docker ps -q -f name=redis_redis) redis-cli <<EOF
SET test_key "test_value"
GET test_key
DEL test_key
EOF
```

- [ ] PostgreSQL CRUD operations: ⬜
- [ ] Redis SET/GET operations: ⬜
- [ ] Replication verified: ⬜

### 3. SSL/TLS Validation (5 minutes)

```bash
# Check certificate
echo | openssl s_client -connect staging.macspark.dev:443 2>/dev/null | \
  openssl x509 -noout -dates -subject -issuer

# Check TLS version
nmap --script ssl-enum-ciphers -p 443 staging.macspark.dev | grep "TLSv1.3"

# Check HSTS header
curl -sI https://staging.macspark.dev | grep -i "strict-transport-security"

# Check security headers
curl -sI https://staging.macspark.dev | grep -E "(X-Frame-Options|X-Content-Type|Content-Security-Policy)"
```

- [ ] Valid SSL certificate: ⬜
- [ ] TLS 1.3 enabled: ⬜
- [ ] HSTS configured: ⬜
- [ ] Security headers present: ⬜

### 4. Network Connectivity (5 minutes)

```bash
# Test internal network communication
docker exec $(docker ps -q -f name=traefik_traefik | head -1) ping -c 3 postgres
docker exec $(docker ps -q -f name=n8n_n8n | head -1) ping -c 3 redis

# Test DNS resolution
docker exec $(docker ps -q -f name=traefik_traefik | head -1) nslookup postgres
docker exec $(docker ps -q -f name=traefik_traefik | head -1) nslookup redis
```

- [ ] Internal networks functional: ⬜
- [ ] DNS resolution working: ⬜
- [ ] No packet loss: ⬜

## 🚀 Performance Tests

### 1. Load Testing (10 minutes)

```javascript
// k6-load-test.js
import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  stages: [
    { duration: '1m', target: 50 },  // Ramp up to 50 users
    { duration: '3m', target: 50 },  // Stay at 50 users
    { duration: '1m', target: 100 }, // Ramp up to 100 users
    { duration: '3m', target: 100 }, // Stay at 100 users
    { duration: '1m', target: 0 },   // Ramp down
  ],
  thresholds: {
    http_req_duration: ['p(95)<500'], // 95% of requests < 500ms
    http_req_failed: ['rate<0.1'],    // Error rate < 10%
  },
};

export default function () {
  const res = http.get('https://staging.macspark.dev');
  check(res, {
    'status is 200': (r) => r.status === 200,
    'response time < 500ms': (r) => r.timings.duration < 500,
  });
  sleep(1);
}
```

```bash
k6 run k6-load-test.js
```

- [ ] P95 latency < 500ms: ⬜
- [ ] P99 latency < 1000ms: ⬜
- [ ] Error rate < 1%: ⬜
- [ ] Throughput > 100 req/s: ⬜

### 2. Database Performance (5 minutes)

```sql
-- PostgreSQL performance test
CREATE TABLE perf_test (
  id SERIAL PRIMARY KEY,
  data TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Insert 10000 records
INSERT INTO perf_test (data)
SELECT md5(random()::text)
FROM generate_series(1, 10000);

-- Query performance
EXPLAIN ANALYZE SELECT * FROM perf_test WHERE id < 1000;
EXPLAIN ANALYZE SELECT COUNT(*) FROM perf_test;

-- Cleanup
DROP TABLE perf_test;
```

- [ ] Insert rate > 1000/s: ⬜
- [ ] Query time < 100ms: ⬜
- [ ] No slow queries: ⬜

## 🔒 Security Validation

### 1. Container Security (10 minutes)

```bash
# Scan images with Trivy
for image in $(docker ps --format "{{.Image}}" | sort -u); do
  echo "Scanning $image..."
  trivy image --severity HIGH,CRITICAL "$image"
done

# Check for running as root
docker ps --format "table {{.Names}}\t{{.Image}}" | while read name image; do
  user=$(docker exec $name whoami 2>/dev/null)
  if [ "$user" = "root" ]; then
    echo "WARNING: $name running as root"
  fi
done
```

- [ ] No CRITICAL vulnerabilities: ⬜
- [ ] No HIGH vulnerabilities: ⬜
- [ ] No containers running as root: ⬜
- [ ] All images from trusted registry: ⬜

### 2. Secret Management (5 minutes)

```bash
# Verify no hardcoded secrets
grep -r "PASSWORD\|SECRET\|KEY\|TOKEN" stacks/ | grep -v "docker secret"

# Check Docker secrets
docker secret ls

# Verify Vault integration
docker exec $(docker ps -q -f name=vault_vault) vault status
```

- [ ] No hardcoded secrets: ⬜
- [ ] All secrets in Docker/Vault: ⬜
- [ ] Vault unsealed: ⬜
- [ ] Secret rotation configured: ⬜

### 3. Network Security (5 minutes)

```bash
# Check exposed ports
docker ps --format "table {{.Names}}\t{{.Ports}}"

# Verify firewall rules
iptables -L -n | grep -E "ACCEPT|DROP|REJECT"

# Test unauthorized access
curl -f http://staging.macspark.dev:5432 2>&1 | grep -q "refused" && echo "✅ PostgreSQL not exposed"
curl -f http://staging.macspark.dev:6379 2>&1 | grep -q "refused" && echo "✅ Redis not exposed"
```

- [ ] Only 80/443 exposed externally: ⬜
- [ ] Database ports protected: ⬜
- [ ] Firewall rules active: ⬜

## 📊 Monitoring Validation

### 1. Metrics Collection (5 minutes)

```bash
# Check Prometheus targets
curl -s https://prometheus.staging.macspark.dev/api/v1/targets | jq '.data.activeTargets[] | {job: .labels.job, health: .health}'

# Verify metrics
curl -s https://prometheus.staging.macspark.dev/api/v1/query?query=up | jq '.data.result[] | {job: .metric.job, up: .value[1]}'
```

- [ ] All targets scraped: ⬜
- [ ] No missing metrics: ⬜
- [ ] Retention configured: ⬜

### 2. Log Aggregation (5 minutes)

```bash
# Check Loki data sources
curl -s https://grafana.staging.macspark.dev/api/datasources | jq '.[] | {name: .name, type: .type}'

# Query recent logs
curl -G -s "https://loki.staging.macspark.dev/loki/api/v1/query_range" \
  --data-urlencode 'query={job="docker"}' \
  --data-urlencode 'limit=10'
```

- [ ] Loki receiving logs: ⬜
- [ ] All services logging: ⬜
- [ ] No log errors: ⬜

### 3. Dashboards & Alerts (5 minutes)

- [ ] Grafana dashboards loaded: ⬜
- [ ] Alert rules configured: ⬜
- [ ] Notification channels tested: ⬜

## 🔄 Failover Testing

### 1. Service Resilience (10 minutes)

```bash
# Kill a container and verify restart
docker kill $(docker ps -q -f name=n8n_n8n | head -1)
sleep 30
docker service ps n8n_n8n

# Scale service and verify
docker service scale n8n_n8n=3
sleep 30
docker service ps n8n_n8n
```

- [ ] Automatic restart working: ⬜
- [ ] Scaling successful: ⬜
- [ ] No data loss: ⬜

### 2. Database Failover (15 minutes)

```bash
# Simulate PostgreSQL primary failure
docker stop $(docker ps -q -f name=postgres_postgres-primary)

# Check failover
sleep 30
docker exec $(docker ps -q -f name=postgres_postgres-standby) psql -U postgres -c "SELECT pg_is_in_recovery();"
```

- [ ] Failover < 30 seconds: ⬜
- [ ] Data consistency maintained: ⬜
- [ ] Applications reconnected: ⬜

### 3. Redis Failover (10 minutes)

```bash
# Simulate Redis master failure
docker stop $(docker ps -q -f name=redis_redis-master)

# Check Sentinel failover
sleep 15
docker exec $(docker ps -q -f name=redis_redis-sentinel) redis-cli -p 26379 SENTINEL masters
```

- [ ] Failover < 15 seconds: ⬜
- [ ] New master elected: ⬜
- [ ] No cache data loss: ⬜

## 📋 Acceptance Criteria

### Mandatory Requirements (Must Pass)

- [ ] **All critical services running**: 7/7 services
- [ ] **Health checks passing**: 100%
- [ ] **SSL/TLS configured**: Valid certificate, TLS 1.3
- [ ] **No critical vulnerabilities**: 0 CRITICAL CVEs
- [ ] **Performance targets met**: P95 < 500ms
- [ ] **Monitoring operational**: Metrics, logs, alerts
- [ ] **Backup configured**: Automated, tested restore
- [ ] **Failover tested**: All services resilient

### Recommended Requirements (Should Pass)

- [ ] **Documentation complete**: All READMEs updated
- [ ] **Runbooks available**: For all critical procedures
- [ ] **Team trained**: Knowledge transfer completed
- [ ] **Cost optimized**: Within budget parameters
- [ ] **Compliance checked**: GDPR, SOC2 requirements

## 🚀 Production Promotion

### Pre-Production Checklist

- [ ] **Staging validation complete**: All tests passed
- [ ] **Performance benchmarked**: Meets SLA requirements
- [ ] **Security review passed**: No blockers identified
- [ ] **Change request approved**: CAB Light approval
- [ ] **Rollback plan ready**: Tested and documented
- [ ] **Team notified**: All stakeholders informed
- [ ] **Monitoring enhanced**: Production alerts configured
- [ ] **Backup verified**: Recent backup available

### Promotion Commands

```bash
# Tag staging images for production
for service in traefik postgres redis n8n evolution vault monitoring; do
  docker tag staging.macspark.dev/${service}:staging macspark.dev/${service}:production
  docker push macspark.dev/${service}:production
done

# Deploy to production
ENV=production make deploy-prod

# Verify production
curl -f https://macspark.dev/health
```

### Post-Deployment Validation

- [ ] **All services healthy**: ⬜
- [ ] **Performance normal**: ⬜
- [ ] **No errors in logs**: ⬜
- [ ] **Users can access**: ⬜
- [ ] **Data integrity verified**: ⬜

## 📈 Success Metrics

| Metric | Target | Actual | Status |
|--------|--------|--------|--------|
| **Deployment Time** | < 30 min | - | ⬜ |
| **Service Availability** | 99.9% | - | ⬜ |
| **Response Time P95** | < 500ms | - | ⬜ |
| **Error Rate** | < 1% | - | ⬜ |
| **Recovery Time** | < 5 min | - | ⬜ |
| **Test Coverage** | > 80% | - | ⬜ |

## 📝 Sign-off

### Validation Team

| Role | Name | Date | Signature |
|------|------|------|-----------|
| DevOps Lead | - | - | ⬜ |
| Security Lead | - | - | ⬜ |
| QA Lead | - | - | ⬜ |
| Product Owner | - | - | ⬜ |

### Decision

- [ ] **APPROVED for Production** ✅
- [ ] **REJECTED - Issues Found** ❌
- [ ] **CONDITIONAL - Minor Issues** ⚠️

### Notes

```
[Add validation notes, issues found, or conditions here]
```

---

**Validation Completed:** _______________  
**Next Review:** _______________  
**Document Version:** 1.0.0

*This checklist must be completed and signed before production deployment.*