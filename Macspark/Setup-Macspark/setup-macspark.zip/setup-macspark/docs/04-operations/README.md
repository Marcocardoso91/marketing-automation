# 🔧 Operações

Guia operacional para manutenção e monitoramento do ambiente MacSpark.

## 📊 Monitoramento

- **[Dashboard Grafana](monitoring-guide.md)** - Visualização de métricas
- **[Alertas](alerts-configuration.md)** - Configuração de alertas
- **[Logs Centralizados](logging-guide.md)** - Análise de logs com Loki

## 🛠️ Manutenção

- **[Backup e Restore](backup-restore.md)** - Procedimentos de backup
- **[Validação de Serviços](critical-services-validation.md)** - Health checks
- **[Troubleshooting](troubleshooting-guide.md)** - Resolução de problemas

## 📚 Runbooks

Procedimentos operacionais padronizados em [runbooks/](runbooks/).

## 🎯 Tarefas Diárias

### Morning Checks
```bash
# Verificar status dos serviços
docker service ls

# Verificar uso de recursos
docker stats

# Verificar logs de erro
docker service logs --tail 100 traefik
```

### Manutenção Preventiva
- Limpeza de logs antigas (semanal)
- Atualização de imagens Docker (mensal)
- Teste de restore (trimestral)
- Disaster recovery drill (anual)

## 📈 KPIs Operacionais

| Métrica | Target | Atual |
|---------|--------|-------|
| Uptime | 99.9% | ✅ |
| Response Time | <200ms | ✅ |
| Error Rate | <0.1% | ✅ |
| Backup Success | 100% | ✅ |

## 🚨 Procedimentos de Emergência

1. **Incidente Crítico**: [Incident Response](incident-response.md)
2. **Disaster Recovery**: [DR Procedures](disaster-recovery.md)
3. **Rollback Emergencial**: [Emergency Rollback](emergency-rollback.md)

## 📞 Escalação

- **N1**: DevOps On-call
- **N2**: Infrastructure Lead
- **N3**: CTO