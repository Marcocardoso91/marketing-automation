# MacSpark Enterprise Backup System 2025

Sistema de backup enterprise modernizado com observabilidade completa, integrado ao Setup-Macspark.

## 📋 Visão Geral

O MacSpark Enterprise Backup System é uma solução completa de backup e disaster recovery que integra múltiplos engines de backup (Kopia, Restic, Borg) com observabilidade enterprise, orquestração Docker Swarm e conformidade regulatória.

### 🎯 Características Principais

- **Multi-Engine**: Kopia, Restic e Borg para redundância
- **Observabilidade Completa**: OpenTelemetry, Prometheus, Grafana, Jaeger
- **Docker Swarm Native**: Integrado à infraestrutura Setup-Macspark
- **Enterprise Grade**: Criptografia, auditoria, conformidade
- **Orquestração Automatizada**: Cron jobs, health checks, notificações
- **Disaster Recovery**: Procedimentos automatizados de recuperação

## 🏗️ Arquitetura

```mermaid
graph TB
    subgraph "MacSpark Infrastructure"
        subgraph "Backup Services"
            K[Kopia Server<br/>Port: 51515]
            R[Restic Server<br/>Port: 8000]
            O[Orchestrator<br/>Cron + Scripts]
            M[Monitor Dashboard<br/>Port: 80]
        end
        
        subgraph "Observability Stack"
            P[Prometheus]
            G[Grafana]
            J[Jaeger]
            L[Loki]
        end
        
        subgraph "Data Sources"
            DB[(PostgreSQL<br/>Redis<br/>MongoDB)]
            DV[Docker Volumes]
            N8N[N8N Workflows]
            CFG[Configurations]
        end
    end
    
    subgraph "External Storage"
        S3[AWS S3]
        GCS[Google Cloud]
        Azure[Azure Blob]
    end
    
    DB --> O
    DV --> O
    N8N --> O
    CFG --> O
    
    O --> K
    O --> R
    
    K --> S3
    R --> GCS
    
    K --> P
    R --> P
    O --> P
    
    P --> G
    J --> G
    L --> G
    
    Traefik --> K
    Traefik --> R
    Traefik --> M
```

## 🚀 Instalação e Deploy

### Pré-requisitos

- Docker Swarm ativo
- Node manager do Swarm
- Redes `traefik-public` e `monitoring`
- Mínimo 10GB espaço livre
- Acesso sudo

### Deploy Completo

```bash
# 1. Clone/atualize o repositório Setup-Macspark
cd /home/marcocardoso/Setup-Macspark

# 2. Execute o deploy enterprise
./scripts/deployment/deploy-backup-enterprise.sh

# 3. Verifique o status
./scripts/deployment/deploy-backup-enterprise.sh --status

# 4. Teste a funcionalidade
docker exec -it backup-enterprise_backup-orchestrator bash
/scripts/core/backup-critical-complete.sh --test
```

### Deploy Personalizado

```bash
# Deploy com configuração específica
ENVIRONMENT=staging ./scripts/deployment/deploy-backup-enterprise.sh

# Apenas verificar deploy existente
./scripts/deployment/deploy-backup-enterprise.sh --verify

# Cleanup completo
./scripts/deployment/deploy-backup-enterprise.sh --cleanup
```

## 🗂️ Estrutura de Arquivos

```
Setup-Macspark/
├── stacks/infrastructure/backup/
│   ├── backup-enterprise-stack.yml      # Stack Docker Swarm
│   ├── configs/
│   │   ├── kopia.json                   # Configuração Kopia
│   │   ├── backup-policies.json         # Políticas de backup
│   │   └── monitoring.yml               # Observabilidade
│   └── dashboard/                       # Dashboard web
│       ├── index.html
│       └── assets/
├── scripts/backup/
│   ├── core/
│   │   ├── backup-critical-complete.sh  # Backup principal
│   │   ├── notification-system.sh       # Sistema notificações
│   │   └── health-check-enterprise.sh   # Health monitoring
│   ├── deployment/
│   │   └── deploy-backup-enterprise.sh  # Deploy automatizado
│   └── maintenance/
└── docs/infrastructure/backup/
    ├── README.md                        # Este arquivo
    ├── ARCHITECTURE.md                  # Arquitetura detalhada
    ├── API.md                          # APIs e endpoints
    └── TROUBLESHOOTING.md              # Resolução problemas
```

## 🔧 Configuração

### Kopia Server

**Configuração:** `/opt/macspark/backup/config/kopia.json`

```json
{
  "repository": {
    "encryption": {
      "algorithm": "AES256-GCM-SCRYPT"
    },
    "compression": {
      "algorithm": "zstd",
      "level": 3
    }
  },
  "policies": {
    "critical": {
      "keep": {
        "hourly": 72,
        "daily": 30,
        "monthly": 36,
        "yearly": 10
      }
    }
  }
}
```

### Políticas de Backup

**Configuração:** `/opt/macspark/backup/config/backup-policies.json`

```json
{
  "backup_sets": {
    "postgresql": {
      "schedule": "*/30 * * * *",
      "policy": "database",
      "compression": "zstd:6",
      "encryption": true
    },
    "n8n_workflows": {
      "schedule": "*/5 * * * *",
      "policy": "critical",
      "compression": "zstd:9"
    }
  }
}
```

## 🔐 Segurança

### Secrets Management

O sistema utiliza Docker Secrets para gerenciar credenciais:

```bash
# Listar secrets
docker secret ls

# Rotacionar password do Kopia
echo "nova_senha_forte" | docker secret create kopia-password-v2 -
docker service update --secret-rm kopia-password --secret-add kopia-password-v2 backup-enterprise_kopia-server
```

### Criptografia

- **At-rest**: AES-256-GCM para repositórios
- **In-transit**: TLS 1.3 para todas comunicações
- **Passwords**: bcrypt + salt para autenticação
- **Keys**: PBKDF2 + Scrypt para derivação

### Auditoria

Logs de auditoria em `/opt/macspark/backup/logs/`:

```bash
# Ver logs de auditoria
tail -f /opt/macspark/backup/logs/health/health-audit.log

# Análise de segurança
grep "CRITICAL\|ERROR" /opt/macspark/backup/logs/notifications/notifications.log
```

## 📊 Monitoramento e Observabilidade

### Métricas Prometheus

**Endpoint:** `http://localhost:9100/metrics`

Principais métricas:

```promql
# Taxa de sucesso de backups
rate(backup_jobs_total{status="success"}[5m])

# Duração média de backups
avg(backup_duration_seconds) by (job_name)

# Espaço de armazenamento
storage_space_available_bytes / storage_space_total_bytes

# Health score do sistema
backup_health_score
```

### Dashboards Grafana

Acesse: `https://grafana.macspark.dev`

**Dashboards disponíveis:**
- MacSpark Backup Overview
- Backup Detailed Analysis  
- Backup Health Monitoring
- Storage & Performance
- Security & Compliance

### Traces Jaeger

Acesse: `https://jaeger.macspark.dev`

**Principais traces:**
- `backup-critical-complete`: Backup completo end-to-end
- `notification-send`: Sistema de notificações
- `health-check`: Verificações de saúde

### Logs Centralizados

**Loki:** `https://grafana.macspark.dev/explore`

```logql
# Logs do sistema de backup
{service="backup-orchestrator"} |= "ERROR"

# Logs de notificações
{service="backup-notifications"} | json

# Performance traces
{service="backup-monitor"} |~ "duration.*[0-9]+s"
```

## 🔔 Sistema de Notificações

### Canais Disponíveis

- **ntfy.sh** (padrão, sem configuração)
- **Email** (SMTP configurável)
- **Telegram** (Bot API)
- **Discord** (Webhook)
- **Slack** (Webhook)
- **Microsoft Teams** (Webhook)
- **PagerDuty** (Enterprise)
- **Webhook** (Custom)

### Configuração

```bash
# Testar todas as notificações
./scripts/backup/core/notification-system.sh --test-enterprise

# Configurar canal específico
nano /opt/macspark/backup/config/notifications.json

# Enviar notificação manual
./scripts/backup/core/notification-system.sh --success-enterprise "Teste" "1GB" "30s"
```

### Templates de Mensagem

```json
{
  "backup_success": "✅ Backup {type} concluído: {size} em {duration}",
  "backup_failure": "🚨 CRÍTICO: Backup {type} falhou: {error}",
  "daily_report": "📊 Relatório diário: {stats}"
}
```

## 🏥 Health Checks e Manutenção

### Health Check Automatizado

**Script:** `/opt/macspark/backup/scripts/core/health-check-enterprise.sh`

**Execução:** A cada 5 minutos via cron

**Verificações:**
- Espaço em disco (filesystems múltiplos)
- Idade dos backups (por tipo)
- Status dos serviços (Docker + sistema)
- Conectividade de rede (endpoints múltiplos)
- Sync com cloud storage
- Recursos do sistema (CPU, RAM, I/O)

### Manutenção Automatizada

```bash
# Executar health check manual
/opt/macspark/backup/scripts/core/health-check-enterprise.sh

# Ver relatório de saúde
cat /opt/macspark/backup/status/health-status.json | jq .

# Manutenção semanal (automática)
/opt/macspark/backup/scripts/maintenance/weekly-maintenance.sh
```

### Troubleshooting

```bash
# Verificar status dos serviços
docker stack services backup-enterprise

# Logs de serviços específicos
docker service logs backup-enterprise_kopia-server
docker service logs backup-enterprise_backup-orchestrator

# Verificar conectividade
docker exec -it backup-enterprise_backup-orchestrator ping kopia-server

# Teste de backup manual
docker exec -it backup-enterprise_backup-orchestrator /scripts/core/backup-critical-complete.sh --test
```

## 📈 Performance e Otimização

### Configurações de Performance

```json
{
  "performance": {
    "parallel_backups": 2,
    "compression_threads": 2,
    "upload_threads": 4,
    "memory_limit_mb": 1024,
    "bandwidth_limit_mbps": 100
  }
}
```

### Otimizações Recomendadas

1. **CPU**: 2+ cores dedicados para backup
2. **Memória**: Mínimo 2GB, ideal 4GB
3. **Storage**: SSD para repositórios locais
4. **Rede**: 100Mbps+ para cloud sync
5. **Compressão**: zstd nível 3-6 (balanço performance/ratio)

### Benchmarking

```bash
# Teste de performance
docker exec -it backup-enterprise_backup-orchestrator /scripts/benchmarks/backup-performance.sh

# Métricas detalhadas
curl http://backup-enterprise_backup-exporter:9100/metrics | grep backup_
```

## 🌐 APIs e Endpoints

### Kopia API

**Base URL:** `https://kopia.macspark.dev/api/v1/`

```bash
# Listar repositórios
curl -H "Authorization: Bearer $KOPIA_TOKEN" https://kopia.macspark.dev/api/v1/repo

# Criar snapshot
curl -X POST -H "Authorization: Bearer $KOPIA_TOKEN" \
  https://kopia.macspark.dev/api/v1/sources/snapshot

# Listar snapshots
curl -H "Authorization: Bearer $KOPIA_TOKEN" \
  https://kopia.macspark.dev/api/v1/snapshots
```

### Restic API

**Base URL:** `https://restic.macspark.dev/`

```bash
# Health check
curl https://restic.macspark.dev/

# Upload backup
curl -X POST --data-binary @backup.tar.gz \
  https://restic.macspark.dev/repository/data/
```

### Monitoring API

**Base URL:** `https://backup.macspark.dev/api/v1/`

```bash
# Status geral
curl https://backup.macspark.dev/api/v1/status

# Métricas específicas  
curl https://backup.macspark.dev/api/v1/metrics?service=kopia

# Health check
curl https://backup.macspark.dev/api/v1/health
```

## 🔄 Disaster Recovery

### Procedimentos de Recuperação

1. **Recuperação Total do Sistema**
```bash
# 1. Deploy da infraestrutura
./scripts/deployment/deploy-backup-enterprise.sh

# 2. Restaurar configurações
docker exec -it backup-enterprise_kopia-server kopia repo restore --target=/opt/macspark/restore

# 3. Restaurar bancos de dados
./scripts/restore/restore-databases.sh --from-backup latest

# 4. Verificar integridade
./scripts/core/health-check-enterprise.sh
```

2. **Recuperação Seletiva**
```bash
# Restaurar apenas PostgreSQL
docker exec -it backup-enterprise_kopia-server \
  kopia restore latest-postgresql --target=/tmp/restore

# Restaurar N8N workflows específicos
./scripts/restore/restore-n8n-workflows.sh --workflow-id 123
```

### RTO/RPO Targets

- **RTO (Recovery Time Objective)**: < 1 hora
- **RPO (Recovery Point Objective)**: < 15 minutos
- **Database RPO**: < 30 minutos
- **Critical Data RPO**: < 5 minutos

## 📋 Conformidade e Auditoria

### Padrões Suportados

- **SOX** (Sarbanes-Oxley)
- **GDPR** (General Data Protection Regulation)
- **HIPAA** (Health Insurance Portability and Accountability Act)
- **ISO 27001** (Information Security Management)

### Recursos de Conformidade

```json
{
  "compliance": {
    "audit_trail": true,
    "retention_enforcement": true,
    "encryption_validation": true,
    "integrity_verification": true,
    "access_logging": true,
    "data_classification": "confidential"
  }
}
```

### Relatórios de Auditoria

```bash
# Relatório de conformidade mensal
./scripts/compliance/generate-compliance-report.sh --month 2025-08

# Verificação de retenção
./scripts/compliance/verify-retention-policy.sh

# Log de acesso detalhado
cat /opt/macspark/backup/logs/health/health-audit.log | jq .
```

## 🆘 Suporte e Troubleshooting

### Problemas Comuns

1. **Serviços não inicializando**
```bash
docker service logs backup-enterprise_kopia-server --tail 50
docker node ls  # Verificar node labels
```

2. **Backup falhou**
```bash
docker exec -it backup-enterprise_backup-orchestrator cat /logs/backup-critical-complete.log
./scripts/core/health-check-enterprise.sh
```

3. **Espaço insuficiente**
```bash
df -h /opt/macspark/backup/
docker system prune -a
find /opt/macspark/backup/logs -mtime +30 -delete
```

### Logs Importantes

- **Deploy**: `/opt/macspark/backup/logs/deployment/`
- **Backup Operations**: `/opt/macspark/backup/logs/backup-history/`
- **Health Checks**: `/opt/macspark/backup/logs/health/`
- **Notifications**: `/opt/macspark/backup/logs/notifications/`
- **Errors**: `/opt/macspark/backup/logs/errors/`

### Contato e Suporte

- **Documentação**: `/home/marcocardoso/Setup-Macspark/docs/infrastructure/backup/`
- **Issues**: GitLab/GitHub issues do projeto Setup-Macspark
- **Monitoring**: Grafana dashboards para diagnóstico visual
- **Logs**: Loki para busca e análise de logs centralizados

---

## 📚 Documentação Adicional

- [Arquitetura Detalhada](./ARCHITECTURE.md)
- [APIs e Endpoints](./API.md)
- [Troubleshooting](./TROUBLESHOOTING.md)
- [Compliance Guide](./COMPLIANCE.md)
- [Performance Tuning](./PERFORMANCE.md)

---

**Desenvolvido pela equipe MacSpark Infrastructure Team**  
**Versão:** 2.0  
**Data:** 2025-08-24  
**Licença:** MIT