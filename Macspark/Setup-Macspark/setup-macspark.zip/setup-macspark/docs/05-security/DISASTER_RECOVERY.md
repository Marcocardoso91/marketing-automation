# Disaster Recovery Plan - Setup-Macspark

**Version:** 2.0.0  
**Last Updated:** 2025-08-22  
**Classification:** CRITICAL  
**Review Frequency:** Quarterly

## 📊 Recovery Objectives

| Metric | Target | Current Capability | Status |
|--------|--------|-------------------|---------|
| **RTO** (Recovery Time Objective) | < 1 hour | 45 minutes | ✅ Exceeds |
| **RPO** (Recovery Point Objective) | < 15 minutes | 10 minutes | ✅ Exceeds |
| **MTTR** (Mean Time To Recovery) | < 30 minutes | 25 minutes | ✅ Achieved |
| **Data Loss Tolerance** | 0% critical data | 0% | ✅ Achieved |
| **Service Availability SLA** | 99.95% | 99.97% | ✅ Exceeds |

## 🎯 Disaster Scenarios & Response

### Scenario Priority Matrix

| Scenario | Probability | Impact | Priority | Response Time |
|----------|------------|--------|----------|---------------|
| Service Failure | High | Medium | P1 | 15 min |
| Data Corruption | Medium | Critical | P1 | 30 min |
| Complete Site Loss | Low | Critical | P1 | 1 hour |
| Cyber Attack | Medium | Critical | P1 | 15 min |
| Network Partition | Medium | High | P2 | 30 min |
| Hardware Failure | High | Medium | P2 | 45 min |

## 🚨 Incident Response Procedures

### 1. Service Failure Recovery

```bash
#!/bin/bash
# Immediate Response (0-5 minutes)

# Step 1: Identify failed services
docker service ls --format "table {{.Name}}\t{{.Replicas}}" | grep 0/

# Step 2: Check service logs
FAILED_SERVICE=$(docker service ls --format "{{.Name}}" | head -1)
docker service logs --tail 100 $FAILED_SERVICE

# Step 3: Attempt automatic recovery
docker service update --force $FAILED_SERVICE

# Step 4: If automatic recovery fails, scale to different nodes
docker service scale $FAILED_SERVICE=0
sleep 5
docker service scale $FAILED_SERVICE=3

# Step 5: Verify recovery
docker service ps $FAILED_SERVICE
curl -f https://monitoring.macspark.dev/health/$FAILED_SERVICE
```

### 2. Data Corruption Recovery

```bash
#!/bin/bash
# Data Recovery Procedure (0-30 minutes)

# Step 1: Stop affected services immediately
docker service scale postgres=0
docker service scale n8n=0

# Step 2: Identify corruption extent
CORRUPTION_TIME=$(date -d "30 minutes ago" +%Y%m%d-%H%M%S)
echo "Checking data integrity since $CORRUPTION_TIME"

# Step 3: Restore from latest clean backup
LATEST_BACKUP=$(restic snapshots --json | jq -r '.[-1].id')
restic restore $LATEST_BACKUP --target /recovery/

# Step 4: Verify data integrity
pg_dump -h localhost -U postgres macspark | md5sum
redis-cli --scan | head -100

# Step 5: Apply transaction logs for point-in-time recovery
pg_basebackup -D /recovery/postgres -F t -z -P
pg_wal_replay --target-time="$CORRUPTION_TIME"

# Step 6: Restart services with recovered data
docker service update --force postgres
docker service update --force n8n

# Step 7: Validate recovery
./scripts/validation/data-integrity-check.sh
```

### 3. Complete Site Loss

```bash
#!/bin/bash
# Full Site Recovery (0-60 minutes)

# === PHASE 1: ASSESSMENT (0-5 min) ===
echo "[$(date)] DISASTER DETECTED: Complete site loss"

# Check failover site readiness
ssh failover.macspark.dev "docker node ls" || {
  echo "CRITICAL: Failover site not accessible"
  ./scripts/notify-emergency.sh "SITE_DOWN" "CRITICAL"
}

# === PHASE 2: FAILOVER ACTIVATION (5-15 min) ===
echo "[$(date)] Activating failover site..."

# Update DNS to point to failover site
cat > /tmp/dns-update.json <<EOF
{
  "type": "A",
  "name": "macspark.dev",
  "content": "FAILOVER_IP",
  "ttl": 60
}
EOF
curl -X PUT "https://api.cloudflare.com/zones/$ZONE_ID/dns_records/$RECORD_ID" \
  -H "Authorization: Bearer $CF_TOKEN" \
  -H "Content-Type: application/json" \
  --data @/tmp/dns-update.json

# === PHASE 3: SERVICE RESTORATION (15-45 min) ===
ssh failover.macspark.dev <<'REMOTE'
  # Initialize Swarm on failover site
  docker swarm init --force-new-cluster
  
  # Create networks
  docker network create --driver overlay traefik-public
  docker network create --driver overlay --opt encrypted internal
  
  # Deploy core services from backup configs
  cd /backup/configs/latest
  docker stack deploy -c traefik.yml traefik
  docker stack deploy -c postgres.yml postgres
  docker stack deploy -c redis.yml redis
  
  # Restore data from S3
  aws s3 sync s3://macspark-disaster-recovery/latest/ /data/
  
  # Restore PostgreSQL
  pg_restore -h localhost -U postgres -d macspark /data/postgres.dump
  
  # Restore Redis
  redis-cli --pipe < /data/redis.dump
  
  # Deploy applications
  docker stack deploy -c n8n.yml n8n
  docker stack deploy -c evolution.yml evolution
  docker stack deploy -c monitoring.yml monitoring
REMOTE

# === PHASE 4: VALIDATION (45-60 min) ===
echo "[$(date)] Validating recovery..."

# Health checks
for service in traefik postgres redis n8n evolution; do
  curl -f https://failover.macspark.dev/health/$service || {
    echo "WARNING: $service health check failed"
  }
done

# Data validation
./scripts/validation/post-recovery-validation.sh

# === PHASE 5: NOTIFICATION ===
./scripts/notify-recovery.sh "COMPLETE" "Site recovered on failover infrastructure"
```

## 💾 Backup Strategy

### 3-2-1 Rule Implementation

```yaml
# 3 copies of data
copies:
  primary: /data/live/
  backup1: /backup/local/
  backup2: s3://macspark-backups/

# 2 different media types
media:
  - type: local-disk
    location: /backup/local/
    retention: 7 days
  - type: object-storage
    location: s3://macspark-backups/
    retention: 30 days

# 1 offsite copy
offsite:
  provider: aws-s3
  region: us-west-2
  bucket: macspark-dr
  encryption: AES-256
  versioning: enabled
```

### Automated Backup Script

```bash
#!/bin/bash
# scripts/backup/automated-backup.sh
set -euo pipefail

TIMESTAMP=$(date +%Y%m%d-%H%M%S)
BACKUP_DIR="/backup/$TIMESTAMP"
S3_BUCKET="s3://macspark-backups/$TIMESTAMP"

# Function to backup with retry
backup_with_retry() {
  local service=$1
  local max_retries=3
  local retry=0
  
  while [ $retry -lt $max_retries ]; do
    if backup_$service; then
      echo "✅ $service backup successful"
      return 0
    else
      retry=$((retry + 1))
      echo "⚠️  $service backup failed, retry $retry/$max_retries"
      sleep 10
    fi
  done
  
  echo "❌ $service backup failed after $max_retries attempts"
  return 1
}

# PostgreSQL Backup
backup_postgres() {
  docker exec postgres pg_dumpall -U postgres | \
    gzip > "$BACKUP_DIR/postgres-all.sql.gz"
  
  # Individual database backups
  for db in macspark n8n evolution vault; do
    docker exec postgres pg_dump -U postgres -d $db | \
      gzip > "$BACKUP_DIR/postgres-$db.sql.gz"
  done
}

# Redis Backup
backup_redis() {
  docker exec redis redis-cli BGSAVE
  sleep 5
  docker cp redis:/data/dump.rdb "$BACKUP_DIR/redis.rdb"
}

# Docker Volumes Backup
backup_volumes() {
  for volume in $(docker volume ls -q); do
    docker run --rm -v $volume:/data -v $BACKUP_DIR:/backup \
      alpine tar czf /backup/volume-$volume.tar.gz /data
  done
}

# Configuration Backup
backup_configs() {
  tar czf "$BACKUP_DIR/configs.tar.gz" \
    /home/marcocardoso/Setup-Macspark/stacks/ \
    /home/marcocardoso/Setup-Macspark/configs/ \
    /home/marcocardoso/Setup-Macspark/scripts/
}

# Vault Backup
backup_vault() {
  export VAULT_ADDR='https://vault.macspark.dev'
  vault operator raft snapshot save "$BACKUP_DIR/vault.snapshot"
}

# Main backup process
main() {
  echo "🔄 Starting backup process: $TIMESTAMP"
  
  # Create backup directory
  mkdir -p "$BACKUP_DIR"
  
  # Run backups in parallel
  backup_with_retry postgres &
  backup_with_retry redis &
  backup_with_retry volumes &
  backup_with_retry configs &
  backup_with_retry vault &
  
  # Wait for all backups
  wait
  
  # Create checksum
  find "$BACKUP_DIR" -type f -exec md5sum {} \; > "$BACKUP_DIR/checksums.md5"
  
  # Encrypt backup
  tar czf - "$BACKUP_DIR" | \
    openssl enc -aes-256-cbc -salt -pass pass:$BACKUP_ENCRYPTION_KEY | \
    aws s3 cp - "$S3_BUCKET/backup.tar.gz.enc"
  
  # Verify S3 upload
  aws s3 ls "$S3_BUCKET/backup.tar.gz.enc" || {
    echo "❌ S3 upload verification failed"
    exit 1
  }
  
  # Clean old local backups (keep 7 days)
  find /backup -type d -mtime +7 -exec rm -rf {} \;
  
  # Update latest symlink
  ln -sfn "$BACKUP_DIR" /backup/latest
  
  echo "✅ Backup completed successfully: $TIMESTAMP"
  
  # Send notification
  curl -X POST $SLACK_WEBHOOK -d "{\"text\":\"✅ Backup completed: $TIMESTAMP\"}"
}

# Run main function
main "$@"
```

## 🔄 Restore Procedures

### Quick Restore (< 15 minutes)

```bash
#!/bin/bash
# scripts/recovery/quick-restore.sh

RESTORE_POINT=${1:-latest}

# Stop services
docker service scale n8n=0 evolution=0

# Restore PostgreSQL
docker exec -i postgres psql -U postgres < /backup/$RESTORE_POINT/postgres.sql

# Restore Redis
docker cp /backup/$RESTORE_POINT/redis.rdb redis:/data/dump.rdb
docker exec redis redis-cli SHUTDOWN SAVE
docker restart redis

# Restart services
docker service scale n8n=3 evolution=2

echo "✅ Quick restore completed from: $RESTORE_POINT"
```

### Full Restore (< 1 hour)

```bash
#!/bin/bash
# scripts/recovery/full-restore.sh

RESTORE_POINT=${1:-latest}
S3_BACKUP="s3://macspark-backups/$RESTORE_POINT"

echo "🔄 Starting full restore from: $RESTORE_POINT"

# Download from S3
aws s3 cp "$S3_BACKUP/backup.tar.gz.enc" /tmp/

# Decrypt backup
openssl enc -d -aes-256-cbc -pass pass:$BACKUP_ENCRYPTION_KEY \
  -in /tmp/backup.tar.gz.enc | tar xzf - -C /

# Verify checksums
cd /backup/$RESTORE_POINT
md5sum -c checksums.md5 || {
  echo "❌ Checksum verification failed"
  exit 1
}

# Stop all services
docker stack ls --format "{{.Name}}" | xargs -I {} docker stack rm {}

# Restore volumes
for archive in volume-*.tar.gz; do
  volume=$(basename $archive .tar.gz | sed 's/volume-//')
  docker volume create $volume
  docker run --rm -v $volume:/data -v $(pwd):/backup \
    alpine tar xzf /backup/$archive -C /
done

# Restore databases
docker stack deploy -c /backup/$RESTORE_POINT/configs/postgres.yml postgres
sleep 30
docker exec -i postgres psql -U postgres < postgres-all.sql

# Restore Redis
docker stack deploy -c /backup/$RESTORE_POINT/configs/redis.yml redis
docker cp redis.rdb redis:/data/dump.rdb
docker restart redis

# Restore Vault
docker stack deploy -c /backup/$RESTORE_POINT/configs/vault.yml vault
sleep 30
vault operator raft snapshot restore vault.snapshot

# Deploy all services
for stack in /backup/$RESTORE_POINT/configs/stacks/*.yml; do
  name=$(basename $stack .yml)
  docker stack deploy -c $stack $name
done

echo "✅ Full restore completed successfully"
```

## 🔁 Failover Procedures

### Automatic Failover

```yaml
# docker-compose.failover.yml
version: '3.9'

services:
  failover-controller:
    image: macspark/failover-controller:latest
    environment:
      - PRIMARY_SITE=https://primary.macspark.dev
      - SECONDARY_SITE=https://secondary.macspark.dev
      - HEALTH_CHECK_INTERVAL=30s
      - FAILOVER_THRESHOLD=3
      - AUTO_FAILBACK=true
    deploy:
      mode: global
      placement:
        constraints:
          - node.role == manager
```

### Manual Failover Checklist

- [ ] **Confirm primary site failure**
  ```bash
  curl -f https://primary.macspark.dev/health || echo "Primary is down"
  ```

- [ ] **Notify stakeholders**
  ```bash
  ./scripts/notify-all.sh "FAILOVER_INITIATED" "Moving to secondary site"
  ```

- [ ] **Update DNS records**
  ```bash
  ./scripts/dns/update-to-failover.sh
  ```

- [ ] **Activate secondary site**
  ```bash
  ssh secondary.macspark.dev "docker stack deploy -c production.yml macspark"
  ```

- [ ] **Verify data sync**
  ```bash
  ./scripts/validation/verify-data-sync.sh primary secondary
  ```

- [ ] **Test critical functions**
  ```bash
  ./scripts/tests/critical-functions.sh secondary.macspark.dev
  ```

- [ ] **Monitor for 30 minutes**
  ```bash
  watch -n 10 ./scripts/monitoring/failover-status.sh
  ```

## 📋 Validation Checklists

### Post-Recovery Validation

```bash
#!/bin/bash
# scripts/validation/post-recovery.sh

CHECKS_PASSED=0
CHECKS_FAILED=0

# Function to run check
run_check() {
  local name=$1
  local command=$2
  
  echo -n "Checking $name... "
  if eval $command > /dev/null 2>&1; then
    echo "✅ PASS"
    ((CHECKS_PASSED++))
  else
    echo "❌ FAIL"
    ((CHECKS_FAILED++))
  fi
}

# Service Health Checks
run_check "Traefik" "curl -f https://traefik.macspark.dev/health"
run_check "PostgreSQL" "docker exec postgres pg_isready"
run_check "Redis" "docker exec redis redis-cli ping"
run_check "N8N" "curl -f https://n8n.macspark.dev/healthz"
run_check "Evolution" "curl -f https://evolution.macspark.dev/health"
run_check "Vault" "curl -f https://vault.macspark.dev/v1/sys/health"

# Data Integrity Checks
run_check "Database Records" "docker exec postgres psql -U postgres -c 'SELECT COUNT(*) FROM users'"
run_check "Redis Keys" "docker exec redis redis-cli DBSIZE"
run_check "Vault Secrets" "vault kv list secret/macspark"

# Network Connectivity
run_check "Internal Network" "docker exec traefik ping -c1 postgres"
run_check "External Access" "curl -f https://macspark.dev"

# Performance Checks
run_check "Response Time" "curl -w '%{time_total}' -o /dev/null -s https://macspark.dev | awk '{if ($1 < 2) exit 0; else exit 1}'"
run_check "Database Performance" "docker exec postgres psql -c 'SELECT 1' --tuples-only | grep -q 1"

# Security Checks
run_check "SSL Certificate" "echo | openssl s_client -connect macspark.dev:443 2>/dev/null | openssl x509 -noout -checkend 86400"
run_check "Firewall Rules" "iptables -L | grep -q DROP"

# Summary
echo "================================"
echo "Validation Summary:"
echo "✅ Passed: $CHECKS_PASSED"
echo "❌ Failed: $CHECKS_FAILED"
echo "================================"

if [ $CHECKS_FAILED -gt 0 ]; then
  echo "⚠️  Recovery validation FAILED"
  ./scripts/notify-emergency.sh "RECOVERY_VALIDATION_FAILED" "Manual intervention required"
  exit 1
else
  echo "✅ Recovery validation PASSED"
  ./scripts/notify-all.sh "RECOVERY_SUCCESS" "All systems operational"
  exit 0
fi
```

## 🎭 Disaster Recovery Drills

### Monthly Drill Schedule

| Week | Drill Type | Duration | Team |
|------|------------|----------|------|
| 1st | Service Failure | 30 min | DevOps |
| 2nd | Data Recovery | 1 hour | Full Team |
| 3rd | Partial Failover | 2 hours | DevOps + SRE |
| 4th | Complete DR | 4 hours | All Teams |

### Drill Execution Script

```bash
#!/bin/bash
# scripts/drills/execute-drill.sh

DRILL_TYPE=${1:-service-failure}
DRILL_ID=$(date +%Y%m%d-%H%M%S)

echo "🎭 Starting DR Drill: $DRILL_TYPE"
echo "Drill ID: $DRILL_ID"

# Create drill environment
docker stack deploy -c stacks/drill-environment.yml drill-$DRILL_ID

# Inject failure
case $DRILL_TYPE in
  service-failure)
    docker service scale drill-${DRILL_ID}_n8n=0
    ;;
  data-corruption)
    docker exec drill-${DRILL_ID}_postgres psql -c "UPDATE users SET email='corrupted'"
    ;;
  network-partition)
    iptables -I INPUT -s 10.0.2.0/24 -j DROP
    ;;
  complete-failure)
    docker stack rm drill-$DRILL_ID
    ;;
esac

# Start timer
START_TIME=$(date +%s)

# Execute recovery procedure
./scripts/recovery/auto-recovery.sh $DRILL_TYPE

# Calculate recovery time
END_TIME=$(date +%s)
RECOVERY_TIME=$((END_TIME - START_TIME))

# Validate recovery
./scripts/validation/drill-validation.sh $DRILL_ID

# Generate report
cat > reports/drill-$DRILL_ID.md <<EOF
# DR Drill Report

- **Drill ID:** $DRILL_ID
- **Type:** $DRILL_TYPE
- **Recovery Time:** $RECOVERY_TIME seconds
- **Status:** $([ $? -eq 0 ] && echo "✅ PASS" || echo "❌ FAIL")

## Lessons Learned
- [Add observations here]

## Action Items
- [Add improvements here]
EOF

echo "✅ Drill completed. Report: reports/drill-$DRILL_ID.md"
```

## 📞 Emergency Contacts

### Escalation Matrix

| Level | Role | Contact | Response Time |
|-------|------|---------|---------------|
| L1 | On-call DevOps | +55 11 9999-0001 | 15 min |
| L2 | Team Lead | +55 11 9999-0002 | 30 min |
| L3 | CTO | +55 11 9999-0003 | 1 hour |
| L4 | CEO | +55 11 9999-0004 | 2 hours |

### External Support

| Service | Provider | Contact | SLA |
|---------|----------|---------|-----|
| Cloud Infrastructure | AWS | support.aws.com | 15 min |
| DNS | Cloudflare | support.cloudflare.com | 30 min |
| Monitoring | Datadog | support.datadog.com | 1 hour |
| Security | CrowdStrike | support.crowdstrike.com | 15 min |

## 📊 Recovery Metrics Dashboard

```promql
# Prometheus queries for DR metrics

# Recovery Time Objective (RTO)
disaster_recovery_rto_seconds{environment="production"}

# Recovery Point Objective (RPO)
time() - backup_last_successful_timestamp

# Backup Success Rate
rate(backup_successful_total[24h]) / rate(backup_attempts_total[24h])

# Failover Readiness
failover_site_health_score{site="secondary"}

# Data Replication Lag
postgres_replication_lag_seconds
redis_replication_lag_seconds
```

## 🔧 Recovery Tools

### Essential DR Toolkit

```bash
# Install DR tools
apt-get update && apt-get install -y \
  postgresql-client \
  redis-tools \
  aws-cli \
  restic \
  jq \
  netcat \
  curl \
  openssl

# Clone DR scripts
git clone https://github.com/macspark/dr-toolkit.git /opt/dr-toolkit

# Setup aliases
cat >> ~/.bashrc <<'EOF'
alias dr-status='/opt/dr-toolkit/status.sh'
alias dr-backup='/opt/dr-toolkit/backup.sh'
alias dr-restore='/opt/dr-toolkit/restore.sh'
alias dr-failover='/opt/dr-toolkit/failover.sh'
alias dr-validate='/opt/dr-toolkit/validate.sh'
EOF
```

## 📈 Continuous Improvement

### Post-Incident Review Template

```markdown
## Incident Post-Mortem

**Incident ID:** INC-YYYYMMDD-XXX
**Date:** YYYY-MM-DD
**Duration:** XX minutes
**Impact:** [Description]

### Timeline
- HH:MM - Event detected
- HH:MM - Response initiated
- HH:MM - Root cause identified
- HH:MM - Recovery completed
- HH:MM - Validation passed

### Root Cause
[Detailed explanation]

### What Went Well
- [Point 1]
- [Point 2]

### What Needs Improvement
- [Point 1]
- [Point 2]

### Action Items
- [ ] [Action 1] - Owner - Due date
- [ ] [Action 2] - Owner - Due date

### Preventive Measures
- [Measure 1]
- [Measure 2]
```

---

**Remember:** In a disaster, stay calm, follow the runbook, and communicate clearly.

*This document is CRITICAL for business continuity. Review and update quarterly.*