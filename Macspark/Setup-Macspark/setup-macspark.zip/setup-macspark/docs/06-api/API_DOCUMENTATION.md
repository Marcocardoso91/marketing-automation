# 📡 API Documentation - SparkOne

Documentação completa da API SparkOne com exemplos práticos, códigos de resposta e fluxos de autenticação.

## 🔗 Base URL

```
Production: https://sparkone.yourdomain.com
Development: http://localhost:8000
```

## 🔐 Autenticação

A API SparkOne utiliza **JWT (JSON Web Tokens)** com refresh tokens para autenticação segura.

### Fluxo de Autenticação

```mermaid
sequenceDiagram
    participant C as Cliente
    participant API as SparkOne API
    participant R as Redis

    C->>API: POST /auth/login
    API->>API: Validar credenciais
    API->>R: Armazenar metadata do token
    API-->>C: Access Token + Refresh Token

    C->>API: GET /agents (com Access Token)
    API->>API: Validar JWT
    API->>R: Verificar se não está blacklisted
    API-->>C: Dados protegidos

    Note over C,API: Token expira após 30 minutos
    C->>API: POST /auth/refresh
    API->>R: Blacklist token antigo
    API-->>C: Novo Access Token + Refresh Token
```

### Headers de Autenticação

```http
Authorization: Bearer <access_token>
Content-Type: application/json
```

## 📚 Endpoints

### 🔐 Autenticação

#### POST /auth/login
Autentica usuário e retorna tokens JWT.

**Request:**
```json
{
  "username": "admin",
  "password": "SuaSenhaSegura123!"
}
```

**Response (200):**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer",
  "expires_in": 1800
}
```

**Errors:**
- `401` - Credenciais inválidas
- `403` - Conta bloqueada
- `429` - Rate limit excedido (5 tentativas/5min)

**cURL Example:**
```bash
curl -X POST https://sparkone.yourdomain.com/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "admin", "password": "SuaSenhaSegura123!"}'
```

#### POST /auth/refresh
Renova access token usando refresh token.

**Request:**
```json
{
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Response (200):**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer",
  "expires_in": 1800
}
```

#### POST /auth/logout
Faz logout e adiciona token à blacklist.

**Headers:** `Authorization: Bearer <token>`

**Response (200):**
```json
{
  "message": "Successfully logged out"
}
```

#### POST /auth/register *(Apenas desenvolvimento)*
Registra novo usuário (desabilitado em produção).

**Request:**
```json
{
  "username": "newuser",
  "email": "user@example.com",
  "password": "SecurePassword123!"
}
```

### 🤖 Agentes IA

#### GET /agents
Lista todos os agentes disponíveis.

**Headers:** `Authorization: Bearer <token>`

**Response (200):**
```json
[
  {
    "name": "backup_agent",
    "type": "backup",
    "status": "idle"
  },
  {
    "name": "security_agent",
    "type": "security",
    "status": "active"
  }
]
```

**Rate Limit:** 100 requests/minute

#### GET /agents/{agent_name}
Obtém informações detalhadas de um agente.

**Headers:** `Authorization: Bearer <token>`

**Response (200):**
```json
{
  "name": "backup_agent",
  "type": "backup",
  "status": "idle",
  "last_execution": "2024-12-22T10:30:00Z",
  "capabilities": ["backup", "restore", "schedule"]
}
```

**Errors:**
- `404` - Agente não encontrado

#### POST /agents/{agent_name}/execute
Executa uma tarefa em um agente específico.

**Headers:** `Authorization: Bearer <token>`

**Request:**
```json
{
  "name": "backup_agent",
  "task": "create_backup",
  "parameters": {
    "type": "full",
    "compression": true
  },
  "priority": 1
}
```

**Response (200):**
```json
{
  "agent_id": "backup_agent_1703248200_admin",
  "status": "queued",
  "execution_time": 0.125,
  "timestamp": "2024-12-22T10:30:00Z"
}
```

**Rate Limit:** 50 requests/minute

### 🔄 Workflows

#### GET /workflows
Lista todos os workflows de automação.

**Headers:** `Authorization: Bearer <token>`

**Response (200):**
```json
[
  {
    "name": "daily_backup",
    "triggers": ["schedule"],
    "actions": [
      {"type": "backup", "target": "database"},
      {"type": "notify", "channel": "telegram"}
    ],
    "enabled": true
  }
]
```

#### POST /workflows
Cria um novo workflow.

**Headers:** `Authorization: Bearer <token>`

**Request:**
```json
{
  "name": "security_scan",
  "triggers": ["manual", "schedule"],
  "actions": [
    {"type": "scan", "target": "all_services"},
    {"type": "report", "format": "json"}
  ],
  "conditions": ["business_hours"],
  "enabled": true
}
```

**Rate Limit:** 20 requests/minute

#### POST /workflows/{workflow_name}/trigger
Dispara um workflow específico.

**Headers:** `Authorization: Bearer <token>`

**Response (200):**
```json
{
  "message": "Workflow security_scan disparado com sucesso",
  "workflow": {
    "name": "security_scan",
    "status": "running"
  },
  "triggered_by": "admin",
  "timestamp": "2024-12-22T10:30:00Z"
}
```

### 🧠 Inteligência Artificial

#### POST /ai/analyze
Executa análise de conteúdo com IA.

**Headers:** `Authorization: Bearer <token>`

**Request:**
```json
{
  "content": "Este é um texto muito positivo sobre o produto!",
  "analysis_type": "sentiment",
  "model": "claude-3-sonnet"
}
```

**Response (200):**
```json
{
  "analysis_type": "sentiment",
  "model": "claude-3-sonnet",
  "result": "Análise sentiment concluída",
  "confidence": 0.95,
  "details": {
    "sentiment": "positive",
    "score": 0.87,
    "emotions": ["joy", "satisfaction"]
  },
  "processed_by": "admin",
  "timestamp": "2024-12-22T10:30:00Z"
}
```

**Tipos de Análise:**
- `sentiment` - Análise de sentimento
- `classification` - Classificação de texto
- `extraction` - Extração de entidades
- `summary` - Resumo de conteúdo

**Rate Limit:** 20 requests/minute

#### POST /ai/generate
Gera conteúdo usando IA.

**Headers:** `Authorization: Bearer <token>`

**Request:**
```json
{
  "prompt": "Escreva um resumo sobre inteligência artificial",
  "model": "claude-3-sonnet",
  "max_tokens": 500
}
```

**Response (200):**
```json
{
  "prompt": "Escreva um resumo sobre inteligência artificial",
  "model": "claude-3-sonnet",
  "generated_content": "A inteligência artificial é uma tecnologia...",
  "tokens_used": 245,
  "generated_by": "admin",
  "timestamp": "2024-12-22T10:30:00Z"
}
```

**Rate Limit:** 10 requests/minute

### 🖥️ Sistema

#### GET /health
Verifica saúde do sistema (público).

**Response (200):**
```json
{
  "status": "healthy",
  "timestamp": "2024-12-22T10:30:00Z",
  "version": "1.0.0",
  "environment": "production",
  "agents_count": 4,
  "workflows_count": 3,
  "queue_size": 0,
  "security": {
    "auth_enabled": true,
    "rate_limiting_enabled": true,
    "audit_logging_enabled": true
  }
}
```

**Rate Limit:** 200 requests/minute

#### GET /metrics
Métricas Prometheus (público).

**Response (200):**
```
# HELP sparkone_requests_total Total requests
# TYPE sparkone_requests_total counter
sparkone_requests_total{method="GET",endpoint="/health",status="200"} 1234
...
```

#### GET /system/status
Status detalhado do sistema (autenticado).

**Headers:** `Authorization: Bearer <token>`

**Response (200):**
```json
{
  "system": "SparkOne",
  "status": "operational",
  "version": "1.0.0",
  "environment": "production",
  "uptime": "5 days, 14 hours",
  "components": {
    "agents": {"status": "active", "count": 4},
    "workflows": {"status": "active", "count": 3},
    "queue": {"status": "active", "size": 0},
    "auth": {"status": "active", "type": "JWT"},
    "rate_limiting": {"status": "active", "type": "Redis"}
  },
  "requested_by": "admin",
  "timestamp": "2024-12-22T10:30:00Z"
}
```

#### POST /system/optimize
Otimiza o sistema (apenas superusuários).

**Headers:** `Authorization: Bearer <token>`

**Response (200):**
```json
{
  "message": "Otimização do sistema iniciada",
  "optimizations": [
    "Limpeza de cache",
    "Compactação de logs",
    "Otimização de memória"
  ],
  "initiated_by": "admin",
  "timestamp": "2024-12-22T10:30:00Z"
}
```

**Rate Limit:** 5 requests/5 minutes

### 👨‍💼 Administração

#### GET /admin/agents
Lista detalhada de agentes (apenas admins).

**Headers:** `Authorization: Bearer <token>`

**Response (200):**
```json
{
  "agents": {
    "backup_agent": {
      "name": "backup_agent",
      "type": "backup",
      "status": "idle",
      "last_execution": "2024-12-22T08:00:00Z",
      "total_executions": 150,
      "success_rate": 0.99
    }
  },
  "total": 4,
  "accessed_by": "admin",
  "timestamp": "2024-12-22T10:30:00Z"
}
```

#### POST /admin/agents/{name}/stop
Para um agente específico (apenas admins).

**Headers:** `Authorization: Bearer <token>`

**Response (200):**
```json
{
  "message": "Agente backup_agent parado com sucesso",
  "agent": {
    "name": "backup_agent",
    "status": "stopped"
  },
  "stopped_by": "admin",
  "timestamp": "2024-12-22T10:30:00Z"
}
```

## 📊 Rate Limiting

A API implementa rate limiting avançado para proteger contra abuso:

| Endpoint | Limite | Janela | Estratégia |
|----------|--------|--------|------------|
| `/auth/login` | 5 requests | 5 minutos | Token Bucket |
| `/auth/refresh` | 10 requests | 1 minuto | Sliding Window |
| `/agents/*` | 100 requests | 1 minuto | Sliding Window |
| `/ai/*` | 20 requests | 1 minuto | Fixed Window |
| `/admin/*` | 50 requests | 1 minuto | Sliding Window |

### Headers de Rate Limit

```http
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1703248800
Retry-After: 60
```

## ❌ Códigos de Erro

| Código | Descrição | Exemplo |
|--------|-----------|---------|
| 400 | Bad Request | Dados inválidos |
| 401 | Unauthorized | Token inválido/expirado |
| 403 | Forbidden | Permissões insuficientes |
| 404 | Not Found | Recurso não encontrado |
| 422 | Validation Error | Dados não passaram na validação |
| 429 | Too Many Requests | Rate limit excedido |
| 500 | Internal Server Error | Erro interno do servidor |

### Formato de Erro Padrão

```json
{
  "detail": "Could not validate credentials",
  "error_code": "INVALID_TOKEN",
  "timestamp": "2024-12-22T10:30:00Z",
  "path": "/agents",
  "method": "GET"
}
```

## 🔒 Segurança

### Headers de Segurança

Todas as respostas incluem headers de segurança:

```http
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
X-XSS-Protection: 1; mode=block
Strict-Transport-Security: max-age=31536000; includeSubDomains
Content-Security-Policy: default-src 'self'
```

### Audit Logging

Todas as operações sensíveis são logadas:

```json
{
  "timestamp": "2024-12-22T10:30:00Z",
  "user": "admin",
  "action": "agent_execution",
  "resource": "backup_agent",
  "ip_address": "192.168.1.100",
  "user_agent": "curl/7.68.0",
  "success": true
}
```

## 📝 Exemplos Práticos

### Fluxo Completo de Autenticação

```bash
#!/bin/bash

# 1. Login
TOKEN_RESPONSE=$(curl -s -X POST https://sparkone.yourdomain.com/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "admin", "password": "SuaSenhaSegura123!"}')

ACCESS_TOKEN=$(echo $TOKEN_RESPONSE | jq -r '.access_token')
REFRESH_TOKEN=$(echo $TOKEN_RESPONSE | jq -r '.refresh_token')

# 2. Usar API autenticada
curl -H "Authorization: Bearer $ACCESS_TOKEN" \
  https://sparkone.yourdomain.com/agents

# 3. Refresh token quando necessário
NEW_TOKEN_RESPONSE=$(curl -s -X POST https://sparkone.yourdomain.com/auth/refresh \
  -H "Content-Type: application/json" \
  -d "{\"refresh_token\": \"$REFRESH_TOKEN\"}")

# 4. Logout
curl -X POST https://sparkone.yourdomain.com/auth/logout \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

### Executar Análise de IA

```python
import requests
import json

# Configuração
API_BASE = "https://sparkone.yourdomain.com"
USERNAME = "admin"
PASSWORD = "SuaSenhaSegura123!"

# Login
login_response = requests.post(f"{API_BASE}/auth/login", json={
    "username": USERNAME,
    "password": PASSWORD
})
tokens = login_response.json()
headers = {"Authorization": f"Bearer {tokens['access_token']}"}

# Análise de sentimento
analysis_response = requests.post(f"{API_BASE}/ai/analyze", 
    headers=headers,
    json={
        "content": "Este produto é incrível! Estou muito satisfeito.",
        "analysis_type": "sentiment",
        "model": "claude-3-sonnet"
    }
)

result = analysis_response.json()
print(f"Sentimento: {result['details']['sentiment']}")
print(f"Confiança: {result['confidence']}")
```

### Monitoramento com Python

```python
import requests
import time

def monitor_api_health():
    try:
        response = requests.get("https://sparkone.yourdomain.com/health", timeout=5)
        data = response.json()
        
        if data["status"] == "healthy":
            print(f"✅ API saudável - {data['agents_count']} agentes ativos")
        else:
            print(f"❌ API com problemas - Status: {data['status']}")
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Erro de conectividade: {e}")

# Monitorar a cada 30 segundos
while True:
    monitor_api_health()
    time.sleep(30)
```

## 🔧 SDKs e Bibliotecas

### JavaScript/TypeScript

```javascript
class SparkOneClient {
  constructor(baseUrl, username, password) {
    this.baseUrl = baseUrl;
    this.username = username;
    this.password = password;
    this.accessToken = null;
    this.refreshToken = null;
  }

  async login() {
    const response = await fetch(`${this.baseUrl}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: this.username,
        password: this.password
      })
    });
    
    const data = await response.json();
    this.accessToken = data.access_token;
    this.refreshToken = data.refresh_token;
    return data;
  }

  async apiCall(endpoint, options = {}) {
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      ...options,
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Content-Type': 'application/json',
        ...options.headers
      }
    });
    
    if (response.status === 401) {
      await this.refreshAccessToken();
      return this.apiCall(endpoint, options);
    }
    
    return response.json();
  }
}
```

### Python

```python
import requests
from typing import Dict, Any, Optional

class SparkOneClient:
    def __init__(self, base_url: str, username: str, password: str):
        self.base_url = base_url.rstrip('/')
        self.username = username
        self.password = password
        self.access_token: Optional[str] = None
        self.refresh_token: Optional[str] = None
        self.session = requests.Session()

    def login(self) -> Dict[str, Any]:
        response = self.session.post(f"{self.base_url}/auth/login", json={
            "username": self.username,
            "password": self.password
        })
        response.raise_for_status()
        
        data = response.json()
        self.access_token = data["access_token"]
        self.refresh_token = data["refresh_token"]
        
        self.session.headers.update({
            "Authorization": f"Bearer {self.access_token}"
        })
        
        return data

    def list_agents(self) -> List[Dict[str, Any]]:
        response = self.session.get(f"{self.base_url}/agents")
        response.raise_for_status()
        return response.json()

    def execute_agent(self, agent_name: str, task: str, parameters: Dict = None) -> Dict[str, Any]:
        payload = {
            "name": agent_name,
            "task": task,
            "parameters": parameters or {},
            "priority": 1
        }
        
        response = self.session.post(f"{self.base_url}/agents/{agent_name}/execute", json=payload)
        response.raise_for_status()
        return response.json()
```

---

## 📞 Suporte

- **Documentação**: [GitHub Wiki](https://github.com/Marcocardoso28/Macspark-Setup/wiki)
- **Issues**: [GitHub Issues](https://github.com/Marcocardoso28/Macspark-Setup/issues)
- **Email**: api-support@macspark.dev

---

*Documentação atualizada em: Dezembro 2024*
*Versão da API: 1.0.0* 