# 🤖 Guia de Configuração de Automação - Macspark Setup 2025

## 📋 Visão Geral

Este guia fornece instruções completas para configurar e utilizar os serviços de automação no Macspark Setup, incluindo N8N, Activepieces, Windmill, Huginn e Automatisch.

## 🛠️ Serviços Disponíveis

### 1. **N8N** - Workflow Automation Leader
- **URL**: https://automacao.seudominio.com
- **Descrição**: Plataforma visual para criação de workflows
- **Ideal para**: Automações complexas, integrações API
- **Recursos**: 400+ integrações, interface visual, suporte a código

### 2. **Activepieces** - Modern Open Source
- **URL**: https://activepieces.seudominio.com  
- **Descrição**: Alternativa moderna ao Zapier
- **Ideal para**: Automações simples e rápidas
- **Recursos**: Interface intuitiva, alta performance

### 3. **Windmill** - Developer-Focused
- **URL**: https://windmill.seudominio.com
- **Descrição**: Engine de workflows com suporte a scripts
- **Ideal para**: Desenvolvedores, automações customizadas
- **Recursos**: Python, JavaScript, SQL nativo

### 4. **Huginn** - Agent-Based Automation
- **URL**: https://huginn.seudominio.com
- **Descrição**: Sistema baseado em agentes para automação
- **Ideal para**: Monitoramento, coleta de dados
- **Recursos**: Agentes especializados, muito flexível

### 5. **Automatisch** - Simplified Alternative
- **URL**: https://automatisch.seudominio.com
- **Descrição**: Alternativa simples ao Zapier
- **Ideal para**: Usuários iniciantes
- **Recursos**: Interface limpa, configuração fácil

## 🚀 Instalação Rápida

### Opção 1: Instalação Completa (Recomendada)
```bash
cd /opt/Macspark-Setup
sudo bash scripts/install-automation.sh --complete
```

### Opção 2: Instalação Interativa
```bash
cd /opt/Macspark-Setup  
sudo bash scripts/install-automation.sh
```

### Opção 3: Serviços Específicos
```bash
# Apenas N8N
sudo bash scripts/install-automation.sh --n8n

# Apenas Activepieces
sudo bash scripts/install-automation.sh --activepieces
```

## ⚙️ Configuração Manual

### 1. Preparar Ambiente
```bash
# Verificar Docker Swarm
docker info | grep Swarm

# Criar diretórios
sudo mkdir -p /opt/macspark/volumes/automation/{n8n,activepieces,windmill}
sudo chown -R 1000:1000 /opt/macspark/volumes/automation/
```

### 2. Configurar Variáveis de Ambiente
```bash
# Editar arquivo de configuração
sudo nano /opt/macspark/config/.env

# Adicionar variáveis necessárias:
N8N_PASSWORD=senha_segura_123
HUGINN_PASSWORD=outra_senha_segura
ACTIVEPIECES_ENCRYPTION_KEY=chave_criptografia_longa
```

### 3. Deploy dos Serviços
```bash
cd /opt/Macspark-Setup

# Deploy do stack completo
docker stack deploy -c stacks/apps/automation-stack.yml automation

# Verificar status
docker service ls | grep automation
```

## 🔧 Configuração Pós-Instalação

### N8N - Configuração Inicial

1. **Acesse**: https://automacao.seudominio.com
2. **Login**: admin / [senha gerada]
3. **Primeiro Workflow**:
   ```
   1. Clique em "Create Workflow"
   2. Adicione trigger "Webhook"
   3. Configure URL: https://automacao.seudominio.com/webhook/test
   4. Adicione action desejada
   5. Salve e ative o workflow
   ```

### Activepieces - Setup

1. **Acesse**: https://activepieces.seudominio.com
2. **Criar conta** (primeiro usuário será admin)
3. **Configurar primeiro flow**:
   ```
   1. "Create Flow"
   2. Escolha trigger (ex: Webhook, Schedule)
   3. Adicione steps/actions
   4. Publish flow
   ```

### Windmill - Configuração de Scripts

1. **Acesse**: https://windmill.seudominio.com
2. **Login** com credenciais geradas
3. **Criar primeiro script**:
   ```python
   # Exemplo de script Python
   def main(name: str = "World"):
       return f"Hello {name}!"
   ```

## 📊 Monitoramento e Manutenção

### Verificar Status dos Serviços
```bash
# Status geral
docker service ls | grep automation

# Logs específicos
docker service logs -f automation_n8n
docker service logs -f automation_activepieces

# Verificar recursos
docker stats --no-stream | grep automation
```

### Backup dos Workflows

#### N8N
```bash
# Backup automático
docker exec $(docker ps -q -f name=automation_n8n) \
  n8n export:all --output=/files/backup-$(date +%Y%m%d).json

# Restore
docker exec $(docker ps -q -f name=automation_n8n) \
  n8n import:all --input=/files/backup-20250120.json
```

#### Activepieces
```bash
# Backup do banco
docker exec $(docker ps -q -f name=postgres) \
  pg_dump -U postgres activepieces > activepieces-backup.sql
```

### Atualização dos Serviços
```bash
# Atualizar imagens
docker service update --image n8nio/n8n:latest automation_n8n
docker service update --image activepieces/activepieces:latest automation_activepieces

# Ou redeployar stack completo
docker stack deploy -c stacks/apps/automation-stack.yml automation
```

## 🔒 Segurança

### Headers de Segurança
Todos os serviços estão configurados com:
- HTTPS obrigatório via Traefik
- Headers de segurança automáticos
- Rate limiting
- Autenticação básica onde aplicável

### Credenciais Seguras
```bash
# Ver senhas geradas
sudo cat /opt/macspark/config/.env | grep -E "(PASSWORD|KEY)"

# Rotar senhas
sudo openssl rand -base64 32 > nova_senha.txt
```

### Firewall e Acesso
```bash
# Verificar regras de firewall
sudo ufw status

# Apenas via Cloudflare Tunnel (servidor doméstico)
# Não é necessário abrir portas adicionais
```

## 🔗 Integrações Populares

### N8N - Workflows Essenciais

#### 1. Webhook → Slack/Discord
```
Trigger: Webhook
Action: Slack/Discord → Send Message
Config: Configure webhook URL e token do bot
```

#### 2. Email → Trello/Notion
```
Trigger: Email (IMAP)
Transform: Extract data
Action: Trello → Create Card / Notion → Create Page
```

#### 3. GitHub → Discord/Slack
```
Trigger: GitHub Webhook
Transform: Format message
Action: Discord/Slack notification
```

### Activepieces - Flows Básicos

#### 1. Form Submission → Email + Spreadsheet
```
Trigger: Webhook/Form
Actions: 
  - Send Email
  - Add to Google Sheets
```

#### 2. RSS → Social Media
```
Trigger: RSS Feed
Transform: Format content
Action: Post to Twitter/LinkedIn
```

### Windmill - Scripts Úteis

#### 1. Data Processing
```python
import pandas as pd

def process_csv(file_path: str):
    df = pd.read_csv(file_path)
    # Process data
    return df.to_dict()
```

#### 2. API Integration
```python
import httpx

def call_api(endpoint: str, data: dict):
    response = httpx.post(endpoint, json=data)
    return response.json()
```

## 🆘 Troubleshooting

### Problemas Comuns

#### Serviço não inicia
```bash
# Verificar logs
docker service logs automation_n8n

# Verificar recursos
docker stats

# Reiniciar serviço
docker service update --force automation_n8n
```

#### Erro de conexão com banco
```bash
# Verificar PostgreSQL
docker exec $(docker ps -q -f name=postgres) pg_isready

# Verificar databases
docker exec $(docker ps -q -f name=postgres) \
  psql -U postgres -l | grep -E "(n8n|activepieces)"
```

#### Problemas de SSL/HTTPS
```bash
# Verificar Traefik
docker service logs traefik_traefik

# Verificar certificados
docker exec $(docker ps -q -f name=traefik) \
  ls -la /etc/traefik/acme/
```

### Performance

#### Otimização de Recursos
```bash
# Ajustar limites de memória
docker service update \
  --limit-memory 2G \
  --reserve-memory 1G \
  automation_n8n

# Verificar uso
docker stats --no-stream | grep automation
```

#### Limpeza de Dados
```bash
# N8N - limpar execuções antigas
docker exec $(docker ps -q -f name=automation_n8n) \
  n8n db:cleanup --older-than=30

# Limpeza geral Docker
docker system prune -f
```

## 📖 Recursos Adicionais

### Documentação Oficial
- [N8N Documentation](https://docs.n8n.io/)
- [Activepieces Docs](https://www.activepieces.com/docs)
- [Windmill Documentation](https://docs.windmill.dev/)

### Templates e Exemplos
- N8N Templates: https://n8n.io/workflows/
- Activepieces Templates: Disponíveis na interface
- Windmill Hub: https://hub.windmill.dev/

### Comunidade
- N8N Community: https://community.n8n.io/
- Discord Activepieces: Disponível no site oficial
- GitHub Issues: Repositórios individuais

## 🎯 Casos de Uso Avançados

### E-commerce Automation
1. **Pedido Recebido → Multi-step Process**
   - Enviar confirmação por email
   - Adicionar ao CRM
   - Notificar equipe no Slack
   - Atualizar inventário

### Content Management
1. **Blog Post → Multi-platform Publishing**
   - Detectar novo post no blog
   - Gerar resumo com IA
   - Publicar no LinkedIn, Twitter
   - Notificar assinantes por email

### Monitoring & Alerts
1. **System Health → Notifications**
   - Monitorar APIs/serviços
   - Alertas inteligentes
   - Escalamento automático
   - Relatórios semanais

---

**✅ Com este guia, você está pronto para dominar a automação no Macspark Setup!**

Para suporte adicional, consulte a documentação específica de cada ferramenta ou abra uma issue no repositório do projeto.