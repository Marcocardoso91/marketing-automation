# 🤝 Contributing to Macspark Setup

Obrigado por considerar contribuir para o **Macspark Setup**! Este documento fornece diretrizes para contribuir com o projeto de forma efetiva e consistente.

## 📋 Índice

- [Código de Conduta](#-código-de-conduta)
- [Como Posso Contribuir?](#-como-posso-contribuir)
- [Processo de Desenvolvimento](#-processo-de-desenvolvimento)
- [Padrões de Código](#-padrões-de-código)
- [Testes](#-testes)
- [Documentação](#-documentação)
- [Commits e Pull Requests](#-commits-e-pull-requests)
- [Configuração do Ambiente](#-configuração-do-ambiente)
- [Arquitetura do Projeto](#-arquitetura-do-projeto)

## 📜 Código de Conduta

Este projeto adere ao [Contributor Covenant](https://www.contributor-covenant.org/). Ao participar, você deve seguir este código. Reporte comportamentos inaceitáveis para [conduct@macspark.dev](mailto:conduct@macspark.dev).

## 🚀 Como Posso Contribuir?

### 🐛 Reportando Bugs

Antes de criar um issue, verifique se o bug já foi reportado:

1. **Pesquise** nos [issues existentes](https://github.com/Marcocardoso28/Macspark-Setup/issues)
2. **Use o template** de bug report
3. **Inclua informações detalhadas**:
   - Versão do sistema operacional
   - Versão do Docker/Docker Compose
   - Logs de erro completos
   - Passos para reproduzir

**Template de Bug Report:**
```markdown
## Descrição do Bug
Uma descrição clara e concisa do que é o bug.

## Passos para Reproduzir
1. Vá para '...'
2. Clique em '....'
3. Role para baixo até '....'
4. Veja o erro

## Comportamento Esperado
Uma descrição clara do que você esperava que acontecesse.

## Screenshots
Se aplicável, adicione screenshots para ajudar a explicar o problema.

## Ambiente:
- OS: [e.g. Ubuntu 20.04]
- Docker: [e.g. 20.10.8]
- Docker Compose: [e.g. 1.29.2]
- Versão do Projeto: [e.g. 1.0.0]

## Logs
```
Cole aqui os logs relevantes
```

## Contexto Adicional
Adicione qualquer outro contexto sobre o problema aqui.
```

### 💡 Sugerindo Melhorias

Para sugerir uma nova funcionalidade:

1. **Verifique** se já não existe um issue similar
2. **Use o template** de feature request
3. **Descreva detalhadamente** a funcionalidade
4. **Explique o caso de uso**

### 🔧 Contribuindo com Código

1. **Fork** o repositório
2. **Crie** uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. **Desenvolva** seguindo os padrões do projeto
4. **Teste** suas alterações
5. **Commit** suas mudanças (`git commit -m 'Add some AmazingFeature'`)
6. **Push** para a branch (`git push origin feature/AmazingFeature`)
7. **Abra** um Pull Request

## 🔄 Processo de Desenvolvimento

### Workflow de Desenvolvimento

```mermaid
gitGraph
    commit id: "main"
    branch develop
    checkout develop
    commit id: "setup"
    branch feature/auth
    checkout feature/auth
    commit id: "implement auth"
    commit id: "add tests"
    checkout develop
    merge feature/auth
    commit id: "integrate auth"
    checkout main
    merge develop
    commit id: "release v1.1"
```

### Branches

- **`main`**: Branch de produção (sempre estável)
- **`develop`**: Branch de desenvolvimento (integração de features)
- **`feature/*`**: Branches para novas funcionalidades
- **`bugfix/*`**: Branches para correções de bugs
- **`hotfix/*`**: Branches para correções urgentes em produção

### Ciclo de Release

1. **Feature Development**: Desenvolvimento em branches `feature/*`
2. **Integration**: Merge para `develop`
3. **Testing**: Testes automatizados e manuais
4. **Release Candidate**: Tag `rc-*` para testes finais
5. **Production**: Merge para `main` e tag de versão

## 📝 Padrões de Código

### Python

Seguimos o **PEP 8** com algumas adaptações:

```python
# ✅ Bom
class SparkOneAPI:
    """API principal do SparkOne com autenticação JWT."""
    
    def __init__(self, config: Config) -> None:
        self.config = config
        self.logger = logging.getLogger(__name__)
    
    async def authenticate_user(self, credentials: UserCredentials) -> TokenResponse:
        """Autentica usuário e retorna tokens JWT."""
        try:
            user = await self._validate_credentials(credentials)
            tokens = await self._generate_tokens(user)
            self.logger.info(f"User {user.username} authenticated successfully")
            return tokens
        except AuthenticationError as e:
            self.logger.warning(f"Authentication failed: {e}")
            raise

# ❌ Ruim
def auth(u,p):
    if u=="admin" and p=="123":
        return "ok"
    return "error"
```

### Configuração de Linting

```toml
# pyproject.toml
[tool.black]
line-length = 120
target-version = ['py39']
include = '\.pyi?$'

[tool.isort]
profile = "black"
line_length = 120
multi_line_output = 3

[tool.flake8]
max-line-length = 120
extend-ignore = ["E203", "W503"]
```

### Docker

```dockerfile
# ✅ Multi-stage build
FROM python:3.11-slim as builder
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

FROM python:3.11-slim
RUN groupadd -r sparkone && useradd -r -g sparkone sparkone
WORKDIR /app
COPY --from=builder /usr/local/lib/python3.11/site-packages /usr/local/lib/python3.11/site-packages
COPY --chown=sparkone:sparkone . .
USER sparkone
EXPOSE 8000
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### YAML/Docker Compose

```yaml
# ✅ Bem estruturado
version: '3.8'

services:
  sparkone:
    build:
      context: ./services/sparkone
      dockerfile: Dockerfile
    environment:
      - DATABASE_URL=${DATABASE_URL}
      - REDIS_URL=${REDIS_URL}
    depends_on:
      - postgres
      - redis
    networks:
      - macspark-network
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

networks:
  macspark-network:
    driver: bridge
```

## 🧪 Testes

### Estrutura de Testes

```
tests/
├── unit/                    # Testes unitários
│   ├── test_auth.py
│   ├── test_agents.py
│   └── test_utils.py
├── integration/            # Testes de integração
│   ├── test_api_flows.py
│   └── test_database.py
├── e2e/                    # Testes end-to-end
│   └── test_complete_flows.py
└── fixtures/               # Dados de teste
    ├── users.json
    └── agents.json
```

### Executando Testes

```bash
# Todos os testes
python -m pytest

# Testes específicos
python -m pytest tests/unit/test_auth.py

# Com cobertura
python -m pytest --cov=services/sparkone --cov-report=html

# Testes de integração (requer Docker)
python -m pytest tests/integration/ --docker
```

### Escrevendo Testes

```python
import pytest
from fastapi.testclient import TestClient
from services.sparkone.main import app

class TestAuthentication:
    """Testes para sistema de autenticação."""
    
    @pytest.fixture
    def client(self):
        return TestClient(app)
    
    @pytest.fixture
    def valid_credentials(self):
        return {"username": "testuser", "password": "testpass123"}
    
    def test_login_success(self, client, valid_credentials):
        """Testa login com credenciais válidas."""
        response = client.post("/auth/login", json=valid_credentials)
        
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert "refresh_token" in data
        assert data["token_type"] == "bearer"
    
    def test_login_invalid_credentials(self, client):
        """Testa login com credenciais inválidas."""
        response = client.post("/auth/login", json={
            "username": "invalid",
            "password": "wrong"
        })
        
        assert response.status_code == 401
        assert "Could not validate credentials" in response.json()["detail"]
```

## 📚 Documentação

### Docstrings

Usamos o formato **Google Style**:

```python
def process_agent_request(agent_name: str, task: str, parameters: Dict[str, Any]) -> AgentResponse:
    """Processa uma requisição para um agente específico.
    
    Args:
        agent_name: Nome do agente a ser executado
        task: Tarefa a ser realizada pelo agente
        parameters: Parâmetros específicos para a tarefa
        
    Returns:
        Resposta do agente com status e resultados
        
    Raises:
        AgentNotFoundError: Quando o agente não existe
        InvalidTaskError: Quando a tarefa não é válida para o agente
        
    Example:
        >>> response = process_agent_request("backup_agent", "create_backup", {"type": "full"})
        >>> print(response.status)
        'completed'
    """
```

### README de Serviços

Cada serviço deve ter seu próprio README:

```markdown
# SparkOne API

API principal do sistema Macspark com autenticação JWT e gerenciamento de agentes.

## Funcionalidades

- ✅ Autenticação JWT com refresh tokens
- ✅ Rate limiting avançado
- ✅ Audit logging
- ✅ Métricas Prometheus
- ✅ Health checks

## Configuração

```bash
cp .env.example .env
# Edite as variáveis necessárias
docker-compose up -d
```

## API Endpoints

### Autenticação
- `POST /auth/login` - Login
- `POST /auth/refresh` - Renovar token
- `POST /auth/logout` - Logout

### Agentes
- `GET /agents` - Listar agentes
- `POST /agents/{name}/execute` - Executar agente
```

## 💬 Commits e Pull Requests

### Conventional Commits

Usamos o padrão [Conventional Commits](https://www.conventionalcommits.org/):

```
<type>[optional scope]: <description>

[optional body]

[optional footer(s)]
```

**Tipos:**
- `feat`: Nova funcionalidade
- `fix`: Correção de bug
- `docs`: Mudanças na documentação
- `style`: Formatação, sem mudança de código
- `refactor`: Refatoração de código
- `test`: Adição ou correção de testes
- `chore`: Manutenção, dependências, etc.

**Exemplos:**
```
feat(auth): add JWT refresh token support

- Implement refresh token rotation
- Add token blacklisting
- Update authentication middleware

Closes #123
```

### Pull Request Template

```markdown
## Descrição
Uma descrição clara do que este PR faz.

## Tipo de Mudança
- [ ] Bug fix (mudança que corrige um problema)
- [ ] Nova funcionalidade (mudança que adiciona funcionalidade)
- [ ] Breaking change (mudança que quebra compatibilidade)
- [ ] Documentação (mudança apenas na documentação)

## Como Foi Testado?
Descreva os testes que você executou para verificar suas mudanças.

- [ ] Testes unitários passando
- [ ] Testes de integração passando
- [ ] Testado manualmente
- [ ] Testado em ambiente similar à produção

## Checklist
- [ ] Meu código segue as diretrizes de estilo do projeto
- [ ] Eu revisei meu próprio código
- [ ] Eu comentei meu código, especialmente em áreas difíceis
- [ ] Eu atualizei a documentação correspondente
- [ ] Minhas mudanças não geram novos warnings
- [ ] Eu adicionei testes que provam que minha correção é efetiva ou que minha funcionalidade funciona
- [ ] Testes unitários novos e existentes passam localmente
- [ ] Quaisquer mudanças dependentes foram merged e publicadas

## Screenshots (se aplicável)
Adicione screenshots para ajudar a explicar suas mudanças.

## Issues Relacionados
Fixes #123
Closes #456
Related to #789
```

## ⚙️ Configuração do Ambiente

### Pré-requisitos

- **Python 3.9+**
- **Docker 20.10+**
- **Docker Compose 2.0+**
- **Git 2.25+**
- **Node.js 16+** (para ferramentas de desenvolvimento)

### Setup Local

```bash
# 1. Clone o repositório
git clone https://github.com/Marcocardoso28/Macspark-Setup.git
cd Macspark-Setup

# 2. Configure o ambiente Python
python -m venv .venv
source .venv/bin/activate  # Linux/Mac
# .venv\Scripts\activate   # Windows

# 3. Instale dependências de desenvolvimento
pip install -r requirements-dev.txt

# 4. Configure pre-commit hooks
pre-commit install

# 5. Configure variáveis de ambiente
cp env.example .env
# Edite o arquivo .env com suas configurações

# 6. Inicie os serviços de desenvolvimento
docker-compose -f docker-compose.dev.yml up -d

# 7. Execute os testes
python -m pytest
```

### Ferramentas de Desenvolvimento

```bash
# Formatação de código
black services/
isort services/

# Linting
flake8 services/
mypy services/

# Testes com cobertura
pytest --cov=services --cov-report=html

# Análise de segurança
bandit -r services/

# Verificação de dependências
pip-audit
```

### VS Code Configuration

```json
// .vscode/settings.json
{
    "python.defaultInterpreterPath": "./.venv/bin/python",
    "python.linting.enabled": true,
    "python.linting.flake8Enabled": true,
    "python.linting.mypyEnabled": true,
    "python.formatting.provider": "black",
    "python.sortImports.args": ["--profile", "black"],
    "editor.formatOnSave": true,
    "editor.codeActionsOnSave": {
        "source.organizeImports": true
    }
}
```

## 🏗️ Arquitetura do Projeto

### Estrutura de Diretórios

```
Macspark-Setup/
├── services/                 # Microserviços
│   ├── sparkone/            # API principal
│   └── evolution-manager/   # Gerenciador Evolution
├── stacks/                  # Docker Compose stacks
│   ├── ai/                 # Serviços de IA
│   ├── monitoring/         # Monitoramento
│   └── security/           # Segurança
├── scripts/                # Scripts de automação
├── tests/                  # Testes automatizados
├── docs/                   # Documentação adicional
└── .github/                # GitHub Actions
```

### Princípios Arquiteturais

1. **Microserviços**: Cada serviço é independente
2. **API First**: APIs bem definidas entre serviços
3. **Containerização**: Tudo roda em containers
4. **Observabilidade**: Logs, métricas e traces
5. **Segurança**: Autenticação, autorização e auditoria
6. **Escalabilidade**: Preparado para crescer

### Padrões de Design

- **Repository Pattern**: Para acesso a dados
- **Factory Pattern**: Para criação de objetos
- **Observer Pattern**: Para eventos
- **Middleware Pattern**: Para processamento de requests
- **Circuit Breaker**: Para resiliência

## 🔒 Segurança

### Diretrizes de Segurança

1. **Nunca** commite secrets no código
2. **Sempre** use HTTPS em produção
3. **Valide** todas as entradas
4. **Sanitize** todas as saídas
5. **Use** autenticação forte
6. **Implemente** rate limiting
7. **Monitore** atividades suspeitas

### Reportando Vulnerabilidades

Para reportar vulnerabilidades de segurança:

1. **NÃO** abra um issue público
2. **Envie** email para [security@macspark.dev](mailto:security@macspark.dev)
3. **Inclua** detalhes da vulnerabilidade
4. **Aguarde** nossa resposta em até 48h

## 📞 Suporte

### Canais de Comunicação

- **GitHub Issues**: Para bugs e feature requests
- **GitHub Discussions**: Para perguntas e discussões
- **Discord**: [Macspark Community](https://discord.gg/macspark)
- **Email**: [dev@macspark.dev](mailto:dev@macspark.dev)

### Horários de Suporte

- **Issues**: Resposta em até 24h (dias úteis)
- **Pull Requests**: Review em até 48h
- **Security**: Resposta em até 2h (crítico)

## 🎉 Reconhecimento

Contribuidores são reconhecidos de várias formas:

- **Hall of Fame** no README
- **Badges** especiais no GitHub
- **Mentions** nas release notes
- **Swag** para contribuições significativas

### Top Contributors

<!-- Automaticamente atualizado pelo GitHub Actions -->
<a href="https://github.com/Marcocardoso28/Macspark-Setup/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=Marcocardoso28/Macspark-Setup" />
</a>

---

## 📜 Licença

Ao contribuir, você concorda que suas contribuições serão licenciadas sob a [MIT License](LICENSE).

---

**Obrigado por contribuir com o Macspark Setup! 🚀**

*Para dúvidas sobre este guia, abra um issue ou entre em contato conosco.*
