# 🌐 CONFIGURAÇÃO DE DOMÍNIO - MACSPARK

## 📋 DOMÍNIO ATUAL: `macspark.dev`

### 🔧 **COMO ALTERAR O DOMÍNIO**

#### 1. **Arquivo Principal (.env)**
Edite o arquivo `.env` e altere apenas esta linha:
```bash
DOMAIN_SUFFIX=seu-novo-dominio.com
```

#### 2. **Variáveis Relacionadas**
Também altere estas variáveis no `.env`:
```bash
PRIMARY_EMAIL=admin@seu-novo-dominio.com
SMTP_FROM_EMAIL=noreply@seu-novo-dominio.com
MATRIX_DOMAIN=matrix.seu-novo-dominio.com
MAIL_DOMAIN=mail.seu-novo-dominio.com
```

### 🌐 **SUBDOMÍNIOS AUTOMÁTICOS**

Com o domínio `macspark.dev`, os serviços ficarão disponíveis em:

#### 📊 **CORE SERVICES**
- **Dashboard**: `https://dashboard.macspark.dev`
- **Traefik**: `https://traefik.macspark.dev`
- **Portainer**: `https://portainer.macspark.dev`

#### 🔍 **MONITORING**
- **Grafana**: `https://grafana.macspark.dev`
- **Prometheus**: `https://prometheus.macspark.dev`
- **Netdata**: `https://monitor.macspark.dev`

#### 💬 **COMMUNICATION**
- **Chatwoot**: `https://chatwoot.macspark.dev`
- **Rocket.Chat**: `https://chat.macspark.dev`
- **Matrix**: `https://matrix.macspark.dev`
- **Element**: `https://element.macspark.dev`

#### 📚 **PRODUCTIVITY**
- **BookStack**: `https://wiki.macspark.dev`
- **WeKan**: `https://kanban.macspark.dev`
- **OnlyOffice**: `https://office.macspark.dev`
- **n8n**: `https://workflow.macspark.dev`

#### 🎨 **DESIGN**
- **Penpot**: `https://design.macspark.dev`
- **Excalidraw**: `https://whiteboard.macspark.dev`

#### 🔧 **DEVELOPMENT**
- **Code Server**: `https://code.macspark.dev`
- **Cursor Server**: `https://cursor.macspark.dev`
- **Drone CI**: `https://ci.macspark.dev`
- **Harbor**: `https://registry.macspark.dev`

#### 🤖 **AI SERVICES**
- **Ollama**: `https://ollama.macspark.dev`
- **Claude**: `https://ai.macspark.dev`
- **LocalAI**: `https://localai.macspark.dev`

#### 💾 **STORAGE**
- **NextCloud**: `https://cloud.macspark.dev`
- **Vaultwarden**: `https://vault.macspark.dev`

#### 🔐 **SECURITY**
- **CrowdSec**: `https://security.macspark.dev`
- **Backup**: `https://backup.macspark.dev`

#### 🎥 **MEDIA & COMMUNICATION**
- **Jellyfin**: `https://media.macspark.dev`
- **Jitsi**: `https://meet.macspark.dev`

### 📝 **CONFIGURAÇÃO DNS**

Para usar o domínio `macspark.dev`, configure os seguintes registros DNS:

#### **Registro A (Principal)**
```
macspark.dev → SEU_IP_SERVIDOR
```

#### **Registro CNAME (Subdomínios)**
```
*.macspark.dev → macspark.dev
```

**OU configure individualmente:**
```
dashboard.macspark.dev → macspark.dev
traefik.macspark.dev → macspark.dev
portainer.macspark.dev → macspark.dev
grafana.macspark.dev → macspark.dev
chat.macspark.dev → macspark.dev
wiki.macspark.dev → macspark.dev
... (todos os outros subdomínios)
```

### 🔧 **COMANDOS ÚTEIS**

#### **Verificar Configuração**
```bash
# Ver todas as variáveis de domínio
grep -i domain .env

# Testar resolução DNS
nslookup dashboard.macspark.dev
```

#### **Recriar Certificados SSL**
```bash
# Forçar renovação de certificados após mudança de domínio
docker service update --force traefik_traefik
```

#### **Verificar Serviços**
```bash
# Listar todos os serviços
docker service ls

# Ver logs do Traefik
docker service logs -f traefik_traefik
```

### ⚠️ **IMPORTANTE**

1. **Backup antes de alterar**: Sempre faça backup antes de mudar o domínio
2. **Certificados SSL**: Serão gerados automaticamente pelo Let's Encrypt
3. **Propagação DNS**: Pode levar até 24h para propagar globalmente
4. **Firewall**: Certifique-se que as portas 80 e 443 estão abertas

### 🆘 **TROUBLESHOOTING**

#### **Problema**: Serviços não acessíveis
```bash
# Verificar DNS
nslookup seu-dominio.com

# Verificar Traefik
docker service logs traefik_traefik
```

#### **Problema**: Certificado SSL inválido
```bash
# Limpar certificados antigos
docker volume rm traefik_certificates

# Reiniciar Traefik
docker service update --force traefik_traefik
```

---

**💡 Dica**: Use o comando `./scripts/deploy-all-enterprise.sh` após alterar o domínio para aplicar as mudanças em todos os serviços. 