# 📱 GUIA DA EVOLUTION API NO MACSPARK

## 📋 **O QUE É A EVOLUTION API?**

A Evolution API é um serviço que permite integração com WhatsApp Business, permitindo:
- 📨 Enviar e receber mensagens
- 🤖 Criar bots e automações
- 📊 Integrar com outros sistemas
- 🔄 Múltiplas instâncias/números

## 🔧 **COMO FUNCIONA NO MACSPARK?**

### **1. Instalação**
A Evolution API é instalada como um serviço Docker Swarm, assim como os outros componentes.

### **2. Geração da API Key**
- A API Key é **gerada automaticamente** durante a instalação
- Não precisa ser fornecida pelo usuário
- É mostrada no console após a instalação
- Deve ser guardada para uso posterior

### **3. Fluxo Correto**
```
1. Instalar Evolution API
   ↓
2. Sistema gera API Key automaticamente
   ↓
3. API Key é exibida no console
   ↓
4. Usar essa API Key para integrar com outros serviços
```

## 🚀 **INSTALAÇÃO MANUAL**

Se você quiser instalar a Evolution API separadamente:

```bash
# 1. Criar os secrets necessários
bash scripts/create-evolution-secrets.sh

# 2. Deploy do stack
docker stack deploy -c stacks/evolution/evolution.yml evolution

# 3. Verificar logs
docker service logs evolution_evolution_api

# 4. Acessar
https://evo.seudominio.com
```

## 🔑 **SOBRE A API KEY**

### **Quando é gerada:**
- Durante a execução do script `create-evolution-secrets.sh`
- Formato: `evo_[64 caracteres hexadecimais]`
- Exemplo: `evo_a1b2c3d4e5f6...`

### **Onde é armazenada:**
- Como Docker Secret: `evolution_api_key`
- Segura e criptografada pelo Docker Swarm

### **Como recuperar:**
```bash
# Ver o valor do secret (apenas em desenvolvimento)
docker secret inspect evolution_api_key --pretty

# Em produção, a chave deve ser guardada quando exibida na instalação
```

## 🔗 **INTEGRAÇÕES**

### **Com N8N:**
1. Instalar N8N
2. Usar a API Key da Evolution
3. Configurar webhook: `https://n8n.seudominio.com/webhook`

### **Com Chatwoot:**
1. Evolution já vem preparada para Chatwoot
2. Configurar no painel da Evolution

### **Com seu sistema:**
```javascript
// Exemplo de uso
const evolutionAPI = {
  url: 'https://evo.seudominio.com',
  apiKey: 'evo_sua_api_key_aqui',
  headers: {
    'apikey': 'evo_sua_api_key_aqui',
    'Content-Type': 'application/json'
  }
};
```

## ❌ **ERROS COMUNS**

### **"Digite a chave da Evolution API"**
- **Problema:** O setup estava pedindo a API key antes de instalar
- **Solução:** Atualizada - agora gera automaticamente

### **"evolution_api_key not found"**
- **Problema:** Secrets não foram criados
- **Solução:** Execute `bash scripts/create-evolution-secrets.sh`

### **"Connection refused"**
- **Problema:** PostgreSQL ou Redis não estão rodando
- **Solução:** Instale a infraestrutura básica primeiro

## 📚 **DOCUMENTAÇÃO**

- **API Docs:** https://doc.evolution-api.com
- **GitHub:** https://github.com/EvolutionAPI/evolution-api
- **Suporte:** Discord da Evolution API

## 💡 **DICAS**

1. **Sempre guarde a API Key** quando ela for exibida na instalação
2. **Use HTTPS** em produção para segurança
3. **Configure rate limits** no Traefik para evitar abuso
4. **Faça backup** do volume `evolution_instancesv2` regularmente

---

**✨ A Evolution API agora está corretamente integrada ao Macspark!** 