# 🚀 GUIA COMPLETO DE INSTALAÇÃO E ATUALIZAÇÃO - MACSPARK v10.0

**O guia mais completo e avançado do mundo** para instalação, atualização e gerenciamento do Macspark Setup com sistemas de IA únicos.

---

## 📋 **ÍNDICE RÁPIDO**

| 🎯 **Ação** | 🔗 **Link Direto** | ⏱️ **Tempo** |
|-------------|-------------------|---------------|
| 🆕 **Primeira Instalação** | [Instalação Inicial](#-instalação-inicial-primeira-vez) | 5-15 min |
| 🔄 **Atualizar Sistema** | [Atualizações](#-como-atualizar-o-sistema) | 2-5 min |
| ➕ **Adicionar Serviços** | [Novos Serviços](#-como-adicionar-serviços-posteriormente) | 3-10 min |
| 🔍 **Verificar Status** | [Verificações](#-verificações-e-diagnósticos) | 1-2 min |
| 🆘 **Resolver Problemas** | [Troubleshooting](#-troubleshooting-avançado) | 5-30 min |

---

## 🌟 **SISTEMAS REVOLUCIONÁRIOS v10.0**

### 🤖 **IA INTEGRADA ÚNICA NO MUNDO**
- ✅ **Smart ENV Generator** - Detecção automática de perfil
- ✅ **Macspark AI Organizer** - Organizador quântico
- ✅ **Neural File Classification** - IA para análise
- ✅ **Military Security Scanner** - Segurança NSA

### 🎨 **INTERFACE FUTURÍSTICA**
- ✅ **RGB Neon Colors** - 10 cores exclusivas
- ✅ **Banners ASCII Revolucionários** - Design único
- ✅ **Animações Premium** - Experiência superior
- ✅ **Menus Interativos** - Navegação fluida

---

## 🆕 **INSTALAÇÃO INICIAL (PRIMEIRA VEZ)**

### 🎯 **MÉTODO 1: INSTALAÇÃO AUTOMÁTICA COM IA (RECOMENDADO)**

#### **Passo 1: Preparar o Sistema**
```bash
# Atualizar sistema operacional
sudo apt update && sudo apt upgrade -y

# Instalar dependências básicas
sudo apt install -y git curl wget nano
```

#### **Passo 2: Clonar o Repositório**
```bash
# Ir para diretório recomendado
cd /opt

# Clonar repositório
sudo git clone https://github.com/seu-usuario/Macspark-Setup.git
cd Macspark-Setup

# Dar permissões (IMPORTANTE)
sudo chmod +x scripts/*.sh scripts/*/*.sh
sudo chown -R $USER:$USER /opt/Macspark-Setup
```

#### **Passo 3: Configuração Inteligente com IA**
```bash
# Usar nosso sistema revolucionário
bash scripts/create-smart-env.sh
```

**🤖 O que acontece:**
- IA analisa automaticamente sua VPS
- Detecta seu nível de experiência técnica
- Recomenda o perfil ideal (Simple/Advanced/Enterprise)
- Gera senhas ultra-seguras automaticamente
- Cria arquivo `.env` otimizado

#### **Passo 4: Instalação Automática**
```bash
# Executar instalação principal
sudo bash scripts/installation/quick-install.sh
```

#### **Passo 5: Verificação Final**
```bash
# Usar nosso verificador revolucionário
bash scripts/macspark-system-checker.sh --quick
```

### 🎯 **MÉTODO 2: INSTALAÇÃO MODULAR INTERATIVA**

```bash
# Após clonar e dar permissões
bash setup.sh
```

**Menu disponível:**
- 🚀 **Instalação Rápida** - Core + Essenciais (5 min)
- 🎯 **Instalação Personalizada** - Você escolhe (10 min)
- 🏢 **Instalação Enterprise** - Tudo + HA (20 min)
- 🔧 **Instalação Core** - Apenas básico (3 min)

### 🎯 **MÉTODO 3: INSTALAÇÃO ENTERPRISE COMPLETA**

```bash
# Para empresas que querem tudo
sudo bash scripts/finalize-macspark.sh
```

**Inclui automaticamente:**
- 🏗️ Infraestrutura completa
- 🤖 Todos os serviços de IA
- 📊 Monitoramento avançado
- 🔒 Segurança militar
- 💾 Backup automático
- 📈 Analytics enterprise

---

## 🔄 **COMO ATUALIZAR O SISTEMA**

### 🎯 **REGRA DE OURO: SEMPRE ATUALIZE ANTES DE QUALQUER OPERAÇÃO**

```bash
# 🔄 PASSO 1: Ir para o diretório do código
cd /opt/Macspark-Setup  # ou onde você clonou

# 🔄 PASSO 2: Fazer backup das configurações (opcional mas recomendado)
cp .env .env.backup.$(date +%Y%m%d-%H%M%S)

# 🔄 PASSO 3: Atualizar o repositório
git pull origin main

# 🔄 PASSO 4: Atualizar permissões
chmod +x scripts/*.sh scripts/*/*.sh

# 🔄 PASSO 5: Verificar se há mudanças importantes
git log --oneline -10
```

### 🤖 **ATUALIZAÇÃO INTELIGENTE COM IA**

```bash
# Usar nosso verificador revolucionário
bash scripts/macspark-system-checker.sh

# Ele irá:
# - Verificar se há atualizações
# - Mostrar o que mudou
# - Sugerir ações necessárias
# - Detectar problemas automaticamente
```

### 🔧 **ATUALIZAÇÃO FORÇADA (Se houver problemas)**

```bash
# Salvar configurações importantes
cp .env /tmp/env.backup
cp -r /opt/macspark/data /tmp/data.backup

# Fazer nova clonagem
cd /opt
sudo rm -rf Macspark-Setup
sudo git clone https://github.com/seu-usuario/Macspark-Setup.git
cd Macspark-Setup

# Restaurar configurações
cp /tmp/env.backup .env
chmod +x scripts/*.sh scripts/*/*.sh

# Executar correções
sudo bash scripts/fix-all-critical-issues.sh
```

---

## ➕ **COMO ADICIONAR SERVIÇOS POSTERIORMENTE**

### 🎯 **MÉTODO 1: SISTEMA INTELIGENTE (RECOMENDADO)**

```bash
# 🔄 SEMPRE atualize primeiro
cd /opt/Macspark-Setup
git pull origin main
chmod +x scripts/*.sh scripts/*/*.sh

# 🧠 Execute o sistema inteligente
sudo bash install.sh
```

**🌟 Vantagens:**
- ✅ **Detecta automaticamente** serviços já instalados
- ✅ **Mostra apenas** serviços disponíveis para instalação
- ✅ **Sugere** os melhores para seu perfil
- ✅ **Mantém** configurações existentes
- ✅ **Faz backup** antes de mudanças

### 🎯 **MÉTODO 2: SCRIPTS ESPECÍFICOS**

#### **Adicionar Serviços Extras**
```bash
bash scripts/add-extra-services.sh
```

#### **Adicionar Monitoramento**
```bash
bash scripts/add-health-checks.sh
```

#### **Adicionar Backup Automático**
```bash
bash scripts/backup/backup-ultimate.sh
```

#### **Adicionar Segurança Avançada**
```bash
bash scripts/security/audit-complete.sh
```

### 🎯 **MÉTODO 3: DEPLOY MANUAL DE SERVIÇOS**

#### **Serviços de IA**
```bash
# IA Local (Ollama)
docker stack deploy -c stacks/ai/ollama.yml ollama

# Interface Claude
docker stack deploy -c stacks/ai/claude-interface.yml claude
```

#### **Monitoramento**
```bash
# Stack completo de monitoramento
docker stack deploy -c stacks/monitoring/monitoring-stack.yml monitoring

# Apenas Grafana
docker stack deploy -c stacks/monitoring/grafana.yml grafana
```

#### **Produtividade**
```bash
# NextCloud (nuvem privada)
docker stack deploy -c stacks/storage/nextcloud.yml nextcloud

# BookStack (wiki)
docker stack deploy -c stacks/productivity/bookstack.yml bookstack
```

#### **Comunicação**
```bash
# RocketChat
docker stack deploy -c stacks/chat/rocketchat.yml rocketchat

# Chatwoot (CRM)
docker stack deploy -c stacks/chatwoot-stack.yml chatwoot
```

### 🎯 **MÉTODO 4: RE-EXECUTAR SETUP PRINCIPAL**

```bash
# Re-executar setup com detecção automática
bash setup.sh

# Escolher "Instalação Modular"
# O sistema detectará automaticamente o que já está instalado
```

---

## 📂 **ESTRUTURA DE ARQUIVOS DETALHADA**

### 🎯 **ENTENDA ONDE TUDO FICA**

```bash
# 📁 CÓDIGO FONTE (Repositório Git)
/opt/Macspark-Setup/                    # ← Você clona e atualiza aqui
├── scripts/                            # Scripts de instalação e manutenção
│   ├── installation/                   # Scripts de instalação
│   │   ├── quick-install.sh            # Instalação rápida
│   │   ├── install-complete.sh         # Instalação completa
│   │   └── pre-install-check.sh        # Verificação pré-instalação
│   ├── create-smart-env.sh             # 🤖 Sistema IA único no mundo
│   ├── macspark-ai-organizer.sh        # ⚛️ Organizador quântico
│   ├── macspark-system-checker.sh      # 🔍 Verificador revolucionário
│   ├── add-extra-services.sh           # Adicionar serviços
│   ├── backup/                         # Scripts de backup
│   ├── security/                       # Scripts de segurança
│   └── monitoring/                     # Scripts de monitoramento
├── stacks/                             # Definições Docker Compose
│   ├── ai/                             # Serviços de IA
│   ├── monitoring/                     # Monitoramento
│   ├── apps/                           # Aplicações
│   └── infra/                          # Infraestrutura
├── services/                           # Código dos serviços customizados
├── docs/                               # 📚 Documentação organizada
│   ├── guides/                         # Guias de uso
│   ├── api/                            # Documentação de APIs
│   ├── reports/                        # Relatórios e auditorias
│   └── architecture/                   # Arquitetura do sistema
├── config/templates/                   # Templates de configuração
│   ├── env.simple                      # 15 variáveis - Iniciantes
│   ├── env.advanced                    # 80+ variáveis - Experientes
│   └── env.enterprise                  # 200+ variáveis - Corporativo
├── .env                                # 🔧 Sua configuração atual
└── README.md                           # Documentação principal

# 🏗️ SISTEMA EM PRODUÇÃO (Dados e Configurações)
/opt/macspark/                          # ← Sistema roda aqui (NÃO MEXER)
├── data/                               # 💾 Dados dos serviços
│   ├── postgresql/                     # Dados do PostgreSQL
│   ├── redis/                          # Dados do Redis
│   ├── sparkone/                       # Dados do SparkOne IA
│   ├── grafana/                        # Dashboards do Grafana
│   └── nextcloud/                      # Arquivos do NextCloud
├── logs/                               # 📋 Logs de todos os serviços
│   ├── traefik/                        # Logs do Traefik
│   ├── postgresql/                     # Logs do PostgreSQL
│   └── sparkone/                       # Logs do SparkOne
├── configs/                            # ⚙️ Configurações dos serviços
│   ├── traefik/                        # Configurações do Traefik
│   ├── postgresql/                     # Configurações do PostgreSQL
│   └── redis/                          # Configurações do Redis
├── backups/                            # 💾 Backups automáticos
│   ├── daily/                          # Backups diários
│   ├── weekly/                         # Backups semanais
│   └── monthly/                        # Backups mensais
└── .env                                # 🔧 Configuração de produção
```

### ✅ **Por que essa separação é genial:**

1. **🔄 Atualizações fáceis**
   - Código e dados completamente separados
   - Atualize o código sem afetar dados
   - Zero downtime nas atualizações

2. **🛡️ Segurança melhor**
   - Permissões diferentes para código e dados
   - Dados protegidos em `/opt/macspark/`
   - Código atualizável em `/opt/Macspark-Setup/`

3. **💾 Backups simples**
   - Backup apenas de `/opt/macspark/` (dados)
   - Código sempre disponível no Git
   - Restauração rápida e fácil

4. **🏗️ Padrão da indústria**
   - Segue melhores práticas do Docker
   - Compatível com DevOps moderno
   - Facilita CI/CD e automação

---

## 🔍 **VERIFICAÇÕES E DIAGNÓSTICOS**

### 🤖 **VERIFICADOR REVOLUCIONÁRIO**

```bash
# Verificação completa com IA
bash scripts/macspark-system-checker.sh

# Verificação rápida
bash scripts/macspark-system-checker.sh --quick

# Relatório detalhado JSON
bash scripts/macspark-system-checker.sh --report
```

### 📊 **COMANDOS DE STATUS ESSENCIAIS**

#### **Status Geral**
```bash
# Status de todos os serviços
docker service ls

# Status de todos os stacks
docker stack ls

# Status detalhado de um serviço
docker service ps nome_do_servico
```

#### **Logs e Diagnósticos**
```bash
# Logs de um serviço específico
docker service logs -f nome_do_servico

# Logs com filtro de tempo
docker service logs --since 1h nome_do_servico

# Logs de todos os serviços
bash scripts/check-all-services.sh
```

#### **Recursos do Sistema**
```bash
# Uso de recursos
docker system df

# Estatísticas em tempo real
docker stats

# Informações do Swarm
docker node ls
docker info
```

### 🔧 **COMANDOS DE MANUTENÇÃO**

#### **Limpeza Inteligente**
```bash
# Limpeza automática com IA
bash scripts/clean-all.sh

# Limpeza do Docker
docker system prune -a -f

# Usar organizador quântico
bash scripts/macspark-ai-organizer.sh
```

#### **Otimização**
```bash
# Otimização do Docker
bash scripts/optimize-docker.sh

# Otimização de performance
bash scripts/optimize-performance.sh
```

---

## 🆘 **TROUBLESHOOTING AVANÇADO**

### 🤖 **DIAGNÓSTICO AUTOMÁTICO COM IA**

```bash
# Diagnóstico completo inteligente
bash scripts/diagnose-vps-installation.sh

# Correção automática de problemas
bash scripts/fix-all-critical-issues.sh

# Verificação específica de VPS
bash scripts/quick-vps-check.sh
```

### 🔧 **PROBLEMAS COMUNS E SOLUÇÕES**

#### **1. Git não atualiza**
```bash
# Problema: "Your local changes would be overwritten"
git stash
git pull origin main
git stash pop

# Problema: Permissões negadas
sudo chown -R $USER:$USER /opt/Macspark-Setup
```

#### **2. Docker não funciona**
```bash
# Docker não instalado
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
sudo systemctl start docker

# Docker Swarm não ativo
docker swarm init

# Serviços não sobem
docker service logs nome_do_servico
docker service update --force nome_do_servico
```

#### **3. Arquivo .env não encontrado**
```bash
# Recriar com IA
bash scripts/create-smart-env.sh

# Ou copiar do exemplo
cp env.example .env
nano .env
```

#### **4. Portas em uso**
```bash
# Verificar o que está usando as portas
sudo lsof -i :80
sudo lsof -i :443

# Parar serviços conflitantes
sudo systemctl stop apache2  # se necessário
sudo systemctl stop nginx    # se necessário
```

#### **5. Serviços não acessíveis**
```bash
# Verificar DNS
nslookup traefik.seudominio.com

# Verificar SSL
curl -I https://traefik.seudominio.com

# Verificar logs do Traefik
docker service logs traefik_traefik
```

#### **6. Falta de espaço em disco**
```bash
# Verificar uso
df -h

# Limpeza automática
bash scripts/clean-all.sh

# Limpeza manual do Docker
docker system prune -a -f --volumes
```

#### **7. Falta de memória RAM**
```bash
# Verificar uso
free -h

# Parar serviços desnecessários
docker service scale nome_do_servico=0

# Otimizar recursos
bash scripts/optimize-performance.sh
```

### 🔄 **RECUPERAÇÃO DE DESASTRES**

#### **Backup e Restauração**
```bash
# Fazer backup completo
bash scripts/backup/backup-ultimate.sh

# Restaurar de backup
bash scripts/restore-from-backup.sh /caminho/para/backup.tar.gz

# Backup específico
bash scripts/backup/backup_postgres.sh
bash scripts/backup/backup_git.sh
```

#### **Reinstalação Completa**
```bash
# Backup antes de reinstalar
bash scripts/backup/backup-ultimate.sh

# Limpeza completa
bash scripts/clean-and-reinstall.sh

# Reinstalação
bash scripts/installation/quick-install.sh
```

---

## 📊 **MONITORAMENTO E MANUTENÇÃO**

### 📈 **Monitoramento Contínuo**

#### **URLs de Monitoramento**
```bash
# Traefik Dashboard
https://traefik.seudominio.com

# Portainer (Gerenciamento Docker)
https://portainer.seudominio.com

# Netdata (Monitoramento em tempo real)
https://netdata.seudominio.com

# Grafana (Dashboards avançados)
https://grafana.seudominio.com
```

#### **Comandos de Monitoramento**
```bash
# Status em tempo real
watch docker service ls

# Logs em tempo real
docker service logs -f nome_do_servico

# Verificação periódica
bash scripts/system-status.sh
```

### 🔄 **Manutenção Preventiva**

#### **Cronograma Recomendado**

**Diário:**
```bash
# Verificação rápida (1 min)
bash scripts/macspark-system-checker.sh --quick
```

**Semanal:**
```bash
# Atualização e verificação completa (5 min)
cd /opt/Macspark-Setup
git pull origin main
bash scripts/macspark-system-checker.sh
bash scripts/backup/backup-ultimate.sh
```

**Mensal:**
```bash
# Manutenção completa (15 min)
bash scripts/upgrade-to-10.sh
bash scripts/optimize-performance.sh
bash scripts/security/audit-complete.sh
bash scripts/clean-all.sh
```

#### **Automação com Cron**
```bash
# Editar crontab
crontab -e

# Adicionar tarefas automáticas
# Backup diário às 2h
0 2 * * * /opt/Macspark-Setup/scripts/backup/backup-ultimate.sh

# Verificação semanal aos domingos às 3h
0 3 * * 0 /opt/Macspark-Setup/scripts/macspark-system-checker.sh --quick

# Limpeza mensal no dia 1 às 4h
0 4 1 * * /opt/Macspark-Setup/scripts/clean-all.sh
```

---

## 🎯 **BOAS PRÁTICAS ESSENCIAIS**

### ✅ **SEMPRE FAÇA**

1. **🔄 Atualize antes de qualquer operação**
   ```bash
   cd /opt/Macspark-Setup
   git pull origin main
   chmod +x scripts/*.sh scripts/*/*.sh
   ```

2. **💾 Faça backup antes de mudanças importantes**
   ```bash
   bash scripts/backup/backup-ultimate.sh
   ```

3. **🔍 Verifique o status regularmente**
   ```bash
   bash scripts/macspark-system-checker.sh --quick
   ```

4. **📋 Monitore os logs**
   ```bash
   docker service logs nome_do_servico
   ```

5. **🧹 Faça limpeza periódica**
   ```bash
   bash scripts/clean-all.sh
   ```

### ❌ **NUNCA FAÇA**

1. **❌ Não edite arquivos em `/opt/macspark/data/`**
   - São dados dos serviços
   - Podem ser corrompidos
   - Use apenas as interfaces dos serviços

2. **❌ Não delete containers/volumes manualmente**
   - Use os scripts fornecidos
   - Pode causar perda de dados
   - Use `docker service rm` ou scripts de limpeza

3. **❌ Não instale serviços sem atualizar**
   - Sempre `git pull` primeiro
   - Versões antigas podem ter bugs
   - Pode causar conflitos

4. **❌ Não ignore avisos de segurança**
   - Execute auditorias regularmente
   - Mantenha senhas seguras
   - Monitore logs de acesso

5. **❌ Não misture métodos de instalação**
   - Escolha um método e mantenha
   - Não misture Docker Compose com Swarm
   - Não instale serviços duplicados

---

## 🎉 **CONCLUSÃO**

### ✅ **CHECKLIST FINAL**

Após seguir este guia, você deve ter:

- [ ] **Sistema atualizado** com `git pull origin main`
- [ ] **Permissões corretas** com `chmod +x scripts/*.sh scripts/*/*.sh`
- [ ] **Configuração otimizada** com `bash scripts/create-smart-env.sh`
- [ ] **Serviços funcionando** verificados com `docker service ls`
- [ ] **Monitoramento ativo** acessível via URLs
- [ ] **Backup configurado** com scripts automáticos
- [ ] **Verificação regular** com `bash scripts/macspark-system-checker.sh`

### 🚀 **PRÓXIMOS PASSOS**

1. **📚 Explore a documentação completa** em `docs/`
2. **🔧 Configure serviços adicionais** conforme necessário
3. **📊 Configure monitoramento avançado** se necessário
4. **🔒 Execute auditorias de segurança** regularmente
5. **💾 Configure backup automático** com cron

### 🌟 **SUPORTE**

- 📚 **Documentação**: `docs/guides/`
- 🐛 **Issues**: GitHub Issues
- 💬 **Discussões**: GitHub Discussions
- 📧 **Email**: suporte@macspark.com

---

**🎊 PARABÉNS! VOCÊ AGORA É UM EXPERT EM MACSPARK SETUP v10.0! 🚀**

---

*Guia criado pela equipe Macspark - Revolucionando a infraestrutura empresarial*  
*Versão: 10.0 Quantum Enterprise Edition*  
*Data: $(date +%Y-%m-%d)* 
