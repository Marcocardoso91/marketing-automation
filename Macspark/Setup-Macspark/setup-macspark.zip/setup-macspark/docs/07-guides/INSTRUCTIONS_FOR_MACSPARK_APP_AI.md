# 🎯 INSTRUÇÕES PARA A IA DO MACSPARK-APP

## 📋 MISSÃO

Você está trabalhando no projeto **Macspark-App** e precisa integrá-lo ao ecossistema **Macspark-Setup**. Este documento contém todas as instruções necessárias para fazer essa integração funcionar perfeitamente.

---

## 🚀 O QUE VOCÊ PRECISA FAZER

### 1. **Criar um Dockerfile** (OBRIGATÓRIO)
- Localização: Raiz do projeto `Macspark-App`
- Use o template apropriado para sua tecnologia no arquivo `MACSPARK_APP_INTEGRATION_GUIDE.md`
- **IMPORTANTE**: O app deve expor a porta **3000** (ou configurável via variável `PORT`)

### 2. **Configurar Variáveis de Ambiente**
- Criar arquivo `.env.example` na raiz do projeto
- Incluir todas as variáveis listadas no guia de integração
- **FOCUS**: As variáveis de conexão com serviços (PostgreSQL, Redis, SparkOne)

### 3. **Implementar Health Check**
- Criar endpoint `/health` que retorna status 200
- Exemplo de resposta:
```json
{
  "status": "healthy",
  "timestamp": "2024-01-01T00:00:00.000Z",
  "version": "1.0.0"
}
```

### 4. **Configurar .dockerignore**
- Excluir `node_modules`, `.git`, `*.log`, etc.
- Otimizar o tamanho da imagem Docker

### 5. **Testar Build Local**
```bash
docker build -t macspark-app:test .
docker run -p 3000:3000 macspark-app:test
```

---

## 🔗 COMO OS PROJETOS SE CONECTAM

### Arquitetura de Rede
```
Internet → Traefik (Proxy) → Macspark-App (Container)
                              ↓
                         PostgreSQL, Redis, SparkOne
```

### Comunicação entre Serviços
- **PostgreSQL**: `postgresql:5432`
- **Redis**: `redis:6379`  
- **SparkOne API**: `sparkone:8000`

### Domínio de Acesso
- **Seu App**: `app.seudominio.com`
- **Traefik Dashboard**: `traefik.seudominio.com`
- **Portainer**: `portainer.seudominio.com`

---

## 📁 ARQUIVOS QUE VOCÊ DEVE CRIAR

### No repositório Macspark-App:
```
macspark-app/
├── Dockerfile              # ← CRIAR
├── .dockerignore           # ← CRIAR
├── .env.example            # ← CRIAR
├── docker-compose.yml      # ← CRIAR (usar template)
└── [seus arquivos existentes]
```

### Exemplo de .env.example:
```env
# App Configuration
NODE_ENV=production
PORT=3000

# Database (PostgreSQL)
POSTGRES_HOST=postgresql
POSTGRES_PORT=5432
POSTGRES_DB=macspark_app
POSTGRES_USER=macspark_app
POSTGRES_PASSWORD=${POSTGRES_PASSWORD}

# Cache (Redis)
REDIS_HOST=redis
REDIS_PORT=6379
REDIS_PASSWORD=${REDIS_PASSWORD}

# API Integration
SPARKONE_API_URL=http://sparkone:8000
SPARKONE_API_KEY=${SPARKONE_API_KEY}

# Security
JWT_SECRET=${JWT_SECRET}
SESSION_SECRET=${SESSION_SECRET}

# Domain
DOMAIN_SUFFIX=seudominio.com
APP_SUBDOMAIN=app
```

---

## 🔐 SEGURANÇA E SECRETS

### Secrets Gerenciados pelo Macspark-Setup:
- `POSTGRES_PASSWORD`
- `REDIS_PASSWORD` 
- `JWT_SECRET`
- `SESSION_SECRET`
- `SPARKONE_API_KEY`

### Como Acessar no Código:
```javascript
// Node.js
const dbPassword = process.env.POSTGRES_PASSWORD;
const jwtSecret = process.env.JWT_SECRET;
```

```python
# Python
import os
db_password = os.getenv('POSTGRES_PASSWORD')
jwt_secret = os.getenv('JWT_SECRET')
```

---

## 🚀 PROCESSO DE DEPLOY

### 1. Build da Imagem
```bash
# No repositório Macspark-App
docker build -t ghcr.io/SEU_USUARIO/macspark-app:latest .
docker push ghcr.io/SEU_USUARIO/macspark-app:latest
```

### 2. Deploy Automático
- O Macspark-Setup fará deploy automático
- Acessível em: `app.seudominio.com`
- SSL automático via Let's Encrypt

### 3. Atualizações
```bash
# Fazer push da nova imagem
docker build -t ghcr.io/SEU_USUARIO/macspark-app:latest .
docker push ghcr.io/SEU_USUARIO/macspark-app:latest

# Atualizar no servidor
docker service update macspark-app_webapp --image ghcr.io/SEU_USUARIO/macspark-app:latest
```

---

## 📊 MONITORAMENTO

### Logs Disponíveis:
```bash
# Logs do seu app
docker service logs -f macspark-app_webapp

# Logs do Traefik
docker service logs -f traefik_traefik
```

### Health Checks:
- Automáticos a cada 30 segundos
- Endpoint: `/health`
- Status: 200 = saudável

---

## 🔧 TROUBLESHOOTING

### Problemas Comuns:

#### 1. App não inicia
```bash
# Verificar logs
docker service logs macspark-app_webapp

# Verificar se a porta está correta (deve ser 3000)
```

#### 2. Erro de conexão com banco
```bash
# Verificar se PostgreSQL está rodando
docker service ls | grep postgresql

# Verificar variáveis de ambiente
docker service inspect macspark-app_webapp
```

#### 3. App não acessível via domínio
```bash
# Verificar se Traefik está roteando
docker service logs traefik_traefik

# Verificar DNS
nslookup app.seudominio.com
```

---

## ✅ CHECKLIST FINAL

Antes de considerar a integração completa:

- [ ] **Dockerfile** criado e testado
- [ ] **.env.example** configurado com todas as variáveis
- [ ] **Health check** endpoint implementado
- [ ] **.dockerignore** configurado
- [ ] **Build local** funcionando
- [ ] **Imagem Docker** pushada para registry
- [ ] **Documentação** atualizada

---

## 📞 SUPORTE

Se você tiver dúvidas sobre:
- **Configurações Docker**: Use os templates fornecidos
- **Variáveis de ambiente**: Consulte o `.env.example`
- **Integração de rede**: Leia o guia de integração
- **Deploy**: O Macspark-Setup cuida automaticamente

---

## 🎯 RESULTADO ESPERADO

Após implementar tudo corretamente:
1. Seu app estará rodando em `app.seudominio.com`
2. SSL automático funcionando
3. Conectividade com PostgreSQL, Redis e SparkOne
4. Monitoramento e logs automáticos
5. Deploy automatizado via Macspark-Setup

---

**Status**: Pronto para implementação  
**Prioridade**: ALTA  
**Dependências**: Docker, Registry (GitHub Container Registry recomendado) 