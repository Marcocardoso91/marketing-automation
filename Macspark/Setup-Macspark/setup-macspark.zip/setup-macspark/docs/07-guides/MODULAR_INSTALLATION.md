# 🚀 MACSPARK - INSTALAÇÃO MODULAR

## 📋 Visão Geral

O Macspark agora oferece um **sistema de instalação modular** que permite escolher exatamente quais componentes instalar, incluindo a opção de instalar ou não o **Macspark-App** (seu site/aplicação).

## 🎯 Tipos de Instalação

### 1. **Instalação Completa**
- Instala todos os componentes automaticamente
- Configuração padrão otimizada
- Ideal para quem quer tudo funcionando rapidamente

### 2. **Instalação Modular** ⭐ **RECOMENDADO**
- Permite escolher quais componentes instalar
- Configuração personalizada
- Ideal para quem quer controlar o que instala
- **Inclui opção para Macspark-App**

### 3. **Instalação Rápida (Core Apenas)**
- Instala apenas a infraestrutura básica
- Traefik, PostgreSQL, Redis
- Ideal para desenvolvimento ou teste

## 🚀 Como Usar

### Iniciar o Setup
```bash
# Execute o script principal
bash setup.sh
```

### Ou execute diretamente:
```bash
# Instalação modular (recomendado)
sudo bash install.sh

# Instalação completa
bash scripts/finalize-macspark.sh

# Instalação rápida (core apenas)
bash scripts/install-modular.sh
```

## 📦 Componentes Disponíveis

### 🔧 **CORE (Obrigatório)**
- Docker Swarm
- Traefik (Proxy Reverso)
- PostgreSQL
- Redis
- Portainer

### 🛡️ **SEGURANÇA**
- Firewall
- CrowdSec
- VaultWarden
- Headers de segurança

### 📊 **MONITORAMENTO**
- Prometheus
- Grafana
- Jaeger
- Netdata
- Health checks

### 💾 **BACKUP**
- Restic
- Agendamento automático
- Retenção configurável

### 🚀 **MACSPARK-APP** ⭐
- Seu site/aplicação principal
- **OPCIONAL** - você escolhe se quer instalar
- Requer containerização prévia

### 🤖 **SERVIÇOS AI**
- Ollama
- Claude Interface
- SparkOne (agentes inteligentes)

### 📚 **PRODUTIVIDADE**
- BookStack
- OnlyOffice
- WeKan
- Excalidraw
- Penpot

### 💬 **CHAT**
- RocketChat
- Chatwoot

### 📁 **STORAGE**
- NextCloud
- Harbor Registry

## 🎯 Exemplo de Instalação Modular

### Passo 1: Executar Setup
```bash
bash setup.sh
```

### Passo 2: Escolher "Instalação Modular"

### Passo 3: Selecionar Componentes
```
🔧 COMPONENTE CORE (OBRIGATÓRIO)
✅ Instalar componente CORE? [y]: y

🛡️ COMPONENTE SEGURANÇA
✅ Instalar componente SEGURANÇA? [y]: y

📊 COMPONENTE MONITORAMENTO
✅ Instalar componente MONITORAMENTO? [y]: y

💾 COMPONENTE BACKUP
✅ Instalar componente BACKUP? [y]: y

🚀 COMPONENTE MACSPARK-APP
✅ Instalar componente MACSPARK-APP? [n]: y  ← SUA ESCOLHA!

🤖 COMPONENTE SERVIÇOS AI
✅ Instalar componente SERVIÇOS AI? [n]: n

📚 COMPONENTE PRODUTIVIDADE
✅ Instalar componente PRODUTIVIDADE? [n]: n

💬 COMPONENTE CHAT
✅ Instalar componente CHAT? [n]: n

📁 COMPONENTE STORAGE
✅ Instalar componente STORAGE? [n]: n
```

### Passo 4: Configurações Adicionais
```
📋 CONFIGURAÇÕES ADICIONAIS

Digite o sufixo do domínio (ex: meudominio.com) [localhost]: meudominio.com

Habilitar SSL automático (Let's Encrypt)? (y/n) [y]: y

Dias de retenção de backup [30]: 30
```

### Passo 5: Confirmação
```
📋 RESUMO DA CONFIGURAÇÃO

Componentes selecionados:
  ✅ core
  ✅ security
  ✅ monitoring
  ✅ backup
  ✅ macspark_app  ← SEU APP!

Configurações:
  Domínio: meudominio.com
  SSL: true
  Retenção de backup: 30 dias

Confirmar instalação com essas configurações? (y/n) [y]: y
```

## 🔧 Configuração do Macspark-App

### Pré-requisitos
Para instalar o **Macspark-App**, você precisa:

1. **Containerizar o app** (Dockerfile)
2. **Configurar variáveis de ambiente**
3. **Implementar health check**
4. **Fazer push da imagem**

### Documentação Completa
Consulte os arquivos criados para a IA do Macspark-App:
- `MACSPARK_APP_INTEGRATION_GUIDE.md`
- `INSTRUCTIONS_FOR_MACSPARK_APP_AI.md`
- `stacks/apps/macspark-app-template.yml`

## 📁 Arquivos de Configuração

### Configuração Salva
```
.macspark-config
```
Contém todas as suas escolhas e configurações.

### Logs de Instalação
```
/tmp/macspark-modular-YYYYMMDD-HHMMSS.log
```
Log detalhado de toda a instalação.

## 🔄 Adicionar Componentes Posteriormente

### Opção 1: Re-executar Setup Modular
```bash
sudo bash install.sh
```
Selecione apenas os novos componentes.

### Opção 2: Instalação Manual
```bash
# Exemplo: adicionar monitoramento
docker stack deploy -c stacks/monitoring/monitoring-stack.yml monitoring
```

## 🎯 URLs de Acesso

Após a instalação, você terá acesso a:

### Sempre Disponível
- **Traefik Dashboard**: `https://traefik.seudominio.com`
- **Portainer**: `https://portainer.seudominio.com`

### Baseado nos Componentes Instalados
- **Macspark-App**: `https://app.seudominio.com` (se instalado)
- **Grafana**: `https://grafana.seudominio.com` (se monitoramento instalado)
- **BookStack**: `https://bookstack.seudominio.com` (se produtividade instalado)
- **RocketChat**: `https://chat.seudominio.com` (se chat instalado)
- **NextCloud**: `https://cloud.seudominio.com` (se storage instalado)

## 🔧 Troubleshooting

### Problema: "Arquivo de configuração não encontrado"
```bash
# Solução: Execute o setup interativo primeiro
sudo bash install.sh
```

### Problema: "Macspark-App não encontrado"
```bash
# Solução: Certifique-se de que o app está containerizado
# Consulte a documentação de integração
```

### Problema: Componente não instalou
```bash
# Verificar logs
docker service logs -f [nome_do_servico]

# Verificar status
docker stack ls
docker service ls
```

## 📋 Checklist de Instalação

### Antes da Instalação
- [ ] Docker instalado e funcionando
- [ ] Domínio configurado (se usando SSL)
- [ ] Macspark-App containerizado (se vai instalar)

### Durante a Instalação
- [ ] Escolher tipo de instalação
- [ ] Selecionar componentes desejados
- [ ] Configurar domínio e SSL
- [ ] Confirmar configurações

### Após a Instalação
- [ ] Verificar serviços ativos
- [ ] Testar URLs de acesso
- [ ] Configurar monitoramento
- [ ] Fazer backup inicial

## 🎉 Vantagens do Sistema Modular

### ✅ **Flexibilidade**
- Escolha exatamente o que precisa
- Evita instalar serviços desnecessários
- Economiza recursos

### ✅ **Controle**
- Você decide sobre o Macspark-App
- Configuração personalizada
- Fácil de expandir depois

### ✅ **Eficiência**
- Instalação mais rápida
- Menos uso de recursos
- Configuração otimizada

### ✅ **Manutenibilidade**
- Fácil de gerenciar
- Componentes isolados
- Troubleshooting simplificado

---

**Status**: Pronto para uso  
**Versão**: 1.0  
**Data**: $(date +%Y-%m-%d) 
