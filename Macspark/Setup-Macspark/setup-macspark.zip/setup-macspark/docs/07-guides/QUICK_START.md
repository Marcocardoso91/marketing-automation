# 🚀 MACSPARK SETUP - GUIA DE INÍCIO RÁPIDO

## 🎯 **ESCOLHA SEU CENÁRIO DE INSTALAÇÃO**

### ⭐ **CENÁRIO 1: VPS LIMPA / PRIMEIRA INSTALAÇÃO** (RECOMENDADO)

**👤 Para quem**: Nunca teve acesso ao Macspark Setup e está com VPS completamente limpa  
**⏱️ Tempo**: 10-15 minutos  
**🎯 Resultado**: Sistema completo funcionando

#### 📋 **Pré-requisitos para VPS Limpa**
- ✅ **VPS Linux** (Ubuntu 22.04 LTS+, Debian 11+, CentOS 8+)
- ✅ **Acesso root/sudo** no servidor
- ✅ **Conexão internet** estável
- ✅ **Portas 80 e 443** liberadas no firewall
- ✅ **Domínio** (opcional, mas recomendado para SSL)

#### 🚀 **Instalação VPS Limpa (3 Passos Simples)**

```bash
# 🔄 PASSO 1: PREPARAR VPS (Instala Docker, Git, dependências)
curl -fsSL https://get.docker.com | sh && \
sudo usermod -aG docker $USER && \
sudo apt update && sudo apt install -y git htpasswd && \
sudo reboot

# 🚀 PASSO 2: INSTALAR MACSPARK (após reboot)
cd /opt && \
sudo git clone https://github.com/Marcocardoso28/Macspark-Setup.git && \
cd Macspark-Setup && \
sudo chmod +x scripts/*.sh scripts/*/*.sh && \
bash scripts/create-smart-env.sh && \
sudo bash scripts/installation/quick-install.sh

# ✅ PASSO 3: VERIFICAR INSTALAÇÃO
bash scripts/macspark-system-checker.sh --quick
```

#### 🎉 **O que será instalado automaticamente:**
- ✅ **Docker Swarm** - Orquestração de containers
- ✅ **Traefik** - Proxy reverso + SSL automático
- ✅ **PostgreSQL** - Banco de dados enterprise
- ✅ **Redis** - Cache de alta performance
- ✅ **SparkOne** - Agente IA revolucionário
- ✅ **Portainer** - Interface de gerenciamento
- ✅ **Netdata** - Monitoramento em tempo real

#### 🌐 **URLs de Acesso (VPS Limpa)**
```bash
# Com domínio próprio:
https://traefik.seudominio.com     # Dashboard Traefik
https://portainer.seudominio.com   # Gerenciamento Docker
https://sparkone.seudominio.com    # IA SparkOne
https://netdata.seudominio.com     # Monitoramento

# Sem domínio (usando nip.io):
http://traefik.SEU_IP_VPS.nip.io
http://portainer.SEU_IP_VPS.nip.io
http://sparkone.SEU_IP_VPS.nip.io
http://netdata.SEU_IP_VPS.nip.io
```

---

### 🔄 **CENÁRIO 2: JÁ TENHO MACSPARK - ATUALIZAR/ADICIONAR**

**👤 Para quem**: Já tem Macspark instalado e quer atualizar ou adicionar serviços  
**⏱️ Tempo**: 5-10 minutos  
**🎯 Resultado**: Novos serviços adicionados, sem perder configurações

#### 🔄 **Atualização e Adição de Serviços**

```bash
# 🔄 SEMPRE atualize o repositório primeiro
cd /opt/Macspark-Setup  # ou onde você clonou
git pull origin main
chmod +x scripts/*.sh scripts/*/*.sh

# 🧠 Sistema inteligente detecta automaticamente:
# - Quais serviços já estão instalados
# - Quais estão disponíveis para instalar
# - Sugere os melhores para seu perfil
sudo bash install.sh
```

#### ✅ **O sistema é inteligente:**
- 🧠 **Detecta automaticamente** o que já está rodando
- 🎯 **Oferece apenas** serviços que ainda não foram instalados
- 🔧 **Mantém configurações** existentes
- 💾 **Faz backup automático** antes de mudanças

---

### 🛠️ **CENÁRIO 3: INSTALAÇÃO PERSONALIZADA**

**👤 Para quem**: Usuários experientes que querem controle total  
**⏱️ Tempo**: 15-30 minutos  
**🎯 Resultado**: Sistema configurado exatamente como desejado

#### 🤖 **Opção 3A: IA Automática (Único no mundo)**
```bash
# IA detecta automaticamente seu perfil e configura
bash scripts/create-smart-env.sh
sudo bash scripts/installation/quick-install.sh
```

#### ⚙️ **Opção 3B: Menu Interativo**
```bash
# Menu com 5 opções diferentes
bash setup.sh
```

**Opções disponíveis:**
- **Opção 1**: Instalação Rápida (core + essenciais)
- **Opção 2**: Instalação Core (minimalista)
- **Opção 3**: Instalação Interativa (personalizada)
- **Opção 4**: Instalação Modular (configuração existente)
- **Opção 5**: Deploy Macspark-App (apenas a aplicação)

#### 🏢 **Opção 3C: Enterprise Completa**
```bash
# Para empresas que querem tudo + Alta Disponibilidade
sudo bash scripts/finalize-macspark.sh
```

---

### ⚡ **CENÁRIO 4: INSTALAÇÕES ESPECÍFICAS**

**👤 Para quem**: Quer apenas componentes específicos  
**⏱️ Tempo**: 3-5 minutos  
**🎯 Resultado**: Apenas o que foi solicitado

#### 🔧 **Opção 4A: Apenas Traefik + Portainer (Mínimo)**
```bash
sudo bash scripts/installation/install-traefik-portainer.sh
```

#### 💻 **Opção 4B: Apenas Core (PostgreSQL + Redis + Traefik)**
```bash
bash scripts/installation/install-core-only.sh
```

#### 🔒 **Opção 4C: Instalação Segura (Com todas as validações)**
```bash
bash scripts/installation/install-secure.sh
```

---

## 🎯 **COMO ESCOLHER A OPÇÃO CERTA?**

| Seu Perfil | Cenário Recomendado | Por quê? |
|-------------|--------------------|---------| 
| 🆕 **Iniciante com VPS nova** | **CENÁRIO 1** ⭐ | Mais simples, tudo automático |
| 🔄 **Já uso Macspark** | **CENÁRIO 2** | Preserva configurações, adiciona só o novo |
| 🧠 **Experiente** | **CENÁRIO 3** | Controle total, personalizações avançadas |
| ⚡ **Quero só o básico** | **CENÁRIO 4** | Rápido, apenas o essencial |

---

## 🛠️ **COMANDOS ÚTEIS PARA TODOS OS CENÁRIOS**

## 🔧 Opções de Instalação Detalhadas

### Opção 1: Instalação Rápida
```bash
bash scripts/quick-install.sh
```

**Instala:**
- ✅ Traefik (Proxy Reverso + SSL)
- ✅ PostgreSQL (Banco de Dados)
- ✅ Redis (Cache)
- ✅ SparkOne (Agente IA)
- ✅ Portainer (Gerenciamento Docker)
- ✅ Netdata (Monitoramento)
- 🔄 Opção de incluir Macspark-App

### Opção 2: Instalação Core
```bash
bash scripts/install-core-only.sh
```

**Instala apenas:**
- ✅ Traefik (Proxy Reverso + SSL)
- ✅ PostgreSQL (Banco de Dados)
- ✅ Redis (Cache)

### Opção 3: Instalação Interativa
```bash
sudo bash install.sh
```

**Permite escolher:**
- 🛡️ Componente Segurança
- 📊 Componente Monitoramento
- 💾 Componente Backup
- 🚀 Componente Macspark-App
- 🤖 Componente Serviços AI
- 📚 Componente Produtividade
- 💬 Componente Chat
- 📁 Componente Storage

### Opção 4: Instalação Modular
```bash
bash scripts/install-modular.sh
```

**Usa arquivo de configuração:**
- 📄 Lê `.macspark-config`
- 🔧 Permite configuração avançada
- 🔄 Cria configuração padrão se não existir

## 🌐 URLs de Acesso

Após a instalação, os serviços estarão disponíveis em:

- **Traefik Dashboard**: https://traefik.localhost
- **Portainer**: https://portainer.localhost  
- **Netdata**: https://netdata.localhost
- **Macspark-App**: https://app.localhost (se instalado)

## 🛠️ Comandos Úteis

### Verificar Status dos Serviços
```bash
# ⭐ VERIFICAÇÃO COMPLETA (RECOMENDADO) - NOVO!
bash scripts/check-all-services-complete.sh

# Comandos básicos
docker stack ls
docker service ls
```

### Verificar Logs
```bash
docker service logs <nome_do_servico>
```

### Remover Tudo
```bash
docker stack rm traefik postgresql redis
docker swarm leave --force
```

## 🔧 Problemas Resolvidos

### ✅ Script Interactive-Setup.sh
- **Problema**: Travamento na entrada do usuário
- **Solução**: Timeout de 30s e modo não-interativo
- **Melhoria**: Valores padrão inteligentes

### ✅ Script Install-Modular.sh  
- **Problema**: Dependência de arquivo de configuração
- **Solução**: Criação de configuração padrão
- **Melhoria**: Pergunta ao usuário antes de criar

### ✅ Script Install-Core-Only.sh
- **Problema**: Script não existia
- **Solução**: Criado script minimalista
- **Melhoria**: Instalação apenas do essencial

### ✅ Script Quick-Install.sh
- **Problema**: Dependências não verificadas
- **Solução**: Verificação de arquivos de stack
- **Melhoria**: Health checks robustos

### ✅ Script Setup.sh Principal
- **Problema**: Falta de verificações
- **Solução**: Verificação de Docker e pré-requisitos
- **Melhoria**: Timeout para ambientes não-interativos

## 🚀 Setup Vivo - Características

### 🔄 Auto-recuperação
- Scripts detectam e corrigem problemas
- Configurações padrão inteligentes
- Fallbacks automáticos

### 📋 Múltiplas Opções
- 5 formas diferentes de instalar
- Desde minimalista até completa
- Personalização total

### 🛡️ Validações
- Verificações de pré-requisitos
- Validação de arquivos necessários
- Tratamento de erros robusto

### 📊 Health Checks
- Monitoramento automático
- Verificação de status dos serviços
- Relatórios detalhados

### 📝 Logs Detalhados
- Debugging facilitado
- Histórico completo
- Logs estruturados

### 🔧 Configuração Flexível
- Padrões inteligentes
- Personalização avançada
- Configuração modular

## 🆘 Solução de Problemas

### Docker não está rodando
```bash
sudo systemctl start docker
sudo systemctl enable docker
```

### Porta já está em uso
```bash
sudo lsof -i :80
sudo lsof -i :443
```

### Serviço não está subindo
```bash
docker service logs <nome_do_servico>
docker service ps <nome_do_servico>
```

### Resetar tudo
```bash
docker system prune -a
docker volume prune
docker network prune
```

## 📚 Próximos Passos

1. **Configure seu domínio** para apontar para o servidor
2. **Aguarde os certificados SSL** serem gerados
3. **Acesse os serviços** através das URLs
4. **Customize conforme necessário**

## 🤝 Suporte

- 📖 **Documentação**: README.md
- 🐛 **Issues**: GitHub Issues
- 💬 **Discussões**: GitHub Discussions
- 📧 **Email**: suporte@macspark.com

---

**🎉 Agora você tem um setup vivo e robusto!** 🚀 
