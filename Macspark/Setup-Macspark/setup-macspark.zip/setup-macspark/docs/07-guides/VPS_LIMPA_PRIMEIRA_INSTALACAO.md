# 🆕 VPS LIMPA - PRIMEIRA INSTALAÇÃO DO MACSPARK

**Guia específico para quem nunca teve acesso ao Macspark Setup e está com VPS completamente limpa**

---

## 🎯 **ESTE GUIA É PARA VOCÊ SE:**

- ✅ **Nunca instalou** o Macspark Setup antes
- ✅ **VPS nova/limpa** sem Docker ou outros serviços
- ✅ **Quer resultado rápido** - sistema funcionando em 15 minutos
- ✅ **Prefere automático** - mínima intervenção manual
- ✅ **Busca simplicidade** - sem configurações complexas

---

## ⚡ **INSTALAÇÃO EM 3 PASSOS SIMPLES**

### 🔧 **PASSO 1: PREPARAR VPS (5 minutos)**

```bash
# Conecte-se à sua VPS via SSH
ssh root@SEU_IP_VPS
# ou
ssh usuario@SEU_IP_VPS

# Execute o comando de preparação (instala Docker + dependências)
curl -fsSL https://get.docker.com | sh && \
sudo usermod -aG docker $USER && \
sudo apt update && sudo apt install -y git htpasswd net-tools && \
sudo reboot
```

**⏳ Aguarde**: A VPS irá reiniciar (1-2 minutos)

---

### 🚀 **PASSO 2: INSTALAR MACSPARK (5 minutos)**

```bash
# Reconecte-se após o reboot
ssh usuario@SEU_IP_VPS

# Vá para o diretório padrão e clone o projeto
cd /opt && \
sudo git clone https://github.com/Marcocardoso28/Macspark-Setup.git && \
cd Macspark-Setup && \
sudo chmod +x scripts/*.sh scripts/*/*.sh

# Configure automaticamente com IA (detecta seu perfil)
bash scripts/create-smart-env.sh

# Instale o sistema completo
sudo bash scripts/installation/quick-install.sh
```

**🤖 Durante a instalação:**
- A IA detecta automaticamente recursos da VPS
- Gera senhas seguras automaticamente  
- Configura SSL com certificados grátis
- Instala todos os serviços essenciais

---

### ✅ **PASSO 3: VERIFICAR E ACESSAR (2 minutos)**

```bash
# Verificar se tudo está funcionando (NOVO SCRIPT COMPLETO)
bash scripts/check-all-services-complete.sh

# Verificação rápida alternativa
bash scripts/macspark-system-checker.sh --quick

# Listar todos os serviços instalados
docker service ls
```

**🌐 Acessar seus serviços:**

**Se você tem domínio configurado:**
```
https://traefik.seudominio.com     # Dashboard Traefik
https://portainer.seudominio.com   # Gerenciamento Docker
https://sparkone.seudominio.com    # IA SparkOne
https://netdata.seudominio.com     # Monitoramento
```

**Se não tem domínio (funciona imediatamente):**
```
http://traefik.SEU_IP_VPS.nip.io
http://portainer.SEU_IP_VPS.nip.io  
http://sparkone.SEU_IP_VPS.nip.io
http://netdata.SEU_IP_VPS.nip.io
```

*Substitua `SEU_IP_VPS` pelo IP real da sua VPS*

---

## 🎉 **PRONTO! O QUE VOCÊ TEM AGORA:**

### 🛠️ **Serviços Instalados**
- ✅ **Traefik**: Proxy reverso + SSL automático
- ✅ **PostgreSQL**: Banco de dados enterprise
- ✅ **Redis**: Cache de alta performance
- ✅ **SparkOne**: Agente IA revolucionário
- ✅ **Portainer**: Interface visual para Docker
- ✅ **Netdata**: Monitoramento em tempo real

### 🔒 **Segurança Configurada**
- ✅ **SSL/HTTPS**: Certificados automáticos
- ✅ **Firewall**: Portas corretas liberadas
- ✅ **Senhas**: Geradas automaticamente (ultra-seguras)
- ✅ **Headers**: Proteções de segurança aplicadas

### 🎯 **Sistema Pronto Para**
- ✅ **Produção**: SSL e segurança configurados
- ✅ **Expansão**: Adicionar mais serviços facilmente
- ✅ **Monitoramento**: Dashboards funcionando
- ✅ **Desenvolvimento**: APIs e interfaces prontas

---

## 📋 **PRÉ-REQUISITOS MÍNIMOS**

### 🖥️ **VPS/Servidor**
- **Sistema**: Ubuntu 22.04 LTS+, Debian 11+, ou CentOS 8+
- **CPU**: 2 cores mínimo (recomendado 8 cores)
- **RAM**: 8GB mínimo (recomendado 16GB)
- **Disco**: 40GB mínimo (recomendado 100GB)
- **Rede**: IP público com portas 80 e 443 abertas

### 🔑 **Acesso**
- **SSH**: Acesso como root ou usuário com sudo
- **Internet**: Conexão estável para downloads

### 🌐 **Domínio (Opcional)**
- **Recomendado**: Para SSL automático e URLs amigáveis
- **Alternativa**: Usar nip.io (funciona sem configuração)

---

## 🚀 **PRÓXIMOS PASSOS**

### 1️⃣ **Configure seu Domínio (Opcional)**
Se você tem um domínio, aponte os subdomínios para o IP da VPS:
```
traefik.seudominio.com  → SEU_IP_VPS
portainer.seudominio.com → SEU_IP_VPS
sparkone.seudominio.com → SEU_IP_VPS
netdata.seudominio.com → SEU_IP_VPS
```

### 2️⃣ **Adicione Mais Serviços**
```bash
# Atualizar repositório (sempre fazer antes de adicionar)
cd /opt/Macspark-Setup
git pull origin main
chmod +x scripts/*.sh scripts/*/*.sh

# Sistema inteligente para adicionar serviços
sudo bash install.sh
```

### 3️⃣ **Configure Backup Automático**
```bash
# Configurar backup diário automático
bash scripts/backup/backup-ultimate.sh
```

---

## 🆘 **PROBLEMAS COMUNS E SOLUÇÕES**

### ❌ **"docker: command not found"**
```bash
# Reinstalar Docker
curl -fsSL https://get.docker.com | sh
sudo systemctl start docker
sudo usermod -aG docker $USER
```

### ❌ **"Permission denied"**
```bash
# Dar permissões corretas
sudo chmod +x scripts/*.sh scripts/*/*.sh
sudo chown -R $USER:$USER /opt/Macspark-Setup
```

### ❌ **"Port already in use"**
```bash
# Verificar o que está usando a porta
sudo lsof -i :80
sudo lsof -i :443

# Parar serviços conflitantes (se necessário)
sudo systemctl stop apache2
sudo systemctl stop nginx
```

### ❌ **Serviços não sobem**
```bash
# Verificar logs
docker service logs nome_do_servico

# Verificar recursos
free -h
df -h

# Reiniciar serviço
docker service update --force nome_do_servico
```

---

## 📞 **SUPORTE**

### 🔍 **Diagnóstico Automático**
```bash
# Verificação completa do sistema
bash scripts/diagnose-vps-installation.sh

# Correção automática de problemas
bash scripts/fix-common-vps-issues.sh
```

### 📚 **Documentação**
- **Guia Completo**: [INSTALL_VPS.md](INSTALL_VPS.md)
- **Troubleshooting**: [TROUBLESHOOTING.md](TROUBLESHOOTING.md)
- **Adição de Serviços**: [README.md](../../README.md)

### 💬 **Comunidade**
- **GitHub Issues**: Para reportar problemas
- **GitHub Discussions**: Para dúvidas gerais
- **Email**: suporte@macspark.dev

---

**🎉 Parabéns! Você agora tem um sistema enterprise funcionando em sua VPS!** 🚀 
