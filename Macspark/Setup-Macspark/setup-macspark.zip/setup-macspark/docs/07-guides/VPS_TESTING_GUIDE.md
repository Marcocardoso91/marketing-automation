# 🧪 GUIA DE TESTES PARA VPS - MACSPARK SETUP

Este guia é específico para a fase final de testes de instalação em VPS. Use os scripts criados para identificar e corrigir problemas automaticamente.

---

## 🎯 OBJETIVO DOS TESTES

Durante a fase final de desenvolvimento, você deve:

1. **🔍 Identificar problemas** comuns em diferentes VPS
2. **🔧 Corrigir automaticamente** problemas encontrados
3. **📊 Documentar** soluções para melhorar o projeto
4. **✅ Validar** que a instalação funciona em diferentes ambientes

---

## 🛠️ SCRIPTS CRIADOS PARA TESTES

### 1. **⚡ Verificação Rápida** - `scripts/quick-vps-check.sh`

**O que faz:**
- Verifica sistema operacional e arquitetura
- Testa Docker e Docker Swarm
- Verifica recursos (RAM, disco)
- Testa conectividade de rede
- Verifica arquivos do projeto
- Testa permissões
- Verifica status dos serviços

**Como usar:**
```bash
# Execute na VPS para diagnóstico rápido
bash scripts/quick-vps-check.sh
```

**Saída esperada:**
```
⚡ MACSPARK VPS QUICK CHECK
============================
🔍 Verificações rápidas...
[SUCCESS] Sistema: Ubuntu 22.04.3 LTS
[SUCCESS] Docker: 24.0.7
[SUCCESS] Docker está rodando
[SUCCESS] Docker Swarm ativo
[SUCCESS] Git: 2.34.0
[INFO] RAM: 4GB
[SUCCESS] RAM adequada: 4GB
[INFO] Disco: 25GB
[SUCCESS] Espaço adequado: 25GB
```

### 2. **🔧 Correção Automática** - `scripts/fix-common-vps-issues.sh`

**O que faz:**
- Instala Docker se necessário
- Configura Docker Swarm
- Corrige permissões de arquivos
- Cria arquivo .env se não existir
- Configura variáveis básicas
- Cria redes Docker necessárias
- Reinicia serviços com problemas

**Como usar:**
```bash
# Execute para corrigir problemas automaticamente
bash scripts/fix-common-vps-issues.sh
```

**Exemplo de interação:**
```
🔧 MACSPARK VPS ISSUE FIXER
============================
🔧 Iniciando correção de problemas comuns...

=== CORRIGINDO PROBLEMAS DO DOCKER ===
[INFO] Docker não encontrado. Instalando...
Instalar Docker automaticamente? (y/N): y
[SUCCESS] ✅ Instalando Docker concluído
[SUCCESS] ✅ Adicionando usuário ao grupo docker concluído
[WARNING] ⚠️  Faça logout e login novamente para aplicar as permissões do Docker
```

### 3. **📊 Diagnóstico Avançado** - `scripts/diagnose-vps-installation.sh`

**O que faz:**
- Diagnóstico completo do sistema
- Análise detalhada de logs
- Relatório com problemas encontrados
- Sugestões de correção
- Logs salvos para análise

**Como usar:**
```bash
# Execute para diagnóstico detalhado
bash scripts/diagnose-vps-installation.sh
```

---

## 🚀 FLUXO DE TESTE RECOMENDADO

### **PASSO 1: Preparação da VPS**
```bash
# 1. Clone o projeto
git clone https://github.com/Marcocardoso28/Macspark-Setup.git
cd Macspark-Setup

# 2. Execute verificação inicial
bash scripts/quick-vps-check.sh
```

### **PASSO 2: Correção de Problemas**
```bash
# Execute correções automáticas se necessário
bash scripts/fix-common-vps-issues.sh
```

### **PASSO 3: Instalação**
```bash
# Execute a instalação
bash setup.sh
# Escolha o modo de instalação (teste ou produção)
```

### **PASSO 4: Verificação Final**
```bash
# Verifique se tudo está funcionando
bash scripts/quick-vps-check.sh

# Teste conectividade dos serviços
curl http://localhost:8080  # Traefik
curl http://localhost:9000  # Portainer
```

---

## 📋 CHECKLIST DE TESTES

### **✅ Pré-Instalação**
- [ ] VPS com Ubuntu 22.04 LTS+ ou Debian 11+
- [ ] Mínimo 8GB RAM (recomendado 16GB+)
- [ ] Mínimo 10GB espaço em disco
- [ ] Conectividade com internet
- [ ] Acesso root ou sudo

### **✅ Durante Instalação**
- [ ] Docker instala corretamente
- [ ] Docker Swarm inicializa
- [ ] Arquivo .env é criado
- [ ] Scripts executam sem erros
- [ ] Serviços iniciam corretamente

### **✅ Pós-Instalação**
- [ ] Traefik responde na porta 8080
- [ ] Portainer responde na porta 9000
- [ ] PostgreSQL está rodando
- [ ] Redis está rodando
- [ ] Redes Docker foram criadas
- [ ] Secrets foram criados

---

## 🚨 PROBLEMAS COMUNS E SOLUÇÕES

### **❌ Docker não instala**
**Sintoma:** Erro "docker: command not found"
**Solução:** Execute `bash scripts/fix-common-vps-issues.sh`

### **❌ Docker Swarm não inicializa**
**Sintoma:** Erro "Swarm: inactive"
**Solução:** Execute `docker swarm init`

### **❌ Permissões de arquivo**
**Sintoma:** Erro "Permission denied"
**Solução:** Execute `chmod +x scripts/*.sh`

### **❌ Arquivo .env não encontrado**
**Sintoma:** Erro "File .env not found"
**Solução:** Execute `cp env.example .env`

### **❌ Portas em uso**
**Sintoma:** Erro "port already in use"
**Solução:** Verifique com `netstat -tuln` e pare serviços conflitantes

---

## 📊 COLETANDO LOGS PARA ANÁLISE

### **Logs do Sistema**
```bash
# Informações básicas
cat /etc/os-release
uname -a
df -h
free -h

# Logs do Docker
docker version
docker info
docker service ls
```

### **Logs de Serviços**
```bash
# Logs do Traefik
docker service logs traefik_traefik

# Logs do Portainer
docker service logs portainer_portainer

# Logs do PostgreSQL
docker service logs postgresql_postgresql
```

### **Logs de Erro**
```bash
# Logs do sistema
dmesg | tail -50

# Logs de serviços com problemas
docker service logs [nome_serviço] --tail 100
```

---

## 🔄 PROCESSO DE MELHORIA

### **1. Identificar Problema**
- Execute `bash scripts/quick-vps-check.sh`
- Anote o problema encontrado

### **2. Tentar Correção Automática**
- Execute `bash scripts/fix-common-vps-issues.sh`
- Verifique se o problema foi resolvido

### **3. Se Não Resolvido**
- Execute `bash scripts/diagnose-vps-installation.sh`
- Colete logs detalhados
- Documente o problema

### **4. Reportar e Corrigir**
- Abra issue no GitHub com logs
- Implemente correção no código
- Teste novamente

---

## 📝 TEMPLATE DE REPORTE

Quando encontrar um problema, use este template:

```markdown
## 🐛 Problema Encontrado

**VPS:** [Tipo e configuração]
**Sistema:** [Ubuntu/Debian + versão]
**RAM:** [Quantidade]
**Disco:** [Quantidade]

**Problema:**
[Descrição detalhada do problema]

**Comandos Executados:**
```bash
bash scripts/quick-vps-check.sh
# Saída do comando
```

**Logs Relevantes:**
```bash
# Colete logs aqui
```

**Tentativas de Correção:**
```bash
bash scripts/fix-common-vps-issues.sh
# Resultado
```

**Solução Encontrada:**
[Como foi resolvido, se aplicável]
```

---

## 🎯 METAS DOS TESTES

### **Objetivos Principais**
- [ ] Instalação funciona em VPS limpa
- [ ] Instalação funciona em VPS com conteúdo existente
- [ ] Correções automáticas funcionam
- [ ] Documentação está clara e completa
- [ ] Scripts são robustos e confiáveis

### **Métricas de Sucesso**
- ✅ 95%+ das instalações sem intervenção manual
- ✅ Tempo de instalação < 30 minutos
- ✅ Zero problemas críticos não documentados
- ✅ Todos os serviços funcionando após instalação

---

## 🔗 LINKS ÚTEIS

- [📖 Documentação Principal](README.md)
- [🔧 Troubleshooting VPS](VPS_TROUBLESHOOTING.md)
- [🚀 Guia de Instalação](INSTALL_VPS.md)
- [📊 Relatório de Auditoria](AUDIT_FINAL_REPORT.md)

---

**🎉 Parabéns por ajudar a finalizar o Macspark Setup!**

Cada teste e correção contribui para tornar o projeto mais robusto e confiável. 