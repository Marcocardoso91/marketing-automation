# 🔧 MACSPARK VPS TROUBLESHOOTING GUIDE

Este guia contém soluções para problemas comuns encontrados durante a instalação do Macspark em VPS.

---

## 🚨 PROBLEMAS CRÍTICOS

### ❌ Docker não está instalado

**Sintomas:**
- Comando `docker` não encontrado
- Erro: "docker: command not found"

**Solução:**
```bash
# Instalar Docker
curl -fsSL https://get.docker.com | sh

# Adicionar usuário ao grupo docker
sudo usermod -aG docker $USER

# Reiniciar ou fazer logout/login
sudo reboot
```

### ❌ Docker não está rodando

**Sintomas:**
- Erro: "Cannot connect to the Docker daemon"
- Docker instalado mas não responde

**Solução:**
```bash
# Iniciar Docker
sudo systemctl start docker

# Habilitar no boot
sudo systemctl enable docker

# Verificar status
sudo systemctl status docker
```

### ❌ Docker Swarm não está ativo

**Sintomas:**
- Erro: "Swarm: inactive"
- Falha ao fazer deploy de stacks

**Solução:**
```bash
# Inicializar Docker Swarm
docker swarm init

# Verificar status
docker info | grep Swarm
```

### ❌ Permissões de arquivo

**Sintomas:**
- Erro: "Permission denied"
- Scripts não executáveis

**Solução:**
```bash
# Tornar scripts executáveis
chmod +x scripts/*.sh

# Corrigir permissões do diretório
sudo chown -R $USER:$USER /opt/macspark
```

---

## ⚠️ PROBLEMAS DE CONFIGURAÇÃO

### ⚠️ Arquivo .env não encontrado

**Sintomas:**
- Erro: "File .env not found"
- Variáveis não configuradas

**Solução:**
```bash
# Copiar arquivo de exemplo
cp env.example .env

# Editar configurações
nano .env
```

### ⚠️ DOMAIN_SUFFIX não configurado

**Sintomas:**
- URLs não funcionam
- Erro de configuração de domínio

**Solução:**
```bash
# Editar .env
nano .env

# Adicionar ou modificar:
DOMAIN_SUFFIX="seu-ip.nip.io"
# ou para testes locais:
DOMAIN_SUFFIX="localhost"
```

### ⚠️ Portas já em uso

**Sintomas:**
- Erro: "port already in use"
- Serviços não iniciam

**Solução:**
```bash
# Verificar portas em uso
netstat -tuln | grep :8080

# Parar serviços conflitantes
sudo systemctl stop apache2  # se estiver usando porta 80
sudo systemctl stop nginx     # se estiver usando porta 80

# Ou alterar portas no .env
```

---

## 🔧 PROBLEMAS DE REDE

### 🔧 Sem conectividade com internet

**Sintomas:**
- Falha ao baixar imagens Docker
- Timeout em requisições

**Solução:**
```bash
# Testar conectividade
ping -c 3 8.8.8.8

# Verificar DNS
nslookup google.com

# Se necessário, configurar DNS
echo "nameserver 8.8.8.8" | sudo tee -a /etc/resolv.conf
echo "nameserver 8.8.4.4" | sudo tee -a /etc/resolv.conf
```

### 🔧 Firewall bloqueando portas

**Sintomas:**
- Serviços não acessíveis externamente
- Timeout em conexões

**Solução:**
```bash
# Verificar UFW
sudo ufw status

# Se ativo, liberar portas necessárias
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 8080/tcp
sudo ufw allow 9000/tcp
```

---

## 🐳 PROBLEMAS DO DOCKER

### 🐳 Imagens não baixam

**Sintomas:**
- Erro: "pull access denied"
- Timeout ao baixar imagens

**Solução:**
```bash
# Verificar espaço em disco
df -h

# Limpar cache Docker
docker system prune -a

# Tentar novamente
docker pull [imagem]
```

### 🐳 Serviços não iniciam

**Sintomas:**
- Status: "0/1" ou "0/3"
- Serviços em estado "failed"

**Solução:**
```bash
# Ver logs do serviço
docker service logs [nome_serviço]

# Reiniciar serviço
docker service update --force [nome_serviço]

# Verificar recursos
docker system df
```

### 🐳 Redes não criadas

**Sintomas:**
- Erro: "network not found"
- Falha de conectividade entre serviços

**Solução:**
```bash
# Criar redes manualmente
docker network create --driver overlay --attachable network_public
docker network create --driver overlay --attachable macspark_internal

# Verificar redes
docker network ls
```

---

## 📊 PROBLEMAS DE MONITORAMENTO

### 📊 Traefik não responde

**Sintomas:**
- Erro 404 no acesso
- Dashboard não carrega

**Solução:**
```bash
# Verificar se Traefik está rodando
docker service ls | grep traefik

# Ver logs do Traefik
docker service logs traefik_traefik

# Reiniciar Traefik
docker service update --force traefik_traefik
```

### 📊 Portainer não acessível

**Sintomas:**
- Erro de conexão na porta 9000
- Interface não carrega

**Solução:**
```bash
# Verificar status do Portainer
docker service ls | grep portainer

# Ver logs
docker service logs portainer_portainer

# Reiniciar Portainer
docker service update --force portainer_portainer
```

---

## 🔐 PROBLEMAS DE SEGURANÇA

### 🔐 Secrets não criados

**Sintomas:**
- Erro: "secret not found"
- Falha de autenticação

**Solução:**
```bash
# Criar secrets manualmente
echo "minha_senha_segura" | docker secret create postgres_password -
echo "outra_senha_segura" | docker secret create redis_password -

# Verificar secrets
docker secret ls
```

### 🔐 SSL não funciona

**Sintomas:**
- Certificados não gerados
- Erro de certificado inválido

**Solução:**
```bash
# Verificar configuração do Let's Encrypt
# No arquivo .env, certifique-se de que:
ACME_EMAIL="seu-email@dominio.com"

# Verificar logs do Traefik
docker service logs traefik_traefik | grep -i acme
```

---

## 🛠️ FERRAMENTAS DE DIAGNÓSTICO

### 🛠️ Script de Verificação Rápida

Execute para verificar o estado geral do sistema:

```bash
bash scripts/quick-vps-check.sh
```

### 🛠️ Script de Correção Automática

Execute para corrigir problemas comuns automaticamente:

```bash
bash scripts/fix-common-vps-issues.sh
```

### 🛠️ Comandos Úteis

```bash
# Ver status de todos os serviços
docker service ls

# Ver logs de um serviço específico
docker service logs -f [nome_serviço]

# Ver recursos do sistema
docker system df

# Limpar recursos não utilizados
docker system prune -a

# Ver stacks
docker stack ls

# Ver redes
docker network ls

# Ver secrets
docker secret ls
```

---

## 📞 SUPORTE

### 📞 Logs Importantes

Para reportar problemas, colete estes logs:

```bash
# Log do sistema
dmesg | tail -50

# Log do Docker
docker system info

# Log de serviços
docker service ls
docker service logs [serviço_problemático]

# Log de recursos
df -h
free -h
```

### 📞 Informações do Sistema

```bash
# Informações do sistema
cat /etc/os-release
uname -a

# Informações de rede
ip addr show
netstat -tuln

# Informações de Docker
docker version
docker info
```

---

## 🎯 SOLUÇÃO RÁPIDA

Se você está com problemas e quer uma solução rápida:

1. **Execute o diagnóstico:**
   ```bash
   bash scripts/quick-vps-check.sh
   ```

2. **Execute as correções automáticas:**
   ```bash
   bash scripts/fix-common-vps-issues.sh
   ```

3. **Se ainda houver problemas, reinstale:**
   ```bash
   # Limpar tudo
   docker system prune -a -f
   docker stack rm $(docker stack ls --format "{{.Name}}")
   
   # Reinstalar
   bash scripts/installation/install-core-only.sh
   ```

4. **Para suporte adicional:**
   - Abra uma issue no GitHub: https://github.com/Marcocardoso28/Macspark-Setup
   - Inclua os logs coletados acima
   - Descreva o problema detalhadamente

---

## ✅ CHECKLIST DE VERIFICAÇÃO

Antes de reportar um problema, verifique:

- [ ] Docker está instalado e rodando
- [ ] Docker Swarm está ativo
- [ ] Arquivo .env está configurado
- [ ] Portas necessárias estão livres
- [ ] Conectividade com internet OK
- [ ] Espaço em disco suficiente
- [ ] RAM suficiente (mínimo 2GB)
- [ ] Scripts têm permissão de execução

---

**🔗 Links Úteis:**
- [Documentação Principal](README.md)
- [Guia de Instalação VPS](INSTALL_VPS.md)
- [Arquitetura do Sistema](ARCHITECTURE.md)
- [GitHub do Projeto](https://github.com/Marcocardoso28/Macspark-Setup) 