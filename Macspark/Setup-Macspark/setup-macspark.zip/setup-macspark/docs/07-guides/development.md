# 🛠️ SETUP DE DESENVOLVIMENTO - MACSPARK

Este guia orienta desenvolvedores sobre como configurar o ambiente de desenvolvimento com todas as ferramentas de qualidade e segurança.

---

## 🎯 **PRÉ-REQUISITOS**

### **Ferramentas Obrigatórias:**
- **Python 3.8+** - Para ferramentas de linting
- **Node.js 16+** - Para ferramentas de Markdown
- **Docker** - Para testes de containers
- **Git** - Controle de versão

### **Ferramentas Opcionais:**
- **htpasswd** - Para gerar hashes de senha
- **shellcheck** - Verificação de scripts shell
- **hadolint** - Linting de Dockerfiles

---

## 🚀 **INSTALAÇÃO RÁPIDA**

### **1. Instalar Pre-commit**
```bash
# Via pip
pip install pre-commit

# Via apt (Ubuntu/Debian)
sudo apt install pre-commit

# Via brew (macOS)
brew install pre-commit
```

### **2. Configurar Hooks**
```bash
# Navegar para o diretório do projeto
cd /path/to/Macspark-Setup

# Instalar hooks do pre-commit
pre-commit install

# Instalar hook para mensagens de commit
pre-commit install --hook-type commit-msg

# Executar em todos os arquivos (primeira vez)
pre-commit run --all-files
```

---

## 🔧 **FERRAMENTAS CONFIGURADAS**

### **📝 Verificações Básicas**
- ✅ **Trailing whitespace** - Remove espaços em branco
- ✅ **End of file fixer** - Garante quebra de linha no final
- ✅ **YAML/JSON syntax** - Verifica sintaxe
- ✅ **Merge conflicts** - Detecta conflitos não resolvidos
- ✅ **Large files** - Impede commit de arquivos grandes
- ✅ **Private keys** - Detecta chaves privadas

### **🐍 Python**
- ✅ **Black** - Formatação automática
- ✅ **isort** - Organização de imports
- ✅ **flake8** - Linting e verificação de estilo
- ✅ **mypy** - Verificação de tipos
- ✅ **bandit** - Scanner de segurança

### **🔒 Segurança**
- ✅ **detect-secrets** - Detecta segredos no código
- ✅ **bandit** - Scanner de vulnerabilidades Python

### **📚 Documentação**
- ✅ **markdownlint** - Linting de Markdown
- ✅ **yamllint** - Linting de YAML

### **🐚 Shell Scripts**
- ✅ **shellcheck** - Verificação de scripts
- ✅ **shfmt** - Formatação de scripts

### **🐳 Docker**
- ✅ **hadolint** - Linting de Dockerfiles

### **📝 Commits**
- ✅ **Conventional Commits** - Padronização de mensagens

---

## 📋 **COMANDOS ÚTEIS**

### **Executar Verificações**
```bash
# Executar em arquivos modificados
pre-commit run

# Executar em todos os arquivos
pre-commit run --all-files

# Executar hook específico
pre-commit run black
pre-commit run flake8
pre-commit run detect-secrets
```

### **Gerenciar Hooks**
```bash
# Atualizar hooks para versões mais recentes
pre-commit autoupdate

# Limpar cache de hooks
pre-commit clean

# Desinstalar hooks
pre-commit uninstall
```

### **Bypass (Emergência)**
```bash
# Pular verificações (NÃO RECOMENDADO)
git commit --no-verify -m "commit de emergência"

# Pular hook específico
SKIP=flake8 git commit -m "pular apenas flake8"
```

---

## 🔍 **CONFIGURAÇÕES PERSONALIZADAS**

### **Python - pyproject.toml**
```toml
[tool.black]
line-length = 88
target-version = ['py38']
include = '\.pyi?$'

[tool.isort]
profile = "black"
line_length = 88
multi_line_output = 3

[tool.mypy]
python_version = "3.8"
warn_return_any = true
warn_unused_configs = true
disallow_untyped_defs = true
```

### **Markdown - .markdownlint.json**
```json
{
  "MD013": {
    "line_length": 120,
    "code_blocks": false
  },
  "MD033": {
    "allowed_elements": ["div", "br", "img"]
  }
}
```

### **YAML - .yamllint.yml**
```yaml
extends: default
rules:
  line-length:
    max: 120
  truthy:
    allowed-values: ['true', 'false', 'yes', 'no']
```

---

## 🛡️ **SEGURANÇA E SEGREDOS**

### **Configurar Baseline de Segredos**
```bash
# Gerar baseline inicial
detect-secrets scan --baseline .secrets.baseline

# Atualizar baseline
detect-secrets scan --baseline .secrets.baseline --update

# Auditar segredos detectados
detect-secrets audit .secrets.baseline
```

### **Adicionar Exceções**
```bash
# Adicionar linha específica à allowlist
echo "senha_exemplo  # pragma: allowlist secret" >> arquivo.py

# Adicionar arquivo inteiro às exceções
# Editar .pre-commit-config.yaml na seção exclude
```

---

## 🔄 **WORKFLOW DE DESENVOLVIMENTO**

### **1. Antes de Começar**
```bash
# Atualizar repositório
git pull origin main

# Atualizar hooks
pre-commit autoupdate

# Executar verificações
pre-commit run --all-files
```

### **2. Durante o Desenvolvimento**
```bash
# Fazer alterações nos arquivos
# ...

# Executar verificações antes do commit
pre-commit run

# Commit (hooks executam automaticamente)
git commit -m "feat: adicionar nova funcionalidade"
```

### **3. Antes do Push**
```bash
# Executar todas as verificações
pre-commit run --all-files

# Executar testes (se houver)
python -m pytest

# Push para o repositório
git push origin feature-branch
```

---

## 🐛 **TROUBLESHOOTING**

### **Problema: Hook falha na primeira execução**
```bash
# Solução: Instalar dependências
pre-commit install-hooks
```

### **Problema: Black e flake8 conflitam**
```bash
# Solução: Configurar flake8 para ignorar regras do Black
# Adicionar ao .flake8:
[flake8]
extend-ignore = E203, W503
max-line-length = 88
```

### **Problema: Muitos segredos detectados**
```bash
# Solução: Atualizar baseline
detect-secrets scan --baseline .secrets.baseline --update
```

### **Problema: Hook muito lento**
```bash
# Solução: Limpar cache
pre-commit clean

# Ou executar hooks específicos
pre-commit run --hook-stage manual
```

---

## 📚 **RECURSOS ADICIONAIS**

### **Documentação Oficial**
- [Pre-commit](https://pre-commit.com/)
- [Black](https://black.readthedocs.io/)
- [Flake8](https://flake8.pycqa.org/)
- [Detect Secrets](https://github.com/Yelp/detect-secrets)

### **Configurações de IDE**
- **VS Code**: Instalar extensões Python, Black, Flake8
- **PyCharm**: Configurar formatadores automáticos
- **Vim/Neovim**: Plugins para Python e linting

### **CI/CD Integration**
```yaml
# GitHub Actions exemplo
- name: Run pre-commit
  uses: pre-commit/action@v3.0.0
```

---

## ✅ **CHECKLIST DE SETUP**

- [ ] Python 3.8+ instalado
- [ ] Pre-commit instalado (`pip install pre-commit`)
- [ ] Hooks instalados (`pre-commit install`)
- [ ] Hooks de commit-msg instalados (`pre-commit install --hook-type commit-msg`)
- [ ] Primeira execução realizada (`pre-commit run --all-files`)
- [ ] Baseline de segredos configurado
- [ ] IDE configurado com formatadores
- [ ] Documentação lida e compreendida

---

**🎉 Ambiente de desenvolvimento configurado com qualidade enterprise!** 