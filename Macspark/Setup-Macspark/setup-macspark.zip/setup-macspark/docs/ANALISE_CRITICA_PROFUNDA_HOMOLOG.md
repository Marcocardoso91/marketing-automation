# 🔴 ANÁLISE CRÍTICA PROFUNDA - PROBLEMAS NÃO DETECTADOS
**Data:** 26/08/2025  
**Status:** ⚠️ **MÚLTIPLOS PROBLEMAS CRÍTICOS ENCONTRADOS**

## 🚨 NOVOS PROBLEMAS CRÍTICOS IDENTIFICADOS

### 1. 🔴 **CONFLITOS DE PORTA GRAVES**
**11 serviços tentando usar porta 80 e 443 simultaneamente!**

```
11 serviços na porta 80
11 serviços na porta 443
5 serviços na porta 8080
5 serviços na porta 4317
3 serviços na porta 9090 (Prometheus)
3 serviços na porta 9000 (Minio/SonarQube)
3 serviços na porta 3000 (Grafana)
```

**IMPACTO:** Deploy vai FALHAR - múltiplos serviços não conseguirão iniciar!

### 2. 🔴 **86 REFERÊNCIAS A LOCALHOST**
**Problema crítico para deploy em cluster!**

Exemplos encontrados:
```yaml
test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
http://localhost:11434/
localhost:5000/qwen-mcp-api:latest
```

**IMPACTO:** Health checks vão falhar, serviços não se comunicarão em ambiente distribuído!

### 3. 🔴 **IMAGENS DOCKER COM TAGS INSTÁVEIS**
**20+ serviços usando :latest, :main, :dev**

```
activepieces/activepieces:latest
alpine:latest
ghcr.io/open-webui/open-webui:main
ghcr.io/windmill-labs/windmill:main
jitsi/jicofo:latest
```

**IMPACTO:** Deploys não reproduzíveis, breaking changes inesperados!

### 4. 🔴 **ARQUIVOS DE BACKUP EXPOSTOS**
**18+ arquivos .ha-backup esquecidos!**

```
./environments/homolog/configs/homolog.env.backup (COM SECRETS!)
./environments/production/configs/production.env.backup (COM SECRETS!)
./stacks/applications/ai/ai.yml.ha-backup
```

**IMPACTO:** Potencial exposição de credenciais!

### 5. ⚠️ **NETWORKS EXTERNAS NÃO CRIADAS**
**63+ referências a networks que precisam existir!**

```
63x traefik-public (external: true)
21x apps-internal (external: true)
17x database-internal (external: true)
```

**IMPACTO:** Serviços não iniciarão sem as networks criadas previamente!

### 6. ⚠️ **POSSÍVEIS DEPENDÊNCIAS CIRCULARES**
```yaml
mcp-orchestrator-ha:
  depends_on:
    - mcp-orchestrator
mcp-api:
  depends_on:
    - mcp-orchestrator
```

**IMPACTO:** Deadlock no startup dos serviços!

### 7. ⚠️ **ARQUIVO DE OVERRIDE LOCAL**
```
./environments/local/docker-compose.override.yml
```

**IMPACTO:** Pode sobrescrever configurações de produção se deployado acidentalmente!

## 📊 RESUMO DOS PROBLEMAS

| Categoria | Crítico | Alto | Médio | Total |
|-----------|---------|------|-------|-------|
| Conflitos de Porta | 11 | 5 | 3 | 19 |
| Referências Localhost | 86 | - | - | 86 |
| Imagens Instáveis | 20+ | - | - | 20+ |
| Arquivos de Backup | 2 | 16 | - | 18 |
| Networks Externas | - | 63 | - | 63 |
| Dependências | - | 2+ | - | 2+ |

## 🛠️ AÇÕES CORRETIVAS NECESSÁRIAS

### 📌 **CORREÇÃO 1: RESOLVER CONFLITOS DE PORTA**

```bash
#!/bin/bash
# Script para mapear e corrigir portas

cat > fix-port-conflicts.sh << 'EOF'
#!/bin/bash

echo "🔧 Corrigindo conflitos de porta..."

# Mapa de portas únicas para cada serviço
declare -A PORT_MAP=(
    ["traefik"]="80:80,443:443"
    ["traefik-dashboard"]="8080:8080"
    ["prometheus"]="9090:9090"
    ["grafana"]="3000:3000"
    ["prometheus-2"]="9091:9090"  # Segunda instância
    ["grafana-2"]="3001:3000"     # Segunda instância
    ["minio"]="9000:9000"
    ["sonarqube"]="9001:9000"     # Porta diferente
)

# Corrigir portas duplicadas
find stacks/ -name "*.yml" | while read file; do
    # Adicionar sufixo único para portas duplicadas
    service_name=$(basename $file .yml)
    
    # Se o serviço não é o Traefik, mudar portas 80/443
    if [[ "$service_name" != "traefik"* ]] && grep -q "- 80:80\|- 443:443" "$file"; then
        echo "Corrigindo portas em $file"
        sed -i 's/- 80:80/# - 80:80 # Exposto via Traefik/g' "$file"
        sed -i 's/- 443:443/# - 443:443 # Exposto via Traefik/g' "$file"
    fi
done
EOF

chmod +x fix-port-conflicts.sh
```

### 📌 **CORREÇÃO 2: REMOVER REFERÊNCIAS LOCALHOST**

```bash
#!/bin/bash
# Corrigir localhost para service discovery

cat > fix-localhost-refs.sh << 'EOF'
#!/bin/bash

echo "🔧 Corrigindo referências localhost..."

find stacks/ -name "*.yml" | while read file; do
    # Substituir localhost por nome do serviço
    sed -i 's|http://localhost:|http://127.0.0.1:|g' "$file"
    sed -i 's|localhost:5000|registry:5000|g' "$file"
    sed -i 's|localhost:11434|ollama:11434|g' "$file"
    
    # Para health checks, usar 127.0.0.1
    sed -i 's|"http://localhost:|"http://127.0.0.1:|g' "$file"
done
EOF

chmod +x fix-localhost-refs.sh
```

### 📌 **CORREÇÃO 3: FIXAR VERSÕES DAS IMAGENS**

```bash
#!/bin/bash
# Fixar versões das imagens Docker

cat > fix-image-tags.sh << 'EOF'
#!/bin/bash

echo "🔧 Fixando versões de imagens Docker..."

# Mapa de versões estáveis
declare -A STABLE_VERSIONS=(
    ["alpine:latest"]="alpine:3.19"
    ["activepieces/activepieces:latest"]="activepieces/activepieces:0.30.0"
    ["ghcr.io/open-webui/open-webui:main"]="ghcr.io/open-webui/open-webui:v0.3.35"
    ["jitsi/jicofo:latest"]="jitsi/jicofo:stable-9584"
    ["huginn/huginn:latest"]="huginn/huginn:latest-2024-08"
)

for old_tag in "${!STABLE_VERSIONS[@]}"; do
    new_tag="${STABLE_VERSIONS[$old_tag]}"
    find stacks/ -name "*.yml" -exec sed -i "s|image: $old_tag|image: $new_tag|g" {} \;
done
EOF

chmod +x fix-image-tags.sh
```

### 📌 **CORREÇÃO 4: LIMPAR ARQUIVOS DE BACKUP**

```bash
#!/bin/bash
# Remover todos os backups

find . -name "*.ha-backup" -o -name "*.backup" -o -name "*.resources-backup" | while read f; do
    echo "Removendo: $f"
    rm -f "$f"
done

# Remover docker-compose.override.yml
rm -f environments/local/docker-compose.override.yml
```

### 📌 **CORREÇÃO 5: CRIAR NETWORKS NECESSÁRIAS**

```bash
#!/bin/bash
# Script para criar todas as networks

cat > create-networks.sh << 'EOF'
#!/bin/bash

echo "🔧 Criando networks Docker necessárias..."

# Networks principais
docker network create --driver overlay --attachable traefik-public 2>/dev/null
docker network create --driver overlay --attachable apps-internal 2>/dev/null
docker network create --driver overlay --attachable database-internal 2>/dev/null
docker network create --driver overlay --attachable monitoring-internal 2>/dev/null

# Networks específicas
docker network create --driver overlay --attachable redis-network 2>/dev/null
docker network create --driver overlay --attachable postgres-network 2>/dev/null
docker network create --driver overlay --attachable ollama-network 2>/dev/null

echo "✅ Networks criadas!"
EOF

chmod +x create-networks.sh
```

## 🚀 SCRIPT MASTER DE CORREÇÃO

```bash
#!/bin/bash
# fix-all-critical.sh

cat > fix-all-critical.sh << 'EOF'
#!/bin/bash
set -e

echo "=========================================="
echo "🔧 CORREÇÃO CRÍTICA PARA DEPLOY HOMOLOG"
echo "=========================================="

# 1. Remover backups
echo "1. Removendo arquivos de backup..."
find . -name "*.ha-backup" -o -name "*.backup" -o -name "*.resources-backup" -delete
rm -f environments/local/docker-compose.override.yml

# 2. Corrigir conflitos de porta
echo "2. Corrigindo conflitos de porta..."
./fix-port-conflicts.sh

# 3. Corrigir localhost
echo "3. Corrigindo referências localhost..."
./fix-localhost-refs.sh

# 4. Fixar versões
echo "4. Fixando versões das imagens..."
./fix-image-tags.sh

# 5. Criar networks
echo "5. Networks serão criadas no deploy..."

echo ""
echo "✅ Correções aplicadas!"
echo ""
echo "⚠️  ANTES DO DEPLOY EM HOMOLOG:"
echo "1. Execute: ./create-networks.sh"
echo "2. Configure variáveis em .env"
echo "3. Execute: docker stack deploy -c <stack.yml> <nome>"
EOF

chmod +x fix-all-critical.sh
```

## ❌ ARQUIVOS PARA REMOVER

```bash
# Lista de arquivos desnecessários
rm -rf ./environments/homolog/configs/*.backup
rm -rf ./environments/production/configs/*.backup
rm -rf ./stacks/**/*.ha-backup
rm -rf ./stacks/**/*.resources-backup
rm -f ./environments/local/docker-compose.override.yml
```

## ✅ CHECKLIST PRÉ-DEPLOY HOMOLOG

- [ ] Executar `fix-all-critical.sh`
- [ ] Criar networks com `create-networks.sh`
- [ ] Verificar arquivo `.env` configurado
- [ ] Testar com `docker-compose config` primeiro
- [ ] Deploy incremental (1 serviço por vez)
- [ ] Monitorar logs: `docker service logs -f <service>`
- [ ] Verificar health: `docker service ps <service>`

## 🎯 CONCLUSÃO

**STATUS ATUAL: NÃO PRONTO PARA HOMOLOG**

**Problemas críticos encontrados:**
- 🔴 208+ problemas que impedirão o deploy
- 🔴 Conflitos de porta tornarão vários serviços inoperantes
- 🔴 Referências localhost quebrarão em cluster
- 🔴 Imagens :latest causarão instabilidade

**RECOMENDAÇÃO:** 
1. Executar TODAS as correções listadas
2. Fazer deploy incremental em homolog
3. Testar cada serviço individualmente
4. Só depois fazer deploy completo

**Tempo estimado para correção:** 2-3 horas
**Risco se deployar sem correções:** ALTO - Sistema não funcionará

---
*Análise crítica realizada com foco em deploy real*