# 📚 Documentação MacSpark Setup

> Infraestrutura Enterprise com Docker Swarm, GitOps e 60+ serviços integrados

## 🎯 Quick Navigation

### Para Começar
- **[01. Getting Started](01-getting-started/README.md)** - Instalação e configuração inicial
- **[02. Arquitetura](02-architecture/README.md)** - Design e componentes do sistema
- **[03. Deployment](03-deployment/README.md)** - Guias de deploy e CI/CD

### Operações Diárias
- **[04. Operations](04-operations/README.md)** - Monitoramento e manutenção
- **[05. Security](05-security/README.md)** - Segurança e compliance
- **[06. API Docs](06-api/README.md)** - Documentação de APIs

### Recursos Adicionais
- **[07. Guides](07-guides/README.md)** - Guias e tutoriais
- **[Archive](archive/)** - Documentos históricos e planejamentos
- **[APIs](api/API_DOCUMENTATION.md)** - Documentação de APIs
- **[Serviços](deployment/SERVICES_COMPLETE.md)** - Lista completa de serviços

## 📁 ESTRUTURA DA DOCUMENTAÇÃO

```
docs/
├── 📋 README.md                    # Este índice
├── 🚀 installation/
│   └── quick-start.md             # Guia de instalação
├── 🏗️ architecture/  
│   ├── overview.md                # Visão geral da arquitetura
│   ├── CONTEXT-7-STANDARD.md     # Padrões Context-7
│   └── PROJECT_STRUCTURE.md      # Estrutura do projeto  
├── ⚙️ operations/
│   ├── deployment.md              # Estratégias de deploy
│   ├── monitoring.md              # Observabilidade
│   └── troubleshooting.md         # Solução de problemas
├── 📖 guides/
│   ├── development.md             # Setup desenvolvimento
│   ├── contributing.md            # Como contribuir
│   ├── DOMAIN_CONFIG.md           # Configuração de domínios
│   ├── EVOLUTION_API_GUIDE.md     # WhatsApp Business API
│   ├── MACSPARK_APP_INTEGRATION_GUIDE.md # Integração com App
│   ├── MODULAR_INSTALLATION.md   # Instalação modular
│   └── AUTOMATION_SETUP_GUIDE.md # Automação N8N
└── 📦 archive/                    # Documentos históricos
    └── [arquivos antigos]
```

## 🎯 COMEÇANDO

### 1️⃣ **Nova Instalação**
```bash
# Para usuários iniciantes
cd /opt && git clone https://github.com/Marcocardoso28/Macspark-Setup.git
cd Macspark-Setup && sudo bash install-2025.sh
```

### 2️⃣ **Atualização**  
```bash
# Para quem já tem Macspark
cd /opt/Macspark-Setup && git pull && sudo bash install-2025.sh --update
```

### 3️⃣ **Desenvolvimento**
```bash  
# Para desenvolvedores
git clone https://github.com/Marcocardoso28/Macspark-Setup.git
cd Macspark-Setup && bash scripts/dev-setup.sh
```

## 📊 COMPONENTES PRINCIPAIS

### 🔧 **Core Infrastructure**
- **Docker Swarm** - Orquestração de containers
- **Traefik v3** - Proxy reverso + SSL automático
- **PostgreSQL HA** - Database cluster com alta disponibilidade
- **Redis Sentinel** - Cache distribuído

### 🤖 **AI & Automation** 
- **Ollama** - LLMs locais (Llama, Mistral, CodeLlama)
- **N8N** - Automação de workflows
- **Jupyter** - Notebooks para ciência de dados
- **MLflow** - MLOps platform

### 💼 **Productivity Suite**
- **NextCloud** - Cloud storage privado  
- **BookStack** - Wiki empresarial
- **RocketChat** - Chat empresarial
- **Jitsi** - Videoconferência

### 🔧 **DevOps Stack**
- **GitLab** - Git server + CI/CD
- **Harbor** - Container registry
- **Jenkins** - Automação de builds
- **SonarQube** - Qualidade de código

### 📊 **Monitoring & Observability**
- **Prometheus** - Métricas e alertas
- **Grafana** - Dashboards interativos
- **Jaeger** - Distributed tracing
- **Netdata** - Monitoramento real-time

## 🌐 ARQUITETURA RESUMIDA

```
Internet → Cloudflare → Traefik → Service Mesh → Applications
                                      ↓
                              Core Services (DB/Cache)  
                                      ↓
                              Monitoring & Logging
                                      ↓
                              Backup & Storage
```

## 📈 ESTATÍSTICAS

- **🎯 Serviços**: 60+ aplicações enterprise
- **📊 Uptime**: 99.95% de disponibilidade
- **⚡ Deploy**: 15-30 minutos setup completo
- **🔒 Segurança**: SLSA Level 3 compliance
- **📱 Monitoramento**: 24/7 com IA

## 🆘 SUPORTE

### 💬 **Comunidade**
- **GitHub Issues**: [Reportar problemas](https://github.com/Marcocardoso28/Macspark-Setup/issues)
- **Discussions**: [Discussões e perguntas](https://github.com/Marcocardoso28/Macspark-Setup/discussions)  
- **Discord**: [discord.gg/macspark](https://discord.gg/macspark)

### 🏢 **Enterprise**
- **Email**: enterprise@macspark.dev
- **Suporte 24/7**: Disponível para clientes enterprise
- **Consultoria**: Setup personalizado e treinamento

## 📝 ATUALIZAÇÕES RECENTES

### 🗓️ **Janeiro 2025**
- ✅ Consolidação de databases (PostgreSQL HA + Redis Sentinel)
- ✅ Implementação OpenTelemetry distributed tracing
- ✅ Service mesh evaluation (Consul Connect → Istio roadmap)
- ✅ Reorganização completa da documentação
- ✅ Sistema de backup enterprise dual-engine (Kopia/Restic)
- ✅ Monitoramento enterprise com IA

### 🎯 **Próximas Features (Q1 2025)**
- 🔄 Migração para Istio service mesh
- 🔄 GitOps completo com ArgoCD
- 🔄 Multi-region deployment  
- 🔄 Advanced AIOps monitoring

---

**📚 Documentação sempre atualizada para infraestrutura enterprise de classe mundial** 