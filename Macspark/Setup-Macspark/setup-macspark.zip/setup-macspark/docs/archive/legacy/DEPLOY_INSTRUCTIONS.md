# 🚀 DEPLOY INSTRUCTIONS - VPS HOMOLOG

**Instruções para deploy na VPS de Homolog**

## 📋 Pré-requisitos VPS Homolog

- **SO**: Ubuntu 20.04+ ou RHEL 8+
- **RAM**: 8GB mínimo (16GB recomendado)
- **Disco**: 50GB livre mínimo
- **Docker**: 24.0+ 
- **Acesso**: SSH com sudo

## 🔧 Deploy Rápido (1 Comando)

```bash
# Clone e execute bootstrap completo
git clone <SEU-REPO-GIT> setup-macspark
cd setup-macspark
sudo bash scripts/bootstrap/00-bootstrap-complete.sh homolog
```

## 📝 Deploy Manual (Passo a Passo)

### 1. Preparar Sistema
```bash
# Atualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar Docker se necessário
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER

# Inicializar Swarm
docker swarm init
```

### 2. Clonar Repositório
```bash
git clone <SEU-REPO> setup-macspark
cd setup-macspark
chmod +x scripts/**/*.sh
```

### 3. Deploy Core Services
```bash
# Criar redes
bash scripts/setup/create-networks.sh

# Deploy PostgreSQL consolidado
docker stack deploy -c stacks/core/database/postgresql-modernized.yml postgres

# Deploy Traefik
docker stack deploy -c stacks/core/traefik/traefik-production.yml traefik

# Deploy Redis
docker stack deploy -c stacks/core/database/redis-modernized.yml redis
```

### 4. Deploy Aplicações
```bash
# N8N (workflows)
docker stack deploy -c stacks/applications/n8n-optimized.yml n8n

# Portainer (gestão)
docker stack deploy -c stacks/infrastructure/portainer-complete.yml portainer

# Monitoring
docker stack deploy -c stacks/core/monitoring/prometheus-modern.yml monitoring
```

### 5. Verificar Deploy
```bash
# Status dos serviços
docker service ls

# Health check
bash scripts/monitoring/health-monitor-ai.sh

# Verificar URLs
curl -I http://localhost:3000  # Grafana
curl -I http://localhost:5678  # N8N
```

## 🌐 Configuração DNS (Homolog)

Configurar DNS para:
- `*.homolog.macspark.dev` → IP_VPS_HOMOLOG

### Serviços Principais:
- **Traefik**: `http://traefik.homolog.macspark.dev`
- **N8N**: `http://n8n.homolog.macspark.dev`
- **Grafana**: `http://grafana.homolog.macspark.dev`
- **Portainer**: `http://portainer.homolog.macspark.dev`

## ⚡ Configurações Importantes

### Environment Variables
```bash
export ENVIRONMENT=homolog
export DOMAIN_SUFFIX=.homolog.macspark.dev
export DATABASE_URL=postgres://postgres@postgres:5432/homolog_db
export REDIS_URL=redis://redis:6379
```

### Resources (Homolog)
- **PostgreSQL**: 2GB RAM, 2 CPU
- **Redis**: 512MB RAM, 1 CPU
- **N8N**: 1GB RAM, 1 CPU
- **Traefik**: 256MB RAM, 0.5 CPU

## 🔒 Segurança

### Firewall
```bash
sudo ufw allow 22/tcp    # SSH
sudo ufw allow 80/tcp    # HTTP
sudo ufw allow 443/tcp   # HTTPS
sudo ufw allow 2377/tcp  # Swarm management
sudo ufw --force enable
```

### SSL/TLS
- Let's Encrypt automático via Traefik
- Certificados salvos em volumes Docker

## 📊 Monitoramento

### Health Checks
```bash
# Todos os serviços
docker service ls

# Logs específicos
docker service logs <service_name> --tail 50

# Métricas
curl http://localhost:9090/metrics  # Prometheus
```

### Alertas
- Configurados no Grafana
- Notificações via email/slack (configurar)

## 🔄 Backup (Homolog)

```bash
# Backup manual
bash scripts/backup/backup-intelligent.sh

# Restaurar
bash scripts/backup/restore-backup.sh <backup_file>
```

## 🐛 Troubleshooting

### Serviço não inicia
```bash
docker service logs <service> --tail 100
docker service inspect <service>
```

### Problemas de rede
```bash
docker network ls
docker network inspect <network_name>
```

### Recursos insuficientes
```bash
free -h      # Verificar RAM
df -h        # Verificar disco
docker system df  # Verificar uso Docker
```

### Limpeza
```bash
# Limpeza geral
docker system prune -a

# Remover stack
docker stack rm <stack_name>
```

## 📞 Suporte

- **Logs**: `/var/log/macspark/`
- **Docs**: `./docs/`
- **Issues**: GitHub Issues

## 🎯 Próximos Passos Após Deploy

1. ✅ Verificar todos os serviços
2. ✅ Configurar DNS
3. ✅ Testar aplicações
4. ✅ Configurar backup automático
5. ✅ Testar disaster recovery
6. ✅ Proceder para migração produção

---

**Desenvolvido pela equipe MacSpark - Setup Enterprise 2025**