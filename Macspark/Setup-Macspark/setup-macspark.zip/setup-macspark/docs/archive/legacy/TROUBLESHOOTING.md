# Troubleshooting - Macspark Setup

Este documento contém soluções para problemas comuns encontrados durante a instalação e uso do Macspark Setup.

## Problemas de Instalação

### 1. Erro: htpasswd não encontrado

**Sintoma:**
```
htpasswd: command not found
```

**Causa:**
O comando `htpasswd` não está instalado no sistema. Este comando é necessário para gerar senhas criptografadas para o Traefik.

**Solução:**
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install -y apache2-utils

# CentOS/RHEL
sudo yum install -y httpd-tools

# Verificar se foi instalado
which htpasswd
```

**Prevenção:**
- Os scripts de instalação agora verificam e instalam automaticamente o `htpasswd`
- Execute sempre o `pre-install-check.sh` antes da instalação

### 2. Erro: Porta já em uso

**Sintoma:**
```
Error response from daemon: driver failed programming external connectivity on endpoint
```

**Causa:**
Uma porta necessária (80, 443, 8080, etc.) já está sendo usada por outro serviço.

**Solução:**
```bash
# Verificar portas em uso
sudo netstat -tulnp | grep :80
sudo netstat -tulnp | grep :443

# Parar serviços conflitantes
sudo systemctl stop apache2  # se estiver usando Apache
sudo systemctl stop nginx     # se estiver usando Nginx

# Ou usar portas alternativas no .env
```

### 3. Erro: Docker Swarm não inicializado

**Sintoma:**
```
Error response from daemon: This node is not a swarm manager
```

**Causa:**
O Docker Swarm não foi inicializado corretamente.

**Solução:**
```bash
# Inicializar Swarm
sudo docker swarm init --advertise-addr $(hostname -I | awk '{print $1}')

# Verificar status
sudo docker info | grep Swarm
```

### 4. Erro: Permissões de arquivo

**Sintoma:**
```
Permission denied
```

**Causa:**
Arquivos de configuração com permissões incorretas.

**Solução:**
```bash
# Corrigir permissões
sudo chown -R root:root /opt/macspark
sudo chmod -R 755 /opt/macspark
sudo chmod 600 /opt/macspark/.env
```

## Problemas de Serviços

### 1. Traefik não carrega

**Verificar:**
```bash
# Status do serviço
docker service ls | grep traefik

# Logs do serviço
docker service logs traefik_traefik

# Verificar configuração
docker service inspect traefik_traefik
```

**Possíveis causas:**
- Certificados SSL inválidos
- Configuração de rede incorreta
- Variáveis de ambiente não definidas

### 2. Evolution API não conecta

**Verificar:**
```bash
# Status do serviço
docker service ls | grep evolution

# Logs do serviço
docker service logs evolution_evolution

# Verificar banco de dados
docker service logs postgresql_postgres
```

**Solução comum:**
```bash
# Reiniciar serviço
docker service update --force evolution_evolution

# Verificar variáveis de ambiente
docker service inspect evolution_evolution | grep -A 10 "Env"
```

### 3. NextCloud não acessível

**Verificar:**
```bash
# Status do serviço
docker service ls | grep nextcloud

# Logs do serviço
docker service logs nextcloud_nextcloud

# Verificar volumes
docker volume ls | grep nextcloud
```

**Solução comum:**
```bash
# Recriar volumes se necessário
docker volume rm nextcloud_data nextcloud_config
docker volume create nextcloud_data
docker volume create nextcloud_config

# Redeploy do serviço
docker stack deploy -c stacks/storage/nextcloud.yml nextcloud
```

## Problemas de Rede

### 1. Domínio não resolve

**Verificar:**
```bash
# Testar resolução DNS
nslookup seu-dominio.com
dig seu-dominio.com

# Verificar configuração no .env
grep DOMAIN_SUFFIX .env
```

**Solução:**
- Configurar DNS A record apontando para o IP da VPS
- Aguardar propagação DNS (pode levar até 24h)
- Verificar se o domínio está configurado corretamente no .env

### 2. SSL não funciona

**Verificar:**
```bash
# Status do Let's Encrypt
docker service logs traefik_traefik | grep -i "certificate"

# Verificar configuração SSL
docker service inspect traefik_traefik | grep -A 5 "certresolver"
```

**Solução:**
```bash
# Forçar renovação de certificados
docker service update --force traefik_traefik

# Verificar configuração no traefik.yml
grep -A 10 "certresolver" stacks/traefik/traefik.yml
```

## Problemas de Performance

### 1. Sistema lento

**Verificar recursos:**
```bash
# Uso de CPU e RAM
htop
free -h
df -h

# Uso de Docker
docker system df
docker stats
```

**Soluções:**
```bash
# Limpar recursos Docker não utilizados
docker system prune -a

# Otimizar configurações no .env
# Reduzir limites de memória para serviços menos críticos
```

### 2. Backup falha

**Verificar:**
```bash
# Logs do backup
tail -f logs/backup.log

# Espaço em disco
df -h /opt/macspark/backups
```

**Solução:**
```bash
# Executar backup manual
bash scripts/backup_all.sh

# Limpar backups antigos
find /opt/macspark/backups -name "*.tar.gz" -mtime +7 -delete
```

## Logs e Debugging

### Comandos úteis para debugging:

```bash
# Ver todos os serviços
docker service ls

# Logs de um serviço específico
docker service logs <nome_do_servico>

# Inspecionar configuração de um serviço
docker service inspect <nome_do_servico>

# Verificar redes Docker
docker network ls

# Verificar volumes
docker volume ls

# Verificar secrets
docker secret ls

# Status do Swarm
docker node ls
```

### Logs importantes:

```bash
# Logs do Traefik (proxy reverso)
docker service logs traefik_traefik

# Logs do Evolution API
docker service logs evolution_evolution

# Logs do PostgreSQL
docker service logs postgresql_postgres

# Logs do sistema
journalctl -u docker
```

## Contato e Suporte

Se você encontrar um problema não documentado aqui:

1. Verifique os logs usando os comandos acima
2. Execute o script de verificação: `bash scripts/pre-install-check.sh`
3. Consulte a documentação completa em `docs/`
4. Abra uma issue no GitHub com:
   - Descrição detalhada do problema
   - Comandos executados
   - Logs relevantes
   - Versão do sistema operacional
   - Configuração do .env (sem senhas)

## Prevenção de Problemas

1. **Sempre execute o pre-check:**
   ```bash
   sudo bash scripts/pre-install-check.sh
   ```

2. **Mantenha backups regulares:**
   ```bash
   # Configurar backup automático
   crontab -e
   # Adicionar: 0 2 * * * /opt/macspark/scripts/backup_all.sh
   ```

3. **Monitore recursos:**
   ```bash
   # Instalar monitoramento
   bash scripts/add-extra-services.sh
   # Selecionar: monitoring
   ```

4. **Atualize regularmente:**
   ```bash
   # Atualizar repositório
   cd /opt/macspark
   git pull origin main
   bash scripts/fix-all-critical-issues.sh
   ``` 