# 🚀 **GUIA DE DEPLOY ENTERPRISE - SETUP MACSPARK**

## 📋 **OVERVIEW**

Deploy único e funcional dos **16 serviços enterprise** integrado perfeitamente com a infraestrutura existente do Setup-Macspark.

---

## ⚡ **QUICK START**

### **1. Pré-requisitos**
```bash
# 1. Ativar Docker Swarm
docker swarm init

# 2. Verificar redes básicas
docker network ls | grep -E "(traefik|monitoring|application)"

# 3. Verificar espaço disponível
df -h /opt
```

### **2. Deploy Enterprise Unificado**
```bash
# Deploy completo dos serviços enterprise
./scripts/deployment/deploy-enterprise-unified.sh
```

### **3. Validação do Deploy**
```bash
# Validar todos os componentes
./scripts/deployment/validate-enterprise-deployment.sh
```

---

## 🔧 **SCRIPT DE DEPLOY UNIFICADO**

### **📄 Localização**: `scripts/deployment/deploy-enterprise-unified.sh`

### **🎯 Features**
- ✅ **Detecção automática** da infraestrutura existente
- ✅ **Integração inteligente** com PostgreSQL/Redis externos
- ✅ **Redes otimizadas** com criptografia
- ✅ **Secrets management** enterprise
- ✅ **Volumes estruturados** com permissões corretas
- ✅ **Configs dinâmicos** baseados no ambiente
- ✅ **Fallback para serviços mínimos** se stacks não existirem
- ✅ **Health checking** completo
- ✅ **Cleanup automático** de recursos

### **🔍 Detecção Inteligente**

O script detecta automaticamente:

```bash
# Domain suffix do ambiente
DOMAIN_SUFFIX="macspark.dev"  # ou detectado dos configs

# PostgreSQL existente
USE_EXTERNAL_POSTGRES=true/false

# Redis existente  
USE_EXTERNAL_REDIS=true/false

# Traefik proxy reverso
TRAEFIK_AVAILABLE=true/false
```

---

## 📊 **SERVIÇOS DEPLOYADOS**

### **🥇 TOP 5 - CRÍTICOS**

#### **1. GitLab CE Enterprise**
- **Stack**: `stacks/applications/development/gitlab-ce-complete.yml`
- **Fallback**: Serviço GitLab mínimo funcional
- **Endpoint**: `https://gitlab.${DOMAIN_SUFFIX}`
- **Features**: 
  - Container Registry integrado
  - CI/CD pipeline completo
  - Integração com PostgreSQL/Redis externos
  - Monitoring Prometheus integrado

#### **2. Service Mesh Security**
- **Stack**: `stacks/infrastructure/service-mesh/istio-security-stack.yml`
- **Fallback**: Envoy proxy básico
- **Endpoint**: `https://proxy.${DOMAIN_SUFFIX}`
- **Features**:
  - Istio control plane
  - Falco runtime security
  - OPA policy engine
  - Envoy load balancing

#### **3. Automation Enterprise**
- **Stack**: `stacks/infrastructure/automation/automation-orchestration-complete.yml`
- **Endpoint**: `https://awx.${DOMAIN_SUFFIX}`
- **Features**:
  - AWX (Ansible Tower)
  - Terraform Cloud Agent
  - ArgoCD GitOps

#### **4. Multi-Cloud Orchestration**
- **Stack**: `stacks/infrastructure/multi-cloud/multi-cloud-edge-complete.yml`
- **Endpoint**: `https://consul.${DOMAIN_SUFFIX}`
- **Features**:
  - HashiCorp Consul cluster
  - Nomad orchestration
  - Edge computing support

#### **5. Performance Optimization**
- **Stack**: `stacks/infrastructure/performance/redis-cluster.yml`
- **Features**:
  - Redis Cluster enterprise
  - Performance monitoring
  - Cache optimization

---

## 🌐 **REDES ENTERPRISE**

### **Redes Criadas Automaticamente**
```bash
enterprise-internal     # Rede principal enterprise
security-internal      # Service mesh e segurança
development-internal    # GitLab e desenvolvimento
automation-internal     # AWX, Terraform, ArgoCD
performance-internal    # Redis, cache, performance
```

### **Integração com Redes Existentes**
- `traefik-public` - Proxy reverso e SSL
- `monitoring-internal` - Prometheus/Grafana integration
- `application_network` - Aplicações existentes

---

## 🔐 **SECRETS ENTERPRISE**

### **Secrets Criados Automaticamente**
```bash
# GitLab
gitlab_root_password        # Password do root GitLab
gitlab_db_password         # Password do banco GitLab
gitlab_redis_password      # Password do Redis GitLab

# Service Mesh
istio_ca_cert             # Certificado CA Istio
opa_bearer_token          # Token OPA policy engine

# Automation
awx_secret_key            # Chave secreta AWX
awx_admin_password        # Password admin AWX

# Multi-Cloud
consul_encrypt_key        # Chave de criptografia Consul

# Notification
slack_webhook_url         # Webhook Slack
pagerduty_api_key        # API key PagerDuty
```

---

## 💾 **ESTRUTURA DE VOLUMES**

### **Organização de Diretórios**
```
/opt/macspark/
├── volumes/enterprise/
│   ├── gitlab/
│   │   ├── data/           # Dados GitLab
│   │   ├── config/         # Configurações
│   │   ├── logs/           # Logs GitLab
│   │   ├── postgres/       # DB (se interno)
│   │   ├── redis/          # Cache (se interno)
│   │   └── registry/       # Container registry
│   ├── service-mesh/
│   │   ├── istio/          # Configurações Istio
│   │   ├── envoy/          # Envoy proxy
│   │   └── opa/            # Políticas OPA
│   └── automation/
│       ├── awx/            # AWX data
│       ├── terraform/      # Terraform state
│       └── argocd/         # ArgoCD configs
├── configs/enterprise/
│   ├── istio/              # Service mesh configs
│   ├── gitlab/             # GitLab configs
│   └── awx/               # AWX configs
└── logs/enterprise/
    ├── security/           # Security logs
    ├── gitlab/             # GitLab logs
    ├── automation/         # Automation logs
    └── performance/        # Performance logs
```

---

## ⚙️ **CONFIGURAÇÕES DINÂMICAS**

### **GitLab Omnibus Config**
Configuração automática baseada no ambiente detectado:

```ruby
external_url 'https://gitlab.${DOMAIN_SUFFIX}'
nginx['listen_https'] = false  # Traefik gerencia SSL

# Database (se PostgreSQL externo detectado)
postgresql['enable'] = false
gitlab_rails['db_host'] = 'postgres_service'

# Redis (se Redis externo detectado) 
redis['enable'] = false
gitlab_rails['redis_host'] = 'redis_service'

# Container Registry
registry_external_url 'https://registry.${DOMAIN_SUFFIX}'
gitlab_rails['registry_enabled'] = true

# Performance otimizada
unicorn['worker_processes'] = 2
sidekiq['max_concurrency'] = 15

# Monitoring integration
prometheus_monitoring['enable'] = true
```

---

## 🏥 **VALIDAÇÃO DO DEPLOY**

### **Script de Validação**: `scripts/deployment/validate-enterprise-deployment.sh`

### **Testes Executados**
```bash
# Pré-requisitos
✅ Docker Swarm ativo
✅ Redes básicas (traefik-public, monitoring-internal)
✅ Espaço em disco (>5GB)
✅ Memória disponível (>2GB)

# Redes Enterprise
✅ Redes criadas e criptografadas
✅ Conectividade interna
✅ Resolução DNS

# Secrets & Configs
✅ Todos os secrets enterprise
✅ Configurações dinâmicas
✅ Permissões corretas

# Serviços
✅ Stacks deployados
✅ Réplicas rodando
✅ Health checks

# Recursos
✅ Uso de CPU (<80%)
✅ Uso de memória (<85%)
✅ Uso de disco (<90%)
```

---

## 🚦 **STATUS E ENDPOINTS**

### **Verificar Status**
```bash
# Status geral
docker stack ls | grep -E "(gitlab|service-mesh|automation)"

# Serviços específicos
docker service ls | grep -E "(gitlab|envoy|awx|consul|redis)"

# Logs específicos
docker service logs gitlab-enterprise_gitlab
docker service logs service-mesh_envoy-proxy
docker service logs automation_awx-web
```

### **Endpoints Enterprise**
```
✅ GitLab CE:              https://gitlab.macspark.dev
✅ Container Registry:     https://registry.macspark.dev  
✅ Service Proxy:          https://proxy.macspark.dev
✅ AWX Automation:         https://awx.macspark.dev
✅ Consul Multi-Cloud:     https://consul.macspark.dev
✅ Nomad Orchestration:    https://nomad.macspark.dev
```

---

## 🔄 **OPERAÇÕES DE MANUTENÇÃO**

### **Restart de Serviços**
```bash
# Restart service mesh
docker service update --force service-mesh_envoy-proxy

# Restart GitLab
docker service update --force gitlab-enterprise_gitlab

# Restart automation
docker service update --force automation_awx-web
```

### **Backup Enterprise**
```bash
# Backup GitLab data
docker run --rm -v gitlab_data:/data -v $(pwd):/backup alpine tar czf /backup/gitlab-backup.tar.gz /data

# Backup configs
tar czf enterprise-configs.tar.gz /opt/macspark/configs/enterprise/
```

### **Scale Services**
```bash
# Scale Envoy proxy
docker service scale service-mesh_envoy-proxy=3

# Scale AWX workers
docker service scale automation_awx-task=2
```

---

## 🔍 **TROUBLESHOOTING**

### **Problemas Comuns**

#### **GitLab não inicializa**
```bash
# Verificar logs
docker service logs gitlab-enterprise_gitlab

# Verificar recursos
docker stats $(docker ps -q --filter ancestor=gitlab/gitlab-ce:16.8.1-ce.0)

# Verificar volume
ls -la /opt/macspark/volumes/gitlab/data
```

#### **Service Mesh não conecta**
```bash
# Verificar redes
docker network ls | grep security-internal

# Verificar Envoy config
docker config inspect envoy_basic_config

# Verificar conectividade
docker exec $(docker ps -q --filter name=envoy) curl -s localhost:8001/stats
```

#### **Secrets não disponíveis**
```bash
# Listar secrets
docker secret ls | grep -E "(gitlab|istio|awx)"

# Recrear secret se necessário
docker secret rm gitlab_root_password
echo "new_password_$(date +%s)" | docker secret create gitlab_root_password -
```

---

## ⚡ **PERFORMANCE TUNING**

### **GitLab Performance**
```ruby
# /opt/macspark/configs/enterprise/gitlab/gitlab.rb
unicorn['worker_processes'] = 4        # Aumentar para mais CPU
sidekiq['max_concurrency'] = 25        # Mais workers Sidekiq
postgresql['shared_buffers'] = "1GB"    # Mais cache DB
```

### **Service Mesh Performance**
```yaml
# Envoy tuning
resources:
  limits:
    memory: 512M    # Aumentar se necessário
    cpus: '0.5'
  reservations:
    memory: 256M
    cpus: '0.25'
```

### **Monitoring Enterprise Performance**
```bash
# CPU usage por serviço
docker stats --format "table {{.Container}}\t{{.CPUPerc}}\t{{.MemUsage}}"

# Network I/O
docker stats --format "table {{.Container}}\t{{.NetIO}}"

# Disk I/O  
docker stats --format "table {{.Container}}\t{{.BlockIO}}"
```

---

## 🎯 **NEXT STEPS**

### **Após Deploy Concluído**
1. ✅ **Configurar GitLab**: Criar projetos e usuários
2. ✅ **Configurar AWX**: Importar playbooks Ansible
3. ✅ **Configurar Consul**: Service discovery policies
4. ✅ **Configurar Service Mesh**: Security policies OPA
5. ✅ **Integrar Monitoring**: Dashboards específicos enterprise

### **Expansões Futuras**
- **Kubernetes Migration**: Preparação para K8s
- **Multi-Cloud Deployment**: AWS/Azure/GCP
- **Zero Trust Security**: Implementação completa
- **AI/ML Integration**: MLOps pipeline
- **Edge Computing**: Expansão para edge nodes

---

## 📞 **SUPORTE**

### **Logs Centralizados**
- **GitLab**: `/opt/macspark/logs/enterprise/gitlab/`
- **Service Mesh**: `/opt/macspark/logs/enterprise/security/`
- **Automation**: `/opt/macspark/logs/enterprise/automation/`

### **Documentação**
- **Arquitetura**: `docs/enterprise/16-SERVICOS-ENTERPRISE-COMPLETOS.md`
- **Troubleshooting**: `docs/enterprise/troubleshooting-enterprise.md`
- **Security**: `docs/enterprise/security-enterprise.md`

### **Health Monitoring**
```bash
# Health check completo
./scripts/deployment/validate-enterprise-deployment.sh

# Monitoring contínuo
watch 'docker service ls | grep -E "(gitlab|envoy|awx|consul)"'
```

---

## ✅ **CHECKLIST PÓS-DEPLOY**

```bash
□ Deploy executado com sucesso
□ Validação passou todos os testes  
□ Endpoints acessíveis via browser
□ GitLab configurado e funcional
□ Service mesh conectando serviços
□ AWX automation disponível
□ Consul cluster descobrindo serviços
□ Monitoring integrado
□ Backup configurado
□ Documentação atualizada
```

---

**🎉 Setup-Macspark agora é uma infraestrutura Fortune 500!**

**Desenvolvido pela equipe MacSpark seguindo as melhores práticas enterprise.**