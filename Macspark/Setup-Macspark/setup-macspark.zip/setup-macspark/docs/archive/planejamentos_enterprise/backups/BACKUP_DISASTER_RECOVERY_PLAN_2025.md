# 🔥 PLANO COMPLETO DE BACKUP & DISASTER RECOVERY - MACSPARK CLUSTER 2025
## Sistema à Prova de Bomba Atômica com Kopia + MinIO + Monitoramento

---

## 📋 RESUMO EXECUTIVO

**Objetivo:** Implementar sistema de backup enterprise-grade com:
- **RPO (Recovery Point Objective):** < 1 hora
- **RTO (Recovery Time Objective):** < 30 minutos
- **Durabilidade:** 99.999999999% (11 noves)
- **Estratégia:** 3-2-1 (3 cópias, 2 mídias, 1 offsite)
- **Validação:** Automática diária com restore tests
- **Monitoramento:** 24/7 com alertas proativos

**Tecnologias Escolhidas:**
- **Kopia:** Melhor ferramenta de backup para Docker Swarm 2025
- **MinIO:** Storage S3-compatible (já instalado)
- **Prometheus/Grafana:** Monitoramento (já instalado)
- **Restic:** Backup secundário para redundância

---

## 🏗️ ARQUITETURA DO SISTEMA

```
┌─────────────────────────────────────────────────────────────┐
│                     DOCKER SWARM CLUSTER                      │
├───────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │   Volumes    │  │   Configs    │  │  Databases   │      │
│  │  (Stateful)  │  │   Secrets    │  │ (PostgreSQL) │      │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘      │
│         │                  │                  │               │
│         └──────────────────┼──────────────────┘               │
│                            │                                  │
│                     ┌──────▼───────┐                         │
│                     │    KOPIA     │                         │
│                     │   (Primary)   │                         │
│                     └──────┬───────┘                         │
│                            │                                  │
│         ┌──────────────────┼──────────────────┐              │
│         │                  │                  │               │
│  ┌──────▼───────┐  ┌──────▼───────┐  ┌──────▼───────┐      │
│  │  Local Disk  │  │    MinIO     │  │  GitHub LFS  │      │
│  │   (Copy 1)   │  │   (Copy 2)   │  │   (Copy 3)   │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│                                                               │
│  ┌──────────────────────────────────────────────────┐        │
│  │            MONITORING & VALIDATION                │        │
│  ├──────────────────────────────────────────────────┤        │
│  │  Prometheus → Grafana → Alerts → Webhook/Email   │        │
│  └──────────────────────────────────────────────────┘        │
└───────────────────────────────────────────────────────────────┘
```

---

## 📊 STATUS ATUAL VS OBJETIVO

| Componente | Status Atual | Objetivo | Ação Necessária |
|------------|--------------|----------|-----------------|
| **Backup Engine** | Scripts manuais | Kopia automatizado | ⚠️ Implementar |
| **Storage Primário** | Local apenas | Local + Dedup | ⚠️ Configurar |
| **Storage S3** | MinIO instalado | MinIO integrado | ⚠️ Integrar |
| **Storage Offsite** | GitHub parcial | GitHub LFS completo | ⚠️ Expandir |
| **Validação** | Nenhuma | Automática diária | 🔴 Criar |
| **Monitoramento** | Básico | Completo c/ alertas | ⚠️ Melhorar |
| **DR Manual** | Não existe | Documentado e testado | 🔴 Criar |
| **Testes Recovery** | Nunca feito | Semanal automático | 🔴 Implementar |

---

## 🚀 FASE 1: INSTALAÇÃO E CONFIGURAÇÃO DO KOPIA (Dia 1)

### 1.1 Instalar Kopia no Cluster

```bash
#!/bin/bash
# install-kopia.sh

# Instalar Kopia em todos os managers
docker service create \
  --name kopia-backup \
  --mode global \
  --constraint 'node.role == manager' \
  --mount type=bind,source=/var/run/docker.sock,target=/var/run/docker.sock \
  --mount type=bind,source=/var/lib/docker/volumes,target=/volumes,readonly \
  --mount type=volume,source=kopia-config,target=/app/config \
  --mount type=volume,source=kopia-cache,target=/app/cache \
  --mount type=volume,source=kopia-logs,target=/app/logs \
  --env KOPIA_PASSWORD="${KOPIA_PASSWORD:-SuperSecurePassword123!}" \
  --network backup-network \
  kopia/kopia:latest \
  server start --insecure --address=0.0.0.0:51515
```

### 1.2 Configurar Repository no MinIO

```bash
#!/bin/bash
# setup-kopia-minio.sh

# Variáveis
MINIO_ENDPOINT="http://minio:9000"
MINIO_ACCESS_KEY="admin"
MINIO_SECRET_KEY="supersecret123"
KOPIA_PASSWORD="SuperSecurePassword123!"

# Criar bucket no MinIO
docker exec $(docker ps -q -f name=minio) \
  mc alias set local http://localhost:9000 $MINIO_ACCESS_KEY $MINIO_SECRET_KEY
docker exec $(docker ps -q -f name=minio) \
  mc mb local/kopia-backups

# Inicializar repository Kopia
docker exec $(docker ps -q -f name=kopia) \
  kopia repository create s3 \
    --bucket=kopia-backups \
    --endpoint=$MINIO_ENDPOINT \
    --access-key=$MINIO_ACCESS_KEY \
    --secret-access-key=$MINIO_SECRET_KEY \
    --retention-mode=COMPLIANCE \
    --retention-period=30d
```

### 1.3 Criar Políticas de Backup

```bash
#!/bin/bash
# setup-kopia-policies.sh

# Política Global - Retenção
docker exec $(docker ps -q -f name=kopia) kopia policy set --global \
  --keep-latest=48 \
  --keep-hourly=24 \
  --keep-daily=30 \
  --keep-weekly=12 \
  --keep-monthly=12 \
  --keep-annual=5

# Política de Compressão
docker exec $(docker ps -q -f name=kopia) kopia policy set --global \
  --compression=zstd-better-compression

# Política de Snapshots para Volumes Críticos
CRITICAL_VOLUMES=(
  "postgres-data"
  "redis-data"
  "portainer-data"
  "prometheus-data"
  "grafana-data"
)

for vol in "${CRITICAL_VOLUMES[@]}"; do
  docker exec $(docker ps -q -f name=kopia) kopia policy set /volumes/${vol}_default \
    --snapshot-interval=1h \
    --snapshot-time=00:00,06:00,12:00,18:00
done
```

---

## 🚀 FASE 2: AUTOMAÇÃO DE BACKUPS (Dia 2)

### 2.1 Script de Backup Automático

```bash
#!/bin/bash
# /opt/backup-system/automated-backup.sh

set -euo pipefail

# Configurações
LOG_FILE="/var/log/kopia-backup.log"
WEBHOOK_URL="${BACKUP_WEBHOOK_URL:-}"
TIMESTAMP=$(date '+%Y%m%d_%H%M%S')

# Função de log
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# Função de notificação
notify() {
    local status=$1
    local message=$2
    
    if [ -n "$WEBHOOK_URL" ]; then
        curl -X POST "$WEBHOOK_URL" \
          -H "Content-Type: application/json" \
          -d "{\"status\":\"$status\",\"message\":\"$message\",\"timestamp\":\"$TIMESTAMP\"}"
    fi
}

# Início do backup
log "=== INICIANDO BACKUP AUTOMÁTICO ==="
notify "started" "Backup automático iniciado"

# 1. Snapshot de todos os volumes Docker
log "Fazendo snapshot dos volumes Docker..."
docker exec kopia-backup kopia snapshot create /volumes \
  --tags "auto,docker-volumes,${TIMESTAMP}" \
  --description "Backup automático dos volumes Docker" || {
    log "ERRO: Falha no snapshot dos volumes"
    notify "error" "Falha no backup dos volumes Docker"
    exit 1
}

# 2. Backup das configurações do Swarm
log "Backup das configurações do Swarm..."
docker exec kopia-backup sh -c "
  docker config ls --format '{{.Name}}' | while read config; do
    docker config inspect \$config > /tmp/config-\$config.json
  done
  kopia snapshot create /tmp --tags 'swarm-configs'
"

# 3. Backup dos secrets
log "Backup dos secrets (encrypted)..."
docker exec kopia-backup sh -c "
  docker secret ls --format '{{.Name}}' | while read secret; do
    echo \$secret >> /tmp/secrets-list.txt
  done
  kopia snapshot create /tmp/secrets-list.txt --tags 'swarm-secrets'
"

# 4. Verificar integridade
log "Verificando integridade dos snapshots..."
docker exec kopia-backup kopia snapshot verify --verify-files-percent=1

# 5. Sincronizar com MinIO
log "Sincronizando com MinIO..."
docker exec kopia-backup kopia repository sync-to s3 \
  --bucket=kopia-backups-mirror \
  --endpoint=http://minio:9000

# Finalização
log "=== BACKUP CONCLUÍDO COM SUCESSO ==="
notify "success" "Backup automático concluído com sucesso"
```

### 2.2 Configurar Cron para Execução Automática

```bash
#!/bin/bash
# setup-cron-backup.sh

# Backup a cada hora
echo "0 * * * * /opt/backup-system/automated-backup.sh" | crontab -

# Validação diária às 3AM
echo "0 3 * * * /opt/backup-system/validate-backups.sh" | crontab -

# Teste de restore semanal (domingo 4AM)
echo "0 4 * * 0 /opt/backup-system/test-restore.sh" | crontab -

# Limpeza mensal
echo "0 2 1 * * docker exec kopia-backup kopia maintenance run --full" | crontab -
```

---

## 🚀 FASE 3: VALIDAÇÃO E TESTES (Dia 3)

### 3.1 Script de Validação Automática

```bash
#!/bin/bash
# /opt/backup-system/validate-backups.sh

set -euo pipefail

LOG_FILE="/var/log/backup-validation.log"
ERRORS=0

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log "=== INICIANDO VALIDAÇÃO DE BACKUPS ==="

# 1. Verificar snapshots recentes
LATEST_SNAPSHOT=$(docker exec kopia-backup kopia snapshot list --json | \
  jq -r '.[0].startTime')
SNAPSHOT_AGE=$(( $(date +%s) - $(date -d "$LATEST_SNAPSHOT" +%s) ))

if [ $SNAPSHOT_AGE -gt 7200 ]; then
    log "ERRO: Último snapshot tem mais de 2 horas!"
    ERRORS=$((ERRORS + 1))
fi

# 2. Verificar integridade (1% dos arquivos)
log "Verificando integridade dos backups..."
if ! docker exec kopia-backup kopia snapshot verify \
  --verify-files-percent=1 \
  --file-parallelism=10; then
    log "ERRO: Falha na verificação de integridade!"
    ERRORS=$((ERRORS + 1))
fi

# 3. Verificar conectividade MinIO
log "Verificando conectividade com MinIO..."
if ! docker exec kopia-backup kopia repository status; then
    log "ERRO: Não foi possível conectar ao MinIO!"
    ERRORS=$((ERRORS + 1))
fi

# 4. Verificar espaço em disco
DISK_USAGE=$(df -h /var/lib/docker | awk 'NR==2 {print $5}' | sed 's/%//')
if [ $DISK_USAGE -gt 80 ]; then
    log "AVISO: Uso de disco acima de 80%!"
fi

# 5. Gerar relatório
if [ $ERRORS -eq 0 ]; then
    log "=== VALIDAÇÃO CONCLUÍDA COM SUCESSO ==="
    # Enviar métrica para Prometheus
    echo "backup_validation_status 1" | curl -X POST \
      --data-binary @- http://localhost:9090/metrics/job/backup_validation
else
    log "=== VALIDAÇÃO FALHOU COM $ERRORS ERROS ==="
    echo "backup_validation_status 0" | curl -X POST \
      --data-binary @- http://localhost:9090/metrics/job/backup_validation
    exit 1
fi
```

### 3.2 Script de Teste de Restore

```bash
#!/bin/bash
# /opt/backup-system/test-restore.sh

set -euo pipefail

LOG_FILE="/var/log/restore-test.log"
TEST_DIR="/tmp/restore-test-${RANDOM}"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log "=== INICIANDO TESTE DE RESTORE ==="

# 1. Criar diretório de teste
mkdir -p "$TEST_DIR"

# 2. Montar snapshot mais recente
LATEST_SNAPSHOT=$(docker exec kopia-backup kopia snapshot list --json | \
  jq -r '.[0].id')

log "Montando snapshot $LATEST_SNAPSHOT..."
docker exec kopia-backup kopia mount "$LATEST_SNAPSHOT" /mnt/test &
MOUNT_PID=$!
sleep 5

# 3. Verificar arquivos críticos
CRITICAL_FILES=(
  "/mnt/test/postgres-data"
  "/mnt/test/redis-data"
  "/mnt/test/portainer-data"
)

for file in "${CRITICAL_FILES[@]}"; do
  if docker exec kopia-backup test -e "$file"; then
    log "✓ Arquivo encontrado: $file"
  else
    log "✗ ERRO: Arquivo não encontrado: $file"
    exit 1
  fi
done

# 4. Testar restore de um volume pequeno
log "Testando restore do volume redis..."
docker exec kopia-backup cp -r /mnt/test/redis-data "$TEST_DIR/"

# 5. Verificar integridade dos dados restaurados
if [ -d "$TEST_DIR/redis-data" ]; then
  log "✓ Restore concluído com sucesso"
else
  log "✗ ERRO: Falha no restore"
  exit 1
fi

# 6. Limpar
docker exec kopia-backup umount /mnt/test
rm -rf "$TEST_DIR"

log "=== TESTE DE RESTORE CONCLUÍDO COM SUCESSO ==="

# Enviar métrica
echo "restore_test_status 1" | curl -X POST \
  --data-binary @- http://localhost:9090/metrics/job/restore_test
```

---

## 🚀 FASE 4: MONITORAMENTO E ALERTAS (Dia 4)

### 4.1 Configuração do Prometheus

```yaml
# /opt/monitoring/prometheus-backup-config.yml

global:
  scrape_interval: 60s
  evaluation_interval: 60s

scrape_configs:
  - job_name: 'kopia_metrics'
    static_configs:
      - targets: ['kopia-backup:51515']
    metrics_path: '/metrics'

  - job_name: 'backup_validation'
    static_configs:
      - targets: ['localhost:9091']

rule_files:
  - 'backup_alerts.yml'

alerting:
  alertmanagers:
    - static_configs:
        - targets: ['alertmanager:9093']
```

### 4.2 Regras de Alerta

```yaml
# /opt/monitoring/backup_alerts.yml

groups:
  - name: backup_alerts
    interval: 5m
    rules:
      - alert: BackupFailed
        expr: backup_validation_status == 0
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: "Backup validation failed"
          description: "Backup validation has been failing for 5 minutes"

      - alert: NoRecentBackup
        expr: time() - kopia_snapshot_last_success > 7200
        for: 10m
        labels:
          severity: warning
        annotations:
          summary: "No recent backup"
          description: "No successful backup in the last 2 hours"

      - alert: RestoreTestFailed
        expr: restore_test_status == 0
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: "Restore test failed"
          description: "Weekly restore test has failed"

      - alert: LowDiskSpace
        expr: node_filesystem_avail_bytes{mountpoint="/"} / node_filesystem_size_bytes{mountpoint="/"} < 0.2
        for: 10m
        labels:
          severity: warning
        annotations:
          summary: "Low disk space for backups"
          description: "Less than 20% disk space available"
```

### 4.3 Dashboard Grafana

```json
{
  "dashboard": {
    "title": "Backup System Monitor",
    "panels": [
      {
        "title": "Backup Status",
        "type": "stat",
        "targets": [
          {
            "expr": "backup_validation_status"
          }
        ]
      },
      {
        "title": "Last Successful Backup",
        "type": "stat",
        "targets": [
          {
            "expr": "time() - kopia_snapshot_last_success"
          }
        ]
      },
      {
        "title": "Total Backup Size",
        "type": "graph",
        "targets": [
          {
            "expr": "kopia_content_total_bytes"
          }
        ]
      },
      {
        "title": "Deduplication Ratio",
        "type": "gauge",
        "targets": [
          {
            "expr": "kopia_content_dedup_ratio"
          }
        ]
      },
      {
        "title": "Restore Test Status",
        "type": "stat",
        "targets": [
          {
            "expr": "restore_test_status"
          }
        ]
      }
    ]
  }
}
```

---

## 📋 MANUAL DE DISASTER RECOVERY

### CENÁRIO 1: Perda Total do Servidor Principal

**Tempo Estimado de Recovery: 30 minutos**

```bash
#!/bin/bash
# disaster-recovery-total.sh

# 1. Provisionar novo servidor
echo "=== DISASTER RECOVERY - PERDA TOTAL ==="

# 2. Instalar Docker e Swarm
curl -fsSL https://get.docker.com | sh
docker swarm init

# 3. Instalar Kopia
docker run -d --name kopia-restore \
  -v /restore:/restore \
  kopia/kopia:latest

# 4. Conectar ao repository MinIO
docker exec kopia-restore kopia repository connect s3 \
  --bucket=kopia-backups \
  --endpoint=http://backup-minio.com:9000 \
  --access-key=$MINIO_KEY \
  --secret-access-key=$MINIO_SECRET

# 5. Listar snapshots disponíveis
docker exec kopia-restore kopia snapshot list

# 6. Restaurar volumes críticos
LATEST=$(docker exec kopia-restore kopia snapshot list --json | jq -r '.[0].id')
docker exec kopia-restore kopia restore "$LATEST" /restore/

# 7. Recriar volumes Docker
for vol in /restore/volumes/*; do
  volume_name=$(basename "$vol")
  docker volume create "$volume_name"
  cp -r "$vol"/* "/var/lib/docker/volumes/${volume_name}/_data/"
done

# 8. Restaurar stacks
docker stack deploy -c /restore/configs/traefik.yml traefik
docker stack deploy -c /restore/configs/portainer.yml portainer
# ... outros stacks

echo "=== RECOVERY CONCLUÍDO ==="
```

### CENÁRIO 2: Corrupção de Dados

```bash
#!/bin/bash
# disaster-recovery-corruption.sh

# 1. Identificar volume corrompido
CORRUPTED_VOLUME="postgres-data"

# 2. Parar serviços dependentes
docker service scale macspark_postgresql=0

# 3. Remover volume corrompido
docker volume rm "$CORRUPTED_VOLUME"

# 4. Restaurar do backup
docker exec kopia-restore kopia restore \
  --snapshot-time="2025-01-19T10:00:00" \
  "/volumes/${CORRUPTED_VOLUME}" \
  "/restore/${CORRUPTED_VOLUME}"

# 5. Recriar volume
docker volume create "$CORRUPTED_VOLUME"
cp -r "/restore/${CORRUPTED_VOLUME}"/* \
  "/var/lib/docker/volumes/${CORRUPTED_VOLUME}/_data/"

# 6. Reiniciar serviços
docker service scale macspark_postgresql=1

echo "Volume $CORRUPTED_VOLUME restaurado com sucesso"
```

### CENÁRIO 3: Ransomware Attack

```bash
#!/bin/bash
# disaster-recovery-ransomware.sh

# 1. Isolar sistema comprometido
iptables -I INPUT -j DROP
iptables -I OUTPUT -j DROP
iptables -I OUTPUT -p tcp --dport 9000 -j ACCEPT  # MinIO

# 2. Conectar ao backup point-in-time (antes do ataque)
ATTACK_TIME="2025-01-19T08:00:00"
docker exec kopia-restore kopia repository connect s3 \
  --point-in-time="$ATTACK_TIME" \
  --bucket=kopia-backups \
  --endpoint=http://minio:9000

# 3. Limpar sistema
docker system prune -a --force
rm -rf /var/lib/docker/volumes/*

# 4. Restaurar sistema completo
docker exec kopia-restore kopia restore \
  --all \
  --before="$ATTACK_TIME" \
  /restore/

# 5. Recriar infraestrutura
./rebuild-cluster.sh

# 6. Validar integridade
./validate-system.sh

# 7. Reabilitar rede
iptables -F

echo "Sistema restaurado para antes do ransomware"
```

---

## 🔄 CRONOGRAMA DE IMPLEMENTAÇÃO

### Semana 1: Implementação Base
- **Dia 1:** Instalar e configurar Kopia + MinIO
- **Dia 2:** Implementar automação de backups
- **Dia 3:** Configurar validação e testes
- **Dia 4:** Setup monitoramento e alertas
- **Dia 5:** Testes de disaster recovery

### Semana 2: Otimização e Documentação
- **Dia 6-7:** Ajuste fino das políticas
- **Dia 8-9:** Documentação completa
- **Dia 10:** Treinamento e handover

---

## 🎯 CHECKLIST DE VALIDAÇÃO FINAL

- [ ] Kopia instalado e funcionando
- [ ] MinIO integrado com retenção de 30 dias
- [ ] GitHub LFS configurado para offsite
- [ ] Backups automáticos a cada hora
- [ ] Validação diária executando
- [ ] Teste de restore semanal agendado
- [ ] Prometheus coletando métricas
- [ ] Grafana dashboard configurado
- [ ] Alertas funcionando
- [ ] Manual de DR testado
- [ ] RTO < 30 minutos validado
- [ ] RPO < 1 hora confirmado
- [ ] Equipe treinada

---

## 💬 MENSAGEM PARA CONTINUAR APÓS QUEDA DE SESSÃO

```
Claude, continuando implementação do sistema de backup do cluster Macspark.

Status atual:
- Plano completo criado em /home/marcocardoso/BACKUP_DISASTER_RECOVERY_PLAN_2025.md
- Kopia escolhido como solução principal
- MinIO já instalado no cluster
- Prometheus/Grafana já rodando

Próximos passos:
1. Executar Fase 1: Instalar Kopia no cluster
2. Executar Fase 2: Configurar automação
3. Executar Fase 3: Implementar validação
4. Executar Fase 4: Configurar monitoramento
5. Testar disaster recovery completo

Por favor, continue de onde paramos executando os scripts do plano.
```

---

## 📞 SUPORTE E MANUTENÇÃO

**Pontos de Verificação Diários:**
1. Dashboard Grafana: http://grafana.cluster:3000/backup-monitor
2. Logs: `tail -f /var/log/kopia-backup.log`
3. Status: `docker exec kopia-backup kopia repository status`

**Comandos Úteis:**
```bash
# Ver últimos backups
docker exec kopia-backup kopia snapshot list

# Forçar backup manual
/opt/backup-system/automated-backup.sh

# Verificar integridade
docker exec kopia-backup kopia snapshot verify --all

# Montar snapshot para explorar
docker exec kopia-backup kopia mount all /mnt/explore
```

---

**SISTEMA COMPLETO E PRONTO PARA IMPLEMENTAÇÃO!**

*Última atualização: 19/01/2025*
*Versão: 1.0 - Production Ready*
*Status: AGUARDANDO EXECUÇÃO*