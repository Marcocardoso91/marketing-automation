# 🏗️ Macspark Enterprise Workspace

**Estrutura moderna de desenvolvimento enterprise com Turborepo e Docker Swarm**

## 🚀 Quick Start

```bash
# Instalar dependências
pnpm install

# Desenvolver todos os projetos
pnpm dev

# Build de produção
pnpm build

# Verificar infraestrutura
pnpm infra:status
```

## 📁 Estrutura

```
workspace/
├── apps/                    # Aplicações frontend
│   └── macspark-app/       # React 19.1.1 + TypeScript
├── services/               # Microsserviços backend
│   ├── agente-ultimate/    # FastAPI + 15 MCPs
│   ├── evolution-api/      # WhatsApp API nodes
│   └── qwen-mcp/          # IA híbrida Qwen+Ollama
├── packages/               # Packages compartilhados
│   ├── ui/                # Design system
│   ├── configs/           # Configurações ESLint/TS
│   └── types/             # TypeScript definitions
├── infrastructure/         # Infraestrutura como código
│   ├── docker/            # 22 stacks Docker Swarm
│   ├── monitoring/        # LGTM stack (Grafana Labs)
│   └── traefik/          # Proxy reverso v3.5
└── tools/                 # Scripts e ferramentas
    ├── scripts/          # Automação
    └── cli/              # Ferramentas CLI
```

## 🐳 Infraestrutura

**22 stacks Docker Swarm otimizadas:**
- **Core**: Traefik, Portainer, Macspark Production
- **Monitoring**: LGTM (Grafana Labs), Netdata, Cyber Monitor
- **AI**: Ollama (4/4 replicas), N8N, Agente Ultimate
- **Services**: Evolution API, Vault, MinIO, Redis

## 📊 Monitoramento

- **Grafana**: http://localhost:3000 (Dashboards unificados)
- **Netdata**: http://localhost:19999 (Real-time metrics)
- **Prometheus**: http://localhost:9090 (Metrics collection)

## 🧰 Tecnologias

- **Frontend**: React 19.1.1, TypeScript, Vite, TailwindCSS
- **Backend**: FastAPI, Node.js, PostgreSQL, Redis
- **IA**: Ollama, OpenAI, LangChain, 14 MCPs
- **Infraestrutura**: Docker Swarm, Traefik v3.5, LGTM Stack
- **Monorepo**: Turborepo, PNPM Workspaces

## 📋 Scripts Principais

```bash
# Desenvolvimento
pnpm dev                    # Todos os projetos em dev
pnpm build                  # Build de produção
pnpm test                   # Testes automatizados
pnpm lint                   # Linting
pnpm type-check            # Verificação TypeScript

# Infraestrutura
pnpm infra:deploy          # Deploy stacks Docker
pnpm infra:status          # Status dos serviços
pnpm infra:monitor         # Abrir Grafana
```

**✨ Enterprise-ready com observabilidade completa e arquitetura escalável**