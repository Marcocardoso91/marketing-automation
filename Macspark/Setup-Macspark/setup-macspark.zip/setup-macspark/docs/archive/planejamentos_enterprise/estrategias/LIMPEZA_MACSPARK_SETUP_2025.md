# 🧹 PLANO DE LIMPEZA MACSPARK-SETUP 2025
## Implementação Completa da Análise Anterior

---

## 📊 STATUS ATUAL DETECTADO

**Diretório:** `/home/marcocardoso/Macspark-Setup/`
- **Tamanho total:** 3.6MB
- **Arquivos totais:** 40 itens 
- **Scripts:** 36 arquivos .sh
- **Documentação:** 42 arquivos .md

**Análise anterior localizada:** ✅ `LIMPEZA_REPOSITORIO_ANALISE.md`

---

## 🎯 EXECUÇÃO DO PLANO DE LIMPEZA

### FASE 1: BACKUP DE SEGURANÇA
```bash
# Criar backup completo antes da limpeza
tar -czf /backup/macspark-setup-backup-$(date +%Y%m%d-%H%M%S).tar.gz /home/marcocardoso/Macspark-Setup/
```

### FASE 2: REMOÇÃO IMEDIATA (Scripts Desnecessários)

#### 🗑️ Scripts para VPS Single (Desnecessários para Dual VPS)
```bash
cd /home/marcocardoso/Macspark-Setup/

# Scripts de instalação específicos (manter apenas os essenciais)
rm -f k3s-installer.sh                    # Kubernetes desnecessário
rm -f interactive-installer.sh            # UI interativa desnecessária
rm -f create-expanded-stacks.sh           # Deployment monolítico
rm -f restore-stacks.sh                   # Restore complexo desnecessário
rm -f templates-installer.sh              # Templates setoriais

# Scripts de manutenção específicos
rm -f apply-security-improvements.sh      # Implementado em security-hardening.sh
rm -f modern-security-2025.sh            # Duplicata de security-hardening.sh
rm -f test-fhs.sh                        # Testing específico
rm -f update-services.sh                 # Funcionalidade em maintenance.sh
rm -f cleanup.sh                         # Genérico desnecessário
```

#### 📁 Arquivos Diversos Desnecessários
```bash
# Arquivos de configuração específicos
rm -f agents.txt                         # Lista agentes desnecessária
rm -f ASCII_ART.md                       # Arte ASCII desnecessária
rm -f GOOGLE_DRIVE_SETUP.md             # Google Drive específico
rm -f cloudflare-tunnel-config.yml      # Config específica (mover para stacks/)
rm -f requirements-ai.txt               # Requirements Python básico
rm -f get-docker.sh                     # Script Docker genérico
rm -f STRUCTURE-PROTECTION.md           # Documentação específica
rm -f audit-checklist.md                # Checklist específico
rm -f checklist-manutencao-mensal.md    # Manutenção específica

# Diretórios específicos desnecessários  
rm -rf web-installer/                    # Interface web desnecessária
rm -rf services/sparkone/                # Serviço específico (mover para stacks/ai/)
rm -rf templates/                        # Templates setoriais (simplificar)
```

### FASE 3: REORGANIZAÇÃO SCRIPTS/

#### 🔄 De 25 scripts para 8 essenciais
```bash
cd /home/marcocardoso/Macspark-Setup/scripts/

# === MANTER ESSENCIAIS ===
# ✅ health-monitor-ai.sh             # Monitoramento IA
# ✅ backup-intelligent.sh            # Backup inteligente  
# ✅ security-hardening.sh            # Hardening segurança
# ✅ create-networks.sh               # Criação redes
# ✅ create-volumes.sh                # Criação volumes
# ✅ modernize-infrastructure.sh      # Modernização infra
# ✅ install-automation.sh            # Automação instalação
# ✅ disaster-recovery.sh             # Recuperação desastre

# === REMOVER ESPECÍFICOS (17 arquivos) ===
rm -f auto-update-stacks.sh              # Funcionalidade em maintenance.sh
rm -f backup-scheduler.sh                # Funcionalidade em backup-intelligent.sh
rm -f deploy-mcp-orchestrator.sh         # Deploy específico
rm -f deploy-modernized.sh               # Deploy específico
rm -f docker-protection-wrapper.sh       # Wrapper específico
rm -f fhs-installation.sh                # FHS específico
rm -f gdrive-config-helper.sh            # Google Drive específico
rm -f modernize-complete.sh              # Duplicata
rm -f protect-source-directory.sh        # Proteção específica
rm -f quick-vps-check.sh                 # Check específico
rm -f security-automation.sh             # Automação específica
rm -f security-iptables.sh               # IPtables específico
rm -f setup-alerts.sh                    # Alertas específicos
rm -f setup-dependabot.sh                # Dependabot específico
rm -f setup-google-drive.sh              # Google Drive específico
rm -f setup-source-protection.sh         # Proteção específica
rm -f system-inventory.sh                # Inventário específico
```

### FASE 4: CRIAÇÃO DE SCRIPTS DUAL VPS

#### 🆕 Scripts Especializados para Homolog/Produção
```bash
# Criar scripts específicos para VPS Dual
cat > scripts/install-homolog.sh << 'EOF'
#!/bin/bash
# MACSPARK HOMOLOG VPS INSTALLER
# Deploy com subdomínios *-homolog.macspark.dev
set -e
echo "🔄 Instalando Macspark HOMOLOG VPS..."
export ENVIRONMENT="homolog"
export DOMAIN_SUFFIX="-homolog.macspark.dev"
# Implementar lógica específica homolog
EOF

cat > scripts/install-production.sh << 'EOF' 
#!/bin/bash
# MACSPARK PRODUCTION VPS INSTALLER
# Deploy com domínios oficiais
set -e
echo "🚀 Instalando Macspark PRODUCTION VPS..."
export ENVIRONMENT="production"
export DOMAIN_SUFFIX=".macspark.dev"
# Implementar lógica específica produção
EOF

cat > scripts/sync-homolog-to-prod.sh << 'EOF'
#!/bin/bash
# SINCRONIZAR CONFIGURAÇÕES HOMOLOG → PRODUÇÃO
set -e
echo "🔄 Sincronizando Homolog → Produção..."
# Implementar validações e sincronização
EOF

cat > scripts/deploy-stack.sh << 'EOF'
#!/bin/bash
# DEPLOY INDIVIDUAL DE STACKS COM VALIDAÇÃO
set -e
echo "📦 Deploy Stack Individual..."
# Implementar deploy + validação + rollback
EOF
```

### FASE 5: CONFIGS CENTRALIZADAS

#### 🗂️ Criar Diretório configs/
```bash
mkdir -p configs/

# Variáveis de ambiente por ambiente
cat > configs/homolog.env << 'EOF'
# MACSPARK HOMOLOG ENVIRONMENT
ENVIRONMENT=homolog
DOMAIN_SUFFIX=-homolog.macspark.dev
RESOURCES_LIMIT_LOW=true
REPLICA_COUNT=1
DATABASE_CONNECTIONS=5
EOF

cat > configs/production.env << 'EOF'  
# MACSPARK PRODUCTION ENVIRONMENT
ENVIRONMENT=production
DOMAIN_SUFFIX=.macspark.dev
RESOURCES_LIMIT_LOW=false
REPLICA_COUNT=2
DATABASE_CONNECTIONS=20
EOF

# Redes padronizadas
cat > configs/networks.yml << 'EOF'
version: '3.9'
networks:
  proxy:
    external: true
  internal:
    external: true  
  monitoring:
    external: true
  backup-net:
    external: true
EOF
```

---

## 📊 RESULTADO ESPERADO

### ANTES vs DEPOIS DA LIMPEZA

| Aspecto | Antes | Depois | Redução |
|---------|--------|---------|----------|
| **Scripts Raiz** | 6 scripts | 4 scripts | 33% |
| **Scripts Pasta** | 25 scripts | 8 scripts | 68% |
| **Arquivos Diversos** | 12 arquivos | 5 arquivos | 58% |
| **Diretórios Extras** | 3 desnecessários | 0 | 100% |
| **Tamanho Repo** | 3.6MB | ~2.5MB | 30% |

### ESTRUTURA FINAL LIMPA

```
Macspark-Setup/
├── docs/                          # ✅ MANTER (bem organizado)
│   ├── planejamento/              # 📋 Planejamentos e análises
│   ├── architecture/              # 🏗️ Arquitetura  
│   ├── guides/                    # 📖 Guias essenciais
│   └── api/                       # 📡 Documentação API
├── stacks/                        # ✅ MANTER INTACTO
│   ├── ai/                        # 🤖 Serviços IA
│   ├── apps/                      # 📱 Aplicações  
│   ├── monitoring/                # 📊 Observabilidade
│   ├── traefik/                   # 🌐 Proxy reverso
│   └── [outras categorias]        
├── scripts/                       # 🧹 LIMPO (8 essenciais)
│   ├── health-monitor-ai.sh       # 💊 Monitoramento
│   ├── backup-intelligent.sh      # 💾 Backup
│   ├── security-hardening.sh      # 🔒 Segurança
│   ├── install-homolog.sh         # 🆕 Instalador homolog
│   ├── install-production.sh      # 🆕 Instalador produção  
│   ├── sync-homolog-to-prod.sh    # 🆕 Sincronização
│   ├── deploy-stack.sh            # 🆕 Deploy stacks
│   └── create-networks.sh         # 🌐 Redes
├── configs/                       # 🆕 CONFIGURAÇÕES CENTRAIS
│   ├── homolog.env                # 🔧 Vars homolog
│   ├── production.env             # 🔧 Vars produção
│   └── networks.yml               # 🌐 Redes padrão
├── monitoring/                    # ✅ MANTER (configs essenciais)
├── install-2025.sh                # ✅ MANTER (principal)
├── install.sh                     # ✅ MANTER (VPS)
├── ai-installer.py                # ✅ MANTER (IA)
├── setup-server.sh                # ✅ MANTER (setup)
├── health-monitor.sh              # ✅ MANTER (monitor)
├── maintenance.sh                 # ✅ MANTER (manutenção)
├── README.md                      # ✅ MANTER
├── CLAUDE.md                      # ✅ MANTER
└── VERSION                        # ✅ MANTER
```

---

## 🚀 IMPLEMENTAÇÃO

### Script Automatizado de Limpeza
```bash
#!/bin/bash
# EXECUTAR LIMPEZA COMPLETA
cd /home/marcocardoso/Macspark-Setup/
bash /home/marcocardoso/SCRIPT_LIMPEZA_AUTOMATICA.sh
```

### Validação Pós-Limpeza
```bash
# 1. Verificar estrutura
find . -type f -name "*.sh" | wc -l  # Deve ser ≤12
du -sh .                             # Deve ser ≤2.5MB

# 2. Testar scripts essenciais
bash -n install-2025.sh
bash -n install.sh  
bash -n scripts/health-monitor-ai.sh

# 3. Validar documentação
find docs/ -name "*.md" | wc -l      # Deve manter ~40
```

---

## ✅ CHECKLIST DE VALIDAÇÃO

- [ ] Backup realizado com sucesso
- [ ] Scripts desnecessários removidos (19 arquivos)  
- [ ] Arquivos diversos removidos (9 arquivos)
- [ ] Diretórios específicos removidos (3 diretórios)
- [ ] Scripts/ reduzido de 25 para 8 arquivos
- [ ] configs/ criado com ambientes
- [ ] Scripts dual VPS criados (4 novos)
- [ ] Estrutura validada e funcional
- [ ] Documentação atualizada
- [ ] Tamanho reduzido para ~2.5MB

**STATUS:** 📋 PLANO COMPLETO PRONTO PARA EXECUÇÃO