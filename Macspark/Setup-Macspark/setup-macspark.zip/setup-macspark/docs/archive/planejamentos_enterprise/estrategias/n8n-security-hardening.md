# 🔒 N8N Security Hardening Guide
## MacSpark Infrastructure - 2025

---

## 🛡️ **IMPLEMENTAÇÕES DE SEGURANÇA APLICADAS**

### ✅ **Configurações de Segurança Ativas**

```yaml
# Trust Proxy (CRÍTICO para Traefik)
N8N_EDITOR_TRUST_PROXY=true

# Cookies Seguros
N8N_SECURE_COOKIE=true

# Chaves de Criptografia
N8N_ENCRYPTION_KEY=n8n_encryption_key_2024_secure
N8N_CREDENTIALS_DEFAULT_DATA_KEY=n8n_credentials_key_2024_secure

# Permissões de Arquivo
N8N_ENFORCE_SETTINGS_FILE_PERMISSIONS=true

# Desabilitar Diagnósticos
N8N_DIAGNOSTICS_ENABLED=false
```

---

## 🔐 **MELHORIAS DE SEGURANÇA RECOMENDADAS**

### **1. Implementar Autenticação 2FA**
```bash
# Adicionar ao environment do N8N
- N8N_USER_MANAGEMENT_JWT_SECRET=jwt_secret_ultra_secure_2025
- N8N_USER_MANAGEMENT_JWT_DURATION_HOURS=24
- N8N_USER_MANAGEMENT_DISABLED=false
```

### **2. Configurar Rate Limiting Avançado**
```yaml
# Traefik Middlewares - Já implementado
traefik.http.middlewares.rate-limit-automation.ratelimit.average=300
traefik.http.middlewares.rate-limit-automation.ratelimit.burst=600
traefik.http.middlewares.rate-limit-automation.ratelimit.period=1m
```

### **3. Logging de Segurança**
```bash
# Adicionar monitoramento
- N8N_LOG_LEVEL=info
- N8N_LOG_OUTPUT=console,file
- N8N_SECURITY_AUDIT=true
```

---

## 🌐 **SEGURANÇA DE REDE**

### **Headers de Segurança Implementados**
```yaml
# OWASP Security Headers
- traefik.http.middlewares.n8n-headers.headers.browserXssFilter=true
- traefik.http.middlewares.n8n-headers.headers.contentTypeNosniff=true
- traefik.http.middlewares.n8n-headers.headers.customFrameOptionsValue=SAMEORIGIN
- traefik.http.middlewares.n8n-headers.headers.forceSTSHeader=true
- traefik.http.middlewares.n8n-headers.headers.stsIncludeSubdomains=true
- traefik.http.middlewares.n8n-headers.headers.stsPreload=true
- traefik.http.middlewares.n8n-headers.headers.stsSeconds=31536000
- traefik.http.middlewares.n8n-headers.headers.referrerPolicy=strict-origin-when-cross-origin
```

---

## 📊 **MONITORAMENTO DE SEGURANÇA**

### **Alertas Recomendados**
1. **Login Failures**: Mais de 5 tentativas por IP
2. **Workflow Errors**: Execuções falhando consistentemente
3. **Resource Usage**: CPU/Memory acima de 80%
4. **SSL Certificate**: Expiração em 30 dias

### **Logs de Auditoria**
```bash
# Monitorar estes eventos
- Authentication attempts
- Workflow executions
- Credential access
- Configuration changes
- API calls
```

---

## 🔧 **COMANDOS DE VALIDAÇÃO**

### **Verificar Status de Segurança**
```bash
# Check SSL Certificate
openssl s_client -connect fluxos.macspark.dev:443 -servername fluxos.macspark.dev < /dev/null 2>/dev/null | openssl x509 -noout -dates

# Check Security Headers
curl -I https://fluxos.macspark.dev

# Check Service Status
docker service ls | grep n8n
docker service logs n8n_n8n --tail 50
```

### **Backup de Segurança**
```bash
# Backup automático das configurações
docker exec n8n_postgres pg_dump -U n8n n8n > /backup/n8n_$(date +%Y%m%d).sql

# Backup das chaves de criptografia
docker config ls | grep n8n
docker secret ls | grep n8n
```

---

## ⚠️ **ALERTAS DE SEGURANÇA**

### **CRÍTICO - Implementar Imediatamente**
- [ ] Trocar senhas padrão do PostgreSQL
- [ ] Configurar backup automático criptografado  
- [ ] Implementar rotação de logs
- [ ] Configurar firewall de aplicação

### **IMPORTANTE - Implementar em 30 dias**
- [ ] Auditoria de usuários e permissões
- [ ] Implementar LDAP/SSO se necessário
- [ ] Configurar alertas de monitoramento
- [ ] Documentar procedimentos de incident response

---

## 📋 **CHECKLIST DE SEGURANÇA MENSAL**

- [ ] Verificar atualizações de segurança do N8N
- [ ] Auditar logs de acesso e erro
- [ ] Validar certificados SSL
- [ ] Testar backups e restore
- [ ] Verificar configurações de firewall
- [ ] Revisar usuários ativos
- [ ] Validar integridade dos workflows críticos

---

**✅ Status Atual**: SEGURO - Implementações básicas ativas
**🎯 Próximos Passos**: Implementar monitoramento avançado e rotação de chaves