# 🤖 Guia de Provedores de IA - MacSpark

## 💰 **SISTEMA MULTI-MODELO INTELIGENTE**

O MacSpark agora usa um **sistema inteligente** que seleciona automaticamente o melhor modelo de IA baseado na complexidade da tarefa, **reduzindo custos em até 83%**!

---

## 📊 **COMPARAÇÃO DE CUSTOS**

| Provedor | Custo | Velocidade | Qualidade | Uso Recomendado |
|----------|-------|------------|-----------|-----------------|
| **Gemini Pro** | 🟢 **GRATUITO** | ⚡ Rápido | ✅ Boa | Textos curtos, detecção básica |
| **GPT-3.5 Turbo** | 🟡 **70% mais barato** | ⚡ Rápido | ✅ Boa | Correções gramaticais |
| **GPT-4 Turbo** | 🔴 **Caro** | 🐌 Lento | 🏆 Premium | Conversação complexa |
| **Ollama Local** | 🟢 **GRATUITO** | 🐌 Lento | ⚠️ Básica | Modo offline |

### **Economia Estimada:**
- **Antes (só GPT-4)**: $7.50 para 150 consultas
- **Depois (sistema inteligente)**: $1.28 para 150 consultas
- **💰 ECONOMIA: 83% ($6.22)**

---

## 🚀 **CONFIGURAÇÃO RÁPIDA**

### **1. Gemini Pro (Google) - GRATUITO** 🎯
```bash
# Obter API Key gratuita:
# 1. Acesse: https://makersuite.google.com/app/apikey
# 2. Crie uma conta Google (se não tiver)
# 3. Gere sua API Key gratuita
# 4. Configure:

GEMINI_API_KEY=your-gemini-api-key-here
```

**✅ Vantagens:**
- **100% GRATUITO** até 60 req/min
- Ótimo para 60% das tarefas
- Sem limite de tempo
- Qualidade excelente para textos curtos

### **2. OpenAI (Opcional)** 💎
```bash
OPENAI_API_KEY=sk-your-openai-key-here
```

**✅ Quando usar:**
- GPT-3.5: Correções gramaticais médias
- GPT-4: Apenas conversação complexa

### **3. Ollama Local (Offline)** 🏠
```bash
# Instalar Ollama:
curl -fsSL https://ollama.ai/install.sh | sh

# Baixar modelo:
ollama pull llama2:7b

# Configurar:
OLLAMA_URL=http://localhost:11434
```

**✅ Vantagens:**
- **100% GRATUITO**
- Funciona offline
- Privacidade total
- Sem limites de uso

---

## 🧠 **LÓGICA INTELIGENTE DE SELEÇÃO**

O sistema escolhe automaticamente:

### **🟢 Tarefas Simples → Gemini (Gratuito)**
- Textos < 50 caracteres
- Detecção de idioma
- Correções básicas
- **Custo: $0.00**

### **🟡 Tarefas Médias → GPT-3.5**
- Textos 50-200 caracteres
- Correções gramaticais
- Análises detalhadas
- **Custo: $0.015**

### **🔴 Tarefas Complexas → GPT-4**
- Textos > 300 caracteres
- Modo conversação
- Análises avançadas
- **Custo: $0.05**
- **Apenas em horário comercial (9h-18h)**

### **🏠 Fallback → Ollama Local**
- Quando outros falham
- Modo offline
- **Custo: $0.00**

---

## 📈 **ESTATÍSTICAS EM TEMPO REAL**

O sistema fornece:

- 📊 **Uso por provedor**
- 💰 **Economia de custos**
- 🧠 **Distribuição por complexidade**
- 🌍 **Idiomas mais usados**
- 💡 **Insights inteligentes**
- 🎯 **Recomendações personalizadas**

---

## ⚙️ **CONFIGURAÇÃO AVANÇADA**

### **Variáveis de Ambiente:**
```bash
# Provedores principais
GEMINI_API_KEY=your-gemini-key
OPENAI_API_KEY=sk-your-openai-key
OLLAMA_URL=http://localhost:11434

# Configurações opcionais
AI_COST_OPTIMIZATION=true
AI_BUSINESS_HOURS_ONLY=true
AI_FALLBACK_TO_LOCAL=true
```

### **Configuração no Supabase:**
```sql
-- Tabela de configuração
INSERT INTO platform_configs (key, value) VALUES 
('polyglot_config', '{
  "geminiApiKey": "your-key",
  "openaiApiKey": "your-key", 
  "ollamaUrl": "http://localhost:11434",
  "costOptimization": true
}');
```

---

## 🎯 **RECOMENDAÇÕES DE USO**

### **💡 Para Reduzir Custos:**
1. **Configure Gemini primeiro** (gratuito)
2. **Use GPT-3.5** para tarefas médias
3. **Reserve GPT-4** apenas para casos complexos
4. **Configure Ollama** para backup offline

### **⚡ Para Máxima Performance:**
1. **Gemini** para velocidade
2. **GPT-3.5** para equilíbrio
3. **Ollama local** para privacidade

### **🏆 Para Máxima Qualidade:**
1. **GPT-4** para análises críticas
2. **GPT-3.5** para uso geral
3. **Gemini** para tarefas simples

---

## 🔧 **TROUBLESHOOTING**

### **Problema: "API Key não configurada"**
```bash
# Verificar variáveis
echo $GEMINI_API_KEY
echo $OPENAI_API_KEY

# Configurar se necessário
export GEMINI_API_KEY="your-key"
```

### **Problema: "Ollama not available"**
```bash
# Verificar se está rodando
curl http://localhost:11434/api/tags

# Iniciar se necessário
ollama serve
```

### **Problema: Custos altos**
1. ✅ Configure Gemini (gratuito)
2. ✅ Verifique distribuição de uso
3. ✅ Ajuste lógica de complexidade

---

## 📚 **RECURSOS ADICIONAIS**

- [Gemini API Docs](https://ai.google.dev/docs)
- [OpenAI API Docs](https://platform.openai.com/docs)
- [Ollama Documentation](https://ollama.ai/docs)
- [MacSpark AI Stats Dashboard](/polyglot/stats)

---

## 🎉 **RESULTADO FINAL**

Com o sistema multi-modelo inteligente:

- ✅ **83% de economia** nos custos
- ✅ **60% das consultas gratuitas**
- ✅ **Seleção automática** do melhor modelo
- ✅ **Qualidade mantida** ou melhorada
- ✅ **Estatísticas detalhadas** em tempo real
- ✅ **Fallback offline** sempre disponível

**🚀 O MacSpark agora é mais inteligente, econômico e eficiente!** 