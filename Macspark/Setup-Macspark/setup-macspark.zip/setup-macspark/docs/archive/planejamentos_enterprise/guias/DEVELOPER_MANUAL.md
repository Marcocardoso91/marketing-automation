# 👨‍💻 Manual do Desenvolvedor - MacSpark

## 📋 Índice
1. [Configuração do Ambiente](#configuração-do-ambiente)
2. [Arquitetura do Sistema](#arquitetura-do-sistema)
3. [Sistema Administrativo](#sistema-administrativo)
4. [APIs e Integrações](#apis-e-integrações)
5. [Deploy e VPS](#deploy-e-vps)
6. [Modelos LLM](#modelos-llm)
7. [Autenticação e Segurança](#autenticação-e-segurança)
8. [Desenvolvimento Local](#desenvolvimento-local)
9. [Testes](#testes)
10. [Funcionalidades Avançadas](#funcionalidades-avançadas)
11. [PWA e Offline](#pwa-e-offline)
12. [Multi-tenancy](#multi-tenancy)
13. [CI/CD e Monitoramento](#cicd-e-monitoramento)
14. [Contribuição](#contribuição)

---

## 🛠️ Configuração do Ambiente

### Pré-requisitos
```bash
# Node.js 18+ (recomendado v20 LTS) e npm
node --version  # v18.0.0+
npm --version   # 8.0.0+

# Git
git --version

# Python 3.8+ (para agentes Python)
python --version  # 3.8.0+

# Editor recomendado: VS Code
code --version
```

### Instalação Inicial
```bash
# 1. Clonar repositório
git clone https://github.com/macspark/macspark-app.git
cd macspark-app

# 2. Instalar dependências
npm install

# 3. Instalar dependências Python (se necessário)
pip install -r requirements.txt

# 4. Configurar variáveis de ambiente
cp .env.example .env.local
```

### Variáveis de Ambiente Obrigatórias
```env
# Supabase
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key

# OAuth (opcional para desenvolvimento)
VITE_GOOGLE_CLIENT_ID=your-google-client-id
VITE_APPLE_CLIENT_ID=your-apple-client-id
VITE_GITHUB_CLIENT_ID=your-github-client-id

# URLs da aplicação
VITE_APP_URL=http://localhost:3000
VITE_REDIRECT_URL=http://localhost:3000/auth/callback

# PWA
VITE_PWA_ENABLED=true
VITE_PWA_NAME=MacSpark
VITE_PWA_SHORT_NAME=MacSpark

# Multi-tenancy
VITE_MULTI_TENANCY_ENABLED=true
VITE_DEFAULT_TENANT_ID=default

# Voice Control
VITE_VOICE_CONTROL_ENABLED=true
VITE_VOICE_LANGUAGE=pt-BR

# Proactive AI
VITE_PROACTIVE_AI_ENABLED=true
VITE_AI_LEARNING_RATE=0.1

# Monitoramento
VITE_SENTRY_DSN=your-sentry-dsn
VITE_ANALYTICS_ID=your-analytics-id
```

### Comandos de Desenvolvimento
```bash
# Iniciar servidor de desenvolvimento
npm run dev

# Build para produção
npm run build

# Build PWA
npm run build:pwa

# Preview da build
npm run preview

# Testes
npm run test
npm run test:coverage
npm run test:integration
npm run test:e2e
npm run test:performance

# Linting
npm run lint
npm run lint:fix

# Type checking
npm run type-check

# Análise de segurança
npm run security:audit
npm run security:check

# Performance
npm run lighthouse
npm run web-vitals
```

---

## 🏗️ Arquitetura do Sistema

### Estrutura de Pastas
```
src/
├── components/           # Componentes reutilizáveis
│   ├── admin/           # Componentes administrativos
│   ├── agents/          # Agentes de IA
│   ├── ai/              # Componentes de IA proativa
│   ├── auth/            # Autenticação
│   ├── calendar/        # Integração com calendário
│   ├── collaboration/   # Colaboração em tempo real
│   ├── dashboard/       # Dashboards
│   ├── ecosystem/       # Ecossistema de agentes
│   ├── executive/       # Dashboard executivo
│   ├── kanban/          # Sistema Kanban
│   ├── layout/          # Layouts da aplicação
│   ├── mission-center/  # Centro de missões
│   ├── notifications/   # Sistema de notificações
│   ├── onboarding/      # Onboarding
│   ├── polyglot/        # Tutor de idiomas
│   ├── pwa/             # Componentes PWA
│   ├── risk/            # Gestão de riscos
│   ├── tools/           # Ferramentas estratégicas
│   ├── ui/              # Componentes base (shadcn/ui)
│   └── voice/           # Controle por voz
├── contexts/            # Context providers
├── hooks/               # Custom hooks
├── integrations/        # Integrações externas
├── pages/               # Páginas da aplicação
├── routes/              # Configuração de rotas
├── services/            # Serviços e APIs
│   ├── ai/              # Serviços de IA
│   ├── multitenancy/    # Multi-tenancy
│   └── risk/            # Gestão de riscos
├── types/               # Definições TypeScript
└── utils/               # Utilitários
    ├── monitoring/      # Monitoramento
    ├── performance/     # Performance
    └── pwa/             # Utilitários PWA
```

### Stack Tecnológico
- **Frontend**: React 18 + TypeScript + Vite
- **UI**: Tailwind CSS + shadcn/ui + Framer Motion
- **Roteamento**: React Router v6
- **Estado**: Context API + Custom Hooks
- **Backend**: Supabase (PostgreSQL + Edge Functions)
- **Autenticação**: Supabase Auth + OAuth
- **PWA**: Service Workers + IndexedDB
- **Voz**: Web Speech API
- **Testes**: Vitest + Playwright + Cypress
- **CI/CD**: GitHub Actions
- **Monitoramento**: Sentry + Core Web Vitals
- **Deploy**: Vercel

### Padrões de Código
```typescript
// Componente funcional padrão
interface ComponentProps {
  title: string;
  children?: React.ReactNode;
  className?: string;
}

const Component: React.FC<ComponentProps> = ({ 
  title, 
  children, 
  className = "" 
}) => {
  return (
    <div className={`space-y-4 ${className}`}>
      <h1 className="text-2xl font-bold">{title}</h1>
      {children}
    </div>
  );
};

export default Component;
```

---

## 🔧 Sistema Administrativo

### Estrutura do Admin

#### Layout Principal
```typescript
// src/components/layout/AdminLayout.tsx
export const AdminLayout: React.FC<AdminLayoutProps> = ({ children }) => {
  // Verificação de permissões
  if (userRole !== 'admin' && userRole !== 'super_admin') {
    return <AccessDenied />;
  }

  return (
    <div className="admin-layout">
      <Sidebar />
      <MainContent>{children}</MainContent>
    </div>
  );
};
```

#### Páginas Administrativas
```
src/pages/admin/
├── AdminDashboard.tsx      # Dashboard principal
├── UserAdminPage.tsx       # Gerenciamento de usuários
├── PermissionsPage.tsx     # Sistema de permissões
├── IntegrationsManager.tsx # Configuração de APIs
├── VPSManager.tsx          # Gerenciamento de servidores
├── LLMManager.tsx          # Modelos de linguagem
├── TenantManager.tsx       # Gestão de inquilinos
├── ExecutiveDashboard.tsx  # Dashboard executivo
└── AuthConfigStatus.tsx    # Status de autenticação
```

### Sistema de Permissões

#### Definição de Permissões
```typescript
interface Permission {
  id: string;
  name: string;
  description: string;
  category: string;
  level: 'read' | 'write' | 'admin';
  resource: string;
}

interface Role {
  id: string;
  name: string;
  permissions: string[];
  isSystem: boolean;
}

interface Tenant {
  id: string;
  name: string;
  domain: string;
  plan: 'free' | 'pro' | 'enterprise';
  branding: BrandingConfig;
  settings: TenantSettings;
}
```

#### Hook de Permissões
```typescript
// src/hooks/usePermissions.ts
export const usePermissions = () => {
  const { userRole, tenantId } = useAuth();
  
  const hasPermission = (permission: string): boolean => {
    // Lógica de verificação de permissão
    return rolePermissions[userRole]?.includes(permission) || false;
  };

  const hasTenantPermission = (permission: string, targetTenantId?: string): boolean => {
    // Verificação de permissão específica do inquilino
    return hasPermission(permission) && (targetTenantId === tenantId || userRole === 'super_admin');
  };

  return { hasPermission, hasTenantPermission };
};
```

### Componentes Administrativos

#### Tabela de Usuários
```typescript
// src/components/admin/UsersTable.tsx
export const UsersTable: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [filters, setFilters] = useState<UserFilters>({});

  const handleRoleChange = async (userId: string, newRole: string) => {
    // Atualizar role do usuário
    await updateUserRole(userId, newRole);
    toast.success('Role atualizada com sucesso!');
  };

  return (
    <Table>
      {/* Implementação da tabela */}
    </Table>
  );
};
```

---

## 🤖 Funcionalidades Avançadas

### ProactiveAI - IA Proativa

#### Configuração
```typescript
// src/services/ai/proactiveAI.ts
interface ProactiveAIConfig {
  enabled: boolean;
  learningRate: number;
  eventTypes: string[];
  suggestionThreshold: number;
}

export class ProactiveAIService {
  async recordEvent(eventType: string, data: any): Promise<void> {
    // Registra eventos do usuário para análise
  }

  async getSuggestions(): Promise<Suggestion[]> {
    // Retorna sugestões baseadas em padrões
  }

  async getInsights(): Promise<Insight[]> {
    // Retorna insights sobre comportamento
  }
}
```

#### Uso no Componente
```typescript
// src/components/ai/ProactiveAIAssistant.tsx
export const ProactiveAIAssistant: React.FC = () => {
  const { suggestions, insights, recordEvent } = useProactiveAI();

  useEffect(() => {
    // Registrar eventos automaticamente
    recordEvent('page_view', { page: 'dashboard' });
  }, []);

  return (
    <div className="proactive-ai-assistant">
      {suggestions.map(suggestion => (
        <SuggestionCard key={suggestion.id} suggestion={suggestion} />
      ))}
    </div>
  );
};
```

### VoiceControl - Controle por Voz

#### Configuração
```typescript
// src/components/voice/VoiceControl.tsx
interface VoiceControlConfig {
  language: string;
  enableFeedback: boolean;
  customCommands: Command[];
  sensitivity: number;
  autoStart: boolean;
}

export const VoiceControl: React.FC<VoiceControlProps> = ({
  onCommand,
  language = "pt-BR",
  enableFeedback = true,
  customCommands = []
}) => {
  // Implementação do controle por voz
};
```

#### Comandos Personalizados
```typescript
const customCommands = [
  {
    phrase: "abrir relatório",
    action: () => navigate('/reports'),
    description: "Abre a página de relatórios"
  },
  {
    phrase: "exportar dados",
    action: () => exportData(),
    description: "Exporta dados atuais"
  }
];
```

### MultiTenancy - Gestão de Inquilinos

#### Serviço de Inquilinos
```typescript
// src/services/multitenancy/tenantService.ts
export class TenantService {
  async getCurrentTenant(): Promise<Tenant> {
    // Retorna inquilino atual
  }

  async getUserRole(userId: string): Promise<UserRole> {
    // Retorna role do usuário no inquilino
  }

  async updateTenantSettings(settings: Partial<TenantSettings>): Promise<void> {
    // Atualiza configurações do inquilino
  }

  async addUserToTenant(userId: string, role: string): Promise<void> {
    // Adiciona usuário ao inquilino
  }
}
```

#### Hook de Inquilinos
```typescript
// src/hooks/useTenantService.ts
export const useTenantService = () => {
  const { getCurrentTenant, getUserRole, updateTenantSettings } = useTenantService();

  const currentTenant = await getCurrentTenant();
  const userRole = await getUserRole(userId);

  return {
    currentTenant,
    userRole,
    updateTenantSettings
  };
};
```

---

## 📱 PWA e Offline

### Service Worker
```typescript
// public/sw.js
const CACHE_NAME = 'macspark-v2.0.0';
const STATIC_CACHE = 'macspark-static-v2.0.0';
const DYNAMIC_CACHE = 'macspark-dynamic-v2.0.0';

// Estratégias de cache
const cacheStrategies = {
  static: 'cache-first',
  dynamic: 'network-first',
  api: 'stale-while-revalidate'
};

// Instalação do service worker
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE).then((cache) => {
      return cache.addAll([
        '/',
        '/static/js/bundle.js',
        '/static/css/main.css',
        '/manifest.json'
      ]);
    })
  );
});
```

### Manifest PWA
```json
{
  "name": "MacSpark - Ecossistema de IA",
  "short_name": "MacSpark",
  "description": "Plataforma completa de produtividade e IA",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#ffffff",
  "theme_color": "#007bff",
  "icons": [
    {
      "src": "/icon-192.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "/icon-512.png",
      "sizes": "512x512",
      "type": "image/png"
    }
  ]
}
```

### Modo Offline
```typescript
// src/hooks/useOfflineMode.ts
export const useOfflineMode = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [offlineData, setOfflineData] = useState({});

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const syncOfflineData = async () => {
    // Sincroniza dados offline quando online
  };

  return { isOnline, offlineData, syncOfflineData };
};
```

---

## 🧪 Testes

### Estrutura de Testes
```
src/
├── __tests__/           # Testes unitários
├── test/               # Configurações de teste
├── components/
│   └── __tests__/      # Testes de componentes
└── hooks/
    └── __tests__/      # Testes de hooks
```

### Testes Unitários
```typescript
// src/components/__tests__/ProactiveAIAssistant.test.tsx
import { render, screen, fireEvent } from '@testing-library/react';
import { ProactiveAIAssistant } from '../ai/ProactiveAIAssistant';

describe('ProactiveAIAssistant', () => {
  it('should render suggestions correctly', () => {
    render(<ProactiveAIAssistant />);
    expect(screen.getByText(/sugestões/i)).toBeInTheDocument();
  });

  it('should handle suggestion clicks', () => {
    const mockOnSuggestionClick = jest.fn();
    render(<ProactiveAIAssistant onSuggestionClick={mockOnSuggestionClick} />);
    
    const suggestion = screen.getByText(/otimizar/i);
    fireEvent.click(suggestion);
    
    expect(mockOnSuggestionClick).toHaveBeenCalled();
  });
});
```

### Testes de Integração
```typescript
// src/test/integration/voice-control.test.ts
import { test, expect } from '@playwright/test';

test('voice control should recognize commands', async ({ page }) => {
  await page.goto('/');
  
  // Simular comando de voz
  await page.evaluate(() => {
    // Mock do Web Speech API
    window.speechSynthesis = {
      speak: jest.fn()
    };
  });
  
  await page.click('[data-testid="voice-control-button"]');
  await page.fill('[data-testid="voice-input"]', 'ir para dashboard');
  
  await expect(page.locator('[data-testid="voice-feedback"]')).toContainText('Navegando para dashboard');
});
```

### Testes E2E
```typescript
// e2e/mission-center.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Mission Center', () => {
  test('should create and complete a mission', async ({ page }) => {
    await page.goto('/mission-center');
    
    // Criar missão
    await page.click('[data-testid="create-mission"]');
    await page.fill('[data-testid="mission-title"]', 'Test Mission');
    await page.fill('[data-testid="mission-description"]', 'Test Description');
    await page.click('[data-testid="save-mission"]');
    
    // Verificar criação
    await expect(page.locator('text=Test Mission')).toBeVisible();
    
    // Completar missão
    await page.click('[data-testid="complete-mission"]');
    await expect(page.locator('[data-testid="mission-status"]')).toContainText('Completa');
  });
});
```

---

## 🚀 CI/CD e Monitoramento

### GitHub Actions
```yaml
# .github/workflows/deploy.yml
name: Deploy MacSpark
on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - run: npm ci
      - run: npm run lint
      - run: npm run type-check
      - run: npm run test:coverage
      - run: npm run test:e2e
      - run: npm run lighthouse

  security:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - run: npm audit
      - run: npm run security:check

  deploy:
    needs: [test, security]
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
      - run: npm ci
      - run: npm run build
      - run: npm run build:pwa
      - uses: vercel/action@v1
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.ORG_ID }}
          vercel-project-id: ${{ secrets.PROJECT_ID }}
```

### Monitoramento
```typescript
// src/utils/monitoring/sentry.ts
import * as Sentry from '@sentry/react';

Sentry.init({
  dsn: import.meta.env.VITE_SENTRY_DSN,
  environment: import.meta.env.MODE,
  integrations: [
    new Sentry.BrowserTracing(),
    new Sentry.Replay()
  ],
  tracesSampleRate: 1.0,
  replaysSessionSampleRate: 0.1,
  replaysOnErrorSampleRate: 1.0,
});

// src/utils/monitoring/webVitals.ts
import { getCLS, getFID, getFCP, getLCP, getTTFB } from 'web-vitals';

function sendToAnalytics(metric: any) {
  // Enviar métricas para analytics
  console.log(metric);
}

getCLS(sendToAnalytics);
getFID(sendToAnalytics);
getFCP(sendToAnalytics);
getLCP(sendToAnalytics);
getTTFB(sendToAnalytics);
```

---

## 📊 Performance e Otimização

### Lazy Loading
```typescript
// src/routes/AppRoutes.tsx
import { lazy, Suspense } from 'react';

const Dashboard = lazy(() => import('../pages/dashboard'));
const MissionCenter = lazy(() => import('../pages/mission-center'));
const ExecutiveDashboard = lazy(() => import('../pages/executive'));

export const AppRoutes = () => {
  return (
    <Suspense fallback={<LoadingSpinner />}>
      <Routes>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/mission-center" element={<MissionCenter />} />
        <Route path="/executive" element={<ExecutiveDashboard />} />
      </Routes>
    </Suspense>
  );
};
```

### Otimização de Imagens
```typescript
// src/components/ui/optimized-image.tsx
interface OptimizedImageProps {
  src: string;
  alt: string;
  width?: number;
  height?: number;
  lazy?: boolean;
}

export const OptimizedImage: React.FC<OptimizedImageProps> = ({
  src,
  alt,
  width,
  height,
  lazy = true
}) => {
  return (
    <img
      src={src}
      alt={alt}
      width={width}
      height={height}
      loading={lazy ? 'lazy' : 'eager'}
      decoding="async"
    />
  );
};
```

---

## 🔒 Segurança

### Validação de Entrada
```typescript
// src/utils/validation.ts
import { z } from 'zod';

const missionSchema = z.object({
  title: z.string().min(1).max(100),
  description: z.string().min(1).max(1000),
  priority: z.enum(['low', 'medium', 'high']),
  dueDate: z.date().optional()
});

export const validateMission = (data: unknown) => {
  return missionSchema.parse(data);
};
```

### Sanitização de Dados
```typescript
// src/utils/sanitization.ts
import DOMPurify from 'dompurify';

export const sanitizeHtml = (html: string): string => {
  return DOMPurify.sanitize(html);
};

export const sanitizeInput = (input: string): string => {
  return input.replace(/[<>]/g, '');
};
```

---

## 🤝 Contribuição

### Padrões de Commit
```bash
# Conventional Commits
feat: add voice control functionality
fix: resolve PWA installation issue
docs: update API documentation
style: format code with prettier
refactor: improve proactive AI algorithm
test: add tests for multi-tenancy
chore: update dependencies
```

### Pull Request Template
```markdown
## Descrição
Breve descrição das mudanças

## Tipo de Mudança
- [ ] Bug fix
- [ ] Nova funcionalidade
- [ ] Breaking change
- [ ] Documentação

## Testes
- [ ] Testes unitários passando
- [ ] Testes de integração passando
- [ ] Testes E2E passando
- [ ] Performance não degradada

## Checklist
- [ ] Código segue padrões do projeto
- [ ] Documentação atualizada
- [ ] Testes adicionados/atualizados
- [ ] Build passando
```

---

**Última atualização**: Janeiro 2025  
**Versão**: v2.0.0

# 👨‍💻 Manual do Desenvolvedor - MacSpark

## 📋 Índice
1. [Configuração do Ambiente](#configuração-do-ambiente)
2. [Arquitetura do Sistema](#arquitetura-do-sistema)
3. [Sistema Administrativo](#sistema-administrativo)
4. [APIs e Integrações](#apis-e-integrações)
5. [Deploy e VPS](#deploy-e-vps)
6. [Modelos LLM](#modelos-llm)
7. [Autenticação e Segurança](#autenticação-e-segurança)
8. [Desenvolvimento Local](#desenvolvimento-local)
9. [Testes](#testes)
10. [Funcionalidades Avançadas](#funcionalidades-avançadas)
11. [PWA e Offline](#pwa-e-offline)
12. [Multi-tenancy](#multi-tenancy)
13. [CI/CD e Monitoramento](#cicd-e-monitoramento)
14. [Contribuição](#contribuição)

---

## 🛠️ Configuração do Ambiente

### Pré-requisitos
```bash
# Node.js 18+ (recomendado v20 LTS) e npm
node --version  # v18.0.0+
npm --version   # 8.0.0+

# Git
git --version

# Python 3.8+ (para agentes Python)
python --version  # 3.8.0+

# Editor recomendado: VS Code
code --version
```

### Instalação Inicial
```bash
# 1. Clonar repositório
git clone https://github.com/macspark/macspark-app.git
cd macspark-app

# 2. Instalar dependências
npm install

# 3. Instalar dependências Python (se necessário)
pip install -r requirements.txt

# 4. Configurar variáveis de ambiente
cp .env.example .env.local
```

### Variáveis de Ambiente Obrigatórias
```env
# Supabase
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key

# OAuth (opcional para desenvolvimento)
VITE_GOOGLE_CLIENT_ID=your-google-client-id
VITE_APPLE_CLIENT_ID=your-apple-client-id
VITE_GITHUB_CLIENT_ID=your-github-client-id

# URLs da aplicação
VITE_APP_URL=http://localhost:3000
VITE_REDIRECT_URL=http://localhost:3000/auth/callback

# PWA
VITE_PWA_ENABLED=true
VITE_PWA_NAME=MacSpark
VITE_PWA_SHORT_NAME=MacSpark

# Multi-tenancy
VITE_MULTI_TENANCY_ENABLED=true
VITE_DEFAULT_TENANT_ID=default

# Voice Control
VITE_VOICE_CONTROL_ENABLED=true
VITE_VOICE_LANGUAGE=pt-BR

# Proactive AI
VITE_PROACTIVE_AI_ENABLED=true
VITE_AI_LEARNING_RATE=0.1

# Monitoramento
VITE_SENTRY_DSN=your-sentry-dsn
VITE_ANALYTICS_ID=your-analytics-id
```

### Comandos de Desenvolvimento
```bash
# Iniciar servidor de desenvolvimento
npm run dev

# Build para produção
npm run build

# Build PWA
npm run build:pwa

# Preview da build
npm run preview

# Testes
npm run test
npm run test:coverage
npm run test:integration
npm run test:e2e
npm run test:performance

# Linting
npm run lint
npm run lint:fix

# Type checking
npm run type-check

# Análise de segurança
npm run security:audit
npm run security:check

# Performance
npm run lighthouse
npm run web-vitals
```

---

## 🏗️ Arquitetura do Sistema

### Estrutura de Pastas
```
src/
├── components/           # Componentes reutilizáveis
│   ├── admin/           # Componentes administrativos
│   ├── agents/          # Agentes de IA
│   ├── ai/              # Componentes de IA proativa
│   ├── auth/            # Autenticação
│   ├── calendar/        # Integração com calendário
│   ├── collaboration/   # Colaboração em tempo real
│   ├── dashboard/       # Dashboards
│   ├── ecosystem/       # Ecossistema de agentes
│   ├── executive/       # Dashboard executivo
│   ├── kanban/          # Sistema Kanban
│   ├── layout/          # Layouts da aplicação
│   ├── mission-center/  # Centro de missões
│   ├── notifications/   # Sistema de notificações
│   ├── onboarding/      # Onboarding
│   ├── polyglot/        # Tutor de idiomas
│   ├── pwa/             # Componentes PWA
│   ├── risk/            # Gestão de riscos
│   ├── tools/           # Ferramentas estratégicas
│   ├── ui/              # Componentes base (shadcn/ui)
│   └── voice/           # Controle por voz
├── contexts/            # Context providers
├── hooks/               # Custom hooks
├── integrations/        # Integrações externas
├── pages/               # Páginas da aplicação
├── routes/              # Configuração de rotas
├── services/            # Serviços e APIs
│   ├── ai/              # Serviços de IA
│   ├── multitenancy/    # Multi-tenancy
│   └── risk/            # Gestão de riscos
├── types/               # Definições TypeScript
└── utils/               # Utilitários
    ├── monitoring/      # Monitoramento
    ├── performance/     # Performance
    └── pwa/             # Utilitários PWA
```

### Stack Tecnológico
- **Frontend**: React 18 + TypeScript + Vite
- **UI**: Tailwind CSS + shadcn/ui + Framer Motion
- **Roteamento**: React Router v6
- **Estado**: Context API + Custom Hooks
- **Backend**: Supabase (PostgreSQL + Edge Functions)
- **Autenticação**: Supabase Auth + OAuth
- **PWA**: Service Workers + IndexedDB
- **Voz**: Web Speech API
- **Testes**: Vitest + Playwright + Cypress
- **CI/CD**: GitHub Actions
- **Monitoramento**: Sentry + Core Web Vitals
- **Deploy**: Vercel

### Padrões de Código
```typescript
// Componente funcional padrão
interface ComponentProps {
  title: string;
  children?: React.ReactNode;
  className?: string;
}

const Component: React.FC<ComponentProps> = ({ 
  title, 
  children, 
  className = "" 
}) => {
  return (
    <div className={`space-y-4 ${className}`}>
      <h1 className="text-2xl font-bold">{title}</h1>
      {children}
    </div>
  );
};

export default Component;
```

---

## 🔧 Sistema Administrativo

### Estrutura do Admin

#### Layout Principal
```typescript
// src/components/layout/AdminLayout.tsx
export const AdminLayout: React.FC<AdminLayoutProps> = ({ children }) => {
  // Verificação de permissões
  if (userRole !== 'admin' && userRole !== 'super_admin') {
    return <AccessDenied />;
  }

  return (
    <div className="admin-layout">
      <Sidebar />
      <MainContent>{children}</MainContent>
    </div>
  );
};
```

#### Páginas Administrativas
```
src/pages/admin/
├── AdminDashboard.tsx      # Dashboard principal
├── UserAdminPage.tsx       # Gerenciamento de usuários
├── PermissionsPage.tsx     # Sistema de permissões
├── IntegrationsManager.tsx # Configuração de APIs
├── VPSManager.tsx          # Gerenciamento de servidores
├── LLMManager.tsx          # Modelos de linguagem
├── TenantManager.tsx       # Gestão de inquilinos
├── ExecutiveDashboard.tsx  # Dashboard executivo
└── AuthConfigStatus.tsx    # Status de autenticação
```

### Sistema de Permissões

#### Definição de Permissões
```typescript
interface Permission {
  id: string;
  name: string;
  description: string;
  category: string;
  level: 'read' | 'write' | 'admin';
  resource: string;
}

interface Role {
  id: string;
  name: string;
  permissions: string[];
  isSystem: boolean;
}

interface Tenant {
  id: string;
  name: string;
  domain: string;
  plan: 'free' | 'pro' | 'enterprise';
  branding: BrandingConfig;
  settings: TenantSettings;
}
```

#### Hook de Permissões
```typescript
// src/hooks/usePermissions.ts
export const usePermissions = () => {
  const { userRole, tenantId } = useAuth();
  
  const hasPermission = (permission: string): boolean => {
    // Lógica de verificação de permissão
    return rolePermissions[userRole]?.includes(permission) || false;
  };

  const hasTenantPermission = (permission: string, targetTenantId?: string): boolean => {
    // Verificação de permissão específica do inquilino
    return hasPermission(permission) && (targetTenantId === tenantId || userRole === 'super_admin');
  };

  return { hasPermission, hasTenantPermission };
};
```

### Componentes Administrativos

#### Tabela de Usuários
```typescript
// src/components/admin/UsersTable.tsx
export const UsersTable: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [filters, setFilters] = useState<UserFilters>({});

  const handleRoleChange = async (userId: string, newRole: string) => {
    // Atualizar role do usuário
    await updateUserRole(userId, newRole);
    toast.success('Role atualizada com sucesso!');
  };

  return (
    <Table>
      {/* Implementação da tabela */}
    </Table>
  );
};
```

---

## 🤖 Funcionalidades Avançadas

### ProactiveAI - IA Proativa

#### Configuração
```typescript
// src/services/ai/proactiveAI.ts
interface ProactiveAIConfig {
  enabled: boolean;
  learningRate: number;
  eventTypes: string[];
  suggestionThreshold: number;
}

export class ProactiveAIService {
  async recordEvent(eventType: string, data: any): Promise<void> {
    // Registra eventos do usuário para análise
  }

  async getSuggestions(): Promise<Suggestion[]> {
    // Retorna sugestões baseadas em padrões
  }

  async getInsights(): Promise<Insight[]> {
    // Retorna insights sobre comportamento
  }
}
```

#### Uso no Componente
```typescript
// src/components/ai/ProactiveAIAssistant.tsx
export const ProactiveAIAssistant: React.FC = () => {
  const { suggestions, insights, recordEvent } = useProactiveAI();

  useEffect(() => {
    // Registrar eventos automaticamente
    recordEvent('page_view', { page: 'dashboard' });
  }, []);

  return (
    <div className="proactive-ai-assistant">
      {suggestions.map(suggestion => (
        <SuggestionCard key={suggestion.id} suggestion={suggestion} />
      ))}
    </div>
  );
};
```

### VoiceControl - Controle por Voz

#### Configuração
```typescript
// src/components/voice/VoiceControl.tsx
interface VoiceControlConfig {
  language: string;
  enableFeedback: boolean;
  customCommands: Command[];
  sensitivity: number;
  autoStart: boolean;
}

export const VoiceControl: React.FC<VoiceControlProps> = ({
  onCommand,
  language = "pt-BR",
  enableFeedback = true,
  customCommands = []
}) => {
  // Implementação do controle por voz
};
```

#### Comandos Personalizados
```typescript
const customCommands = [
  {
    phrase: "abrir relatório",
    action: () => navigate('/reports'),
    description: "Abre a página de relatórios"
  },
  {
    phrase: "exportar dados",
    action: () => exportData(),
    description: "Exporta dados atuais"
  }
];
```

### MultiTenancy - Gestão de Inquilinos

#### Serviço de Inquilinos
```typescript
// src/services/multitenancy/tenantService.ts
export class TenantService {
  async getCurrentTenant(): Promise<Tenant> {
    // Retorna inquilino atual
  }

  async getUserRole(userId: string): Promise<UserRole> {
    // Retorna role do usuário no inquilino
  }

  async updateTenantSettings(settings: Partial<TenantSettings>): Promise<void> {
    // Atualiza configurações do inquilino
  }

  async addUserToTenant(userId: string, role: string): Promise<void> {
    // Adiciona usuário ao inquilino
  }
}
```

#### Hook de Inquilinos
```typescript
// src/hooks/useTenantService.ts
export const useTenantService = () => {
  const { getCurrentTenant, getUserRole, updateTenantSettings } = useTenantService();

  const currentTenant = await getCurrentTenant();
  const userRole = await getUserRole(userId);

  return {
    currentTenant,
    userRole,
    updateTenantSettings
  };
};
```

---

## 📱 PWA e Offline

### Service Worker
```typescript
// public/sw.js
const CACHE_NAME = 'macspark-v2.0.0';
const STATIC_CACHE = 'macspark-static-v2.0.0';
const DYNAMIC_CACHE = 'macspark-dynamic-v2.0.0';

// Estratégias de cache
const cacheStrategies = {
  static: 'cache-first',
  dynamic: 'network-first',
  api: 'stale-while-revalidate'
};

// Instalação do service worker
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE).then((cache) => {
      return cache.addAll([
        '/',
        '/static/js/bundle.js',
        '/static/css/main.css',
        '/manifest.json'
      ]);
    })
  );
});
```

### Manifest PWA
```json
{
  "name": "MacSpark - Ecossistema de IA",
  "short_name": "MacSpark",
  "description": "Plataforma completa de produtividade e IA",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#ffffff",
  "theme_color": "#007bff",
  "icons": [
    {
      "src": "/icon-192.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "/icon-512.png",
      "sizes": "512x512",
      "type": "image/png"
    }
  ]
}
```

### Modo Offline
```typescript
// src/hooks/useOfflineMode.ts
export const useOfflineMode = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [offlineData, setOfflineData] = useState({});

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const syncOfflineData = async () => {
    // Sincroniza dados offline quando online
  };

  return { isOnline, offlineData, syncOfflineData };
};
```

---

## 🧪 Testes

### Estrutura de Testes
```
src/
├── __tests__/           # Testes unitários
├── test/               # Configurações de teste
├── components/
│   └── __tests__/      # Testes de componentes
└── hooks/
    └── __tests__/      # Testes de hooks
```

### Testes Unitários
```typescript
// src/components/__tests__/ProactiveAIAssistant.test.tsx
import { render, screen, fireEvent } from '@testing-library/react';
import { ProactiveAIAssistant } from '../ai/ProactiveAIAssistant';

describe('ProactiveAIAssistant', () => {
  it('should render suggestions correctly', () => {
    render(<ProactiveAIAssistant />);
    expect(screen.getByText(/sugestões/i)).toBeInTheDocument();
  });

  it('should handle suggestion clicks', () => {
    const mockOnSuggestionClick = jest.fn();
    render(<ProactiveAIAssistant onSuggestionClick={mockOnSuggestionClick} />);
    
    const suggestion = screen.getByText(/otimizar/i);
    fireEvent.click(suggestion);
    
    expect(mockOnSuggestionClick).toHaveBeenCalled();
  });
});
```

### Testes de Integração
```typescript
// src/test/integration/voice-control.test.ts
import { test, expect } from '@playwright/test';

test('voice control should recognize commands', async ({ page }) => {
  await page.goto('/');
  
  // Simular comando de voz
  await page.evaluate(() => {
    // Mock do Web Speech API
    window.speechSynthesis = {
      speak: jest.fn()
    };
  });
  
  await page.click('[data-testid="voice-control-button"]');
  await page.fill('[data-testid="voice-input"]', 'ir para dashboard');
  
  await expect(page.locator('[data-testid="voice-feedback"]')).toContainText('Navegando para dashboard');
});
```

### Testes E2E
```typescript
// e2e/mission-center.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Mission Center', () => {
  test('should create and complete a mission', async ({ page }) => {
    await page.goto('/mission-center');
    
    // Criar missão
    await page.click('[data-testid="create-mission"]');
    await page.fill('[data-testid="mission-title"]', 'Test Mission');
    await page.fill('[data-testid="mission-description"]', 'Test Description');
    await page.click('[data-testid="save-mission"]');
    
    // Verificar criação
    await expect(page.locator('text=Test Mission')).toBeVisible();
    
    // Completar missão
    await page.click('[data-testid="complete-mission"]');
    await expect(page.locator('[data-testid="mission-status"]')).toContainText('Completa');
  });
});
```

---

## 🚀 CI/CD e Monitoramento

### GitHub Actions
```yaml
# .github/workflows/deploy.yml
name: Deploy MacSpark
on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - run: npm ci
      - run: npm run lint
      - run: npm run type-check
      - run: npm run test:coverage
      - run: npm run test:e2e
      - run: npm run lighthouse

  security:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - run: npm audit
      - run: npm run security:check

  deploy:
    needs: [test, security]
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
      - run: npm ci
      - run: npm run build
      - run: npm run build:pwa
      - uses: vercel/action@v1
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.ORG_ID }}
          vercel-project-id: ${{ secrets.PROJECT_ID }}
```

### Monitoramento
```typescript
// src/utils/monitoring/sentry.ts
import * as Sentry from '@sentry/react';

Sentry.init({
  dsn: import.meta.env.VITE_SENTRY_DSN,
  environment: import.meta.env.MODE,
  integrations: [
    new Sentry.BrowserTracing(),
    new Sentry.Replay()
  ],
  tracesSampleRate: 1.0,
  replaysSessionSampleRate: 0.1,
  replaysOnErrorSampleRate: 1.0,
});

// src/utils/monitoring/webVitals.ts
import { getCLS, getFID, getFCP, getLCP, getTTFB } from 'web-vitals';

function sendToAnalytics(metric: any) {
  // Enviar métricas para analytics
  console.log(metric);
}

getCLS(sendToAnalytics);
getFID(sendToAnalytics);
getFCP(sendToAnalytics);
getLCP(sendToAnalytics);
getTTFB(sendToAnalytics);
```

---

## 📊 Performance e Otimização

### Lazy Loading
```typescript
// src/routes/AppRoutes.tsx
import { lazy, Suspense } from 'react';

const Dashboard = lazy(() => import('../pages/dashboard'));
const MissionCenter = lazy(() => import('../pages/mission-center'));
const ExecutiveDashboard = lazy(() => import('../pages/executive'));

export const AppRoutes = () => {
  return (
    <Suspense fallback={<LoadingSpinner />}>
      <Routes>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/mission-center" element={<MissionCenter />} />
        <Route path="/executive" element={<ExecutiveDashboard />} />
      </Routes>
    </Suspense>
  );
};
```

### Otimização de Imagens
```typescript
// src/components/ui/optimized-image.tsx
interface OptimizedImageProps {
  src: string;
  alt: string;
  width?: number;
  height?: number;
  lazy?: boolean;
}

export const OptimizedImage: React.FC<OptimizedImageProps> = ({
  src,
  alt,
  width,
  height,
  lazy = true
}) => {
  return (
    <img
      src={src}
      alt={alt}
      width={width}
      height={height}
      loading={lazy ? 'lazy' : 'eager'}
      decoding="async"
    />
  );
};
```

---

## 🔒 Segurança

### Validação de Entrada
```typescript
// src/utils/validation.ts
import { z } from 'zod';

const missionSchema = z.object({
  title: z.string().min(1).max(100),
  description: z.string().min(1).max(1000),
  priority: z.enum(['low', 'medium', 'high']),
  dueDate: z.date().optional()
});

export const validateMission = (data: unknown) => {
  return missionSchema.parse(data);
};
```

### Sanitização de Dados
```typescript
// src/utils/sanitization.ts
import DOMPurify from 'dompurify';

export const sanitizeHtml = (html: string): string => {
  return DOMPurify.sanitize(html);
};

export const sanitizeInput = (input: string): string => {
  return input.replace(/[<>]/g, '');
};
```

---

## 🤝 Contribuição

### Padrões de Commit
```bash
# Conventional Commits
feat: add voice control functionality
fix: resolve PWA installation issue
docs: update API documentation
style: format code with prettier
refactor: improve proactive AI algorithm
test: add tests for multi-tenancy
chore: update dependencies
```

### Pull Request Template
```markdown
## Descrição
Breve descrição das mudanças

## Tipo de Mudança
- [ ] Bug fix
- [ ] Nova funcionalidade
- [ ] Breaking change
- [ ] Documentação

## Testes
- [ ] Testes unitários passando
- [ ] Testes de integração passando
- [ ] Testes E2E passando
- [ ] Performance não degradada

## Checklist
- [ ] Código segue padrões do projeto
- [ ] Documentação atualizada
- [ ] Testes adicionados/atualizados
- [ ] Build passando
```

---

**Última atualização**: Janeiro 2025  
**Versão**: v2.0.0 