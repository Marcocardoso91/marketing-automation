# 🛠️ Desenvolvimento - MacSpark

## Configuração do Ambiente

### Pré-requisitos

- **Node.js**: v18+ (recomendado v20 LTS)
- **npm**: v9+ ou **yarn**: v1.22+ ou **bun**: v1.0+
- **Git**: v2.30+
- **VS Code**: Recomendado com extensões

### Extensões VS Code Recomendadas

```json
{
  "recommendations": [
    "bradlc.vscode-tailwindcss",
    "esbenp.prettier-vscode",
    "dbaeumer.vscode-eslint",
    "ms-vscode.vscode-typescript-next",
    "formulahendry.auto-rename-tag",
    "christian-kohler.path-intellisense",
    "ms-vscode.vscode-json"
  ]
}
```

## 🚀 Setup Inicial

### 1. Clone o Repositório

```bash
git clone https://github.com/macspark/macspark-app.git
cd macspark-app
```

### 2. Instale as Dependências

```bash
# Com npm
npm install

# Com yarn
yarn install

# Com bun
bun install
```

### 3. Configure as Variáveis de Ambiente

Crie um arquivo `.env.local` na raiz do projeto:

```bash
# Supabase
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key

# OpenAI (para desenvolvimento)
VITE_OPENAI_API_KEY=your_openai_api_key

# Outras configurações
VITE_APP_ENV=development
VITE_APP_VERSION=1.0.0
```

### 4. Configure o Supabase

1. Acesse [supabase.com](https://supabase.com)
2. Crie um novo projeto
3. Configure as tabelas necessárias (veja `supabase/migrations/`)
4. Configure as políticas RLS
5. Copie as credenciais para o `.env.local`

### 5. Inicie o Servidor de Desenvolvimento

```bash
# Com npm
npm run dev

# Com yarn
yarn dev

# Com bun
bun dev
```

O projeto estará disponível em `http://localhost:5173`

## 📁 Estrutura de Desenvolvimento

### Organização de Arquivos

```
src/
├── components/           # Componentes reutilizáveis
│   ├── ui/              # Componentes base (shadcn/ui)
│   ├── auth/            # Componentes de autenticação
│   ├── dashboard/       # Componentes do dashboard
│   ├── mission-center/  # Central de missões
│   ├── collaboration/   # Área colaborativa
│   ├── tools/           # Ferramentas metodológicas
│   └── sparkone/        # Componentes do SparkOne
├── pages/               # Páginas da aplicação
├── routes/              # Configuração de rotas
├── hooks/               # Custom hooks
├── contexts/            # Contextos React
├── integrations/        # Integrações externas
├── lib/                 # Utilitários e configurações
├── types/               # Definições TypeScript
└── utils/               # Funções utilitárias
```

### Convenções de Nomenclatura

#### Arquivos e Pastas
- **Componentes**: PascalCase (`MissionControl.tsx`)
- **Hooks**: camelCase com prefixo `use` (`useMissionData.ts`)
- **Utilitários**: camelCase (`formatDate.ts`)
- **Tipos**: PascalCase (`Mission.ts`)
- **Constantes**: UPPER_SNAKE_CASE (`API_ENDPOINTS.ts`)

#### Componentes
```typescript
// ✅ Correto
export const MissionCard: React.FC<MissionCardProps> = ({ mission }) => {
  return <div>...</div>;
};

// ❌ Incorreto
export const missionCard = ({ mission }) => {
  return <div>...</div>;
};
```

## 🎨 Padrões de Código

### Estrutura de Componentes

```typescript
// 1. Imports
import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

// 2. Types/Interfaces
interface ComponentProps {
  title: string;
  description?: string;
  children?: React.ReactNode;
}

// 3. Component
export const Component: React.FC<ComponentProps> = ({ 
  title, 
  description, 
  children 
}) => {
  // 4. Hooks
  const [state, setState] = useState(false);
  
  // 5. Handlers
  const handleClick = () => {
    setState(!state);
  };
  
  // 6. Effects
  useEffect(() => {
    // Side effects
  }, []);
  
  // 7. Render
  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        {description && <p>{description}</p>}
      </CardHeader>
      <CardContent>
        {children}
      </CardContent>
    </Card>
  );
};
```

### Custom Hooks

```typescript
// hooks/useMissionData.ts
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Mission } from '@/types/mission';

export const useMissionData = (userId: string) => {
  const [missions, setMissions] = useState<Mission[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchMissions = async () => {
      try {
        setLoading(true);
        const { data, error } = await supabase
          .from('missions')
          .select('*')
          .eq('created_by', userId)
          .order('created_at', { ascending: false });

        if (error) throw error;
        setMissions(data || []);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    if (userId) {
      fetchMissions();
    }
  }, [userId]);

  return { missions, loading, error };
};
```

### Contextos

```typescript
// contexts/MissionContext.tsx
import React, { createContext, useContext, useReducer } from 'react';

interface MissionState {
  missions: Mission[];
  loading: boolean;
  error: string | null;
}

interface MissionContextType {
  state: MissionState;
  dispatch: React.Dispatch<MissionAction>;
}

const MissionContext = createContext<MissionContextType | undefined>(undefined);

export const MissionProvider: React.FC<{ children: React.ReactNode }> = ({ 
  children 
}) => {
  const [state, dispatch] = useReducer(missionReducer, initialState);

  return (
    <MissionContext.Provider value={{ state, dispatch }}>
      {children}
    </MissionContext.Provider>
  );
};

export const useMissionContext = () => {
  const context = useContext(MissionContext);
  if (!context) {
    throw new Error('useMissionContext must be used within MissionProvider');
  }
  return context;
};
```

## 🔧 Scripts Disponíveis

### Desenvolvimento
```bash
# Iniciar servidor de desenvolvimento
npm run dev

# Build para desenvolvimento
npm run build:dev

# Preview do build
npm run preview
```

### Produção
```bash
# Build para produção
npm run build

# Lint do código
npm run lint

# Type checking
npm run type-check
```

### Supabase
```bash
# Iniciar Supabase localmente
npx supabase start

# Parar Supabase local
npx supabase stop

# Aplicar migrações
npx supabase db push

# Gerar tipos TypeScript
npx supabase gen types typescript --local > src/types/supabase.ts
```

## 🧪 Testes

### Configuração de Testes

```typescript
// vitest.config.ts
import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',
    setupFiles: ['./src/test/setup.ts'],
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
});
```

### Exemplo de Teste

```typescript
// __tests__/components/MissionCard.test.tsx
import { render, screen } from '@testing-library/react';
import { MissionCard } from '@/components/mission-center/MissionCard';

describe('MissionCard', () => {
  const mockMission = {
    id: '1',
    title: 'Test Mission',
    description: 'Test Description',
    status: 'pending',
    created_at: '2025-01-01T00:00:00Z',
  };

  it('renders mission title and description', () => {
    render(<MissionCard mission={mockMission} />);
    
    expect(screen.getByText('Test Mission')).toBeInTheDocument();
    expect(screen.getByText('Test Description')).toBeInTheDocument();
  });
});
```

## 🔍 Debugging

### VS Code Debug Configuration

```json
// .vscode/launch.json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Launch Chrome",
      "type": "chrome",
      "request": "launch",
      "url": "http://localhost:5173",
      "webRoot": "${workspaceFolder}/src"
    }
  ]
}
```

### Console Logging

```typescript
// Utilitário para logging
export const logger = {
  info: (message: string, data?: any) => {
    console.log(`[INFO] ${message}`, data);
  },
  error: (message: string, error?: any) => {
    console.error(`[ERROR] ${message}`, error);
  },
  warn: (message: string, data?: any) => {
    console.warn(`[WARN] ${message}`, data);
  },
};
```

## 📦 Build e Deploy

### Build de Produção

```bash
# Build otimizado
npm run build

# Verificar bundle
npm run analyze
```

### Deploy para Vercel

```bash
# Instalar Vercel CLI
npm i -g vercel

# Deploy
vercel

# Deploy para produção
vercel --prod
```

## 🔄 Git Workflow

### Conventional Commits

```bash
# Estrutura: type(scope): description

# Exemplos:
git commit -m "feat(mission): add mission creation functionality"
git commit -m "fix(auth): resolve login redirect issue"
git commit -m "docs(readme): update installation instructions"
git commit -m "style(ui): improve button styling"
git commit -m "refactor(hooks): simplify useMissionData hook"
```

### Branches

- `main`: Código de produção
- `develop`: Código de desenvolvimento
- `feature/feature-name`: Novas funcionalidades
- `fix/bug-description`: Correções de bugs
- `hotfix/urgent-fix`: Correções urgentes

## 🚨 Troubleshooting

### Problemas Comuns

#### 1. Erro de Build
```bash
# Limpar cache
rm -rf node_modules package-lock.json
npm install
```

#### 2. Erro de TypeScript
```bash
# Verificar tipos
npm run type-check

# Regenerar tipos do Supabase
npx supabase gen types typescript --local > src/types/supabase.ts
```

#### 3. Erro de Supabase
```bash
# Verificar status
npx supabase status

# Reiniciar serviços
npx supabase stop
npx supabase start
```

#### 4. Performance Issues
```bash
# Analisar bundle
npm run analyze

# Verificar dependências
npm ls
```

## 📚 Recursos Adicionais

### Documentação
- [React Documentation](https://react.dev/)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
- [Tailwind CSS](https://tailwindcss.com/docs)
- [Supabase Documentation](https://supabase.com/docs)
- [Vite Documentation](https://vitejs.dev/)

### Ferramentas Úteis
- [React Developer Tools](https://chrome.google.com/webstore/detail/react-developer-tools)
- [Supabase Studio](https://supabase.com/docs/guides/getting-started/tutorials/with-expo-react-native#supabase-studio)
- [Vercel Dashboard](https://vercel.com/dashboard)

---

**Última atualização**: Janeiro 2025  
**Versão**: v1.0.0  
**Autor**: Equipe MacSpark 