# 🔗 N8N - GUIA DE IMPLEMENTAÇÃO DE INTEGRAÇÕES
## MacSpark Infrastructure - Agosto 2025

---

## 🗄️ **CONFIGURAÇÕES DE BANCOS DE DADOS PARA N8N**

### **1. PostgreSQL Nodes - Configurações Completas**

#### **Evolution API PostgreSQL**
```yaml
# Credencial N8N
Tipo: PostgreSQL
Host: evolution-postgres
Port: 5432
Database: evolution
User: evolution
Password: evolution
SSL: false

# Environment Variables para N8N conectar
DB_EVOLUTION_HOST=evolution-postgres
DB_EVOLUTION_PORT=5432
DB_EVOLUTION_DATABASE=evolution
DB_EVOLUTION_USER=evolution
DB_EVOLUTION_PASSWORD=evolution
```

#### **Qwen Enterprise PostgreSQL**
```yaml
# Credencial N8N
Tipo: PostgreSQL
Host: qwen-postgres
Port: 5432
Database: qwen_db
User: qwen_user
Password: [CONFIGURAR_SENHA_SEGURA]
SSL: false

# Environment Variables para N8N conectar
DB_QWEN_HOST=qwen-postgres
DB_QWEN_PORT=5432
DB_QWEN_DATABASE=qwen_db
DB_QWEN_USER=qwen_user
DB_QWEN_PASSWORD=qwen_secure_password_2025
```

#### **Agente Ultimate PostgreSQL**
```yaml
# Credencial N8N
Tipo: PostgreSQL
Host: agente-postgres
Port: 5432
Database: agente_db
User: agente_user
Password: [CONFIGURAR_SENHA_SEGURA]
SSL: false

# Environment Variables para N8N conectar
DB_AGENTE_HOST=agente-postgres
DB_AGENTE_PORT=5432
DB_AGENTE_DATABASE=agente_db
DB_AGENTE_USER=agente_user
DB_AGENTE_PASSWORD=agente_secure_password_2025
```

#### **MacSpark Production PostgreSQL**
```yaml
# Credencial N8N
Tipo: PostgreSQL
Host: postgresql
Port: 5432
Database: macspark_db
User: macspark_user
Password: [CONFIGURAR_SENHA_SEGURA]
SSL: false

# Environment Variables para N8N conectar
DB_MACSPARK_HOST=postgresql
DB_MACSPARK_PORT=5432
DB_MACSPARK_DATABASE=macspark_db
DB_MACSPARK_USER=macspark_user
DB_MACSPARK_PASSWORD=macspark_secure_password_2025
```

### **2. MySQL Nodes - Configurações**

#### **BookStack MySQL**
```yaml
# Credencial N8N
Tipo: MySQL
Host: bookstack-mysql
Port: 3306
Database: bookstack
User: bookstack
Password: [CONFIGURAR_SENHA_SEGURA]
SSL: false
Connect Timeout: 10000

# Environment Variables para N8N conectar
DB_BOOKSTACK_HOST=bookstack-mysql
DB_BOOKSTACK_PORT=3306
DB_BOOKSTACK_DATABASE=bookstack
DB_BOOKSTACK_USER=bookstack
DB_BOOKSTACK_PASSWORD=bookstack_secure_password_2025
```

### **3. Redis Nodes - Configurações**

#### **Redis Principal**
```yaml
# Credencial N8N
Tipo: Redis
Host: redis
Port: 6379
Database Number: 0
Password: [OPCIONAL]
SSL: false
```

#### **Qwen Redis Cluster**
```yaml
# Credencial N8N - Cluster Mode
Tipo: Redis Cluster
Hosts: 
  - qwen-redis-cluster-1:6379
  - qwen-redis-cluster-2:6379
  - qwen-redis-cluster-3:6379
Password: [CONFIGURAR_SE_NECESSÁRIO]
SSL: false
```

#### **Performance Redis Cluster**
```yaml
# Credencial N8N - Cluster Mode
Tipo: Redis Cluster
Hosts:
  - redis-cluster-1:6379
  - redis-cluster-2:6379
  - redis-cluster-3:6379
Password: [CONFIGURAR_SE_NECESSÁRIO]
SSL: false
```

---

## 🔧 **IMPLEMENTAÇÃO STEP-BY-STEP**

### **PASSO 1: Configurar Senhas Seguras**

```bash
# Criar secrets Docker para senhas seguras
docker secret create evolution_postgres_password "evolution_secure_2025_$(openssl rand -hex 16)"
docker secret create qwen_postgres_password "qwen_secure_2025_$(openssl rand -hex 16)"
docker secret create agente_postgres_password "agente_secure_2025_$(openssl rand -hex 16)"
docker secret create macspark_postgres_password "macspark_secure_2025_$(openssl rand -hex 16)"
docker secret create bookstack_mysql_password "bookstack_secure_2025_$(openssl rand -hex 16)"
docker secret create redis_cluster_password "redis_secure_2025_$(openssl rand -hex 16)"
```

### **PASSO 2: Configurar Cross-Network Connectivity**

```yaml
# Adicionar ao n8n-optimized.yml
networks:
  traefik-public:
    external: true
  n8n-internal:
    driver: overlay
    attachable: true
  # Redes dos outros serviços
  evolution_default:
    external: true
  qwen-enterprise_default:
    external: true
  agente-ultimate_default:
    external: true
  macspark-production_default:
    external: true
  bookstack_default:
    external: true
  redis_redis-network:
    external: true
  performance-2025_default:
    external: true

services:
  n8n:
    networks:
      - traefik-public
      - n8n-internal
      - evolution_default
      - qwen-enterprise_default
      - agente-ultimate_default
      - macspark-production_default
      - bookstack_default
      - redis_redis-network
      - performance-2025_default
```

### **PASSO 3: Atualizar Configuração N8N**

```yaml
# Adicionar ao environment do N8N
environment:
  # Bancos PostgreSQL Externos
  - EVOLUTION_POSTGRES_HOST=evolution-postgres
  - EVOLUTION_POSTGRES_PORT=5432
  - EVOLUTION_POSTGRES_DATABASE=evolution
  - EVOLUTION_POSTGRES_USER=evolution
  - EVOLUTION_POSTGRES_PASSWORD_FILE=/run/secrets/evolution_postgres_password
  
  - QWEN_POSTGRES_HOST=qwen-postgres
  - QWEN_POSTGRES_PORT=5432
  - QWEN_POSTGRES_DATABASE=qwen_db
  - QWEN_POSTGRES_USER=qwen_user
  - QWEN_POSTGRES_PASSWORD_FILE=/run/secrets/qwen_postgres_password
  
  - AGENTE_POSTGRES_HOST=agente-postgres
  - AGENTE_POSTGRES_PORT=5432
  - AGENTE_POSTGRES_DATABASE=agente_db
  - AGENTE_POSTGRES_USER=agente_user
  - AGENTE_POSTGRES_PASSWORD_FILE=/run/secrets/agente_postgres_password
  
  - MACSPARK_POSTGRES_HOST=postgresql
  - MACSPARK_POSTGRES_PORT=5432
  - MACSPARK_POSTGRES_DATABASE=macspark_db
  - MACSPARK_POSTGRES_USER=macspark_user
  - MACSPARK_POSTGRES_PASSWORD_FILE=/run/secrets/macspark_postgres_password
  
  # MySQL BookStack
  - BOOKSTACK_MYSQL_HOST=bookstack-mysql
  - BOOKSTACK_MYSQL_PORT=3306
  - BOOKSTACK_MYSQL_DATABASE=bookstack
  - BOOKSTACK_MYSQL_USER=bookstack
  - BOOKSTACK_MYSQL_PASSWORD_FILE=/run/secrets/bookstack_mysql_password
  
  # Redis Clusters
  - REDIS_PRIMARY_HOST=redis
  - REDIS_PRIMARY_PORT=6379
  - REDIS_CLUSTER_ENDPOINTS=redis-cluster-1:6379,redis-cluster-2:6379,redis-cluster-3:6379
  - REDIS_QWEN_ENDPOINTS=qwen-redis-cluster-1:6379,qwen-redis-cluster-2:6379,qwen-redis-cluster-3:6379

secrets:
  - evolution_postgres_password
  - qwen_postgres_password
  - agente_postgres_password
  - macspark_postgres_password
  - bookstack_mysql_password
  - redis_cluster_password
```

---

## 📊 **WORKFLOWS DE EXEMPLO**

### **1. Workflow: Sincronização Entre Bancos**
```json
{
  "name": "Database Sync - Evolution to Qwen",
  "nodes": [
    {
      "type": "n8n-nodes-base.cron",
      "name": "Schedule Sync",
      "parameters": {
        "triggerTimes": {
          "item": [
            {
              "mode": "everyHour"
            }
          ]
        }
      }
    },
    {
      "type": "n8n-nodes-base.postgres",
      "name": "Evolution Source",
      "parameters": {
        "operation": "executeQuery",
        "query": "SELECT * FROM users WHERE updated_at > NOW() - INTERVAL '1 hour'"
      },
      "credentials": {
        "postgres": "evolution-postgres-credential"
      }
    },
    {
      "type": "n8n-nodes-base.postgres",
      "name": "Qwen Target",
      "parameters": {
        "operation": "insert",
        "table": "synced_users"
      },
      "credentials": {
        "postgres": "qwen-postgres-credential"
      }
    }
  ]
}
```

### **2. Workflow: Cache Management com Redis**
```json
{
  "name": "Cache Management - Multi Redis",
  "nodes": [
    {
      "type": "n8n-nodes-base.webhook",
      "name": "Cache Request",
      "parameters": {
        "path": "cache-request",
        "httpMethod": "POST"
      }
    },
    {
      "type": "n8n-nodes-base.redis",
      "name": "Primary Cache Check",
      "parameters": {
        "operation": "get",
        "key": "{{$json.cache_key}}"
      },
      "credentials": {
        "redis": "redis-primary-credential"
      }
    },
    {
      "type": "n8n-nodes-base.if",
      "name": "Cache Hit Check",
      "parameters": {
        "conditions": {
          "string": [
            {
              "value1": "{{$json.value}}",
              "operation": "isNotEmpty"
            }
          ]
        }
      }
    },
    {
      "type": "n8n-nodes-base.redis",
      "name": "Performance Cache Fallback",
      "parameters": {
        "operation": "get",
        "key": "{{$json.cache_key}}"
      },
      "credentials": {
        "redis": "redis-performance-credential"
      }
    }
  ]
}
```

### **3. Workflow: Backup Automático Multi-Database**
```json
{
  "name": "Multi-Database Backup",
  "nodes": [
    {
      "type": "n8n-nodes-base.cron",
      "name": "Daily Backup",
      "parameters": {
        "triggerTimes": {
          "item": [
            {
              "mode": "everyDay",
              "hour": 2,
              "minute": 0
            }
          ]
        }
      }
    },
    {
      "type": "n8n-nodes-base.postgres",
      "name": "Evolution Backup",
      "parameters": {
        "operation": "executeQuery",
        "query": "SELECT pg_dump('evolution') as backup_data"
      },
      "credentials": {
        "postgres": "evolution-postgres-credential"
      }
    },
    {
      "type": "n8n-nodes-base.postgres",
      "name": "Qwen Backup",
      "parameters": {
        "operation": "executeQuery",
        "query": "SELECT pg_dump('qwen_db') as backup_data"
      },
      "credentials": {
        "postgres": "qwen-postgres-credential"
      }
    },
    {
      "type": "n8n-nodes-base.mysql",
      "name": "BookStack Backup",
      "parameters": {
        "operation": "executeQuery",
        "query": "SELECT 'mysqldump bookstack' as backup_data"
      },
      "credentials": {
        "mysql": "bookstack-mysql-credential"
      }
    }
  ]
}
```

---

## 🛠️ **COMANDOS DE IMPLEMENTAÇÃO**

### **Deploy Configuração Atualizada**
```bash
# 1. Atualizar arquivo de configuração
cd /home/marcocardoso
cp n8n-optimized.yml n8n-optimized-with-integrations.yml

# 2. Aplicar secrets
docker secret create evolution_postgres_password "evolution_secure_password_2025"
docker secret create qwen_postgres_password "qwen_secure_password_2025"  
docker secret create agente_postgres_password "agente_secure_password_2025"
docker secret create macspark_postgres_password "macspark_secure_password_2025"
docker secret create bookstack_mysql_password "bookstack_secure_password_2025"

# 3. Atualizar serviço N8N
docker service update --config-rm n8n-config --config-add source=n8n-optimized-with-integrations.yml,target=/app/n8n.yml n8n_n8n

# 4. Verificar conectividade
docker service logs n8n_n8n --tail 50 | grep -E "(database|redis|connection)"
```

### **Testar Conectividade**
```bash
# Testar PostgreSQL connections
docker exec $(docker ps -q --filter "name=n8n_n8n") pg_isready -h evolution-postgres -p 5432 -U evolution
docker exec $(docker ps -q --filter "name=n8n_n8n") pg_isready -h qwen-postgres -p 5432 -U qwen_user
docker exec $(docker ps -q --filter "name=n8n_n8n") pg_isready -h agente-postgres -p 5432 -U agente_user
docker exec $(docker ps -q --filter "name=n8n_n8n") pg_isready -h postgresql -p 5432 -U macspark_user

# Testar MySQL connection
docker exec $(docker ps -q --filter "name=n8n_n8n") mysqladmin ping -h bookstack-mysql -P 3306 -u bookstack

# Testar Redis connections
docker exec $(docker ps -q --filter "name=n8n_n8n") redis-cli -h redis -p 6379 ping
docker exec $(docker ps -q --filter "name=n8n_n8n") redis-cli -h redis-cluster-1 -p 6379 ping
docker exec $(docker ps -q --filter "name=n8n_n8n") redis-cli -h qwen-redis-cluster -p 6379 ping
```

---

## 📋 **CHECKLIST DE VALIDAÇÃO**

### **Configurações de Rede**
- [ ] N8N conectado a todas as redes necessárias
- [ ] Resolução DNS funcionando para todos os hosts
- [ ] Firewall Docker configurado corretamente
- [ ] Portas de rede acessíveis

### **Credenciais e Segurança**
- [ ] Senhas seguras configuradas para todos os bancos
- [ ] Secrets Docker criados e aplicados
- [ ] SSL/TLS configurado onde necessário
- [ ] Princípio de menor privilégio aplicado

### **Conectividade de Bancos**
- [ ] PostgreSQL Evolution API - Conectividade testada
- [ ] PostgreSQL Qwen Enterprise - Conectividade testada
- [ ] PostgreSQL Agente Ultimate - Conectividade testada
- [ ] PostgreSQL MacSpark Production - Conectividade testada
- [ ] MySQL BookStack - Conectividade testada
- [ ] Redis Principal - Conectividade testada
- [ ] Redis Qwen Cluster - Conectividade testada
- [ ] Redis Performance Cluster - Conectividade testada

### **Workflows de Teste**
- [ ] Workflow de sincronização entre bancos criado
- [ ] Workflow de cache management criado
- [ ] Workflow de backup automático criado
- [ ] Workflows executando sem erros

### **Monitoramento**
- [ ] Logs de conectividade sendo monitorados
- [ ] Alertas de falha de conexão configurados
- [ ] Métricas de performance coletadas
- [ ] Dashboard de status implementado

---

## 🎯 **RESULTADOS ESPERADOS**

### **Capacidades Habilitadas**
✅ **14 Bancos Integrados**: 6 PostgreSQL + 1 MySQL + 7 Redis
✅ **Cross-Database Workflows**: Sincronização automática entre sistemas
✅ **Cache Distribuído**: Performance otimizada com Redis clusters
✅ **Backup Automático**: Proteção de dados multi-database
✅ **Monitoramento Centralizado**: Visibilidade total da infraestrutura

### **Performance Esperada**
- **Latência**: < 100ms para queries locais
- **Throughput**: > 1000 operações/segundo
- **Disponibilidade**: 99.9% uptime
- **Backup**: Recovery point < 1 hora

**🚀 Status Final**: N8N configurado como hub central de dados para toda a infraestrutura MacSpark