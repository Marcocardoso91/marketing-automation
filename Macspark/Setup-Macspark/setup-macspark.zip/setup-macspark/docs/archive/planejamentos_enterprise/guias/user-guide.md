# 👥 Guia do Usuário - MacSpark

## Bem-vindo ao MacSpark!

O MacSpark é uma plataforma de produtividade e automação que combina ferramentas colaborativas com inteligência artificial para otimizar seu fluxo de trabalho. Agora com funcionalidades avançadas como PWA, controle por voz, IA proativa e muito mais!

## 🚀 Primeiros Passos

### 1. Criar uma Conta

1. Acesse [macspark.ai](https://macspark.ai)
2. Clique em "Registrar" no canto superior direito
3. Preencha seu email e senha
4. Confirme seu email (verifique a caixa de spam)
5. Faça login na plataforma

### 2. Instalar como App (PWA)

Para uma experiência ainda melhor, instale o MacSpark como app:

1. No navegador, clique no ícone de instalação (📱) na barra de endereços
2. Ou clique no botão "Instalar App" no canto superior direito
3. Confirme a instalação
4. O MacSpark agora funciona como um app nativo!

**Benefícios do PWA:**
- ✅ Funciona offline
- ✅ Notificações push
- ✅ Carregamento mais rápido
- ✅ Experiência de app nativo
- ✅ Sincronização automática

### 3. Configurar seu Perfil

1. Clique no seu avatar no canto superior direito
2. Selecione "Configurações"
3. Adicione sua foto de perfil
4. Configure suas preferências de notificação
5. Configure o controle por voz (opcional)
6. Salve as alterações

### 4. Criar seu Primeiro Workspace

1. Na tela inicial, clique em "Criar Workspace"
2. Dê um nome ao seu workspace (ex: "Projeto Principal")
3. Adicione uma descrição opcional
4. Configure as permissões da equipe
5. Clique em "Criar"

## 🎯 Central de Missões (SparkOne)

### O que é o SparkOne?

O SparkOne é o agente de IA coordenador do MacSpark. Ele pode ajudar você com:
- Análise de dados e relatórios
- Planejamento de projetos
- Resolução de problemas
- Geração de conteúdo
- Sugestões proativas
- E muito mais!

### Como Usar o SparkOne

#### Conversa Rápida
1. Clique no ícone do SparkOne no canto inferior direito
2. Digite sua pergunta ou solicitação
3. Aguarde a resposta do agente (agora com streaming em tempo real!)
4. Continue a conversa conforme necessário

#### Criar uma Missão
1. Vá para "Central de Missões" no menu lateral
2. Clique em "Nova Missão"
3. Dê um título à missão
4. Descreva o que você precisa
5. Clique em "Criar Missão"
6. Interaja com o SparkOne para completar a missão

#### Histórico e Busca
- Acesse o histórico completo de conversas
- Use a busca para encontrar missões anteriores
- Filtre por data, tipo ou status
- Exporte conversas importantes

### Exemplos de Uso

```
"Analise os dados de vendas do último trimestre e crie um relatório"

"Planeje uma campanha de marketing para o lançamento do novo produto"

"Ajude-me a organizar as tarefas do projeto X"

"Crie um resumo executivo do relatório financeiro"

"Quais são as tendências de produtividade da minha equipe?"
```

## 🎤 Controle por Voz

### Ativar Controle por Voz

1. Clique no ícone de microfone flutuante no canto inferior esquerdo
2. Ou vá em "Configurações" > "Acessibilidade" > "Controle por Voz"
3. Permita o acesso ao microfone
4. O controle por voz está ativo!

### Comandos Disponíveis

#### Navegação
- **"Ir para dashboard"** - Navega para o dashboard
- **"Abrir missões"** - Abre a central de missões
- **"Mostrar ferramentas"** - Abre as ferramentas
- **"Voltar"** - Volta para a página anterior

#### Ações
- **"Criar missão"** - Inicia criação de nova missão
- **"Salvar"** - Salva o conteúdo atual
- **"Cancelar"** - Cancela a ação atual
- **"Buscar [termo]"** - Realiza busca

#### Controle
- **"Ativar modo escuro"** - Alterna tema escuro
- **"Aumentar volume"** - Aumenta volume do sistema
- **"Parar"** - Para o reconhecimento de voz

#### Comandos Personalizados
Você pode configurar comandos personalizados:
1. Vá em "Configurações" > "Controle por Voz"
2. Clique em "Adicionar Comando"
3. Digite a frase de ativação
4. Configure a ação desejada

### Dicas para Melhor Reconhecimento

- Fale claramente e em ritmo normal
- Use frases completas
- Evite ambientes muito barulhentos
- Configure o idioma correto (português brasileiro)

## 🤖 IA Proativa (ProactiveAI)

### O que é a IA Proativa?

A IA Proativa analisa seus padrões de uso e oferece sugestões inteligentes para melhorar sua produtividade.

### Funcionalidades

#### Sugestões Inteligentes
- **Descoberta de Funcionalidades**: Sugere recursos que você pode não conhecer
- **Otimização de Fluxo**: Recomenda melhorias no seu workflow
- **Insights de Produtividade**: Analisa seus padrões de trabalho

#### Aprendizado Contínuo
- A IA aprende com suas interações
- Sugestões ficam mais precisas com o tempo
- Personalização baseada no seu comportamento

#### Insights Automáticos
- Relatórios de produtividade
- Análise de tendências
- Recomendações de melhoria

### Como Usar

1. **Receber Sugestões**: As sugestões aparecem automaticamente
2. **Aceitar/Rejeitar**: Clique em "Aplicar" ou "Ignorar"
3. **Configurar Preferências**: Vá em "Configurações" > "IA Proativa"
4. **Ver Insights**: Acesse "Dashboard" > "Insights"

### Exemplos de Sugestões

```
"Você gasta muito tempo criando missões similares. 
Que tal usar um template?"

"Baseado no seu padrão, você pode otimizar o fluxo 
de trabalho usando automação."

"Detectamos que você é mais produtivo pela manhã. 
Que tal agendar tarefas importantes neste período?"
```

## 🌍 Tutor de Idiomas (SparkPolyglot)

### O que é o SparkPolyglot?

O SparkPolyglot é o tutor de idiomas inteligente do MacSpark. Ele oferece:
- Prática de texto com correção gramatical
- Prática de áudio com feedback de pronúncia
- Sistema de gamificação com XP e conquistas
- Suporte para inglês, espanhol, italiano e português
- Detecção automática de idioma
- Sistema de conquistas e badges

### Como Usar o SparkPolyglot

#### Acessar o Tutor
1. Vá para "Idiomas" no menu lateral
2. Ou clique no widget "SparkPolyglot" no dashboard
3. Escolha o idioma que deseja praticar

#### Prática de Texto
1. Selecione "Prática de Texto"
2. Digite uma frase no idioma escolhido
3. Clique em "Enviar" ou pressione Enter
4. Receba correções e explicações
5. Ganhe XP por cada prática

#### Prática de Áudio
1. Selecione "Prática de Áudio"
2. Clique no botão de gravação (microfone)
3. Fale uma frase no idioma escolhido
4. Clique novamente para parar a gravação
5. Receba feedback sobre pronúncia e correções

#### Sistema de Gamificação
- **XP**: Ganhe pontos por cada prática
- **Níveis**: Suba de nível conforme acumula XP
- **Conquistas**: Desbloqueie conquistas especiais
- **Estatísticas**: Acompanhe seu progresso
- **Badges**: Colete badges por marcos especiais

#### Idiomas Suportados
- 🇺🇸 **Inglês**: American English
- 🇪🇸 **Espanhol**: Español
- 🇮🇹 **Italiano**: Italiano
- 🇧🇷 **Português**: Português Brasileiro

### Exemplos de Prática

```
Texto: "I go to the store yesterday"
Correção: "I went to the store yesterday"
Explicação: Use past tense for actions in the past

Texto: "Me gusta mucho la música"
Correção: "Me gusta mucho la música" ✅
Feedback: Perfect! No corrections needed.
```

### Dicas para Melhor Aproveitamento

1. **Pratique Regularmente**: Dedique 10-15 minutos por dia
2. **Varie os Idiomas**: Pratique diferentes idiomas
3. **Use Frases Completas**: Evite palavras soltas
4. **Acompanhe as Correções**: Leia as explicações
5. **Monitore seu Progresso**: Verifique suas estatísticas
6. **Colete Conquistas**: Complete desafios para ganhar badges

## 📱 Modo Offline

### Funcionalidades Offline

O MacSpark funciona mesmo sem internet! Você pode:
- ✅ Visualizar missões e tarefas
- ✅ Editar conteúdo (sincroniza quando online)
- ✅ Usar ferramentas básicas
- ✅ Acessar histórico de conversas
- ✅ Trabalhar com documentos salvos

### Indicadores de Status

- **🟢 Online**: Conexão normal
- **🟡 Sincronizando**: Salvando alterações offline
- **🔴 Offline**: Modo offline ativo

### Sincronização

Quando a conexão for restaurada:
1. As alterações são sincronizadas automaticamente
2. Você recebe uma notificação de sucesso
3. Todos os dados ficam atualizados

## 📋 Área Colaborativa

### Sistema Kanban

O Kanban ajuda você a visualizar e gerenciar suas tarefas de forma eficiente.

#### Criar um Quadro
1. Vá para "Colaboração" no menu lateral
2. Clique em "Novo Quadro"
3. Dê um nome ao quadro (ex: "Projeto Website")
4. Adicione colunas padrão ou personalizadas:
   - **A Fazer**: Tarefas pendentes
   - **Em Andamento**: Tarefas sendo trabalhadas
   - **Revisão**: Tarefas para revisão
   - **Concluído**: Tarefas finalizadas

#### Criar Tarefas
1. Clique em "Nova Tarefa" em qualquer coluna
2. Preencha:
   - **Título**: Nome da tarefa
   - **Descrição**: Detalhes da tarefa
   - **Responsável**: Quem vai executar
   - **Prazo**: Data limite
   - **Prioridade**: Baixa, Média, Alta
3. Clique em "Criar"

#### Mover Tarefas
- Arraste e solte tarefas entre colunas
- Use o menu de contexto para mais opções
- Adicione comentários e anexos

### Visualizações Disponíveis

#### Kanban (Padrão)
- Visualização em colunas
- Drag & drop para mover tarefas
- Visão geral do progresso

#### Lista
- Tarefas em formato de lista
- Filtros e ordenação
- Busca rápida

#### Calendário
- Visualização temporal
- Prazos e marcos
- Integração com calendário externo

#### Grid
- Visualização em cards
- Informações resumidas
- Filtros visuais

## 🎯 Dashboard Executivo

### Acessar o Dashboard Executivo

1. Vá para "Dashboard" > "Executivo" no menu lateral
2. Ou use o comando de voz: "Abrir dashboard executivo"

### KPIs Disponíveis

#### Produtividade
- Missões completadas
- Tempo médio de execução
- Taxa de eficiência
- Produtividade da equipe

#### Engajamento
- Usuários ativos
- Tempo de sessão
- Interações por usuário
- Retenção

#### Qualidade
- Taxa de sucesso
- Feedback dos usuários
- Satisfação
- Qualidade das entregas

#### Crescimento
- Novos usuários
- Expansão de funcionalidades
- Adoção de recursos
- ROI

### Funcionalidades

#### Filtros Avançados
- Por período (hoje, semana, mês, trimestre, ano)
- Por equipe ou usuário
- Por projeto ou categoria
- Por status ou prioridade

#### Exportação
- PDF: Relatórios formatados
- Excel: Dados para análise
- CSV: Dados brutos
- Gráficos: Imagens de alta qualidade

#### Alertas Inteligentes
- Notificações baseadas em thresholds
- Alertas de performance
- Avisos de tendências
- Recomendações automáticas

## 🛠️ Ferramentas Metodológicas

### OKR (Objetivos e Key Results)

OKR ajuda você a definir e acompanhar objetivos estratégicos.

#### Criar OKRs
1. Vá para "Ferramentas" > "OKR"
2. Clique em "Novo OKR"
3. Defina:
   - **Objetivo**: O que você quer alcançar
   - **Key Results**: Como medir o sucesso
   - **Prazo**: Período de execução
   - **Responsável**: Quem lidera o OKR

#### Exemplo de OKR
```
Objetivo: Aumentar a satisfação do cliente
Key Results:
- NPS de 8.5+ (atual: 7.2)
- Reduzir tempo de resposta em 50%
- Implementar 3 novos recursos solicitados
Prazo: Q1 2025
```

### BSC (Balanced Scorecard)

BSC oferece uma visão equilibrada da performance organizacional.

#### Perspectivas
1. **Financeira**: Resultados financeiros
2. **Cliente**: Satisfação e retenção
3. **Processos**: Eficiência operacional
4. **Aprendizado**: Crescimento e inovação

#### Criar BSC
1. Vá para "Ferramentas" > "BSC"
2. Clique em "Novo BSC"
3. Defina indicadores para cada perspectiva
4. Configure metas e prazos

### Canvas de Negócio

Canvas ajuda você a visualizar e planejar seu modelo de negócio.

#### Blocos do Canvas
- **Proposta de Valor**: O que você oferece
- **Segmentos de Cliente**: Para quem
- **Canais**: Como chegar aos clientes
- **Relacionamento**: Como manter clientes
- **Receitas**: Como ganhar dinheiro
- **Recursos**: O que você precisa
- **Atividades**: O que você faz
- **Parceiros**: Quem te ajuda
- **Custos**: O que você gasta

## 📊 Gestão de Riscos

### Matriz de Riscos 5x5

A matriz de riscos ajuda você a identificar e priorizar riscos.

#### Como Usar
1. Vá para "Riscos" no menu lateral
2. Clique em "Nova Matriz"
3. Identifique os riscos
4. Avalie probabilidade (1-5) e impacto (1-5)
5. Visualize na matriz 5x5

#### Cores da Matriz
- **🟢 Verde**: Riscos baixos (1-6 pontos)
- **🟡 Amarelo**: Riscos médios (7-12 pontos)
- **🔴 Vermelho**: Riscos altos (13-25 pontos)

#### Ações por Risco
- **Baixo**: Monitorar
- **Médio**: Mitigar
- **Alto**: Evitar ou transferir

### Relatórios Automáticos

- Relatórios semanais de riscos
- Alertas de novos riscos
- Análise de tendências
- Recomendações de mitigação

## 🔧 Configurações Avançadas

### Multi-tenancy (Organizações)

Se você faz parte de uma organização:

#### Trocar de Organização
1. Clique no seletor de organização no topo
2. Escolha a organização desejada
3. As configurações mudam automaticamente

#### Configurações da Organização
- **Branding**: Logo e cores personalizadas
- **Usuários**: Gestão de membros
- **Permissões**: Controle de acesso
- **Planos**: Limites e funcionalidades

### Notificações

#### Configurar Notificações
1. Vá em "Configurações" > "Notificações"
2. Configure:
   - **Email**: Notificações por email
   - **Push**: Notificações no navegador
   - **SMS**: Notificações por SMS (se disponível)
   - **Frequência**: Imediata, diária, semanal

#### Tipos de Notificação
- Missões atribuídas
- Prazos próximos
- Comentários em tarefas
- Atualizações de sistema
- Sugestões da IA proativa

### Integrações

#### Calendário
- **Google Calendar**: Sincronização bidirecional
- **Microsoft Outlook**: Integração completa
- **Eventos**: Criação automática de eventos

#### Armazenamento
- **Google Drive**: Acesso a arquivos
- **Dropbox**: Sincronização de documentos
- **OneDrive**: Integração Microsoft

## 📱 Comandos por Gestos (Mobile)

### Gestos Disponíveis

#### Navegação
- **Swipe para direita**: Voltar
- **Swipe para esquerda**: Avançar
- **Swipe para cima**: Abrir menu
- **Swipe para baixo**: Atualizar

#### Ações
- **Double tap**: Ação rápida
- **Long press**: Menu de contexto
- **Pinch**: Zoom in/out

#### Configurar Gestos
1. Vá em "Configurações" > "Acessibilidade"
2. Selecione "Comandos por Gestos"
3. Configure os gestos desejados
4. Teste os gestos

## 🆘 Suporte e Ajuda

### Central de Ajuda
1. Clique no ícone de ajuda (?) no canto superior direito
2. Ou use o comando de voz: "Abrir ajuda"
3. Explore os tópicos disponíveis
4. Use a busca para encontrar respostas

### Contato
- **Email**: suporte@macspark.ai
- **Chat**: Disponível na plataforma
- **Documentação**: docs.macspark.ai
- **Status**: status.macspark.ai

### Feedback
- **Sugestões**: Use o botão "Feedback" na plataforma
- **Bugs**: Reporte problemas via chat ou email
- **Melhorias**: Participe das pesquisas de usuário

## 🎉 Dicas e Truques

### Produtividade
1. **Use atalhos de teclado**: Ctrl+K para busca rápida
2. **Configure comandos de voz**: Personalize para seu workflow
3. **Use templates**: Crie templates para tarefas repetitivas
4. **Aproveite a IA proativa**: Siga as sugestões inteligentes

### Organização
1. **Use tags**: Organize missões e tarefas com tags
2. **Configure filtros**: Crie filtros personalizados
3. **Use favoritos**: Marque itens importantes
4. **Exporte relatórios**: Mantenha backup dos dados

### Colaboração
1. **Comente em tarefas**: Mantenha comunicação clara
2. **Use @mentions**: Mencione colegas quando necessário
3. **Configure notificações**: Receba alertas importantes
4. **Compartilhe dashboards**: Mostre progresso para a equipe

---

**Última atualização**: Janeiro 2025  
**Versão**: v2.0.0 