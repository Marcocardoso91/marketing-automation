# 🧹 ANÁLISE DE LIMPEZA - MACSPARK-SETUP REPOSITORY
## Scripts Desnecessários e Estrutura para VPS Dual

---

## 📊 RESUMO DA "SUJEIRA" IDENTIFICADA

### 🗑️ **SCRIPTS DESNECESSÁRIOS (VPS Dual)**
```bash
# REMOVER - Scripts para ambiente single-server
k3s-installer.sh                  # Kubernetes desnecessário  
interactive-installer.sh          # UI interativa desnecessária
macspark-ui.sh (92KB)            # Interface web complexa
create-expanded-stacks.sh         # Deployment monolítico
restore-stacks.sh                 # Restore complexo desnecessário  
templates-installer.sh            # Templates setoriais desnecessários
web-installer/                    # Pasta web installer completa

# MANTER MODIFICADOS - Utilitários básicos
install-2025.sh                  # Base boa, simplificar para VPS dual
ai-installer.py                  # IA útil, adaptar para dual VPS
setup-server.sh                  # Configuração base, adaptar
health-monitor.sh                # Monitoramento essencial
maintenance.sh                   # Manutenção básica
```

### 📁 **ARQUIVOS DIVERSOS DESNECESSÁRIOS**
```bash
# REMOVER
agents.txt                       # Lista agentes desnecessária
ASCII_ART.md                     # Arte ASCII desnecessária  
GOOGLE_DRIVE_SETUP.md           # Google Drive específico
cloudflare-tunnel-config.yml    # Configuração específica
requirements-ai.txt             # Requirements Python básico
get-docker.sh                   # Script Docker genérico
```

### 🗂️ **DIRETÓRIOS COM EXCESSO**
```bash
scripts/ (25 arquivos)          # Muitos scripts específicos
  - Manter apenas: health-monitor-ai.sh, backup-intelligent.sh
  - Remover: 20+ scripts específicos 

services/sparkone/              # Serviço específico desnecessário
web-installer/                  # Interface web desnecessária
monitoring/grafana/             # Dashboards específicos (manter configs básicas)
```

---

## 🎯 PROPOSTA DE ESTRUTURA LIMPA PARA VPS DUAL

### 📋 **ESTRUTURA RECOMENDADA**
```
Macspark-Setup-Clean/
├── docs/
│   ├── planejamento/            # ✅ Nossos arquivos já organizados
│   ├── architecture/            # ✅ Manter arquitetura
│   └── guides/                  # 📝 Simplificar guides essenciais
├── stacks/                      # ✅ MANTER INTACTO (organizado)
│   ├── core/                    # 🆕 Criar: traefik, postgres-mega, redis-ha  
│   ├── apps/                    # ✅ Manter
│   ├── monitoring/              # ✅ Manter
│   ├── ai/                      # ✅ Manter
│   └── [outras categorias]      # ✅ Manter organizadas
├── scripts/                     # 🧹 LIMPAR DRASTICAMENTE
│   ├── install-homolog.sh       # 🆕 Criar instalador homolog
│   ├── install-production.sh    # 🆕 Criar instalador produção
│   ├── deploy-stack.sh          # 🆕 Deploy individual stacks
│   ├── health-monitor.sh        # ✅ Manter
│   └── backup-basic.sh          # 🆕 Backup simplificado
├── configs/                     # 🆕 Configurações centralizadas
│   ├── homolog.env              # 🆕 Variáveis homolog
│   ├── production.env           # 🆕 Variáveis produção
│   └── networks.yml             # 🆕 Redes padronizadas
├── README.md                    # 📝 Documentação principal
├── CLAUDE.md                    # 📝 Instruções para Claude
└── VERSION                      # 📝 Controle de versão
```

---

## 🗑️ LISTA DETALHADA PARA REMOÇÃO

### **FASE 1: Remoção Imediata (Sem Impacto)**
```bash
# Scripts desnecessários (19 arquivos)
rm -f k3s-installer.sh
rm -f interactive-installer.sh  
rm -f macspark-ui.sh
rm -f create-expanded-stacks.sh
rm -f restore-stacks.sh
rm -f templates-installer.sh
rm -f ai-assistant.sh
rm -f apply-security-improvements.sh
rm -f modern-security-2025.sh
rm -f test-fhs.sh
rm -f update-services.sh
rm -f cleanup.sh

# Arquivos diversos (8 arquivos)
rm -f agents.txt
rm -f ASCII_ART.md
rm -f GOOGLE_DRIVE_SETUP.md
rm -f cloudflare-tunnel-config.yml
rm -f requirements-ai.txt
rm -f get-docker.sh
rm -f STRUCTURE-PROTECTION.md
rm -f audit-checklist.md

# Diretórios específicos
rm -rf web-installer/
rm -rf services/sparkone/
rm -rf templates/
```

### **FASE 2: Simplificação Scripts/ (20→4 arquivos)**
```bash
# Manter apenas essenciais
scripts/
├── health-monitor-ai.sh         # ✅ Monitoramento IA
├── backup-intelligent.sh        # ✅ Backup inteligente  
├── security-hardening.sh        # ✅ Hardening segurança
└── create-networks.sh           # ✅ Criação redes

# Remover outros 20 scripts específicos
```

### **FASE 3: Limpeza Configs Monitoring/**  
```bash
# Manter apenas configs essenciais
monitoring/
├── configs/
│   ├── prometheus.yml           # ✅ Config base
│   ├── loki.yml                 # ✅ Config base
│   └── alertmanager.yml         # ✅ Config base
└── [remover dashboards específicos]
```

---

## 💡 SCRIPTS NOVOS A CRIAR

### 🆕 **Para VPS Dual Architecture**
```bash
1. scripts/install-homolog.sh
   - Deploy específico para VPS homolog
   - Subdomínios *-homolog.macspark.dev
   - Recursos limitados
   
2. scripts/install-production.sh  
   - Deploy específico para VPS produção
   - Domínios oficiais
   - Recursos completos
   
3. scripts/sync-homolog-to-prod.sh
   - Sincronizar configurações testadas
   - Validações antes do deploy prod
   
4. scripts/deploy-stack.sh
   - Deploy individual de stacks
   - Validação automática
   - Rollback integrado

5. configs/networks-standard.yml
   - Redes padrão para ambos ambientes
   - Consistência entre homolog/prod
```

---

## 📈 RESULTADO DA LIMPEZA

### **ANTES vs DEPOIS**
| Aspecto | Antes | Depois | Redução |
|---------|-------|--------|---------|
| **Scripts Raiz** | 19 scripts | 4 scripts | 79% |
| **Scripts Pasta** | 25 scripts | 4 scripts | 84% |
| **Arquivos Diversos** | 15 arquivos | 5 arquivos | 67% |
| **Diretórios Extras** | 5 desnecessários | 0 | 100% |
| **Tamanho Repo** | ~150MB | ~80MB | 47% |

### **BENEFÍCIOS**
- ✅ **Estrutura focada** em VPS dual
- ✅ **Manutenção simplificada** 
- ✅ **Deploy específico** homolog/produção
- ✅ **Documentação organizada**
- ✅ **Scripts essenciais** apenas

---

## 🚀 PRÓXIMAS AÇÕES

1. ✅ **Documentação organizada** (pasta docs/planejamento/ criada)
2. 🔄 **Executar limpeza** scripts desnecessários
3. 🔄 **Criar scripts dual VPS** 
4. 🔄 **Testar estrutura limpa**
5. 🔄 **Validar funcionamento**

**Status:** 📋 ANÁLISE COMPLETA - PRONTA PARA LIMPEZA