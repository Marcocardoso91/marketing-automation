# 🎯 MATRIZ DE MIGRAÇÃO MACSPARK - DEZEMBRO 2025

## 🚨 STATUS CRÍTICO ATUAL

| Métrica | Valor Atual | Status | Ação Necessária |
|---------|------------|--------|-----------------|
| **SWAP** | 100% (2GB/2GB) | 🔴 CRÍTICO | IMEDIATA |
| **RAM** | 48% (7.3GB/15GB) | 🟡 ALERTA | URGENTE |
| **DISCO** | 69% (133GB/193GB) | 🟡 ALERTA | PRIORITÁRIA |
| **NODES** | 4 (3 managers) | ✅ OK | OTIMIZAR |
| **SERVIÇOS** | 88 ativos | 🟡 EXCESSIVO | CONSOLIDAR |
| **VOLUMES** | 159 total | 🔴 CRÍTICO | LIMPAR |

## 📊 MATRIZ DE SERVIÇOS E MIGRAÇÃO

### 🔴 PRIORIDADE 1 - CONSOLIDAÇÃO IMEDIATA (SEMANA 1)

| Serviço Atual | Recurso Usado | Serviço Destino | Economia Esperada | Downtime |
|---------------|---------------|-----------------|-------------------|----------|
| 5x PostgreSQL separados | ~4GB RAM | postgres-mega (único) | 3GB RAM | 30min |
| 6x Redis separados | ~1.5GB RAM | redis-ha-cluster | 1GB RAM | 15min |
| 3x Monitoring stacks | ~2GB RAM | LGTM unificado | 1.5GB RAM | 1h |
| 4x Node exporters | ~500MB RAM | 1x global exporter | 375MB RAM | 0min |
| Netdata (93% mem) | 478MB RAM | Reduzir limite | 250MB RAM | 0min |

**Total Economia Fase 1:** ~6.1GB RAM

### 🟡 PRIORIDADE 2 - OTIMIZAÇÃO (SEMANA 2)

| Stack | Serviços | Ação | Justificativa |
|-------|----------|------|---------------|
| evolution | 3 serviços | Manter | Core business |
| n8n | 2 serviços | Consolidar DB | Automação crítica |
| macspark-app | 2 stacks duplicadas | Unificar | Redundância desnecessária |
| ollama | 2 serviços (0/0) | Remover | Não utilizado |
| bookstack | 2 serviços | Avaliar uso | Documentação |
| heimdall | 1 serviço | Manter | Dashboard |

### ✅ PRIORIDADE 3 - MANUTENÇÃO (SEMANA 3)

| Stack | Status | Decisão |
|-------|--------|---------|
| traefik v3.5 | ✅ Atualizado | Manter configuração |
| vault/vaultwarden | 4 réplicas | Reduzir para 2 |
| portainer | Ativo | Manter para gestão |
| minio (2 instâncias) | Duplicado | Consolidar em 1 |
| registry | 0/0 réplicas | Remover |

## 🔄 MAPA DE DEPENDÊNCIAS

```mermaid
graph TD
    A[Traefik v3] --> B[Frontend Apps]
    A --> C[APIs]
    
    B --> D[postgres-mega]
    B --> E[redis-ha]
    
    C --> D
    C --> E
    
    F[n8n] --> D
    F --> G[Evolution API]
    
    H[Monitoring LGTM] --> I[Prometheus]
    I --> J[All Services]
    
    K[Backup System] --> D
    K --> L[MinIO]
    K --> M[Vault]
```

## 📅 CRONOGRAMA DE MIGRAÇÃO

### DIA 1-2: EMERGENCIAL
- [ ] Executar `01-emergency-swap-fix.sh`
- [ ] Liberar 70% volumes órfãos
- [ ] Reduzir swap para <50%

### SEMANA 1: CONSOLIDAÇÃO
- [ ] PostgreSQL: 5→1 instância
- [ ] Redis: 6→1 cluster
- [ ] Monitoring: 3→1 stack
- [ ] Validar aplicações

### SEMANA 2: STAGING
- [ ] Deploy nova VPS staging
- [ ] Replicar configuração otimizada
- [ ] Testes de carga
- [ ] Validação completa

### SEMANA 3: PRODUÇÃO
- [ ] Backup completo
- [ ] DNS staging
- [ ] Migração gradual (10%→50%→100%)
- [ ] Rollback preparado

### SEMANA 4: FINALIZAÇÃO
- [ ] VPS antiga → nova produção
- [ ] Formatação e setup limpo
- [ ] Documentação final
- [ ] Monitoramento 24/7

## 🎯 MÉTRICAS DE SUCESSO

| KPI | Atual | Meta | Validação |
|-----|-------|------|-----------|
| Uso RAM | 7.3GB | <4GB | `free -h` |
| Uso SWAP | 100% | 0% | `free -h` |
| Containers | 88 | <40 | `docker ps\|wc -l` |
| Volumes | 159 | <50 | `docker volume ls\|wc -l` |
| Response Time | - | <200ms | Grafana |
| Uptime | - | 99.9% | Monitoring |

## 🚀 COMANDOS RÁPIDOS

```bash
# STATUS GERAL
docker node ls && docker service ls | wc -l && free -h

# LIMPEZA EMERGENCIAL
docker system prune -a -f --volumes
docker volume prune -f

# CONSOLIDAÇÃO POSTGRES
bash /home/marcocardoso/02-consolidate-postgresql.sh

# MONITORAMENTO
docker stats --no-stream | sort -k4 -hr | head -20

# BACKUP ANTES DE MIGRAR
bash /home/marcocardoso/workspace/infrastructure/backup-system/scripts/backup-critical-complete.sh
```

## ⚠️ RISCOS E MITIGAÇÃO

| Risco | Probabilidade | Impacto | Mitigação |
|-------|--------------|---------|-----------|
| Perda de dados | Baixa | Alto | 3 backups + snapshots |
| Downtime prolongado | Média | Alto | Rollback automático |
| Incompatibilidade | Baixa | Médio | Testes em staging |
| Degradação performance | Média | Médio | Monitoring + alertas |

## 📝 CHECKLIST PRÉ-MIGRAÇÃO

- [ ] Backup completo validado
- [ ] Scripts testados em dev
- [ ] DNS secundário configurado
- [ ] Team notificado
- [ ] Janela de manutenção aprovada
- [ ] Rollback plan documentado
- [ ] Monitoring alerts configurados
- [ ] Load balancer health checks

---
**Última Atualização:** $(date)
**Responsável:** DevOps Team
**Status:** 🔴 AÇÃO IMEDIATA NECESSÁRIA