# 🚀 MEGA PLANEJAMENTO DE MIGRAÇÃO MACSPARK 2025
## Infraestrutura Enterprise com GitOps e Automação Total

---

## 📋 SUMÁRIO EXECUTIVO

Este documento apresenta o planejamento completo para transformação da infraestrutura MacSpark de um ambiente fragmentado para uma arquitetura enterprise-grade com GitOps, seguindo as melhores práticas corporativas de 2025.

**Status Atual:** 32 stacks Docker Swarm, 159 volumes, serviços duplicados
**Meta Final:** Infraestrutura GitOps com separação Homolog/Prod, CI/CD automatizado, zero-downtime deployments

---

## 🎯 OBJETIVOS E ESCOPO

### Objetivos Primários
1. ✅ Consolidar serviços duplicados (5 PostgreSQL → 1, 6 Redis → 1)
2. ✅ Implementar GitOps com repositório `setup-macspark`
3. ✅ Separação clara de ambientes (Homolog/Produção)
4. ✅ CI/CD automatizado via GitHub Actions
5. ✅ Zero-downtime deployments com rollback automático

### Escopo Técnico
- **Orquestração:** Docker Swarm (mantido por decisão técnica)
- **IaC:** Terraform (VPS) + Docker Compose (stacks)
- **Secrets:** Docker Secrets + HashiCorp Vault
- **Monitoring:** Stack LGTM completa
- **Backup:** Multi-cloud com DR automático

---

## 🏗️ ESTRUTURA DO REPOSITÓRIO GITOPS

```
setup-macspark/
├── .github/
│   └── workflows/
│       ├── infra-provision.yml      # Terraform apply automático
│       ├── deploy-homolog.yml       # Deploy em homolog
│       ├── deploy-production.yml    # Deploy em produção
│       ├── rollback.yml            # Rollback automático
│       └── security-scan.yml       # Trivy/Snyk scanning
├── infrastructure/
│   ├── terraform/
│   │   ├── modules/
│   │   │   ├── vps/
│   │   │   ├── networking/
│   │   │   └── security/
│   │   ├── environments/
│   │   │   ├── homolog/
│   │   │   └── production/
│   │   └── backend.tf              # S3/Terraform Cloud state
├── stacks/
│   ├── core/
│   │   ├── traefik.yml            # Proxy reverso
│   │   ├── postgres-mega.yml      # DB centralizado
│   │   ├── redis-ha.yml           # Cache HA
│   │   └── n8n.yml                # Automação
│   ├── apps/
│   │   ├── macspark-app.yml
│   │   └── evolution-api.yml
│   ├── ai/
│   │   ├── qwen-enterprise.yml
│   │   ├── agente-ultimate.yml
│   │   └── ollama.yml
│   ├── observability/
│   │   └── lgtm-stack.yml         # Grafana+Loki+Tempo+Mimir
│   └── backup/
│       ├── minio.yml
│       ├── restic.yml
│       └── vault-agent.yml
├── scripts/
│   ├── install/
│   │   └── bootstrap.sh           # Inicialização completa
│   ├── migration/
│   │   ├── migrate-postgres.sh
│   │   └── migrate-redis.sh
│   ├── operations/
│   │   ├── backup.sh
│   │   ├── restore.sh
│   │   └── health-check.sh
│   └── emergency/
│       └── disaster-recovery.sh
├── configs/
│   ├── traefik/
│   ├── prometheus/
│   └── vault/
└── docs/
    ├── ARCHITECTURE.md
    ├── RUNBOOK.md
    └── DISASTER_RECOVERY.md
```

---

## 📅 ROADMAP DETALHADO - 10 FASES

### Timeline Total: 8-10 Semanas

| Fase | Nome | Duração | Início | Fim | Status |
|------|------|---------|--------|-----|--------|
| **0** | 🎯 **Planejamento e Preparação** | 5 dias | Sem 1 | Sem 1 | ⏳ |
| **1** | 🏗️ **Provisionamento Nova VPS PROD** | 3 dias | Sem 2 | Sem 2 | ⏳ |
| **2** | 🔧 **Setup Ferramentas Core** | 4 dias | Sem 2 | Sem 3 | ⏳ |
| **3** | 💾 **Migração de Dados** | 7 dias | Sem 3 | Sem 4 | ⏳ |
| **4** | 🚀 **Deploy Stacks Core** | 5 dias | Sem 4 | Sem 5 | ⏳ |
| **5** | 📱 **Deploy Aplicações** | 7 dias | Sem 5 | Sem 6 | ⏳ |
| **6** | 🤖 **Deploy Stack AI** | 4 dias | Sem 6 | Sem 7 | ⏳ |
| **7** | ✅ **Testes e Validação** | 10 dias | Sem 7 | Sem 8 | ⏳ |
| **8** | 🔄 **Cutover Final** | 1 dia | Sem 9 | Sem 9 | ⏳ |
| **9** | 🏭 **Setup Nova Homolog** | 7 dias | Sem 9 | Sem 10 | ⏳ |
| **10** | 📊 **Otimização e Documentação** | 7 dias | Sem 10 | Sem 10 | ⏳ |

---

## 🔄 PLANO DE ROLLBACK POR FASE

### Fase 0-2: Rollback Simples
**Trigger:** Falha no provisionamento ou configuração inicial
**Procedimento:**
1. Destruir recursos via `terraform destroy`
2. Reverter commits no GitHub
3. Restaurar configurações originais
**Tempo:** 30 minutos
**Impacto:** Zero (ainda não em produção)

### Fase 3-4: Rollback de Dados
**Trigger:** Corrupção ou falha na migração de dados
**Procedimento:**
1. Parar replicação de dados
2. Restaurar backups do ponto anterior
3. Revalidar integridade
**Tempo:** 2-4 horas
**Impacto:** Atraso no cronograma

### Fase 5-7: Rollback de Aplicações
**Trigger:** Falha nos testes ou problemas críticos
**Procedimento:**
```bash
#!/bin/bash
# Rollback automático via GitHub Actions
docker stack rm $FAILED_STACK
docker stack deploy -c stacks/${STACK}/previous-version.yml $STACK
# Verificar health checks
./scripts/health-check.sh $STACK
```
**Tempo:** 15 minutos por stack
**Impacto:** Serviço indisponível temporariamente

### Fase 8: Rollback de Cutover (CRÍTICO)
**Trigger:** Falha grave após migração de DNS
**Procedimento:**
1. **IMEDIATO:** Reverter DNS para VPS antiga
2. Parar tráfego na nova VPS
3. Validar serviços na VPS antiga
4. Notificar stakeholders
**Tempo:** 5-10 minutos
**Impacto:** Downtime de 5-10 minutos

---

## 📊 MÉTRICAS DE SUCESSO (KPIs)

### Disponibilidade
- **Uptime Target:** 99.95% (22 minutos downtime/mês)
- **MTTR (Mean Time To Recovery):** < 15 minutos
- **MTBF (Mean Time Between Failures):** > 30 dias
- **Deployment Success Rate:** > 95%

### Performance
- **API Response Time:** P95 < 200ms
- **Database Query Time:** P95 < 50ms
- **Page Load Time:** < 2 segundos
- **Container Startup Time:** < 30 segundos

### Segurança
- **Vulnerabilidades Críticas:** 0 tolerância
- **Patch Time:** < 24h para críticas
- **Secrets Rotation:** A cada 90 dias
- **Compliance Score:** 100% (CIS benchmarks)

### Automação
- **Deploy Frequency:** > 10/semana
- **Manual Interventions:** < 5%
- **Infrastructure as Code Coverage:** 100%
- **Test Coverage:** > 80%

### Custos
- **Redução de Custos:** -30% vs atual
- **Resource Utilization:** > 70%
- **Idle Resources:** < 10%

---

## 💰 ESTIMATIVA DE CUSTOS DETALHADA

| Item | Descrição | Custo Mensal | Custo Anual |
|------|-----------|--------------|-------------|
| **INFRAESTRUTURA** |
| VPS Produção | 8 vCPU, 32GB RAM, 500GB SSD | $320 | $3,840 |
| VPS Homolog | 4 vCPU, 16GB RAM, 250GB SSD | $160 | $1,920 |
| Backup Storage | S3-compatible, 1TB | $50 | $600 |
| CDN/DDoS | Cloudflare Pro | $20 | $240 |
| **FERRAMENTAS** |
| HashiCorp Vault | HCP Vault (Managed) | $58 | $696 |
| GitHub Actions | 3000 min/mês | $45 | $540 |
| Monitoring (Datadog/NR) | APM + Logs | $99 | $1,188 |
| **MIGRAÇÃO (ONE-TIME)** |
| DevOps Engineer | 160h @ $150/h | $24,000 | - |
| Contingência (20%) | Buffer para imprevistos | $4,800 | - |
| **TOTAIS** |
| **Mensal Recorrente** | | **$752** | **$9,024** |
| **Custo Migração** | | **$28,800** | - |
| **ROI Esperado** | Economia após consolidação | -40% | **-$3,600** |

---

## ⚠️ ANÁLISE DE RISCOS E MITIGAÇÕES

| Risco | Probabilidade | Impacto | Mitigação | Plano B |
|-------|---------------|---------|-----------|---------|
| **Perda de dados durante migração** | Baixa (20%) | Crítico | Backups incrementais a cada hora, replicação síncrona | Restore point-in-time do backup |
| **Downtime não planejado** | Média (40%) | Alto | Blue-green deployment, health checks automáticos | Rollback automático em 5 min |
| **Falha de segurança/breach** | Baixa (15%) | Crítico | Vault para secrets, network policies, WAF | Incident response plan, forensics |
| **Estouro de orçamento** | Média (35%) | Médio | Monitoramento de custos diário, alertas | Reduzir specs de homolog |
| **Resistência da equipe** | Alta (60%) | Médio | Treinamento, documentação, pair programming | Contratar consultoria |
| **Vendor lock-in** | Baixa (25%) | Baixo | Usar padrões abertos, containers | Manter compatibilidade |
| **Performance degradada** | Média (30%) | Alto | Load testing, APM, auto-scaling | Scaling vertical emergencial |
| **Falha no CI/CD** | Baixa (20%) | Médio | Múltiplos runners, cache | Deploy manual como fallback |

---

## 🏗️ DIAGRAMA DE ARQUITETURA FINAL (ASCII)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                            MACSPARK INFRASTRUCTURE 2025                      │
└─────────────────────────────────────────────────────────────────────────────┘

                                   ┌──────────────┐
                                   │   Internet   │
                                   └──────┬───────┘
                                          │
                                   ┌──────▼───────┐
                                   │  Cloudflare  │
                                   │   (WAF/CDN)  │
                                   └──────┬───────┘
                                          │
                ┌─────────────────────────┴──────────────────────────┐
                │                                                     │
       ┌────────▼────────┐                           ┌───────────────▼──────┐
       │  VPS PRODUÇÃO   │                           │   VPS HOMOLOGAÇÃO    │
       │  185.199.x.x    │                           │    185.199.y.y       │
       └─────────────────┘                           └──────────────────────┘
                │                                              │
    ┌───────────┴───────────┐                     ┌───────────┴───────────┐
    │   Docker Swarm Mgr    │                     │   Docker Swarm Mgr    │
    └───────────┬───────────┘                     └───────────┬───────────┘
                │                                              │
    ┌───────────▼────────────────────────┐       ┌────────────▼───────────┐
    │         CORE SERVICES              │       │     CORE SERVICES      │
    ├─────────────────────────────────────┤       ├────────────────────────┤
    │ ► Traefik (Proxy/LB)               │       │ ► Traefik              │
    │ ► PostgreSQL Mega (Patroni HA)     │◄──────┤ ► PostgreSQL (Replica) │
    │ ► Redis HA Cluster (3 nodes)       │       │ ► Redis Cluster        │
    │ ► n8n (Automation)                 │       │ ► n8n                  │
    └─────────────────────────────────────┘       └────────────────────────┘
                │                                              │
    ┌───────────▼────────────────────────┐       ┌────────────▼───────────┐
    │       APPLICATION LAYER            │       │   APPLICATION LAYER    │
    ├─────────────────────────────────────┤       ├────────────────────────┤
    │ ► MacSpark App (3 replicas)        │       │ ► MacSpark App (1 rep) │
    │ ► Evolution API                    │       │ ► Evolution API        │
    │ ► Qwen Enterprise AI               │       │ ► Qwen AI (limited)    │
    │ ► Agente Ultimate                  │       │ ► Agente Ultimate      │
    └─────────────────────────────────────┘       └────────────────────────┘
                │                                              │
    ┌───────────▼────────────────────────┐       ┌────────────▼───────────┐
    │      OBSERVABILITY STACK           │       │  OBSERVABILITY STACK   │
    ├─────────────────────────────────────┤       ├────────────────────────┤
    │ ► Prometheus (Metrics)             │       │ ► Prometheus           │
    │ ► Loki (Logs)                      │       │ ► Loki                 │
    │ ► Tempo (Traces)                   │       │ ► Grafana              │
    │ ► Mimir (Long-term)                │       └────────────────────────┘
    │ ► Grafana (Dashboards)             │
    └─────────────────────────────────────┘
                │                                              │
    ┌───────────▼────────────────────────┐                    │
    │        BACKUP & DR                 │                    │
    ├─────────────────────────────────────┤                    │
    │ ► MinIO (Object Storage)           │◄───────────────────┘
    │ ► Restic (Incremental Backup)      │
    │ ► Vault (Secrets Management)       │
    │ ► Rclone (Multi-cloud Sync)        │
    └─────────────┬───────────────────────┘
                  │
         ┌────────▼────────┐
         │  Cloud Storage  │
         │   (S3/GCS/B2)   │
         └─────────────────┘

═══════════════════════════════════════════════════════════════════════════════

                            CI/CD PIPELINE (GitHub Actions)
                            
    ┌──────────┐     ┌──────────┐     ┌──────────┐     ┌──────────┐
    │   Code   │────▶│  Build   │────▶│   Test   │────▶│  Deploy  │
    │  Commit  │     │  Docker  │     │  Suite   │     │  Swarm   │
    └──────────┘     └──────────┘     └──────────┘     └──────────┘
         │                │                 │                │
         ▼                ▼                 ▼                ▼
    [GitHub]      [Registry]      [Sonarqube]      [Homolog→Prod]
```

---

## 🔐 CONFIGURAÇÕES DE SEGURANÇA AVANÇADAS

### Network Policies
```yaml
# Docker Swarm Network Isolation
networks:
  frontend:
    driver: overlay
    encrypted: true
    internal: false
  backend:
    driver: overlay
    encrypted: true
    internal: true
  data:
    driver: overlay
    encrypted: true
    internal: true
```

### Firewall Rules (iptables)
```bash
#!/bin/bash
# Regras de firewall para VPS

# Limpar regras existentes
iptables -F
iptables -X

# Políticas padrão
iptables -P INPUT DROP
iptables -P FORWARD DROP
iptables -P OUTPUT ACCEPT

# Loopback
iptables -A INPUT -i lo -j ACCEPT

# Conexões estabelecidas
iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT

# SSH (restrito por IP)
iptables -A INPUT -p tcp --dport 22 -s 10.0.0.0/8 -j ACCEPT

# HTTP/HTTPS (via Cloudflare apenas)
for ip in $(curl https://www.cloudflare.com/ips-v4); do
  iptables -A INPUT -p tcp -m multiport --dports 80,443 -s $ip -j ACCEPT
done

# Docker Swarm
iptables -A INPUT -p tcp --dport 2377 -j ACCEPT  # Cluster management
iptables -A INPUT -p tcp --dport 7946 -j ACCEPT  # Communication
iptables -A INPUT -p udp --dport 7946 -j ACCEPT  # Communication
iptables -A INPUT -p udp --dport 4789 -j ACCEPT  # Overlay network

# Monitoring (interno apenas)
iptables -A INPUT -p tcp --dport 9090 -s 10.0.0.0/8 -j ACCEPT  # Prometheus
iptables -A INPUT -p tcp --dport 3000 -s 10.0.0.0/8 -j ACCEPT  # Grafana

# Salvar regras
iptables-save > /etc/iptables/rules.v4
```

### TLS/SSL Configuration
```yaml
# Traefik TLS Configuration
tls:
  options:
    default:
      minVersion: VersionTLS12
      cipherSuites:
        - TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256
        - TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384
        - TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305
      sniStrict: true
  certificates:
    - certFile: /certs/cert.pem
      keyFile: /certs/key.pem
      stores:
        - default
```

### Vault Policies
```hcl
# Política para aplicações
path "secret/data/macspark/*" {
  capabilities = ["read", "list"]
}

path "secret/metadata/macspark/*" {
  capabilities = ["list"]
}

# Política para CI/CD
path "secret/data/ci/*" {
  capabilities = ["create", "read", "update", "delete", "list"]
}

# Política para backup
path "secret/data/backup/*" {
  capabilities = ["read"]
}
```

### GitHub Branch Protection
```json
{
  "protection_rules": {
    "main": {
      "required_reviews": 2,
      "dismiss_stale_reviews": true,
      "require_code_owner_reviews": true,
      "required_status_checks": [
        "continuous-integration/github-actions",
        "security/snyk",
        "sonarcloud"
      ],
      "enforce_admins": false,
      "restrictions": {
        "teams": ["devops", "senior-developers"]
      }
    }
  }
}
```

---

## 📋 PROCEDIMENTOS OPERACIONAIS PADRÃO (SOPs)

### SOP-001: Deploy de Nova Aplicação
```bash
#!/bin/bash
# 1. Criar branch feature
git checkout -b feature/new-app

# 2. Adicionar stack YAML
cat > stacks/apps/new-app.yml << EOF
version: '3.8'
services:
  new-app:
    image: registry/new-app:latest
    deploy:
      replicas: 2
      update_config:
        parallelism: 1
        delay: 10s
      restart_policy:
        condition: any
EOF

# 3. Adicionar secrets no Vault
vault kv put secret/macspark/new-app \
  db_password="secure_password" \
  api_key="secure_key"

# 4. Commit e push
git add stacks/apps/new-app.yml
git commit -m "feat: add new-app stack"
git push origin feature/new-app

# 5. Create PR e aguardar aprovação
gh pr create --title "Deploy new-app" --body "Deploy da nova aplicação"

# 6. Após merge, CI/CD fará deploy automático
```

### SOP-002: Atualização de Aplicação
```bash
#!/bin/bash
APP_NAME=$1
NEW_VERSION=$2

# 1. Update image tag
sed -i "s|image: .*${APP_NAME}:.*|image: registry/${APP_NAME}:${NEW_VERSION}|" \
  stacks/apps/${APP_NAME}.yml

# 2. Commit com conventional commits
git add stacks/apps/${APP_NAME}.yml
git commit -m "chore: update ${APP_NAME} to ${NEW_VERSION}"

# 3. Push para trigger CI/CD
git push origin main

# 4. Monitor deployment
watch docker service ps ${APP_NAME}
```

### SOP-003: Backup Manual de Emergência
```bash
#!/bin/bash
# Backup completo emergencial

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backup/emergency_${TIMESTAMP}"

echo "Iniciando backup emergencial..."

# 1. Backup PostgreSQL
docker exec postgres-mega pg_dumpall -U postgres | \
  gzip > ${BACKUP_DIR}/postgres_all.sql.gz

# 2. Backup Redis
docker exec redis-master redis-cli BGSAVE
docker cp redis-master:/data/dump.rdb ${BACKUP_DIR}/redis.rdb

# 3. Backup volumes críticos
for volume in $(docker volume ls -q | grep -E "app|data"); do
  docker run --rm -v ${volume}:/source:ro \
    -v ${BACKUP_DIR}:/backup \
    alpine tar czf /backup/${volume}.tar.gz -C /source .
done

# 4. Sync para cloud
rclone sync ${BACKUP_DIR} remote:emergency-backups/

echo "Backup emergencial completo: ${BACKUP_DIR}"
```

### SOP-004: Disaster Recovery
```bash
#!/bin/bash
# Procedimento de Disaster Recovery

echo "=== INICIANDO DISASTER RECOVERY ==="

# 1. Verificar último backup válido
LATEST_BACKUP=$(rclone ls remote:backups/ | tail -1 | awk '{print $2}')

# 2. Baixar backup
rclone copy remote:backups/${LATEST_BACKUP} /tmp/restore/

# 3. Parar todos os serviços
docker stack ls --format "{{.Name}}" | xargs -I {} docker stack rm {}

# 4. Restore PostgreSQL
gunzip < /tmp/restore/postgres_all.sql.gz | \
  docker exec -i postgres-mega psql -U postgres

# 5. Restore Redis
docker cp /tmp/restore/redis.rdb redis-master:/data/dump.rdb
docker restart redis-master

# 6. Restore volumes
for archive in /tmp/restore/*.tar.gz; do
  volume=$(basename ${archive} .tar.gz)
  docker volume create ${volume}
  docker run --rm -v ${volume}:/restore \
    -v /tmp/restore:/backup \
    alpine tar xzf /backup/$(basename ${archive}) -C /restore
done

# 7. Redeploy all stacks
for stack in stacks/*/*.yml; do
  name=$(basename $(dirname ${stack}))
  docker stack deploy -c ${stack} ${name}
done

# 8. Verificar saúde
./scripts/health-check-all.sh

echo "=== DISASTER RECOVERY COMPLETO ==="
```

---

## 📅 CRONOGRAMA VISUAL (GANTT ASCII)

```
FASES                   Sem1 Sem2 Sem3 Sem4 Sem5 Sem6 Sem7 Sem8 Sem9 Sem10
═══════════════════════════════════════════════════════════════════════════
0. Planejamento         ████
1. Provision VPS PROD        ███
2. Setup Ferramentas         ████
3. Migração Dados                 ███████
4. Deploy Core                         █████
5. Deploy Apps                              ███████
6. Deploy AI                                      ████
7. Testes/Validação                                   ██████████
8. Cutover Final                                               █
9. Setup Homolog                                               ███████
10. Otimização                                                      ███████

Legenda: █ = Período de execução da fase
```

---

## ✅ CHECKLIST FINAL PRÉ-MIGRAÇÃO

### Semana -1 (Preparação)
- [ ] Backup completo da VPS atual
- [ ] Credenciais do Vault criadas
- [ ] Repositório setup-macspark criado
- [ ] GitHub Actions configurado
- [ ] Terraform state backend configurado
- [ ] Equipe treinada no novo processo
- [ ] Comunicação com stakeholders enviada
- [ ] Janela de manutenção aprovada

### Dia D (Cutover)
- [ ] Backup final realizado
- [ ] Health checks passando em nova PROD
- [ ] Monitoramento ativo
- [ ] Equipe em standby
- [ ] Plano de rollback testado
- [ ] DNS TTL reduzido para 60s
- [ ] Comunicação status page atualizada

---

## 🎯 CONCLUSÃO

Este MEGA PLANEJAMENTO representa a transformação completa da infraestrutura MacSpark para padrões enterprise 2025. Com GitOps, automação total e observabilidade completa, a nova arquitetura proporcionará:

- **99.95% de disponibilidade**
- **Deploys 10x mais rápidos**
- **40% de redução de custos**
- **100% Infrastructure as Code**
- **Zero-downtime deployments**

O sucesso depende da execução disciplinada do plano, com checkpoints claros e rollback sempre disponível.

---

**Documento criado por:** DevOps Team MacSpark  
**Data:** $(date +%Y-%m-%d)  
**Versão:** 1.0.0  
**Status:** APROVADO PARA EXECUÇÃO

---

## 📚 ANEXOS

- Anexo A: Scripts completos de automação
- Anexo B: Configurações Terraform detalhadas
- Anexo C: Docker Compose YAMLs completos
- Anexo D: Runbooks de troubleshooting
- Anexo E: Plano de comunicação com stakeholders