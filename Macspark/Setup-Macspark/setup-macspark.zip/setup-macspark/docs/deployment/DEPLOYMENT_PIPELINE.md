# 🚀 Pipeline de Deploy Enterprise - Macspark

## Visão Geral

O Macspark Setup agora inclui um **pipeline completo de deploy DevOps** que automatiza todo o processo desde a preparação da VPS até a validação pós-deploy, seguindo as melhores práticas da indústria.

## 🎯 Arquitetura do Pipeline

### Pipeline Tradicional (Anterior)
```
Manual VPS Setup → Manual Git Clone → Manual Install → Manual Validation
     ❌ Propenso a erros    ❌ Inconsistente    ❌ Não escalável
```

### Pipeline Enterprise (Atual)
```
prepare-vps.sh → install.sh → validation.sh → deploy.sh → post-validation.sh
    ✅ Automatizado    ✅ Consistente    ✅ Escalável    ✅ Auditável
```

## 🔧 Componentes do Pipeline

### 1. **Preparação da VPS** (`scripts/setup/prepare-vps.sh`)
- ✅ Verificação de requisitos de sistema (CPU, RAM, Disk)
- ✅ Atualização completa do sistema operacional
- ✅ Instalação do Docker + Docker Swarm
- ✅ Configuração de firewall com portas necessárias
- ✅ Instalação de dependências (yq, jq, docker-compose)
- ✅ Otimizações de sistema para containers
- ✅ Inicialização automática do Docker Swarm
- ✅ Validação completa da preparação

### 2. **Pipeline Completo** (`scripts/deployment/deploy-complete-pipeline.sh`)
- ✅ Orquestração de todas as fases do deploy
- ✅ Suporte a múltiplos ambientes (homolog/production)
- ✅ Validação pré e pós-deploy
- ✅ Relatório detalhado de status
- ✅ Rollback em caso de falhas
- ✅ Logs estruturados para auditoria

### 3. **Quick Start** (`quick-start.sh`)
- ✅ Deploy completo em um único comando
- ✅ Interface simplificada para usuários
- ✅ Proteções de segurança para produção
- ✅ Validação de ambiente automática

## 📋 Modos de Uso

### 🚀 Modo Quick Start (Recomendado para iniciantes)
```bash
# Deploy homologação (padrão)
./quick-start.sh

# Deploy homologação explícito
./quick-start.sh homolog

# Deploy produção
./quick-start.sh production
```

### 🔧 Modo Pipeline Completo (Controle avançado)
```bash
# Deploy homolog interativo
./scripts/deployment/deploy-complete-pipeline.sh -e homolog

# Deploy produção automático (CI/CD)
./scripts/deployment/deploy-complete-pipeline.sh -e production -y

# Pular preparação (VPS já preparada)
./scripts/deployment/deploy-complete-pipeline.sh --skip-prep -e homolog
```

### ⚙️ Modo Manual (Controle total)
```bash
# 1. Preparar VPS
./scripts/setup/prepare-vps.sh

# 2. Validação pré-deploy
./scripts/validation/preflight.sh

# 3. Instalação
./scripts/setup/install.sh

# 4. Validação pós-deploy
./scripts/validation/preflight.sh
```

## 🔍 Fases do Pipeline

### Fase 1: Preparação da VPS
- **Objetivo**: Transformar VPS limpa em ambiente pronto para Macspark
- **Duração**: 2-5 minutos
- **Saídas**: Docker Swarm ativo, dependências instaladas, sistema otimizado

### Fase 2: Validação Pré-Deploy
- **Objetivo**: Garantir que ambiente está adequado
- **Duração**: 30-60 segundos
- **Saídas**: Relatório de compatibilidade, lista de problemas (se houver)

### Fase 3: Instalação/Deploy
- **Objetivo**: Instalar stacks Docker do Macspark
- **Duração**: 3-10 minutos (depende do ambiente)
- **Saídas**: Serviços deployados, networks criadas, secrets configurados

### Fase 4: Validação Pós-Deploy
- **Objetivo**: Confirmar que deploy foi bem-sucedido
- **Duração**: 1-2 minutos
- **Saídas**: Relatório de saúde dos serviços, métricas de performance

### Fase 5: Relatório Final
- **Objetivo**: Fornecer informações para próximos passos
- **Duração**: 5 segundos
- **Saídas**: URLs de acesso, comandos úteis, documentação

## 🛡️ Recursos de Segurança

### Proteções de Produção
- ✅ Confirmação dupla para deploy em produção
- ✅ Validação obrigatória de credenciais
- ✅ Backup automático antes de mudanças
- ✅ Rollback automático em falhas críticas

### Auditoria
- ✅ Logs estruturados com timestamps
- ✅ Rastreabilidade completa de ações
- ✅ Métricas de performance por fase
- ✅ Relatórios de conformidade

## 📊 Monitoramento e Observabilidade

### Métricas Coletadas
- **Tempo de execução** por fase
- **Taxa de sucesso** por ambiente
- **Recursos utilizados** (CPU, RAM, Disk)
- **Número de serviços** deployados
- **Score de validação** pré e pós-deploy

### Logging
```bash
# Logs do pipeline
tail -f /var/log/macspark-deploy.log

# Logs de serviços específicos
docker service logs -f <service-name>

# Logs de sistema
journalctl -f -u docker
```

## 🚨 Troubleshooting

### Problemas Comuns

#### 1. **Falha na Preparação da VPS**
```bash
# Diagnóstico
./scripts/validation/preflight.sh

# Soluções
sudo systemctl status docker    # Verificar Docker
docker swarm init              # Reinicializar Swarm
```

#### 2. **Falha na Validação**
```bash
# Verificar recursos
free -h                        # RAM
df -h                         # Disk
docker system df              # Docker storage
```

#### 3. **Falha no Deploy**
```bash
# Verificar stacks
docker stack ls
docker service ls

# Logs detalhados
docker service logs --tail 100 <service>
```

### Comandos de Recuperação
```bash
# Reset completo do Swarm
docker swarm leave --force
./scripts/setup/prepare-vps.sh

# Limpeza completa de containers
docker system prune -a --volumes

# Reinstalação do pipeline
git pull origin main
./quick-start.sh homolog
```

## 🎯 Melhores Práticas

### Para Ambientes de Homologação
- ✅ Use `quick-start.sh homolog` para rapidez
- ✅ Teste mudanças antes de produção
- ✅ Monitore recursos durante deploy
- ✅ Documente problemas encontrados

### Para Ambientes de Produção
- ✅ **SEMPRE** testar em homolog primeiro
- ✅ Executar backup completo antes
- ✅ Usar modo interativo com validações
- ✅ Monitorar métricas pós-deploy
- ✅ Ter plano de rollback pronto

### Para CI/CD
```yaml
# Exemplo GitHub Actions
- name: Deploy Macspark
  run: |
    ./scripts/deployment/deploy-complete-pipeline.sh \
      --environment production \
      --yes \
      --skip-prep
```

## 📚 Próximos Passos

Após o deploy bem-sucedido:

1. **Configurar Monitoramento**
   - Acessar dashboards (Grafana, Netdata)
   - Configurar alertas críticos
   - Estabelecer baselines de performance

2. **Configurar Backup**
   - Executar `./scripts/backup/backup.sh`
   - Configurar rotinas automáticas
   - Testar processo de restore

3. **Configurar SSL/DNS**
   - Configurar domínios no Cloudflare
   - Validar certificados SSL
   - Testar acessos externos

4. **Documentar Ambiente**
   - Catalogar URLs de acesso
   - Documentar credenciais
   - Criar runbooks operacionais

---

**🎉 Com este pipeline, você tem uma solução enterprise completa que segue as melhores práticas DevOps, reduzindo tempo de deploy de horas para minutos e eliminando erros manuais!**