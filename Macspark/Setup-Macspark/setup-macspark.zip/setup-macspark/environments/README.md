# 🌍 Environments Configuration

Configurações específicas por ambiente seguindo padrões GitOps enterprise.

## 📁 Estrutura

```
environments/
├── shared/           # Configurações compartilhadas entre ambientes
├── local/            # Desenvolvimento local
├── staging/          # Ambiente de staging
├── homolog/          # Homologação (pré-produção)
└── production/       # Produção
```

## 🔧 Componentes por Ambiente

Cada ambiente contém:
- `configs/` - Configurações específicas do ambiente
- `scripts/` - Scripts de deploy e manutenção
- `secrets/` - Secrets e credenciais (não versionados)
- `stacks/` - Overrides de stacks Docker

## 🚀 Uso

### Desenvolvimento Local
```bash
export ENVIRONMENT=local
source environments/local/.env
docker-compose -f docker-compose.yml -f environments/local/docker-compose.override.yml up
```

### Homologação
```bash
export ENVIRONMENT=homolog
./environments/homolog/scripts/deploy.sh
```

### Produção
```bash
export ENVIRONMENT=production
./environments/production/scripts/deploy.sh
```

## 🔐 Gestão de Secrets

Secrets **NÃO** devem ser versionados. Use:
- Docker Secrets
- HashiCorp Vault
- Variáveis de ambiente do CI/CD

## 📋 Variáveis por Ambiente

| Variável | Local | Staging | Homolog | Production |
|----------|-------|---------|---------|------------|
| DOMAIN | localhost | staging.macspark.dev | homolog.macspark.dev | macspark.dev |
| SSL | false | true | true | true |
| DEBUG | true | true | false | false |
| REPLICAS | 1 | 1 | 2 | 3 |

## 🔄 Promoção entre Ambientes

```
local → staging → homolog → production
```

Cada promoção requer:
1. Testes automatizados passando
2. Aprovação manual
3. Backup do ambiente de destino
4. Deploy com rollback automático