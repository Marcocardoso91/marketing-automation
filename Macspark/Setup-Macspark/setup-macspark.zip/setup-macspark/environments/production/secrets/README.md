# 🔐 Production Secrets

**ATENÇÃO**: Este diretório contém secrets de produção. **NUNCA** commitar arquivos sensíveis!

## Gestão de Secrets

### Docker Secrets (Recomendado)
```bash
# Criar secret
echo "senha-super-secreta" | docker secret create postgres_password -

# Usar no stack
services:
  postgres:
    secrets:
      - postgres_password
    environment:
      POSTGRES_PASSWORD_FILE: /run/secrets/postgres_password
```

### HashiCorp Vault (Enterprise)
```bash
# Armazenar secret
vault kv put secret/macspark/prod/db password="senha-secreta"

# Recuperar secret
vault kv get secret/macspark/prod/db
```

### Variáveis de CI/CD
Configure no GitHub Actions:
- Settings → Secrets → Actions
- Adicionar secrets como: `PROD_DB_PASSWORD`

## Secrets Necessários

- `postgres_password` - Senha do PostgreSQL
- `redis_password` - Senha do Redis
- `jwt_secret` - Secret para tokens JWT
- `encryption_key` - Chave de criptografia
- `vault_token` - Token do Vault
- `slack_webhook` - Webhook do Slack
- `aws_access_key` - AWS para backups
- `aws_secret_key` - AWS secret
- `cloudflare_api_token` - Token da Cloudflare
- `ssl_cert` - Certificado SSL
- `ssl_key` - Chave privada SSL

## Rotação de Secrets

Secrets devem ser rotacionados:
- Passwords: A cada 90 dias
- API Keys: A cada 180 dias
- Certificates: Antes de expirar

## Auditoria

Todos os acessos a secrets são logados em:
- `/var/log/macspark/secrets-access.log`