# Monitoring Stack - Macspark Enterprise

## 📊 Visão Geral

Stack completo de observabilidade enterprise com Prometheus, Grafana, Loki e ferramentas de suporte.

## 🏗️ Arquitetura

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Aplicações │────▶│  Prometheus │────▶│   Grafana   │
└─────────────┘     └─────────────┘     └─────────────┘
                           │                     │
┌─────────────┐     ┌─────────────┐            │
│   Exporters │────▶│    Loki     │────────────┘
└─────────────┘     └─────────────┘
                           │
┌─────────────┐     ┌─────────────┐
│   Services  │────▶│  Promtail   │
└─────────────┘     └─────────────┘
```

## 📁 Estrutura

```
monitoring/
├── alerts/                 # Regras de alertas
│   ├── critical/          # Alertas críticos
│   ├── warning/           # Alertas de warning
│   └── info/              # Alertas informativos
├── dashboards/            # Dashboards Grafana
│   ├── infrastructure/    # Infra (CPU, RAM, Disk, Network)
│   ├── applications/      # Apps (Response time, errors)
│   ├── business/          # KPIs de negócio
│   └── security/          # Segurança
├── rules/                 # Recording rules Prometheus
│   ├── aggregations/      # Agregações
│   ├── slo/              # Service Level Objectives
│   └── sli/              # Service Level Indicators
├── configs/              # Configurações
│   ├── prometheus/       # Prometheus configs
│   ├── grafana/          # Grafana configs
│   ├── loki/             # Loki configs
│   └── promtail/         # Promtail configs
└── exporters/            # Configurações de exporters
    ├── node-exporter/    # Métricas de host
    ├── cadvisor/         # Métricas de container
    ├── postgres/         # Métricas PostgreSQL
    └── redis/            # Métricas Redis
```

## 🚀 Deploy

### Desenvolvimento
```bash
docker-compose -f stacks/core/monitoring/prometheus-grafana.yml up -d
```

### Produção
```bash
docker stack deploy -c stacks/core/monitoring/prometheus-grafana.yml monitoring
```

## 📊 Dashboards Incluídos

### Infrastructure
- **System Overview**: CPU, RAM, Disk, Network
- **Docker Swarm**: Nodes, services, containers
- **Network Traffic**: Bandwidth, connections
- **Storage**: Disk usage, I/O

### Applications
- **Application Performance**: Response time, throughput
- **Error Tracking**: Error rates, types
- **Database Performance**: Queries, connections
- **Cache Performance**: Hit rate, latency

### Business
- **KPI Dashboard**: Business metrics
- **User Analytics**: User behavior
- **Revenue Tracking**: Financial metrics
- **SLA Compliance**: Uptime, performance

### Security
- **Security Events**: Login attempts, failures
- **Vulnerability Scanning**: CVE tracking
- **Access Control**: Permission changes
- **Compliance**: Audit logs

## 🔔 Alertas Configurados

### Críticos (Pager Duty)
- Sistema down
- Database inacessível
- Disk > 90%
- Memory > 95%
- Error rate > 5%

### Warning (Email/Slack)
- CPU > 80%
- Memory > 80%
- Disk > 70%
- Response time > 1s
- Error rate > 1%

### Info (Dashboard)
- Deploys
- Config changes
- Backup success
- Maintenance windows

## 📈 Métricas Coletadas

### Sistema
- CPU: usage, load, cores
- Memory: used, free, cached
- Disk: usage, I/O, latency
- Network: bandwidth, packets, errors

### Aplicação
- HTTP: requests, latency, errors
- Database: queries, connections, locks
- Cache: hits, misses, evictions
- Queue: size, processing time

### Negócio
- Users: active, new, retention
- Transactions: volume, value
- Performance: SLA, SLO, SLI
- Revenue: MRR, ARR, churn

## 🛠️ Manutenção

### Retenção de Dados
- Prometheus: 30 dias
- Loki: 90 dias
- Grafana: Indefinido (PostgreSQL)

### Backup
- Dashboards: Git versionado
- Alertas: Git versionado
- Data: Restic incremental

### Performance
- Prometheus: 2GB RAM, 50GB disk
- Loki: 1GB RAM, 100GB disk
- Grafana: 512MB RAM, 10GB disk

## 📚 Documentação

- [Prometheus Docs](https://prometheus.io/docs/)
- [Grafana Docs](https://grafana.com/docs/)
- [Loki Docs](https://grafana.com/docs/loki/)
- [Promtail Docs](https://grafana.com/docs/loki/latest/clients/promtail/)

## 🔐 Segurança

- TLS/SSL em todos endpoints
- Autenticação via LDAP/OAuth
- RBAC (Role-Based Access Control)
- Audit logging habilitado