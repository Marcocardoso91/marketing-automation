# Networks Configuration - Docker Swarm

## 🌐 Arquitetura de Redes

Configuração enterprise de redes Docker Swarm seguindo princípio Zero Trust e segmentação.

## 📊 Topologia

```
┌─────────────────────────────────────────────────────────┐
│                    INTERNET                             │
└────────────────────┬────────────────────────────────────┘
                     │
              ┌──────▼──────┐
              │   Traefik   │ (traefik-public)
              │  Proxy/LB   │
              └──────┬──────┘
                     │
    ┌────────────────┼────────────────┐
    │                │                │
┌───▼──┐        ┌───▼──┐        ┌───▼──┐
│ Apps │        │  AI  │        │ Comm │
└───┬──┘        └───┬──┘        └───┬──┘
    │               │                │
    └───────────────┼────────────────┘
                    │
            ┌───────▼───────┐
            │   Internal    │
            │   Services    │
            └───────┬───────┘
                    │
        ┌───────────┼───────────┐
        │           │           │
    ┌───▼──┐   ┌───▼──┐   ┌───▼──┐
    │ Data │   │Cache │   │Queue │
    └──────┘   └──────┘   └──────┘
```

## 🔒 Networks Definidos

### 1. **traefik-public** (Externa)
- **Tipo**: overlay, attachable, encrypted
- **Propósito**: Exposição de serviços via Traefik
- **Segurança**: TLS/SSL obrigatório
- **Serviços**: Todos que precisam acesso externo

### 2. **apps-internal** (Interna)
- **Tipo**: overlay, internal, encrypted
- **Propósito**: Comunicação entre aplicações
- **Segurança**: Isolada da internet
- **Serviços**: APIs internas, microsserviços

### 3. **ai-internal** (Interna)
- **Tipo**: overlay, internal, encrypted
- **Propósito**: Serviços de IA e ML
- **Segurança**: Isolada, alta performance
- **Serviços**: Ollama, MCP, Qwen, LLMs

### 4. **data-internal** (Interna)
- **Tipo**: overlay, internal, encrypted
- **Propósito**: Camada de dados
- **Segurança**: Máximo isolamento
- **Serviços**: PostgreSQL, MySQL, MongoDB

### 5. **cache-internal** (Interna)
- **Tipo**: overlay, internal, encrypted
- **Propósito**: Cache e sessões
- **Segurança**: Isolada
- **Serviços**: Redis, Memcached

### 6. **monitoring** (Semi-interna)
- **Tipo**: overlay, attachable, encrypted
- **Propósito**: Observabilidade
- **Segurança**: Acesso controlado
- **Serviços**: Prometheus, Grafana, Loki

### 7. **backup-internal** (Interna)
- **Tipo**: overlay, internal, encrypted
- **Propósito**: Operações de backup
- **Segurança**: Isolada
- **Serviços**: Restic, Kopia

## 🚀 Criação das Networks

```bash
# Executar script de criação
sudo bash /opt/macspark/networks/create-networks.sh

# Verificar networks criadas
docker network ls --filter driver=overlay
```

## 📋 Melhores Práticas

### Segurança
- ✅ Sempre usar `encrypted: "true"`
- ✅ Networks internas com `internal: true`
- ✅ Segmentação por função
- ✅ Princípio do menor privilégio

### Performance
- ✅ MTU otimizado (1450 para overlay)
- ✅ Attachable apenas quando necessário
- ✅ Evitar bridge em produção

### Nomenclatura
- ✅ Sufixo `-internal` para redes internas
- ✅ Sufixo `-public` para redes externas
- ✅ Nome descritivo da função

## 🔧 Troubleshooting

### Verificar conectividade
```bash
docker run --rm -it --network=traefik-public alpine ping google.com
```

### Inspecionar network
```bash
docker network inspect traefik-public
```

### Listar containers em uma network
```bash
docker network inspect traefik-public -f '{{range .Containers}}{{.Name}} {{end}}'
```

## 📊 Monitoramento

### Métricas importantes
- Latência entre containers
- Packet loss
- Bandwidth utilization
- Connection count

### Dashboards Grafana
- Network Overview
- Container Network Stats
- Inter-service Communication

## 🛡️ Segurança

### Firewall Rules
```bash
# Bloquear tráfego direto entre networks
iptables -I DOCKER-USER -s 10.0.1.0/24 -d 10.0.2.0/24 -j DROP
```

### Network Policies
- Deny all por padrão
- Allow explícito por serviço
- Log de conexões rejeitadas

## 📚 Referências

- [Docker Swarm Networking](https://docs.docker.com/engine/swarm/networking/)
- [Overlay Network Driver](https://docs.docker.com/network/overlay/)
- [Network Security Best Practices](https://docs.docker.com/engine/security/)