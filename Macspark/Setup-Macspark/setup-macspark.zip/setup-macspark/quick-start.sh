#!/bin/bash

# ============================================================================
# MACSPARK QUICK START - DEPLOY EM UM COMANDO
# ============================================================================
# Script de conveniência para deploy rápido em VPS limpa
# Executa todo o pipeline automaticamente
# ============================================================================

set -euo pipefail

# Cores
GREEN='\033[0;32m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Banner
show_banner() {
    echo -e "${CYAN}"
    echo "======================================================================="
    echo "                    MACSPARK QUICK START v1.0"
    echo "======================================================================="
    echo "🚀 Deploy completo em VPS limpa - Zero configuração manual"
    echo "📋 Pipeline: Preparação → Instalação → Validação automática"
    echo "⚡ Um comando, infraestrutura completa!"
    echo "======================================================================="
    echo -e "${NC}"
}

# Ajuda
show_help() {
    echo -e "${BLUE}USAGE:${NC}"
    echo "  $0 [homolog|production]"
    echo ""
    echo -e "${BLUE}EXAMPLES:${NC}"
    echo "  $0                    # Deploy homolog (padrão)"
    echo "  $0 homolog           # Deploy homolog explícito"
    echo "  $0 production        # Deploy produção"
    echo ""
    echo -e "${BLUE}WHAT THIS SCRIPT DOES:${NC}"
    echo "  ✅ Prepara VPS completamente (Docker, dependências, etc)"
    echo "  ✅ Valida sistema antes do deploy"
    echo "  ✅ Instala Macspark Setup no ambiente escolhido"
    echo "  ✅ Valida deployment pós-instalação"
    echo "  ✅ Fornece relatório completo com próximos passos"
    echo ""
    echo -e "${BLUE}REQUIREMENTS:${NC}"
    echo "  • VPS Ubuntu/Debian com acesso sudo"
    echo "  • Mínimo 2 vCPU, 4GB RAM, 20GB disk"
    echo "  • Conexão com internet estável"
    echo ""
    echo -e "${YELLOW}⚠️  WARNING:${NC}"
    echo "  Este script modifica configurações do sistema!"
    echo "  Use apenas em VPS dedicada ao Macspark."
    echo ""
}

main() {
    show_banner
    
    # Parse argumento
    local environment="${1:-homolog}"
    
    # Ajuda
    if [[ "$environment" =~ ^(-h|--help|help)$ ]]; then
        show_help
        exit 0
    fi
    
    # Validar ambiente
    if [[ ! "$environment" =~ ^(homolog|production)$ ]]; then
        echo -e "${YELLOW}❌ Ambiente inválido: $environment${NC}"
        echo -e "${BLUE}💡 Use: homolog ou production${NC}"
        echo ""
        show_help
        exit 1
    fi
    
    # Confirmação para produção
    if [ "$environment" = "production" ]; then
        echo -e "${YELLOW}⚠️  DEPLOY PRODUÇÃO detectado!${NC}"
        echo -e "${YELLOW}   Esta operação afetará ambiente live.${NC}"
        echo ""
        read -p "Tem certeza que deseja continuar? (digite 'SIM' para confirmar): " confirm
        if [ "$confirm" != "SIM" ]; then
            echo -e "${BLUE}✋ Operação cancelada.${NC}"
            exit 0
        fi
    fi
    
    echo -e "${GREEN}🎯 Ambiente selecionado: $environment${NC}"
    echo -e "${BLUE}🚀 Iniciando deploy automático completo...${NC}"
    echo ""
    
    # Verificar se estamos no diretório correto
    local script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    local pipeline_script="$script_dir/scripts/deployment/deploy-complete-pipeline.sh"
    
    if [ ! -f "$pipeline_script" ]; then
        echo -e "${YELLOW}❌ Pipeline script não encontrado: $pipeline_script${NC}"
        echo -e "${BLUE}💡 Execute este script a partir da raiz do projeto Macspark Setup${NC}"
        exit 1
    fi
    
    # Tornar executável
    chmod +x "$pipeline_script"
    
    # Executar pipeline completo
    echo -e "${CYAN}==============================================="
    echo "EXECUTANDO PIPELINE COMPLETO"
    echo "===============================================${NC}"
    
    if bash "$pipeline_script" --environment "$environment" --yes; then
        echo ""
        echo -e "${GREEN}🎉 SUCCESS! Macspark Setup instalado com sucesso!${NC}"
        echo -e "${BLUE}🔗 Para acessar os serviços, consulte o relatório acima.${NC}"
    else
        echo ""
        echo -e "${YELLOW}❌ FALHA no deploy. Verifique os logs acima.${NC}"
        echo -e "${BLUE}💡 Execute: ./scripts/validation/preflight.sh para diagnóstico${NC}"
        exit 1
    fi
}

# Verificar se é root
if [ "$EUID" -eq 0 ]; then
    echo -e "${YELLOW}❌ Não execute como root!${NC}"
    echo -e "${BLUE}💡 Execute como usuário normal com sudo:${NC}"
    echo "   sudo usermod -aG sudo \$USER"
    echo "   su - \$USER"
    echo "   ./quick-start.sh"
    exit 1
fi

# Executar
main "$@"