# 📜 Scripts Directory - Macspark Enterprise

## 🎯 Visão Geral

Diretório centralizado contendo TODOS os scripts de automação, instalação, manutenção e operação do ambiente Macspark.

## 📊 Estatísticas

- **Total de Scripts**: 47 arquivos
- **Linguagens**: Bash (45), Python (2)
- **Categorias**: 15 diretórios organizados
- **Última Reorganização**: Janeiro 2025

## 📁 Estrutura Organizacional

```
scripts/
├── backup/                 # Scripts de backup e restore
│   ├── backup.sh          # Script principal de backup
│   ├── restore.sh         # Script principal de restore
│   ├── restore-complete.sh # Restore completo
│   ├── restore-selective.sh # Restore seletivo
│   ├── lib/               # Bibliotecas e funções
│   ├── tools/             # Ferramentas auxiliares
│   ├── monitoring/        # Scripts de monitoramento de backup
│   └── deprecated/        # Scripts descontinuados
│
├── consolidation/         # Scripts de consolidação de serviços
│   ├── consolidate-databases.sh
│   ├── migrate-to-unified.sh
│   └── validate-and-migrate.sh
│
├── database/              # Scripts de banco de dados
│   ├── database-manager.sh
│   ├── manage-databases.py
│   └── reset-database.sh
│
├── deployment/            # Scripts de deploy
│   ├── deploy-homolog.sh
│   ├── deploy-homolog-complete.sh
│   ├── deploy-homolog-env.sh      # (movido de environments/)
│   ├── deploy-production.sh
│   ├── deploy-production-env.sh   # (movido de environments/)
│   ├── deploy-stack-production.sh
│   ├── deploy-traefik-homolog.sh
│   └── deploy-traefik-production.sh
│
├── generators/            # Geradores de código/config
│   └── (vazio - aguardando implementação)
│
├── helpers/               # Scripts auxiliares
│   └── cleanup-gitkeep.sh
│
├── installers/            # Instaladores de componentes
│   └── ai-installer.py   # (movido da raiz)
│
├── maintenance/           # Scripts de manutenção
│   ├── health-monitor.sh
│   ├── health-monitor-ai.sh
│   ├── maintenance.sh
│   └── update-services.sh
│
├── migration/             # Scripts de migração
│   ├── convert-compose-to-swarm.py
│   └── migrate-data.sh
│
├── recovery/              # Scripts de disaster recovery
│   ├── disaster-recovery.sh
│   └── rollback-production.sh  # (movido de environments/)
│
├── security/              # Scripts de segurança
│   └── security-hardening.sh
│
├── setup/                 # Scripts de instalação inicial
│   ├── install-2025.sh   # Script principal de instalação
│   ├── install-local.sh
│   ├── install.sh
│   ├── setup-homolog.sh
│   ├── setup-monitoring.sh
│   ├── setup-swarm-cluster.sh
│   └── create-networks.sh  # (movido de networks/)
│
├── testing/               # Scripts de teste
│   └── test-stack.sh
│
└── validation/            # Scripts de validação
    ├── validate-enterprise-deployment.sh
    ├── validate-homolog-setup.sh
    └── validate-structure.sh
```

## 🚀 Scripts Principais

### Instalação
```bash
# Instalação completa do ambiente
bash scripts/setup/install-2025.sh

# Criar networks Docker Swarm
bash scripts/setup/create-networks.sh
```

### Deploy
```bash
# Deploy em homologação
bash scripts/deployment/deploy-homolog-complete.sh

# Deploy em produção
bash scripts/deployment/deploy-production.sh
```

### Backup & Restore
```bash
# Backup completo
bash scripts/backup/backup.sh

# Restore seletivo
bash scripts/backup/restore-selective.sh
```

### Manutenção
```bash
# Health check geral
bash scripts/maintenance/health-monitor.sh

# Atualização de serviços
bash scripts/maintenance/update-services.sh
```

## 📝 Convenções de Nomenclatura

### Padrão: `[categoria]-[função]-[especificação].sh`

| Categoria | Prefixo | Exemplo |
|-----------|---------|---------|
| Install | `install-` | `install-2025.sh` |
| Deploy | `deploy-` | `deploy-production.sh` |
| Backup | `backup-` | `backup-incremental.sh` |
| Restore | `restore-` | `restore-selective.sh` |
| Validate | `validate-` | `validate-structure.sh` |
| Health | `health-` | `health-monitor.sh` |
| Setup | `setup-` | `setup-monitoring.sh` |
| Migrate | `migrate-` | `migrate-data.sh` |

## 🔄 Scripts Reorganizados (Janeiro 2025)

### Movidos para localização correta:
1. ✅ `/ai-installer.py` → `/scripts/installers/ai-installer.py`
2. ✅ `/networks/create-networks.sh` → `/scripts/setup/create-networks.sh`
3. ✅ `/environments/homolog/stacks/deploy-homolog.sh` → `/scripts/deployment/deploy-homolog-env.sh`
4. ✅ `/environments/production/scripts/deploy.sh` → `/scripts/deployment/deploy-production-env.sh`
5. ✅ `/environments/production/scripts/rollback.sh` → `/scripts/recovery/rollback-production.sh`
6. ✅ Scripts de restore fragmentados → `/scripts/backup/`
7. ✅ `/docs/archive/SCRIPT_BACKUP_PLANEJAMENTOS.sh` → `/scripts/backup/tools/backup-planejamentos.sh`

### Duplicações resolvidas:
- ✅ `/install-2025.sh` → Link simbólico para `/scripts/setup/install-2025.sh`

## 🛡️ Segurança

- Todos os scripts devem ter permissão `755` ou `700`
- Variáveis sensíveis em arquivos `.env` separados
- Nunca commitar credenciais em scripts
- Usar `set -euo pipefail` em todos os scripts Bash

## 🧪 Testando Scripts

```bash
# Validar sintaxe Bash
shellcheck scripts/setup/install-2025.sh

# Validar Python
python -m py_compile scripts/installers/ai-installer.py

# Executar em modo dry-run
DRY_RUN=true bash scripts/deployment/deploy-production.sh
```

## 📚 Documentação Adicional

- [Script Development Guide](../docs/07-guides/script-development.md)
- [Backup Strategy](../docs/04-operations/backup-strategy.md)
- [Deployment Process](../docs/03-deployment/deployment-process.md)

## 🔧 Manutenção

### Scripts Deprecated
Scripts na pasta `deprecated/` serão removidos após 30 dias sem uso.

### Versionamento
- Scripts críticos devem ter backup antes de alterações
- Usar comentários de versão no cabeçalho

### Logs
- Todos os scripts devem gerar logs em `/var/log/macspark/`
- Rotação de logs configurada para 30 dias

---

**Mantido por**: DevOps Team - Macspark
**Última atualização**: Janeiro 2025