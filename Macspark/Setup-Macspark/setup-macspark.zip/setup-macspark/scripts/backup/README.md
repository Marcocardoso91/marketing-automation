# 🚀 MacSpark Unified Backup System

Sistema de backup unificado e otimizado para o ecossistema MacSpark, seguindo as melhores práticas enterprise de 2025.

## ✨ Características

- **Zero Duplicação**: Código 100% modular e reutilizável
- **Bibliotecas Compartilhadas**: Funções centralizadas em `/lib`
- **3 Scripts Principais**: `backup.sh`, `restore.sh`, `manage.sh`
- **Configuração Externa**: YAML/JSON em `/config`
- **Suporte Multi-Ambiente**: Local, Docker, Cloud
- **Verificação de Integridade**: Validação automática de backups
- **Relatórios HTML**: Dashboard visual de status

## 📁 Estrutura

```
scripts/backup/
├── backup.sh              # Orquestrador principal de backup
├── restore.sh             # Sistema unificado de restore
├── manage.sh              # Gerenciamento do sistema
│
├── lib/                   # Bibliotecas compartilhadas
│   ├── logging.sh         # Sistema de logging centralizado
│   ├── backup-database.sh # Backup de bancos de dados
│   ├── backup-volumes.sh  # Backup de volumes Docker
│   ├── notification-system.sh # Notificações
│   └── health-check-enterprise.sh # Verificação de saúde
│
├── config/                # Configurações centralizadas
│   ├── backup-policies.json # Políticas de backup
│   ├── kopia.json         # Configuração Kopia
│   └── monitoring.yml     # Configuração de monitoramento
│
├── tests/                 # Testes automatizados
│   ├── unit/             # Testes unitários
│   └── integration/      # Testes de integração
│
└── deprecated/           # Scripts antigos (remover após migração)
```

## 🎯 Uso Rápido

### Backup Completo
```bash
./backup.sh full all
```

### Backup Apenas Databases
```bash
./backup.sh databases critical
```

### Restore Completo
```bash
./restore.sh latest full
```

### Restore Específico
```bash
./restore.sh 20250825 databases postgres
```

### Gerenciamento
```bash
# Ver status do sistema
./manage.sh status

# Configurar backup diário
./manage.sh schedule add daily

# Executar testes
./manage.sh test all

# Gerar relatório HTML
./manage.sh report

# Limpar backups antigos (> 7 dias)
./manage.sh cleanup --days=7
```

## 🔧 Configuração

### Variáveis de Ambiente (.env)
```bash
BACKUP_ROOT=/opt/macspark/backups
COMPRESSION_ENABLED=true
ENCRYPTION_ENABLED=true
PARALLEL_JOBS=4
RETENTION_DAILY=7
RETENTION_WEEKLY=4
RETENTION_MONTHLY=12
```

### Políticas de Backup (config/backup-policies.json)
- **critical**: Dados críticos com retenção estendida
- **database**: Backups frequentes de bancos de dados
- **application**: Dados de aplicação
- **development**: Ambientes de desenvolvimento

## 🚀 Deploy

### Local
```bash
./manage.sh deploy local
```

### Docker Swarm
```bash
./manage.sh deploy docker
```

### Cloud (AWS/Azure/GCP)
```bash
./manage.sh deploy cloud
```

## 📊 Monitoramento

### Dashboard Status
```bash
./manage.sh status
```

### Verificar Integridade
```bash
./manage.sh verify
```

### Relatório Visual
```bash
./manage.sh report
# Abre relatório HTML no navegador
```

## 🔄 Migração do Sistema Antigo

Os scripts antigos foram movidos para `/deprecated`. Para migrar:

1. Revisar configurações em `/deprecated`
2. Atualizar crontab para usar novos scripts
3. Testar com dry-run:
   ```bash
   ./backup.sh full all --dry-run
   ```
4. Após validação, remover `/deprecated`

## 🧪 Testes

### Executar Todos os Testes
```bash
./manage.sh test all
```

### Testes Específicos
```bash
./manage.sh test unit        # Testes unitários
./manage.sh test integration # Testes de integração
./manage.sh test restore     # Testes de restore
```

## 📈 Métricas e SLOs

- **RTO (Recovery Time Objective)**: < 1 hora
- **RPO (Recovery Point Objective)**: < 15 minutos
- **Backup Success Rate**: > 99.5%
- **Verificação Semanal**: 100% dos backups

## 🔐 Segurança

- ✅ Criptografia end-to-end
- ✅ Storage imutável (S3 Object Lock ready)
- ✅ Verificação de integridade
- ✅ Logs estruturados para auditoria
- ✅ Suporte para HashiCorp Vault

## 📝 Logs

Logs são armazenados em:
- `/opt/macspark/backups/logs/backup_YYYYMMDD.log` - Log diário
- `/opt/macspark/backups/logs/backup-structured.log` - Log estruturado (JSON)
- `/opt/macspark/backups/logs/metrics.json` - Métricas

## 🆘 Troubleshooting

### Backup Falhou
```bash
# Verificar logs
tail -f /opt/macspark/backups/logs/backup_$(date +%Y%m%d).log

# Verificar status dos serviços
./manage.sh status

# Executar teste de diagnóstico
./manage.sh test all
```

### Restore Falhou
```bash
# Verificar integridade do backup
./manage.sh verify

# Tentar restore com dry-run
./restore.sh latest full --dry-run
```

## 📚 Documentação Adicional

- [Arquitetura do Sistema](../../docs/architecture/backup-system.md)
- [Plano de Disaster Recovery](../../docs/operations/disaster-recovery.md)
- [Matriz de Compliance](../../docs/compliance/backup-compliance.md)

## 🤝 Contribuindo

1. Sempre adicione testes para novas funcionalidades
2. Use as bibliotecas em `/lib` - não duplique código
3. Mantenha documentação atualizada
4. Siga os padrões de código existentes

## 📄 Licença

Copyright © 2025 MacSpark Team. Todos os direitos reservados.

---

**Versão**: 2025.1.0  
**Última Atualização**: 25/08/2025  
**Mantido por**: Equipe de Infraestrutura MacSpark