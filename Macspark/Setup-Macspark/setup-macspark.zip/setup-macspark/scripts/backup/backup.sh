#!/bin/bash
# ============================================================================
# MACSPARK UNIFIED BACKUP ORCHESTRATOR
# ============================================================================
# Script principal consolidado para todos os backups
# Elimina duplicações e centraliza a lógica de backup
# Versão: 2025.1.0
# ============================================================================

set -euo pipefail

# Diretório base do script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LIB_DIR="${SCRIPT_DIR}/lib"

# Carregar bibliotecas
source "${LIB_DIR}/logging.sh"
source "${LIB_DIR}/backup-database.sh"
source "${LIB_DIR}/backup-volumes.sh"

# Carregar configurações do ambiente se existir
if [[ -f "${SCRIPT_DIR}/../../.env" ]]; then
    source "${SCRIPT_DIR}/../../.env"
fi

# ============================================================================
# CONFIGURAÇÕES
# ============================================================================
BACKUP_ROOT="${BACKUP_ROOT:-/opt/macspark/backups}"
BACKUP_DATE=$(date +"%Y%m%d_%H%M%S")
BACKUP_TYPE="${1:-full}"  # full, incremental, databases, volumes, configs
BACKUP_SCOPE="${2:-all}"  # all, critical, custom

# Criar estrutura de diretórios
mkdir -p "${BACKUP_ROOT}"/{databases,volumes,configs,logs}

# ============================================================================
# FUNÇÕES DE SUPORTE
# ============================================================================

show_usage() {
    cat << EOF
Usage: $0 [TYPE] [SCOPE] [OPTIONS]

TYPES:
    full        - Complete backup (databases + volumes + configs)
    databases   - Database backup only
    volumes     - Docker volumes backup only
    configs     - Configuration files backup only
    
SCOPES:
    all         - Backup everything
    critical    - Critical services only
    custom      - Use custom target list from config

OPTIONS:
    --dry-run           - Show what would be backed up
    --no-compression    - Disable compression
    --parallel=N        - Number of parallel jobs (default: $(nproc))
    --retention=DAYS    - Clean backups older than DAYS
    --verify            - Verify backup integrity after completion
    --help              - Show this help message

Examples:
    $0 full all                    # Complete backup of everything
    $0 databases critical           # Backup only critical databases
    $0 volumes all --parallel=4    # Backup all volumes with 4 parallel jobs
    
EOF
    exit 0
}

# Parse argumentos adicionais
parse_options() {
    for arg in "${@:3}"; do
        case $arg in
            --dry-run)
                DRY_RUN=true
                log INFO "Dry run mode enabled"
                ;;
            --no-compression)
                export COMPRESSION_ENABLED=false
                log INFO "Compression disabled"
                ;;
            --parallel=*)
                export PARALLEL_JOBS="${arg#*=}"
                log INFO "Parallel jobs set to: $PARALLEL_JOBS"
                ;;
            --retention=*)
                RETENTION_DAYS="${arg#*=}"
                log INFO "Retention set to: $RETENTION_DAYS days"
                ;;
            --verify)
                VERIFY_BACKUP=true
                log INFO "Backup verification enabled"
                ;;
            --help)
                show_usage
                ;;
            *)
                log WARNING "Unknown option: $arg"
                ;;
        esac
    done
}

# ============================================================================
# BACKUP DE CONFIGURAÇÕES
# ============================================================================
backup_configs() {
    log_operation_start "Configuration Backup"
    
    local config_backup_dir="${BACKUP_ROOT}/configs/config_${BACKUP_DATE}"
    mkdir -p "$config_backup_dir"
    
    # Backup de configurações Docker
    log INFO "Backing up Docker configurations"
    
    # Docker Swarm configs
    if docker node ls >/dev/null 2>&1; then
        docker config ls --format "table {{.Name}}\t{{.ID}}" > "${config_backup_dir}/docker-configs.txt"
        docker secret ls --format "table {{.Name}}\t{{.ID}}" > "${config_backup_dir}/docker-secrets.txt"
        docker service ls --format "table {{.Name}}\t{{.Mode}}\t{{.Replicas}}" > "${config_backup_dir}/docker-services.txt"
        docker network ls --format "table {{.Name}}\t{{.Driver}}\t{{.Scope}}" > "${config_backup_dir}/docker-networks.txt"
    fi
    
    # Backup de stacks YAML
    if [[ -d "${SCRIPT_DIR}/../../stacks" ]]; then
        log INFO "Backing up stack definitions"
        tar -czf "${config_backup_dir}/stacks.tar.gz" -C "${SCRIPT_DIR}/../.." stacks/
    fi
    
    # Backup de scripts
    log INFO "Backing up scripts"
    tar -czf "${config_backup_dir}/scripts.tar.gz" -C "${SCRIPT_DIR}/../.." scripts/
    
    # Criar arquivo de metadados
    cat > "${config_backup_dir}/metadata.json" << EOF
{
    "backup_date": "$(date -Iseconds)",
    "backup_type": "configuration",
    "hostname": "$(hostname)",
    "docker_version": "$(docker --version)",
    "total_services": $(docker service ls -q 2>/dev/null | wc -l || echo 0),
    "total_volumes": $(docker volume ls -q | wc -l),
    "total_containers": $(docker ps -q | wc -l)
}
EOF
    
    # Comprimir tudo
    tar -czf "${config_backup_dir}.tar.gz" -C "$(dirname "$config_backup_dir")" "$(basename "$config_backup_dir")"
    rm -rf "$config_backup_dir"
    
    local size=$(du -h "${config_backup_dir}.tar.gz" | cut -f1)
    log SUCCESS "Configuration backup completed: ${config_backup_dir}.tar.gz ($size)"
    
    log_operation_end "Configuration Backup" "success"
}

# ============================================================================
# BACKUP CRÍTICO (Serviços essenciais)
# ============================================================================
backup_critical() {
    log_operation_start "Critical Services Backup"
    
    # Lista de serviços críticos (pode ser carregada de config)
    local critical_services=(
        "postgres"
        "mysql"
        "redis"
        "mongodb"
        "vault"
        "traefik"
    )
    
    local errors=0
    
    # Backup de databases críticos
    for service in "${critical_services[@]}"; do
        local containers=$(docker ps --filter "name=${service}" --format '{{.Names}}')
        for container in $containers; do
            case "$service" in
                postgres)
                    backup_postgresql "$container" || ((errors++))
                    ;;
                mysql)
                    backup_mysql "$container" || ((errors++))
                    ;;
                redis)
                    backup_redis "$container" || ((errors++))
                    ;;
                mongodb)
                    backup_mongodb "$container" || ((errors++))
                    ;;
            esac
        done
    done
    
    # Backup de volumes críticos
    backup_critical_volumes || ((errors++))
    
    if [[ $errors -eq 0 ]]; then
        log_operation_end "Critical Services Backup" "success"
        return 0
    else
        log_operation_end "Critical Services Backup" "failed"
        return 1
    fi
}

# ============================================================================
# VERIFICAÇÃO DE INTEGRIDADE
# ============================================================================
verify_backups() {
    log_operation_start "Backup Verification"
    
    local verification_errors=0
    
    # Verificar backups de hoje
    local today=$(date +%Y%m%d)
    
    # Verificar databases
    for backup in $(find "${BACKUP_ROOT}/databases" -name "*${today}*.gz" -type f); do
        if gzip -t "$backup" 2>/dev/null; then
            log SUCCESS "Verified: $(basename "$backup")"
        else
            log ERROR "Verification failed: $(basename "$backup")"
            ((verification_errors++))
        fi
    done
    
    # Verificar volumes
    for backup in $(find "${BACKUP_ROOT}/volumes" -name "*${today}*.tar.gz" -type f); do
        if verify_volume_backup "$backup"; then
            log SUCCESS "Verified: $(basename "$backup")"
        else
            ((verification_errors++))
        fi
    done
    
    log_operation_end "Backup Verification" $([ $verification_errors -eq 0 ] && echo "success" || echo "failed")
    return $verification_errors
}

# ============================================================================
# LIMPEZA DE BACKUPS ANTIGOS
# ============================================================================
cleanup_old_backups() {
    local retention_days=${1:-7}
    
    log_operation_start "Cleanup Old Backups"
    
    # Limpar databases
    find "${BACKUP_ROOT}/databases" -type f -mtime +$retention_days -delete 2>/dev/null || true
    
    # Limpar volumes
    cleanup_old_volume_backups $retention_days
    
    # Limpar configs
    find "${BACKUP_ROOT}/configs" -type f -mtime +$retention_days -delete 2>/dev/null || true
    
    # Limpar logs
    rotate_logs $retention_days
    
    log_operation_end "Cleanup Old Backups" "success"
}

# ============================================================================
# RELATÓRIO DE BACKUP
# ============================================================================
generate_report() {
    local report_file="${BACKUP_ROOT}/logs/backup_report_${BACKUP_DATE}.txt"
    
    cat > "$report_file" << EOF
================================================================================
MACSPARK BACKUP REPORT
================================================================================
Date: $(date)
Type: $BACKUP_TYPE
Scope: $BACKUP_SCOPE
Host: $(hostname)

SUMMARY
--------------------------------------------------------------------------------
EOF
    
    # Estatísticas de databases
    local db_count=$(find "${BACKUP_ROOT}/databases" -name "*$(date +%Y%m%d)*" -type f 2>/dev/null | wc -l)
    local db_size=$(du -sh "${BACKUP_ROOT}/databases" 2>/dev/null | cut -f1)
    echo "Databases backed up: $db_count (Total size: $db_size)" >> "$report_file"
    
    # Estatísticas de volumes
    local vol_count=$(find "${BACKUP_ROOT}/volumes" -name "*$(date +%Y%m%d)*" -type f 2>/dev/null | wc -l)
    local vol_size=$(du -sh "${BACKUP_ROOT}/volumes" 2>/dev/null | cut -f1)
    echo "Volumes backed up: $vol_count (Total size: $vol_size)" >> "$report_file"
    
    # Estatísticas de configs
    local cfg_count=$(find "${BACKUP_ROOT}/configs" -name "*$(date +%Y%m%d)*" -type f 2>/dev/null | wc -l)
    local cfg_size=$(du -sh "${BACKUP_ROOT}/configs" 2>/dev/null | cut -f1)
    echo "Configs backed up: $cfg_count (Total size: $cfg_size)" >> "$report_file"
    
    echo "" >> "$report_file"
    echo "Total backup size: $(du -sh "$BACKUP_ROOT" | cut -f1)" >> "$report_file"
    echo "=================================================================================" >> "$report_file"
    
    log SUCCESS "Report generated: $report_file"
}

# ============================================================================
# MAIN EXECUTION
# ============================================================================
main() {
    # Parse opções
    parse_options "$@"
    
    # Verificar modo dry-run
    if [[ "${DRY_RUN:-false}" == "true" ]]; then
        log INFO "DRY RUN MODE - No actual backups will be performed"
        log INFO "Would backup type: $BACKUP_TYPE with scope: $BACKUP_SCOPE"
        exit 0
    fi
    
    # Iniciar backup
    log_operation_start "MacSpark Unified Backup"
    log INFO "Backup type: $BACKUP_TYPE"
    log INFO "Backup scope: $BACKUP_SCOPE"
    
    local backup_status="success"
    
    # Executar backup baseado no tipo
    case "$BACKUP_TYPE" in
        full)
            log INFO "Performing full backup"
            if [[ "$BACKUP_SCOPE" == "critical" ]]; then
                backup_critical || backup_status="failed"
            else
                discover_and_backup_databases || backup_status="failed"
                backup_all_volumes || backup_status="failed"
            fi
            backup_configs || backup_status="failed"
            ;;
        databases)
            log INFO "Performing database backup"
            if [[ "$BACKUP_SCOPE" == "critical" ]]; then
                backup_critical || backup_status="failed"
            else
                discover_and_backup_databases || backup_status="failed"
            fi
            ;;
        volumes)
            log INFO "Performing volume backup"
            if [[ "$BACKUP_SCOPE" == "critical" ]]; then
                backup_critical_volumes || backup_status="failed"
            else
                backup_all_volumes || backup_status="failed"
            fi
            ;;
        configs)
            log INFO "Performing configuration backup"
            backup_configs || backup_status="failed"
            ;;
        *)
            log ERROR "Unknown backup type: $BACKUP_TYPE"
            show_usage
            ;;
    esac
    
    # Verificar backups se solicitado
    if [[ "${VERIFY_BACKUP:-false}" == "true" ]]; then
        verify_backups || backup_status="failed"
    fi
    
    # Limpar backups antigos se especificado
    if [[ -n "${RETENTION_DAYS:-}" ]]; then
        cleanup_old_backups "$RETENTION_DAYS"
    fi
    
    # Gerar relatório
    generate_report
    
    # Finalizar
    log_operation_end "MacSpark Unified Backup" "$backup_status"
    
    if [[ "$backup_status" == "success" ]]; then
        exit 0
    else
        exit 1
    fi
}

# Executar se não estiver sendo sourced
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi