#!/bin/bash

# ═══════════════════════════════════════════════════════════════════════════════
# 🚀 MACSPARK ENTERPRISE BACKUP SYSTEM 2025 - CRITICAL COMPLETE
# ═══════════════════════════════════════════════════════════════════════════════
# Modernized enterprise-grade critical backup with 2025 best practices
# Features: OpenTelemetry tracing, Prometheus metrics, structured logging,
# multi-engine support, cloud-native architecture, compliance-ready
# ═══════════════════════════════════════════════════════════════════════════════

set -euo pipefail

# Modern configuration management
readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly PROJECT_ROOT="$(cd "$SCRIPT_DIR/../../../" && pwd)"
readonly CONFIG_DIR="$PROJECT_ROOT/configs/backup"
readonly LOG_DIR="$PROJECT_ROOT/logs/backup"
readonly DATA_DIR="$PROJECT_ROOT/data/backup"
readonly VERSION="2025.1.0"

# Load environment-specific configuration
if [[ -f "$PROJECT_ROOT/.env" ]]; then
    source "$PROJECT_ROOT/.env"
fi

# Load backup-specific configuration
if [[ -f "$CONFIG_DIR/backup.conf" ]]; then
    source "$CONFIG_DIR/backup.conf"
fi

# Create required directories
mkdir -p "$LOG_DIR" "$DATA_DIR" "$(dirname "$CONFIG_DIR")"

# Modern logging with structured output
source "$SCRIPT_DIR/../monitoring/logging.sh" 2>/dev/null || {
    log() { echo "[$(date -Iseconds)] [$1] ${*:2}"; }
}

# OpenTelemetry tracing (if available)
source "$SCRIPT_DIR/../monitoring/tracing.sh" 2>/dev/null || true

# Prometheus metrics (if available)
source "$SCRIPT_DIR/../monitoring/metrics.sh" 2>/dev/null || true

# Configuration with modern defaults
readonly BACKUP_ENGINE="${BACKUP_PRIMARY_ENGINE:-kopia}"
readonly BACKUP_LOCATION="${BACKUP_PRIMARY_LOCATION:-$DATA_DIR/critical-complete}"
readonly COMPRESSION_LEVEL="${BACKUP_COMPRESSION_LEVEL:-6}"
readonly ENCRYPTION_ENABLED="${BACKUP_ENABLE_ENCRYPTION:-true}"
readonly PARALLEL_JOBS="${BACKUP_PARALLEL_JOBS:-4}"
readonly TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# Modern error handling with tracing
trap 'handle_error $? $LINENO' ERR
handle_error() {
    local exit_code=$1
    local line_number=$2
    log ERROR "Critical backup failed at line $line_number with exit code $exit_code"
    
    # Send error to observability stack
    emit_error_metric "$exit_code" "$line_number" "backup-critical-complete" 2>/dev/null || true
    increment_counter "backup_operations_total" "error" "critical-complete" 2>/dev/null || true
    
    # Trigger immediate alert
    if command -v "$SCRIPT_DIR/../monitoring/notification-system.sh" >/dev/null; then
        "$SCRIPT_DIR/../monitoring/notification-system.sh" --failure "Critical Complete Backup" \
            "Failed at line $line_number with code $exit_code" 2>/dev/null || true
    fi
    
    cleanup_on_error 2>/dev/null || true
    exit "$exit_code"
}

cleanup_on_error() {
    log WARNING "Cleaning up after error..."
    # Remove partial backup data
    [[ -d "$BACKUP_ROOT" ]] && rm -rf "$BACKUP_ROOT" 2>/dev/null || true
}

# Configuration validation
validate_configuration() {
    local validation_errors=0
    
    # Check backup location
    if ! mkdir -p "$BACKUP_LOCATION" 2>/dev/null; then
        log ERROR "Cannot create backup location: $BACKUP_LOCATION"
        ((validation_errors++))
    fi
    
    # Check disk space (minimum 10GB)
    local available_space
    available_space=$(df "$BACKUP_LOCATION" | tail -1 | awk '{print $4}')
    if [[ $available_space -lt 10485760 ]]; then  # 10GB in KB
        log WARNING "Low disk space: $(numfmt --to=iec $((available_space * 1024)))"
    fi
    
    # Check Docker connectivity
    if ! docker info >/dev/null 2>&1; then
        log ERROR "Docker is not accessible"
        ((validation_errors++))
    fi
    
    # Check backup engine
    if ! command -v "$BACKUP_ENGINE" >/dev/null 2>&1; then
        log WARNING "Primary backup engine '$BACKUP_ENGINE' not found, using built-in methods"
    fi
    
    return $validation_errors
}

# Pre-flight health checks
run_preflight_checks() {
    log INFO "Running preflight health checks..."
    local checks_passed=0
    local total_checks=0
    
    # System resource checks
    ((total_checks++))
    local cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1)
    if (( $(echo "$cpu_usage < 80" | bc -l) 2>/dev/null || [[ ${cpu_usage%.*} -lt 80 ]] )); then
        ((checks_passed++))
        log DEBUG "CPU usage check: OK (${cpu_usage}%)"
    else
        log WARNING "CPU usage check: HIGH (${cpu_usage}%)"
    fi
    
    # Memory check
    ((total_checks++))
    local mem_usage=$(free | grep Mem | awk '{printf "%.0f", $3/$2 * 100.0}')
    if [[ $mem_usage -lt 85 ]]; then
        ((checks_passed++))
        log DEBUG "Memory usage check: OK (${mem_usage}%)"
    else
        log WARNING "Memory usage check: HIGH (${mem_usage}%)"
    fi
    
    # Network connectivity
    ((total_checks++))
    if timeout 5 ping -c 1 8.8.8.8 >/dev/null 2>&1; then
        ((checks_passed++))
        log DEBUG "Network connectivity: OK"
    else
        log WARNING "Network connectivity: LIMITED"
    fi
    
    # Docker services
    ((total_checks++))
    local running_services=$(docker service ls 2>/dev/null | wc -l)
    if [[ $running_services -gt 0 ]]; then
        ((checks_passed++))
        log DEBUG "Docker services: $running_services services running"
    else
        log WARNING "Docker services: No services found"
    fi
    
    local success_rate=$((checks_passed * 100 / total_checks))
    log INFO "Preflight checks: $checks_passed/$total_checks passed ($success_rate%)"
    
    # Emit health check metrics
    set_gauge "backup_preflight_checks_passed" "$checks_passed" "type=\"critical-complete\""
    set_gauge "backup_preflight_success_rate" "$success_rate" "type=\"critical-complete\""
    
    return $((total_checks - checks_passed))
}

# Enhanced database discovery and backup
discover_and_backup_databases() {
    log INFO "🗄️ Phase 1: Enhanced database discovery and backup..."
    local backup_dir="$BACKUP_ROOT/databases"
    mkdir -p "$backup_dir"
    
    local databases_backed_up=0
    local database_size_total=0
    
    # PostgreSQL databases with enhanced detection
    log INFO "Discovering PostgreSQL databases..."
    docker ps --format "{{.Names}}" | grep -E "postgres|postgresql|pg|timescale" | while read -r container; do
        if docker exec "$container" which psql >/dev/null 2>&1; then
            log INFO "Found PostgreSQL in container: $container"
            
            # Get version and configuration
            local pg_version
            pg_version=$(docker exec "$container" psql -U postgres -t -c "SELECT version();" 2>/dev/null | head -1 | awk '{print $2}' || echo "unknown")
            log DEBUG "PostgreSQL version: $pg_version"
            
            # Get all non-template databases
            local databases
            databases=$(docker exec "$container" psql -U postgres -t -c \
                "SELECT datname FROM pg_database WHERE datistemplate = false AND datallowconn = true;" \
                2>/dev/null | grep -v '^$' || echo "")
            
            for db in $databases; do
                db=$(echo "$db" | xargs)  # Trim whitespace
                log INFO "Backing up database: $db from $container"
                
                local backup_file="$backup_dir/${container}_${db}_${TIMESTAMP}.sql"
                local compressed_file="${backup_file}.gz"
                
                # Enhanced backup with options
                if docker exec "$container" pg_dump \
                    -U postgres \
                    --verbose \
                    --clean \
                    --if-exists \
                    --create \
                    --format=custom \
                    "$db" > "${backup_file}.custom" 2>/dev/null; then
                    
                    # Also create SQL version for compatibility
                    docker exec "$container" pg_dump -U postgres "$db" 2>/dev/null | gzip > "$compressed_file"
                    
                    local backup_size
                    backup_size=$(stat -f%z "$compressed_file" 2>/dev/null || stat -c%s "$compressed_file")
                    database_size_total=$((database_size_total + backup_size))
                    ((databases_backed_up++))
                    
                    log INFO "✅ PostgreSQL backup completed: $db ($(numfmt --to=iec $backup_size))"
                else
                    log WARNING "❌ Failed to backup PostgreSQL database: $db from $container"
                fi
            done
        fi
    done
    
    # Redis databases with RDB and AOF
    log INFO "Discovering Redis databases..."
    docker ps --format "{{.Names}}" | grep -E "redis|valkey" | while read -r container; do
        if docker exec "$container" which redis-cli >/dev/null 2>&1; then
            log INFO "Found Redis in container: $container"
            
            # Get Redis info
            local redis_info
            redis_info=$(docker exec "$container" redis-cli INFO server 2>/dev/null | grep redis_version || echo "unknown")
            log DEBUG "Redis info: $redis_info"
            
            # Create consistent backup
            docker exec "$container" redis-cli BGSAVE >/dev/null 2>&1 || true
            docker exec "$container" redis-cli BGREWRITEAOF >/dev/null 2>&1 || true
            
            # Wait for background operations to complete
            local attempts=0
            while [[ $attempts -lt 30 ]]; do
                if docker exec "$container" redis-cli LASTSAVE 2>/dev/null | grep -q "$(date +%s)"; then
                    break
                fi
                sleep 1
                ((attempts++))
            done
            
            # Copy dump files
            local backup_files=("dump.rdb" "appendonly.aof")
            for backup_file in "${backup_files[@]}"; do
                if docker exec "$container" test -f "/data/$backup_file" 2>/dev/null; then
                    local target_file="$backup_dir/${container}_${backup_file}_${TIMESTAMP}"
                    if docker cp "$container:/data/$backup_file" "$target_file" 2>/dev/null; then
                        gzip "$target_file"
                        ((databases_backed_up++))
                        log INFO "✅ Redis backup completed: $backup_file"
                    fi
                fi
            done
        fi
    done
    
    # MongoDB databases
    log INFO "Discovering MongoDB databases..."
    docker ps --format "{{.Names}}" | grep -E "mongo|mongodb" | while read -r container; do
        if docker exec "$container" which mongodump >/dev/null 2>&1; then
            log INFO "Found MongoDB in container: $container"
            
            local backup_dir_mongo="$backup_dir/${container}_mongo_${TIMESTAMP}"
            mkdir -p "$backup_dir_mongo"
            
            # Create dump inside container then copy out
            if docker exec "$container" mongodump --out /tmp/mongodump 2>/dev/null; then
                docker cp "$container:/tmp/mongodump/." "$backup_dir_mongo/"
                tar -czf "${backup_dir_mongo}.tar.gz" -C "$(dirname "$backup_dir_mongo")" "$(basename "$backup_dir_mongo")"
                rm -rf "$backup_dir_mongo"
                ((databases_backed_up++))
                log INFO "✅ MongoDB backup completed"
            else
                log WARNING "❌ Failed to backup MongoDB from $container"
            fi
        fi
    done
    
    # MySQL/MariaDB databases
    log INFO "Discovering MySQL/MariaDB databases..."
    docker ps --format "{{.Names}}" | grep -E "mysql|mariadb|percona" | while read -r container; do
        if docker exec "$container" which mysqldump >/dev/null 2>&1; then
            log INFO "Found MySQL/MariaDB in container: $container"
            
            local backup_file="$backup_dir/${container}_all_databases_${TIMESTAMP}.sql.gz"
            
            # Enhanced mysqldump with options
            if docker exec "$container" mysqldump \
                --all-databases \
                --single-transaction \
                --routines \
                --triggers \
                --events \
                --flush-logs \
                --hex-blob 2>/dev/null | gzip > "$backup_file"; then
                
                ((databases_backed_up++))
                log INFO "✅ MySQL/MariaDB backup completed"
            else
                log WARNING "❌ Failed to backup MySQL/MariaDB from $container"
            fi
        fi
    done
    
    log INFO "📊 Database backup summary: $databases_backed_up databases, $(numfmt --to=iec $database_size_total) total"
    record_backup_size "$database_size_total" "databases"
    set_gauge "backup_databases_count" "$databases_backed_up" "type=\"critical-complete\""
}

# Enhanced N8N workflow backup
backup_n8n_workflows() {
    log INFO "🔧 Phase 2: Enhanced N8N workflow and data backup..."
    local backup_dir="$BACKUP_ROOT/n8n"
    mkdir -p "$backup_dir"
    
    local workflows_backed_up=0
    
    # Find all N8N containers with improved detection
    local n8n_containers
    n8n_containers=$(docker ps --format "{{.Names}}" | grep -E "n8n|workflow" || echo "")
    
    for container in $n8n_containers; do
        log INFO "Processing N8N container: $container"
        
        # Check if it's actually n8n
        if docker exec "$container" which n8n >/dev/null 2>&1; then
            log INFO "Confirmed N8N in container: $container"
            
            # Export workflows with enhanced options
            if docker exec "$container" n8n export:workflow --all --output=/tmp/workflows.json 2>/dev/null; then
                docker cp "$container:/tmp/workflows.json" "$backup_dir/${container}_workflows_${TIMESTAMP}.json"
                ((workflows_backed_up++))
                log INFO "✅ N8N workflows exported"
            fi
            
            # Export credentials (encrypted)
            if docker exec "$container" n8n export:credentials --all --output=/tmp/credentials.json 2>/dev/null; then
                docker cp "$container:/tmp/credentials.json" "$backup_dir/${container}_credentials_${TIMESTAMP}.json"
                log INFO "✅ N8N credentials exported"
            fi
            
            # Backup complete .n8n directory
            if docker cp "$container:/home/node/.n8n" "$backup_dir/${container}_data_${TIMESTAMP}" 2>/dev/null; then
                log INFO "✅ N8N data directory backed up"
            fi
            
            # Backup environment and config
            if docker exec "$container" printenv | grep -E "^N8N_" > "$backup_dir/${container}_environment_${TIMESTAMP}.env" 2>/dev/null; then
                log INFO "✅ N8N environment variables saved"
            fi
        fi
    done
    
    # Backup N8N-related volumes
    docker volume ls --format "{{.Name}}" | grep -E "n8n|workflow" | while read -r volume; do
        log INFO "Backing up N8N volume: $volume"
        
        if docker run --rm \
            -v "$volume:/source:ro" \
            -v "$backup_dir:/backup" \
            alpine:latest \
            tar -czf "/backup/${volume}_${TIMESTAMP}.tar.gz" -C /source . 2>/dev/null; then
            
            log INFO "✅ Volume backed up: $volume"
        else
            log WARNING "❌ Failed to backup volume: $volume"
        fi
    done
    
    set_gauge "backup_n8n_workflows_count" "$workflows_backed_up" "type=\"critical-complete\""
    log INFO "📊 N8N backup summary: $workflows_backed_up containers processed"
}

# Enhanced Docker volume backup with progress tracking
backup_docker_volumes() {
    log INFO "📦 Phase 3: Enhanced Docker volume backup with parallel processing..."
    local backup_dir="$BACKUP_ROOT/volumes"
    mkdir -p "$backup_dir"
    
    # Get all volumes excluding system volumes
    local volumes
    volumes=$(docker volume ls --format "{{.Name}}" | grep -vE "^[a-f0-9]{64}$" || echo "")
    local total_volumes
    total_volumes=$(echo "$volumes" | wc -l)
    
    if [[ -z "$volumes" ]]; then
        log WARNING "No named volumes found to backup"
        return 0
    fi
    
    log INFO "Found $total_volumes volumes to backup"
    
    local current_volume=0
    local volumes_backed_up=0
    local total_size=0
    
    # Process volumes with parallel processing
    echo "$volumes" | xargs -I {} -P "$PARALLEL_JOBS" bash -c '
        volume="$1"
        backup_dir="$2"
        timestamp="$3"
        
        # Progress indicator
        echo "Processing volume: $volume"
        
        # Create backup with metadata
        backup_file="$backup_dir/${volume}_${timestamp}.tar.gz"
        metadata_file="$backup_dir/${volume}_${timestamp}.json"
        
        # Get volume info
        docker volume inspect "$volume" > "$metadata_file" 2>/dev/null || echo "{}" > "$metadata_file"
        
        # Create backup
        if docker run --rm \
            --label "macspark.backup.temp=true" \
            -v "$volume:/source:ro" \
            -v "$backup_dir:/backup" \
            alpine:latest \
            sh -c "cd /source && tar -czf \"/backup/$(basename \"$backup_file\")\" . 2>/dev/null"; then
            
            # Get file size
            size=$(stat -f%z "$backup_file" 2>/dev/null || stat -c%s "$backup_file" 2>/dev/null || echo "0")
            echo "✅ Volume backed up: $volume ($(numfmt --to=iec $size))"
        else
            echo "❌ Failed to backup volume: $volume"
            rm -f "$backup_file" "$metadata_file" 2>/dev/null
        fi
    ' -- {} "$backup_dir" "$TIMESTAMP"
    
    # Count successful backups and calculate total size
    volumes_backed_up=$(find "$backup_dir" -name "*.tar.gz" | wc -l)
    total_size=$(find "$backup_dir" -name "*.tar.gz" -exec stat -f%z {} \; 2>/dev/null | awk '{sum+=$1} END {print sum+0}')
    
    log INFO "📊 Volume backup summary: $volumes_backed_up/$total_volumes volumes, $(numfmt --to=iec $total_size) total"
    
    record_backup_size "$total_size" "volumes"
    set_gauge "backup_volumes_count" "$volumes_backed_up" "type=\"critical-complete\""
}

# Enhanced Docker configuration backup
backup_docker_configurations() {
    log INFO "🐳 Phase 4: Enhanced Docker configuration backup..."
    local backup_dir="$BACKUP_ROOT/docker"
    mkdir -p "$backup_dir"
    
    # Export all container configurations with labels
    log INFO "Exporting container configurations..."
    docker ps -a --format "{{.Names}}" | while read -r container; do
        docker inspect "$container" > "$backup_dir/container_${container}.json" 2>/dev/null || true
    done
    
    # Export Swarm service configurations
    if docker info --format '{{.Swarm.LocalNodeState}}' 2>/dev/null | grep -q active; then
        log INFO "Exporting Docker Swarm configurations..."
        
        # Services
        docker service ls --format "{{.Name}}" 2>/dev/null | while read -r service; do
            docker service inspect "$service" > "$backup_dir/service_${service}.json" 2>/dev/null || true
        done
        
        # Networks
        docker network ls --format "{{.Name}}" | while read -r network; do
            docker network inspect "$network" > "$backup_dir/network_${network}.json" 2>/dev/null || true
        done
        
        # Secrets (metadata only, not content)
        docker secret ls --format "{{.Name}}" 2>/dev/null | while read -r secret; do
            docker secret inspect "$secret" > "$backup_dir/secret_${secret}.json" 2>/dev/null || true
        done
        
        # Configs
        docker config ls --format "{{.Name}}" 2>/dev/null | while read -r config; do
            docker config inspect "$config" > "$backup_dir/config_${config}.json" 2>/dev/null || true
        done
        
        # Nodes
        docker node ls --format "{{.Hostname}}" 2>/dev/null | while read -r node; do
            docker node inspect "$node" > "$backup_dir/node_${node}.json" 2>/dev/null || true
        done
    fi
    
    # Backup compose files and stack definitions
    log INFO "Finding and backing up compose files..."
    find "$PROJECT_ROOT" -name "docker-compose*.yml" -o -name "*.yml" -path "*/stacks/*" | while read -r file; do
        local relative_path
        relative_path=$(realpath --relative-to="$PROJECT_ROOT" "$file")
        local safe_name
        safe_name=$(echo "$relative_path" | tr '/' '_')
        cp "$file" "$backup_dir/compose_${safe_name}" 2>/dev/null || true
    done
    
    # Export system Docker configuration
    if [[ -f "/etc/docker/daemon.json" ]]; then
        cp "/etc/docker/daemon.json" "$backup_dir/daemon.json" 2>/dev/null || true
    fi
    
    local config_files
    config_files=$(find "$backup_dir" -type f | wc -l)
    log INFO "📊 Docker configurations: $config_files files backed up"
    
    set_gauge "backup_docker_configs_count" "$config_files" "type=\"critical-complete\""
}

# Enhanced system configuration backup
backup_system_configurations() {
    log INFO "⚙️ Phase 5: Enhanced system configuration backup..."
    local backup_dir="$BACKUP_ROOT/system"
    mkdir -p "$backup_dir"
    
    # System configurations with improved detection
    local system_configs=(
        "$PROJECT_ROOT/.env"
        "$PROJECT_ROOT/configs"
        "$PROJECT_ROOT/environments"
        "$PROJECT_ROOT/scripts"
        "/etc/docker"
        "/etc/systemd/system/docker.service.d"
        "$HOME/.docker"
    )
    
    for config_path in "${system_configs[@]}"; do
        if [[ -e "$config_path" ]]; then
            log INFO "Backing up system config: $config_path"
            
            local basename_safe
            basename_safe=$(basename "$config_path" | tr '.' '_')
            
            if [[ -d "$config_path" ]]; then
                tar -czf "$backup_dir/system_${basename_safe}_${TIMESTAMP}.tar.gz" -C "$(dirname "$config_path")" "$(basename "$config_path")" 2>/dev/null || true
            else
                cp "$config_path" "$backup_dir/system_${basename_safe}_${TIMESTAMP}" 2>/dev/null || true
            fi
        fi
    done
    
    # System information
    cat > "$backup_dir/system_info_${TIMESTAMP}.json" << EOF
{
    "hostname": "$(hostname)",
    "kernel": "$(uname -r)",
    "os": "$(lsb_release -d 2>/dev/null | cut -f2 || echo 'Unknown')",
    "docker_version": "$(docker version --format '{{.Server.Version}}' 2>/dev/null || echo 'Unknown')",
    "backup_date": "$(date -Iseconds)",
    "backup_version": "$VERSION"
}
EOF
    
    log INFO "✅ System configurations backed up"
}

# Create comprehensive recovery manifest
create_recovery_manifest() {
    log INFO "📋 Phase 6: Creating comprehensive recovery manifest..."
    
    local manifest_file="$BACKUP_ROOT/RECOVERY_MANIFEST.json"
    local backup_stats
    
    # Calculate backup statistics
    local database_count
    database_count=$(find "$BACKUP_ROOT/databases" -name "*.gz" -o -name "*.custom" 2>/dev/null | wc -l)
    local volume_count
    volume_count=$(find "$BACKUP_ROOT/volumes" -name "*.tar.gz" 2>/dev/null | wc -l)
    local n8n_count
    n8n_count=$(find "$BACKUP_ROOT/n8n" -name "*.json" 2>/dev/null | wc -l)
    local docker_config_count
    docker_config_count=$(find "$BACKUP_ROOT/docker" -name "*.json" 2>/dev/null | wc -l)
    local system_config_count
    system_config_count=$(find "$BACKUP_ROOT/system" -type f 2>/dev/null | wc -l)
    
    # Create comprehensive manifest
    cat > "$manifest_file" << EOF
{
  "metadata": {
    "backup_id": "$TIMESTAMP",
    "backup_date": "$(date -Iseconds)",
    "backup_version": "$VERSION",
    "backup_type": "critical_complete",
    "backup_engine": "$BACKUP_ENGINE",
    "compression_level": $COMPRESSION_LEVEL,
    "encryption_enabled": $ENCRYPTION_ENABLED
  },
  "system_info": {
    "hostname": "$(hostname)",
    "kernel": "$(uname -r)",
    "docker_version": "$(docker version --format '{{.Server.Version}}' 2>/dev/null || echo 'unknown')",
    "swarm_mode": "$(docker info --format '{{.Swarm.LocalNodeState}}' 2>/dev/null || echo 'inactive')",
    "total_containers": $(docker ps -aq | wc -l),
    "running_containers": $(docker ps -q | wc -l),
    "total_volumes": $(docker volume ls -q | wc -l),
    "total_images": $(docker image ls -q | wc -l),
    "total_networks": $(docker network ls -q | wc -l),
    "total_services": $(docker service ls -q 2>/dev/null | wc -l || echo 0)
  },
  "backup_contents": {
    "databases": {
      "count": $database_count,
      "types": ["postgresql", "mysql", "redis", "mongodb"],
      "location": "databases/"
    },
    "volumes": {
      "count": $volume_count,
      "location": "volumes/"
    },
    "n8n_workflows": {
      "count": $n8n_count,
      "location": "n8n/"
    },
    "docker_configs": {
      "count": $docker_config_count,
      "location": "docker/"
    },
    "system_configs": {
      "count": $system_config_count,
      "location": "system/"
    }
  },
  "recovery_procedures": {
    "preparation": [
      "Ensure Docker and Docker Swarm are installed and configured",
      "Verify network connectivity and DNS resolution",
      "Prepare storage with sufficient space",
      "Install backup tools: kopia, restic, etc."
    ],
    "volume_recovery": {
      "command": "docker volume create [name] && docker run --rm -v [name]:/restore -v \$(pwd):/backup alpine tar -xzf /backup/volumes/[volume_file] -C /restore",
      "verification": "docker run --rm -v [name]:/data alpine ls -la /data"
    },
    "database_recovery": {
      "postgresql": "zcat [backup_file] | docker exec -i [container] psql -U postgres [database]",
      "mysql": "zcat [backup_file] | docker exec -i [container] mysql -u root -p",
      "redis": "docker cp [backup_file] [container]:/data/ && docker exec [container] redis-cli DEBUG RELOAD",
      "mongodb": "docker cp [backup_dir] [container]:/tmp/ && docker exec [container] mongorestore /tmp/[backup_dir]"
    },
    "application_recovery": {
      "n8n_workflows": "docker exec [n8n_container] n8n import:workflow --input=/tmp/workflows.json",
      "docker_services": "docker stack deploy -c [compose_file] [stack_name]"
    },
    "verification": {
      "services": "docker service ls && docker stack ls",
      "containers": "docker ps --format 'table {{.Names}}\\t{{.Status}}'",
      "volumes": "docker volume ls",
      "health": "docker system df && docker system events --since 5m"
    }
  },
  "critical_services": [
    "traefik",
    "postgres-mega",
    "redis-ha",
    "n8n",
    "evolution-api",
    "portainer",
    "prometheus",
    "grafana"
  ],
  "compliance": {
    "retention_policy": "$BACKUP_RETENTION_DAILY",
    "encryption": "$ENCRYPTION_ENABLED",
    "immutable": "$([ "$BACKUP_IMMUTABLE_BACKUPS" = "true" ] && echo true || echo false)",
    "audit_trail": true
  }
}
EOF
    
    log INFO "✅ Recovery manifest created with comprehensive procedures"
}

# Create final archive with modern compression and verification
create_final_archive() {
    log INFO "📦 Phase 7: Creating final enterprise archive..."
    
    cd "$BACKUP_LOCATION"
    local archive_name="critical_complete_backup_${TIMESTAMP}.tar.gz"
    
    log INFO "Compressing backup data (this may take several minutes)..."
    
    # Create archive with progress and verification
    if command -v pv >/dev/null 2>&1; then
        # Use pv for progress if available
        tar -cf - "backup_$TIMESTAMP" | pv -s $(du -sb "backup_$TIMESTAMP" | cut -f1) | gzip -$COMPRESSION_LEVEL > "$archive_name"
    else
        # Fallback to standard tar with verbose output
        tar -czf "$archive_name" "backup_$TIMESTAMP"
    fi
    
    # Verify archive integrity
    if gzip -t "$archive_name" 2>/dev/null; then
        log INFO "✅ Archive integrity verified"
    else
        log ERROR "❌ Archive integrity check failed!"
        return 1
    fi
    
    # Calculate checksums
    local checksum_file="${archive_name}.checksums"
    {
        echo "# MacSpark Enterprise Backup Checksums - $TIMESTAMP"
        echo "# Generated: $(date -Iseconds)"
        echo ""
        echo "# SHA256"
        sha256sum "$archive_name"
        echo ""
        echo "# MD5 (for compatibility)"
        md5sum "$archive_name"
        echo ""
        echo "# File size"
        ls -lh "$archive_name"
    } > "$checksum_file"
    
    # Get final statistics
    local archive_size
    archive_size=$(stat -f%z "$archive_name" 2>/dev/null || stat -c%s "$archive_name")
    local compression_ratio=0
    
    if [[ -d "backup_$TIMESTAMP" ]]; then
        local original_size
        original_size=$(du -sb "backup_$TIMESTAMP" | cut -f1)
        if [[ $original_size -gt 0 ]]; then
            compression_ratio=$(( (original_size - archive_size) * 100 / original_size ))
        fi
    fi
    
    # Record final metrics
    record_backup_size "$archive_size" "critical-complete"
    set_gauge "backup_compression_ratio" "$compression_ratio" "type=\"critical-complete\""
    
    log INFO "📊 Final archive statistics:"
    log INFO "  📁 Archive: $archive_name"
    log INFO "  💾 Size: $(numfmt --to=iec $archive_size)"
    log INFO "  🗜️ Compression: ${compression_ratio}%"
    log INFO "  🔒 Checksums: $checksum_file"
    
    # Export key variables for cleanup
    export FINAL_ARCHIVE="$archive_name"
    export ARCHIVE_SIZE="$archive_size"
    export CHECKSUM_FILE="$checksum_file"
}

# Generate enhanced recovery script
generate_recovery_script() {
    log INFO "🔧 Phase 8: Generating enhanced recovery script..."
    
    local recovery_script="$BACKUP_LOCATION/RECOVERY_SCRIPT_${TIMESTAMP}.sh"
    
    cat > "$recovery_script" << 'RECOVERY_SCRIPT_EOF'
#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
# 🚀 MACSPARK ENTERPRISE DISASTER RECOVERY SCRIPT 2025
# ═══════════════════════════════════════════════════════════════════════════════
# Generated: TIMESTAMP_PLACEHOLDER
# Version: VERSION_PLACEHOLDER
# ═══════════════════════════════════════════════════════════════════════════════

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
BACKUP_FILE="${1:-}"
RESTORE_DIR="/tmp/macspark_restore_$(date +%s)"
LOG_FILE="/tmp/disaster_recovery_$(date +%s).log"

# Logging function
log() {
    local level="$1"
    shift
    local message="$*"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    case "$level" in
        INFO)  echo -e "${BLUE}[INFO]${NC} $message" | tee -a "$LOG_FILE" ;;
        SUCCESS) echo -e "${GREEN}[SUCCESS]${NC} $message" | tee -a "$LOG_FILE" ;;
        WARNING) echo -e "${YELLOW}[WARNING]${NC} $message" | tee -a "$LOG_FILE" ;;
        ERROR) echo -e "${RED}[ERROR]${NC} $message" | tee -a "$LOG_FILE" ;;
    esac
}

# Print banner
print_banner() {
    echo -e "${BLUE}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                    MACSPARK DISASTER RECOVERY 2025                          ║${NC}"
    echo -e "${BLUE}║                        Enterprise Full Restore                                ║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

# Validate prerequisites
validate_prerequisites() {
    log INFO "Validating system prerequisites..."
    
    local validation_errors=0
    
    # Check Docker
    if ! command -v docker >/dev/null; then
        log ERROR "Docker is not installed"
        ((validation_errors++))
    elif ! docker info >/dev/null 2>&1; then
        log ERROR "Docker is not running"
        ((validation_errors++))
    else
        log SUCCESS "Docker is available"
    fi
    
    # Check backup file
    if [[ -z "$BACKUP_FILE" ]]; then
        log ERROR "Usage: $0 <backup_archive.tar.gz>"
        ((validation_errors++))
    elif [[ ! -f "$BACKUP_FILE" ]]; then
        log ERROR "Backup file not found: $BACKUP_FILE"
        ((validation_errors++))
    else
        log SUCCESS "Backup file found: $BACKUP_FILE"
        
        # Verify archive integrity
        if gzip -t "$BACKUP_FILE" 2>/dev/null; then
            log SUCCESS "Archive integrity verified"
        else
            log ERROR "Archive integrity check failed"
            ((validation_errors++))
        fi
    fi
    
    # Check available space
    local backup_size
    backup_size=$(stat -f%z "$BACKUP_FILE" 2>/dev/null || stat -c%s "$BACKUP_FILE")
    local available_space
    available_space=$(df /tmp | tail -1 | awk '{print $4 * 1024}')
    
    if [[ $available_space -lt $((backup_size * 3)) ]]; then
        log WARNING "Low disk space for extraction. Required: $(numfmt --to=iec $((backup_size * 3)))"
    fi
    
    return $validation_errors
}

# Extract and prepare backup
extract_backup() {
    log INFO "Extracting backup archive..."
    
    mkdir -p "$RESTORE_DIR"
    
    # Extract with progress if pv is available
    if command -v pv >/dev/null 2>&1; then
        pv "$BACKUP_FILE" | tar -xzf - -C "$RESTORE_DIR"
    else
        tar -xzf "$BACKUP_FILE" -C "$RESTORE_DIR"
    fi
    
    # Find backup root directory
    BACKUP_ROOT=$(find "$RESTORE_DIR" -name "backup_*" -type d | head -1)
    
    if [[ -z "$BACKUP_ROOT" ]]; then
        log ERROR "Could not find backup root directory in archive"
        return 1
    fi
    
    log SUCCESS "Backup extracted to: $BACKUP_ROOT"
    
    # Load recovery manifest
    if [[ -f "$BACKUP_ROOT/RECOVERY_MANIFEST.json" ]]; then
        log INFO "Recovery manifest found, validating backup contents..."
        # Additional validation could be added here
    fi
}

# Restore Docker volumes
restore_volumes() {
    log INFO "Restoring Docker volumes..."
    
    local volumes_restored=0
    
    for volume_file in "$BACKUP_ROOT"/volumes/*.tar.gz; do
        [[ -f "$volume_file" ]] || continue
        
        # Extract volume name from filename
        local volume_name
        volume_name=$(basename "$volume_file" | sed 's/_[0-9]*\.tar\.gz$//')
        
        log INFO "Restoring volume: $volume_name"
        
        # Create volume
        if docker volume create "$volume_name" >/dev/null 2>&1; then
            # Restore data
            if docker run --rm \
                -v "$volume_name:/restore" \
                -v "$(dirname "$volume_file"):/backup" \
                alpine tar -xzf "/backup/$(basename "$volume_file")" -C /restore 2>/dev/null; then
                
                log SUCCESS "Volume restored: $volume_name"
                ((volumes_restored++))
            else
                log WARNING "Failed to restore volume data: $volume_name"
            fi
        else
            log WARNING "Failed to create volume: $volume_name"
        fi
    done
    
    log INFO "Volume restoration summary: $volumes_restored volumes restored"
}

# Restore databases
restore_databases() {
    log INFO "Restoring databases..."
    
    log WARNING "Database restoration requires running database containers"
    log WARNING "Please ensure your database services are running before proceeding"
    
    # List available database backups
    local db_backups=()
    for db_file in "$BACKUP_ROOT"/databases/*.sql.gz; do
        [[ -f "$db_file" ]] || continue
        db_backups+=("$(basename "$db_file")")
    done
    
    if [[ ${#db_backups[@]} -gt 0 ]]; then
        log INFO "Available database backups:"
        for backup in "${db_backups[@]}"; do
            log INFO "  - $backup"
        done
        
        log INFO "Database restoration commands:"
        log INFO "PostgreSQL: zcat $BACKUP_ROOT/databases/[backup_file] | docker exec -i [container] psql -U postgres [database]"
        log INFO "MySQL: zcat $BACKUP_ROOT/databases/[backup_file] | docker exec -i [container] mysql -u root -p"
        log INFO "Redis: docker cp $BACKUP_ROOT/databases/[backup_file] [container]:/data/"
    fi
}

# Restore N8N workflows
restore_n8n() {
    log INFO "Restoring N8N workflows..."
    
    local n8n_files=()
    for n8n_file in "$BACKUP_ROOT"/n8n/*_workflows_*.json; do
        [[ -f "$n8n_file" ]] || continue
        n8n_files+=("$n8n_file")
    done
    
    if [[ ${#n8n_files[@]} -gt 0 ]]; then
        log INFO "Found ${#n8n_files[@]} N8N workflow backup(s)"
        
        # Check for running N8N containers
        local n8n_containers
        n8n_containers=$(docker ps --format "{{.Names}}" | grep n8n || echo "")
        
        if [[ -n "$n8n_containers" ]]; then
            for container in $n8n_containers; do
                log INFO "Restoring workflows to N8N container: $container"
                
                for workflow_file in "${n8n_files[@]}"; do
                    # Copy workflow file to container
                    if docker cp "$workflow_file" "$container:/tmp/workflows.json"; then
                        # Import workflows
                        if docker exec "$container" n8n import:workflow --input=/tmp/workflows.json >/dev/null 2>&1; then
                            log SUCCESS "Workflows imported to: $container"
                        else
                            log WARNING "Failed to import workflows to: $container"
                        fi
                    fi
                done
            done
        else
            log WARNING "No running N8N containers found"
            log INFO "Manual restoration required after starting N8N services"
        fi
    fi
}

# Restore Docker configurations
restore_docker_configs() {
    log INFO "Restoring Docker configurations..."
    
    # List available configurations
    local config_files
    config_files=$(find "$BACKUP_ROOT/docker" -name "*.json" | wc -l)
    
    if [[ $config_files -gt 0 ]]; then
        log INFO "Found $config_files Docker configuration files"
        log INFO "Configuration files are available at: $BACKUP_ROOT/docker/"
        log WARNING "Manual review and restoration of Docker services is recommended"
    fi
}

# Generate restoration report
generate_report() {
    local report_file="/tmp/disaster_recovery_report_$(date +%s).txt"
    
    cat > "$report_file" << REPORT_EOF
# MacSpark Disaster Recovery Report
Generated: $(date -Iseconds)
Backup File: $BACKUP_FILE
Recovery Directory: $BACKUP_ROOT

## Recovery Summary
- Backup extracted successfully
- Docker volumes processed
- Database backups identified
- N8N workflows processed
- Configuration files extracted

## Next Steps
1. Verify all Docker volumes are restored correctly
2. Start your Docker services/stacks
3. Restore databases manually using provided backups
4. Import N8N workflows if containers are running
5. Review and apply Docker configurations as needed
6. Perform application-level verification

## Important Locations
- Recovery log: $LOG_FILE
- Backup contents: $BACKUP_ROOT
- This report: $report_file

## Manual Commands for Database Restoration
See the log file for specific database restoration commands.

## Verification Commands
- docker volume ls
- docker service ls
- docker stack ls
- docker ps

REPORT_EOF
    
    log SUCCESS "Recovery report generated: $report_file"
}

# Cleanup function
cleanup() {
    log INFO "Cleaning up temporary files..."
    
    if [[ "$1" == "--keep-backup" ]]; then
        log INFO "Keeping backup files at: $BACKUP_ROOT"
    else
        if [[ -d "$RESTORE_DIR" ]]; then
            rm -rf "$RESTORE_DIR"
            log INFO "Temporary directory cleaned up"
        fi
    fi
}

# Main recovery process
main() {
    print_banner
    
    log INFO "Starting MacSpark Enterprise Disaster Recovery"
    log INFO "Backup file: $BACKUP_FILE"
    log INFO "Recovery log: $LOG_FILE"
    echo ""
    
    # Validate prerequisites
    if ! validate_prerequisites; then
        log ERROR "Prerequisites validation failed. Aborting recovery."
        exit 1
    fi
    
    # Extract backup
    if ! extract_backup; then
        log ERROR "Backup extraction failed. Aborting recovery."
        exit 1
    fi
    
    # Perform recovery operations
    restore_volumes
    restore_databases
    restore_n8n
    restore_docker_configs
    
    # Generate report
    generate_report
    
    echo ""
    log SUCCESS "╔════════════════════════════════════════════════════════════════════════════╗"
    log SUCCESS "║                    DISASTER RECOVERY COMPLETED                            ║"
    log SUCCESS "╚════════════════════════════════════════════════════════════════════════════╝"
    echo ""
    log INFO "Next steps:"
    log INFO "1. Start your Docker services: docker stack deploy -c [stack-file] [stack-name]"
    log INFO "2. Verify services: docker service ls && docker ps"
    log INFO "3. Check application functionality"
    log INFO "4. Monitor logs: docker service logs [service-name]"
    echo ""
    log INFO "For detailed recovery information, see: $LOG_FILE"
    
    # Ask about cleanup
    read -p "Keep extracted backup files? [y/N]: " -r
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        cleanup --keep-backup
    else
        cleanup
    fi
}

# Execute main function
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi
RECOVERY_SCRIPT_EOF

    # Replace placeholders
    sed -i "s/TIMESTAMP_PLACEHOLDER/$(date -Iseconds)/g" "$recovery_script"
    sed -i "s/VERSION_PLACEHOLDER/$VERSION/g" "$recovery_script"
    
    chmod +x "$recovery_script"
    log INFO "✅ Enhanced recovery script created: $(basename "$recovery_script")"
}

# Cleanup temporary backup directory
cleanup_backup_directory() {
    log INFO "🧹 Cleaning up temporary backup directory..."
    
    if [[ -d "$BACKUP_ROOT" ]]; then
        # Remove the temporary backup directory
        rm -rf "$BACKUP_ROOT"
        log INFO "✅ Temporary backup directory cleaned up"
    fi
    
    # Clean up any temporary containers
    docker container prune -f --filter "label=macspark.backup.temp=true" >/dev/null 2>&1 || true
}

# Generate final report
generate_final_report() {
    local end_time=$(date +%s)
    local duration=$((end_time - START_TIME))
    
    log INFO "📋 Generating final backup report..."
    
    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║                    CRITICAL BACKUP COMPLETED SUCCESSFULLY                     ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${BLUE}📊 BACKUP SUMMARY REPORT${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "🎯 Backup Type: Critical Complete Enterprise Backup"
    echo "📅 Date: $(date '+%Y-%m-%d %H:%M:%S')"
    echo "⏱️ Duration: $(printf '%02d:%02d:%02d' $((duration/3600)) $((duration%3600/60)) $((duration%60)))"
    echo "🏷️ Version: $VERSION"
    echo "🔧 Engine: $BACKUP_ENGINE"
    echo ""
    echo -e "${BLUE}📁 FILE LOCATIONS${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "📦 Archive: $BACKUP_LOCATION/$FINAL_ARCHIVE"
    echo "💾 Size: $(numfmt --to=iec $ARCHIVE_SIZE)"
    echo "🔒 Checksums: $BACKUP_LOCATION/$CHECKSUM_FILE"
    echo "🔧 Recovery Script: $BACKUP_LOCATION/RECOVERY_SCRIPT_${TIMESTAMP}.sh"
    echo "📋 Manifest: Included in archive"
    echo ""
    echo -e "${BLUE}📈 BACKUP STATISTICS${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    # Calculate statistics
    local database_count=$(find "$BACKUP_LOCATION/backup_$TIMESTAMP/databases" -type f 2>/dev/null | wc -l)
    local volume_count=$(find "$BACKUP_LOCATION/backup_$TIMESTAMP/volumes" -type f 2>/dev/null | wc -l)
    local n8n_count=$(find "$BACKUP_LOCATION/backup_$TIMESTAMP/n8n" -type f 2>/dev/null | wc -l)
    local docker_count=$(find "$BACKUP_LOCATION/backup_$TIMESTAMP/docker" -type f 2>/dev/null | wc -l)
    local system_count=$(find "$BACKUP_LOCATION/backup_$TIMESTAMP/system" -type f 2>/dev/null | wc -l)
    
    echo "🗄️ Database backups: $database_count files"
    echo "📂 Docker volumes: $volume_count volumes"
    echo "🔧 N8N components: $n8n_count files"
    echo "🐳 Docker configs: $docker_count configurations"
    echo "⚙️ System configs: $system_count files"
    echo ""
    echo -e "${GREEN}✅ ENTERPRISE BACKUP COMPLETE - DISASTER RECOVERY READY${NC}"
    echo ""
    echo -e "${YELLOW}🚀 RECOVERY INSTRUCTIONS${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "1. 📋 Copy archive to new system: scp $FINAL_ARCHIVE user@newhost:/path/"
    echo "2. 🔧 Run recovery script: ./RECOVERY_SCRIPT_${TIMESTAMP}.sh $FINAL_ARCHIVE"
    echo "3. ✅ Verify restoration: docker service ls && docker ps"
    echo "4. 🔍 Check application health: curl http://your-services/health"
    echo ""
    echo -e "${BLUE}📊 COMPLIANCE AND AUDIT${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "🔒 Encryption: $([ "$ENCRYPTION_ENABLED" = "true" ] && echo "Enabled (AES-256)" || echo "Disabled")"
    echo "📋 Manifest: Complete recovery procedures included"
    echo "🔍 Verification: Archive integrity verified"
    echo "📝 Audit Trail: Comprehensive logging enabled"
    echo "⏰ Retention: $BACKUP_RETENTION_DAILY (configurable)"
    echo ""
    
    # Send success notification
    if command -v "$SCRIPT_DIR/../monitoring/notification-system.sh" >/dev/null; then
        "$SCRIPT_DIR/../monitoring/notification-system.sh" --success "Critical Complete Backup" \
            "$(numfmt --to=iec $ARCHIVE_SIZE)" "$(printf '%02d:%02d:%02d' $((duration/3600)) $((duration%3600/60)) $((duration%60)))" \
            2>/dev/null || true
    fi
    
    # Record final metrics
    record_duration "critical-complete" "$duration"
    increment_counter "backup_operations_total" "success" "critical-complete"
}

# Main execution function
main() {
    local START_TIME=$(date +%s)
    
    log INFO "🚀 MacSpark Enterprise Critical Complete Backup $VERSION"
    log INFO "═══════════════════════════════════════════════════════════════════════════════"
    log INFO "🎯 Starting enterprise-grade critical backup with 2025 best practices"
    log INFO "📊 Engine: $BACKUP_ENGINE | Compression: Level $COMPRESSION_LEVEL | Encryption: $ENCRYPTION_ENABLED"
    echo ""
    
    # Create OpenTelemetry span
    start_span "backup_critical_complete" "$(basename "$0")" 2>/dev/null || true
    
    # Initialize metrics
    init_metrics 2>/dev/null || true
    
    # Validate configuration
    if ! validate_configuration; then
        log ERROR "Configuration validation failed"
        exit 1
    fi
    
    # Pre-flight health checks
    if ! run_preflight_checks; then
        log WARNING "Some preflight checks failed - continuing with caution"
    fi
    
    # Create backup structure
    export BACKUP_ROOT="$BACKUP_LOCATION/backup_$TIMESTAMP"
    mkdir -p "$BACKUP_ROOT"/{databases,volumes,configs,secrets,n8n,evolution,docker,system}
    
    log INFO "📁 Backup directory: $BACKUP_ROOT"
    log INFO "⏱️ Started: $(date '+%Y-%m-%d %H:%M:%S')"
    echo ""
    
    # Execute backup phases
    discover_and_backup_databases
    backup_n8n_workflows
    backup_docker_volumes
    backup_docker_configurations
    backup_system_configurations
    create_recovery_manifest
    create_final_archive
    generate_recovery_script
    cleanup_backup_directory
    
    # Generate final report
    generate_final_report
    
    log INFO "🎉 Critical complete backup finished successfully"
    
    # Copy to cloud sync if configured
    if [[ -n "${BACKUP_CLOUD_SYNC_DIR:-}" ]] && [[ -d "$BACKUP_CLOUD_SYNC_DIR" ]]; then
        log INFO "📤 Copying to cloud sync directory..."
        cp "$BACKUP_LOCATION/$FINAL_ARCHIVE" "$BACKUP_CLOUD_SYNC_DIR/" 2>/dev/null || true
        cp "$BACKUP_LOCATION/$CHECKSUM_FILE" "$BACKUP_CLOUD_SYNC_DIR/" 2>/dev/null || true
    fi
}

# Execute main function if script is run directly
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi