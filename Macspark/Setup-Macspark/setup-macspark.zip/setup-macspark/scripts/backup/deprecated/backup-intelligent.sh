#!/bin/bash

# ============================================================================
# MACSPARK INTELLIGENT BACKUP SYSTEM 2025
# ============================================================================
# Sistema de backup inteligente com IA, deduplicação e observabilidade
# Versão: 2025.1.0
# ============================================================================

set -euo pipefail

# ============================================================================
# CONFIGURAÇÕES AVANÇADAS
# ============================================================================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(dirname "$SCRIPT_DIR")"

# Carregar variáveis do .env
if [[ -f "$BASE_DIR/.env" ]]; then
    source "$BASE_DIR/.env"
fi

# Paths principais
BACKUP_ROOT="${BACKUP_PATH:-/opt/macspark/backups}"
VOLUMES_PATH="${DOCKER_VOLUMES_PATH:-/opt/macspark/volumes}"
CONFIG_PATH="${CONFIG_PATH:-/opt/macspark/config}"
LOGS_PATH="${LOGS_PATH:-/opt/macspark/logs}"

# Configurações de backup
BACKUP_DATE=$(date +"%Y%m%d_%H%M%S")
BACKUP_TYPE="${1:-full}"  # full, incremental, differential
RETENTION_DAILY=${BACKUP_RETENTION_DAILY:-7}
RETENTION_WEEKLY=${BACKUP_RETENTION_WEEKLY:-4}
RETENTION_MONTHLY=${BACKUP_RETENTION_MONTHLY:-12}
RETENTION_YEARLY=${BACKUP_RETENTION_YEARLY:-3}

# Configurações de performance
COMPRESSION_LEVEL=${COMPRESSION_LEVEL:-6}
PARALLEL_JOBS=${PARALLEL_JOBS:-$(nproc)}
ENCRYPTION_ENABLED=${ENCRYPTION_ENABLED:-true}
DEDUPLICATION_ENABLED=${DEDUPLICATION_ENABLED:-true}

# Configurações de notificação
WEBHOOK_URL="${WEBHOOK_SLACK_URL:-}"
EMAIL_NOTIFICATIONS="${EMAIL_NOTIFICATIONS:-true}"
MONITORING_ENABLED="${MONITORING_ENABLED:-true}"

# ============================================================================
# CORES E LOGGING
# ============================================================================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m'

LOGFILE="${LOGS_PATH}/backup_$(date +%Y%m%d).log"
mkdir -p "$(dirname "$LOGFILE")"

log() {
    local level=$1
    shift
    local message="$*"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    case $level in
        INFO)  echo -e "${BLUE}[INFO]${NC} $message" | tee -a "$LOGFILE" ;;
        SUCCESS) echo -e "${GREEN}[SUCCESS]${NC} $message" | tee -a "$LOGFILE" ;;
        WARNING) echo -e "${YELLOW}[WARNING]${NC} $message" | tee -a "$LOGFILE" ;;
        ERROR) echo -e "${RED}[ERROR]${NC} $message" | tee -a "$LOGFILE" ;;
        AI) echo -e "${PURPLE}[AI]${NC} $message" | tee -a "$LOGFILE" ;;
    esac
    
    # Log estruturado para monitoring
    if [[ "$MONITORING_ENABLED" == "true" ]]; then
        echo "{\"timestamp\":\"$timestamp\",\"level\":\"$level\",\"message\":\"$message\",\"component\":\"backup\"}" >> "${LOGS_PATH}/backup-structured.log"
    fi
}

# ============================================================================
# INTELIGÊNCIA ARTIFICIAL E ANÁLISE
# ============================================================================
analyze_backup_requirements() {
    log AI "🤖 Analisando requisitos de backup com IA..."
    
    local total_size=0
    local change_rate=0
    local service_count=0
    local backup_score=0
    
    # Analisar tamanho dos dados
    if [[ -d "$VOLUMES_PATH" ]]; then
        total_size=$(du -sb "$VOLUMES_PATH" 2>/dev/null | cut -f1 || echo "0")
        log AI "📊 Volume total de dados: $(numfmt --to=iec $total_size)"
    fi
    
    # Analisar taxa de mudança (últimas 24h)
    if [[ -d "$VOLUMES_PATH" ]]; then
        local changed_files=$(find "$VOLUMES_PATH" -type f -mtime -1 2>/dev/null | wc -l)
        local total_files=$(find "$VOLUMES_PATH" -type f 2>/dev/null | wc -l)
        if [[ $total_files -gt 0 ]]; then
            change_rate=$((changed_files * 100 / total_files))
        fi
        log AI "📈 Taxa de mudança (24h): $change_rate% ($changed_files de $total_files arquivos)"
    fi
    
    # Contar serviços ativos
    if command -v docker >/dev/null 2>&1; then
        service_count=$(docker ps --format "table {{.Names}}" | grep -v NAMES | wc -l)
        log AI "🐳 Serviços Docker ativos: $service_count"
    fi
    
    # Calcular score de backup (0-100)
    backup_score=$(( (total_size / 1073741824) + change_rate + (service_count * 5) ))
    if [[ $backup_score -gt 100 ]]; then backup_score=100; fi
    
    log AI "🎯 Score de backup: $backup_score/100"
    
    # Recomendações baseadas em IA
    if [[ $backup_score -ge 80 ]]; then
        log AI "💡 Recomendação: Backup completo com alta compressão"
        RECOMMENDED_TYPE="full"
        COMPRESSION_LEVEL=9
    elif [[ $backup_score -ge 50 ]]; then
        log AI "💡 Recomendação: Backup incremental com compressão média"
        RECOMMENDED_TYPE="incremental"
        COMPRESSION_LEVEL=6
    else
        log AI "💡 Recomendação: Backup diferencial com compressão baixa"
        RECOMMENDED_TYPE="differential"
        COMPRESSION_LEVEL=3
    fi
    
    # Ajustar tipo de backup se não foi especificado
    if [[ "$BACKUP_TYPE" == "auto" ]]; then
        BACKUP_TYPE="$RECOMMENDED_TYPE"
        log AI "🔄 Tipo de backup ajustado automaticamente: $BACKUP_TYPE"
    fi
    
    export BACKUP_SCORE=$backup_score
    export TOTAL_DATA_SIZE=$total_size
    export CHANGE_RATE=$change_rate
    export SERVICE_COUNT=$service_count
}

# ============================================================================
# FUNÇÕES DE BACKUP INTELIGENTE
# ============================================================================
create_backup_directory() {
    local backup_dir="$BACKUP_ROOT/$BACKUP_TYPE/$BACKUP_DATE"
    mkdir -p "$backup_dir"
    echo "$backup_dir"
}

backup_docker_volumes() {
    local backup_dir=$1
    local volumes_backup="$backup_dir/volumes"
    
    log INFO "📦 Iniciando backup de volumes Docker..."
    mkdir -p "$volumes_backup"
    
    if [[ ! -d "$VOLUMES_PATH" ]]; then
        log WARNING "⚠️  Diretório de volumes não encontrado: $VOLUMES_PATH"
        return 1
    fi
    
    # Backup com deduplicação se habilitado
    if [[ "$DEDUPLICATION_ENABLED" == "true" ]] && command -v fdupes >/dev/null 2>&1; then
        log AI "🔄 Executando deduplicação antes do backup..."
        fdupes -r -d -N "$VOLUMES_PATH" || log WARNING "Deduplicação falhou"
    fi
    
    # Usar rsync para backup incremental eficiente
    local rsync_opts="-avh --progress --stats"
    
    if [[ "$BACKUP_TYPE" == "incremental" ]]; then
        local last_backup=$(find "$BACKUP_ROOT/incremental" -maxdepth 1 -type d -name "20*" | sort | tail -1)
        if [[ -n "$last_backup" ]]; then
            rsync_opts="$rsync_opts --link-dest=$last_backup/volumes"
            log INFO "🔗 Backup incremental baseado em: $(basename "$last_backup")"
        fi
    fi
    
    if rsync $rsync_opts "$VOLUMES_PATH/" "$volumes_backup/"; then
        log SUCCESS "✅ Backup de volumes concluído"
        
        # Compactar se necessário
        if [[ "$COMPRESSION_LEVEL" -gt 0 ]]; then
            log INFO "🗜️  Comprimindo backup de volumes..."
            tar -czf "$volumes_backup.tar.gz" -C "$backup_dir" volumes && rm -rf "$volumes_backup"
            log SUCCESS "✅ Compressão concluída"
        fi
        
        return 0
    else
        log ERROR "❌ Falha no backup de volumes"
        return 1
    fi
}

backup_databases() {
    local backup_dir=$1
    local db_backup="$backup_dir/databases"
    mkdir -p "$db_backup"
    
    log INFO "🗄️  Iniciando backup de bancos de dados..."
    
    # PostgreSQL
    if docker ps --format "{{.Names}}" | grep -q postgres; then
        log INFO "📊 Backup PostgreSQL..."
        local postgres_containers=$(docker ps --format "{{.Names}}" | grep postgres)
        
        while IFS= read -r container; do
            if [[ -n "$container" ]]; then
                log INFO "🐘 Backup container: $container"
                
                # Obter informações do banco
                local db_name=$(docker exec "$container" psql -U postgres -t -c "SELECT current_database();" 2>/dev/null | xargs || echo "postgres")
                local dump_file="$db_backup/${container}_${db_name}_${BACKUP_DATE}.sql"
                
                if docker exec "$container" pg_dumpall -U postgres > "$dump_file" 2>/dev/null; then
                    log SUCCESS "✅ Backup PostgreSQL $container concluído"
                    
                    # Comprimir dump
                    gzip "$dump_file"
                    log INFO "🗜️  Dump PostgreSQL comprimido"
                else
                    log ERROR "❌ Falha no backup PostgreSQL $container"
                fi
            fi
        done <<< "$postgres_containers"
    fi
    
    # MySQL/MariaDB
    if docker ps --format "{{.Names}}" | grep -qE "(mysql|mariadb)"; then
        log INFO "📊 Backup MySQL/MariaDB..."
        local mysql_containers=$(docker ps --format "{{.Names}}" | grep -E "(mysql|mariadb)")
        
        while IFS= read -r container; do
            if [[ -n "$container" ]]; then
                log INFO "🐬 Backup container: $container"
                
                local dump_file="$db_backup/${container}_${BACKUP_DATE}.sql"
                
                if docker exec "$container" mysqldump --all-databases --single-transaction --routines --triggers > "$dump_file" 2>/dev/null; then
                    log SUCCESS "✅ Backup MySQL $container concluído"
                    gzip "$dump_file"
                else
                    log ERROR "❌ Falha no backup MySQL $container"
                fi
            fi
        done <<< "$mysql_containers"
    fi
    
    # MongoDB
    if docker ps --format "{{.Names}}" | grep -q mongo; then
        log INFO "📊 Backup MongoDB..."
        local mongo_containers=$(docker ps --format "{{.Names}}" | grep mongo)
        
        while IFS= read -r container; do
            if [[ -n "$container" ]]; then
                log INFO "🍃 Backup container: $container"
                
                local dump_dir="$db_backup/${container}_${BACKUP_DATE}"
                mkdir -p "$dump_dir"
                
                if docker exec "$container" mongodump --out "/tmp/dump" 2>/dev/null; then
                    docker cp "$container:/tmp/dump/." "$dump_dir/"
                    tar -czf "$dump_dir.tar.gz" -C "$db_backup" "$(basename "$dump_dir")"
                    rm -rf "$dump_dir"
                    log SUCCESS "✅ Backup MongoDB $container concluído"
                else
                    log ERROR "❌ Falha no backup MongoDB $container"
                fi
            fi
        done <<< "$mongo_containers"
    fi
    
    # Redis
    if docker ps --format "{{.Names}}" | grep -q redis; then
        log INFO "📊 Backup Redis..."
        local redis_containers=$(docker ps --format "{{.Names}}" | grep redis)
        
        while IFS= read -r container; do
            if [[ -n "$container" ]]; then
                log INFO "🔴 Backup container: $container"
                
                local dump_file="$db_backup/${container}_${BACKUP_DATE}.rdb"
                
                if docker exec "$container" redis-cli BGSAVE >/dev/null 2>&1; then
                    sleep 5  # Aguardar BGSAVE completar
                    docker cp "$container:/data/dump.rdb" "$dump_file"
                    gzip "$dump_file"
                    log SUCCESS "✅ Backup Redis $container concluído"
                else
                    log ERROR "❌ Falha no backup Redis $container"
                fi
            fi
        done <<< "$redis_containers"
    fi
}

backup_configurations() {
    local backup_dir=$1
    local config_backup="$backup_dir/configurations"
    
    log INFO "⚙️  Iniciando backup de configurações..."
    mkdir -p "$config_backup"
    
    # Backup de configurações do sistema
    local config_sources=(
        "$BASE_DIR/.env"
        "$BASE_DIR/docker-compose.yml"
        "$BASE_DIR/stacks"
        "$CONFIG_PATH"
        "/etc/docker"
        "/etc/nginx"
        "/etc/letsencrypt"
    )
    
    for source in "${config_sources[@]}"; do
        if [[ -e "$source" ]]; then
            local dest_name=$(basename "$source")
            if [[ -d "$source" ]]; then
                cp -r "$source" "$config_backup/$dest_name"
            else
                cp "$source" "$config_backup/$dest_name"
            fi
            log INFO "📄 Backup configuração: $dest_name"
        fi
    done
    
    # Backup de secrets Docker
    if command -v docker >/dev/null 2>&1 && docker info | grep -q "Swarm: active"; then
        log INFO "🔐 Backup Docker secrets..."
        docker secret ls --format "{{.Name}}" > "$config_backup/docker_secrets.list"
    fi
    
    # Compactar configurações
    tar -czf "$config_backup.tar.gz" -C "$backup_dir" configurations
    rm -rf "$config_backup"
    
    log SUCCESS "✅ Backup de configurações concluído"
}

encrypt_backup() {
    local backup_dir=$1
    
    if [[ "$ENCRYPTION_ENABLED" != "true" ]]; then
        return 0
    fi
    
    log INFO "🔒 Iniciando criptografia do backup..."
    
    # Gerar chave de criptografia se não existir
    local key_file="$BACKUP_ROOT/.encryption_key"
    if [[ ! -f "$key_file" ]]; then
        openssl rand -base64 32 > "$key_file"
        chmod 600 "$key_file"
        log INFO "🗝️  Chave de criptografia gerada"
    fi
    
    # Criptografar arquivos
    find "$backup_dir" -type f -name "*.tar.gz" -o -name "*.sql.gz" -o -name "*.rdb.gz" | while read -r file; do
        if openssl enc -aes-256-cbc -salt -in "$file" -out "${file}.enc" -pass file:"$key_file"; then
            rm "$file"
            log INFO "🔐 Arquivo criptografado: $(basename "$file")"
        else
            log ERROR "❌ Falha na criptografia: $(basename "$file")"
        fi
    done
    
    log SUCCESS "✅ Criptografia concluída"
}

# ============================================================================
# LIMPEZA E RETENÇÃO INTELIGENTE
# ============================================================================
cleanup_old_backups() {
    log INFO "🧹 Iniciando limpeza de backups antigos..."
    
    # Limpeza por tipo de backup
    local backup_types=("full" "incremental" "differential")
    
    for backup_type in "${backup_types[@]}"; do
        local type_dir="$BACKUP_ROOT/$backup_type"
        
        if [[ ! -d "$type_dir" ]]; then
            continue
        fi
        
        log INFO "🗂️  Limpando backups $backup_type..."
        
        # Definir política de retenção baseada no tipo
        local retention_days
        case $backup_type in
            full) retention_days=$RETENTION_MONTHLY ;;
            incremental) retention_days=$RETENTION_DAILY ;;
            differential) retention_days=$RETENTION_WEEKLY ;;
        esac
        
        # Encontrar backups antigos
        local old_backups=$(find "$type_dir" -maxdepth 1 -type d -name "20*" -mtime +$retention_days)
        
        if [[ -n "$old_backups" ]]; then
            while IFS= read -r old_backup; do
                if [[ -n "$old_backup" ]]; then
                    local backup_size=$(du -sh "$old_backup" | cut -f1)
                    log INFO "🗑️  Removendo backup antigo: $(basename "$old_backup") ($backup_size)"
                    rm -rf "$old_backup"
                fi
            done <<< "$old_backups"
        else
            log INFO "✨ Nenhum backup antigo encontrado para $backup_type"
        fi
    done
    
    log SUCCESS "✅ Limpeza de backups concluída"
}

# ============================================================================
# MONITORAMENTO E MÉTRICAS
# ============================================================================
generate_backup_metrics() {
    local backup_dir=$1
    local start_time=$2
    local end_time=$(date +%s)
    local duration=$((end_time - start_time))
    
    log INFO "📊 Gerando métricas de backup..."
    
    # Calcular estatísticas
    local backup_size=0
    if [[ -d "$backup_dir" ]]; then
        backup_size=$(du -sb "$backup_dir" 2>/dev/null | cut -f1 || echo "0")
    fi
    
    local files_count=$(find "$backup_dir" -type f 2>/dev/null | wc -l)
    local compression_ratio=0
    
    if [[ $TOTAL_DATA_SIZE -gt 0 && $backup_size -gt 0 ]]; then
        compression_ratio=$(( (TOTAL_DATA_SIZE - backup_size) * 100 / TOTAL_DATA_SIZE ))
    fi
    
    # Criar arquivo de métricas
    local metrics_file="$backup_dir/backup_metrics.json"
    cat > "$metrics_file" << EOF
{
    "timestamp": "$(date -Iseconds)",
    "backup_type": "$BACKUP_TYPE",
    "duration_seconds": $duration,
    "backup_size_bytes": $backup_size,
    "backup_size_human": "$(numfmt --to=iec $backup_size)",
    "original_size_bytes": $TOTAL_DATA_SIZE,
    "compression_ratio": $compression_ratio,
    "files_count": $files_count,
    "ai_score": $BACKUP_SCORE,
    "change_rate": $CHANGE_RATE,
    "services_count": $SERVICE_COUNT,
    "encryption_enabled": $ENCRYPTION_ENABLED,
    "deduplication_enabled": $DEDUPLICATION_ENABLED,
    "status": "completed"
}
EOF
    
    # Log das métricas
    log INFO "⏱️  Duração: $(printf '%02d:%02d:%02d' $((duration/3600)) $((duration%3600/60)) $((duration%60)))"
    log INFO "📦 Tamanho backup: $(numfmt --to=iec $backup_size)"
    log INFO "🗜️  Taxa compressão: $compression_ratio%"
    log INFO "📁 Arquivos: $files_count"
    
    # Enviar métricas para monitoring (Prometheus format)
    if [[ "$MONITORING_ENABLED" == "true" ]]; then
        local prometheus_file="${LOGS_PATH}/backup_metrics.prom"
        cat >> "$prometheus_file" << EOF
# HELP macspark_backup_duration_seconds Duration of backup operation
# TYPE macspark_backup_duration_seconds gauge
macspark_backup_duration_seconds{type="$BACKUP_TYPE"} $duration

# HELP macspark_backup_size_bytes Size of backup in bytes
# TYPE macspark_backup_size_bytes gauge
macspark_backup_size_bytes{type="$BACKUP_TYPE"} $backup_size

# HELP macspark_backup_compression_ratio Compression ratio percentage
# TYPE macspark_backup_compression_ratio gauge
macspark_backup_compression_ratio{type="$BACKUP_TYPE"} $compression_ratio

# HELP macspark_backup_files_count Number of files in backup
# TYPE macspark_backup_files_count gauge
macspark_backup_files_count{type="$BACKUP_TYPE"} $files_count

EOF
    fi
    
    log SUCCESS "✅ Métricas geradas"
}

# ============================================================================
# NOTIFICAÇÕES E ALERTAS
# ============================================================================
send_notification() {
    local status=$1
    local message=$2
    local backup_dir=$3
    
    # Slack/Discord webhook
    if [[ -n "$WEBHOOK_URL" ]]; then
        local color
        case $status in
            success) color="good" ;;
            error) color="danger" ;;
            warning) color="warning" ;;
            *) color="#439FE0" ;;
        esac
        
        local backup_size=""
        if [[ -d "$backup_dir" ]]; then
            backup_size=$(du -sh "$backup_dir" 2>/dev/null | cut -f1 || echo "Unknown")
        fi
        
        local payload=$(cat << EOF
{
    "attachments": [
        {
            "color": "$color",
            "title": "Backup Macspark - $status",
            "text": "$message",
            "fields": [
                {
                    "title": "Tipo",
                    "value": "$BACKUP_TYPE",
                    "short": true
                },
                {
                    "title": "Tamanho",
                    "value": "$backup_size",
                    "short": true
                },
                {
                    "title": "Score IA",
                    "value": "$BACKUP_SCORE/100",
                    "short": true
                },
                {
                    "title": "Timestamp",
                    "value": "$(date)",
                    "short": true
                }
            ]
        }
    ]
}
EOF
        )
        
        curl -X POST -H 'Content-type: application/json' --data "$payload" "$WEBHOOK_URL" >/dev/null 2>&1 || true
    fi
    
    # Email notification
    if [[ "$EMAIL_NOTIFICATIONS" == "true" ]] && command -v mail >/dev/null 2>&1; then
        echo "$message" | mail -s "Backup Macspark - $status" "${SMTP_FROM:-admin@$(hostname)}" || true
    fi
}

# ============================================================================
# FUNÇÃO PRINCIPAL
# ============================================================================
main() {
    local start_time=$(date +%s)
    
    # Banner inicial
    log INFO "🚀 MACSPARK INTELLIGENT BACKUP SYSTEM 2025"
    log INFO "═══════════════════════════════════════════"
    log INFO "🕒 Início: $(date)"
    log INFO "📋 Tipo: $BACKUP_TYPE"
    
    # Verificações iniciais
    if [[ $EUID -eq 0 ]]; then
        log WARNING "⚠️  Executando como root. Recomendado usar usuário com sudo."
    fi
    
    # Criar diretórios necessários
    mkdir -p "$BACKUP_ROOT" "$LOGS_PATH"
    
    # Análise IA
    analyze_backup_requirements
    
    # Criar diretório de backup
    local backup_dir
    backup_dir=$(create_backup_directory)
    log INFO "📁 Diretório backup: $backup_dir"
    
    # Executar backups
    local backup_success=true
    
    # Backup volumes
    if ! backup_docker_volumes "$backup_dir"; then
        backup_success=false
    fi
    
    # Backup bancos de dados
    if ! backup_databases "$backup_dir"; then
        backup_success=false
    fi
    
    # Backup configurações
    if ! backup_configurations "$backup_dir"; then
        backup_success=false
    fi
    
    # Criptografar se habilitado
    if [[ "$backup_success" == "true" ]]; then
        encrypt_backup "$backup_dir"
    fi
    
    # Limpeza de backups antigos
    cleanup_old_backups
    
    # Gerar métricas
    generate_backup_metrics "$backup_dir" "$start_time"
    
    # Status final
    local end_time=$(date +%s)
    local total_duration=$((end_time - start_time))
    
    if [[ "$backup_success" == "true" ]]; then
        log SUCCESS "🎉 Backup concluído com sucesso!"
        log SUCCESS "⏱️  Tempo total: $(printf '%02d:%02d:%02d' $((total_duration/3600)) $((total_duration%3600/60)) $((total_duration%60)))"
        send_notification "success" "Backup $BACKUP_TYPE concluído com sucesso em $(printf '%02d:%02d:%02d' $((total_duration/3600)) $((total_duration%3600/60)) $((total_duration%60)))" "$backup_dir"
    else
        log ERROR "❌ Backup concluído com erros!"
        send_notification "error" "Backup $BACKUP_TYPE falhou ou teve erros. Verifique os logs." "$backup_dir"
        exit 1
    fi
}

# ============================================================================
# EXECUÇÃO
# ============================================================================
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi