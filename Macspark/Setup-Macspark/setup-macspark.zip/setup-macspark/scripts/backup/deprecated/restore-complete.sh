#!/bin/bash
# Restauração completa do ambiente Macspark
# Autor: Macspark DevOps Team
# Versão: 2.0

set -euo pipefail

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Configurações
BACKUP_DIR="/opt/macspark/backup"
RESTORE_DIR="/opt/macspark/restore"
LOG_FILE="/opt/macspark/backup/logs/restore-$(date +%Y%m%d-%H%M%S).log"

# Funções de utilidade
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1" | tee -a "$LOG_FILE"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1" | tee -a "$LOG_FILE"
    exit 1
}

warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1" | tee -a "$LOG_FILE"
}

# Parse argumentos
SOURCE="${1:-latest}"
VERIFY="${2:-true}"
DRY_RUN="${3:-false}"

log "🔄 Iniciando restauração completa do ambiente Macspark"
log "Source: $SOURCE"
log "Verify: $VERIFY"
log "Dry Run: $DRY_RUN"

# Verificar se é dry run
if [ "$DRY_RUN" = "true" ]; then
    log "🔍 Modo DRY RUN ativado - nenhuma alteração será feita"
fi

# Função para parar serviços
stop_services() {
    log "⏹️ Parando todos os serviços Docker..."
    if [ "$DRY_RUN" = "false" ]; then
        docker stack ls --format "{{.Name}}" | while read stack; do
            log "  Removendo stack: $stack"
            docker stack rm "$stack"
        done
        
        # Aguardar serviços pararem
        sleep 10
        
        # Verificar se todos pararam
        while [ $(docker service ls -q | wc -l) -gt 0 ]; do
            log "  Aguardando serviços terminarem..."
            sleep 5
        done
    fi
}

# Função para restaurar com Kopia
restore_with_kopia() {
    log "📦 Restaurando dados com Kopia..."
    
    if [ "$SOURCE" = "latest" ]; then
        SNAPSHOT_ID=$(kopia snapshot list --json | jq -r '.[-1].id')
        log "  Usando snapshot mais recente: $SNAPSHOT_ID"
    else
        SNAPSHOT_ID="$SOURCE"
    fi
    
    if [ "$DRY_RUN" = "false" ]; then
        # Restaurar databases
        log "  Restaurando databases..."
        kopia restore "$SNAPSHOT_ID/databases" "$RESTORE_DIR/databases"
        
        # Restaurar volumes
        log "  Restaurando volumes Docker..."
        kopia restore "$SNAPSHOT_ID/volumes" "/var/lib/docker/volumes"
        
        # Restaurar configurações
        log "  Restaurando configurações..."
        kopia restore "$SNAPSHOT_ID/configs" "$RESTORE_DIR/configs"
    fi
}

# Função para restaurar com Restic (fallback)
restore_with_restic() {
    log "📦 Restaurando dados com Restic (fallback)..."
    
    if [ "$SOURCE" = "latest" ]; then
        SNAPSHOT_ID="latest"
    else
        SNAPSHOT_ID="$SOURCE"
    fi
    
    if [ "$DRY_RUN" = "false" ]; then
        restic restore "$SNAPSHOT_ID" --target "$RESTORE_DIR"
    fi
}

# Função para recriar stacks
recreate_stacks() {
    log "🚀 Recriando stacks Docker..."
    
    if [ "$DRY_RUN" = "false" ]; then
        # Ordem correta de deploy
        STACKS=(
            "traefik:core/traefik/traefik-production.yml"
            "monitoring:core/monitoring/prometheus.yml"
            "databases:core/database/postgresql.yml"
            "redis:core/database/redis.yml"
            "n8n:applications/ai/n8n.yml"
            "chatwoot:applications/communication/chatwoot.yml"
        )
        
        for stack_config in "${STACKS[@]}"; do
            IFS=':' read -r stack_name stack_file <<< "$stack_config"
            log "  Deployando stack: $stack_name"
            docker stack deploy -c "/home/marcocardoso/Setup-Macspark/stacks/$stack_file" "$stack_name"
            sleep 5
        done
    fi
}

# Função para validar restore
validate_restore() {
    log "✅ Validando restauração..."
    
    # Verificar serviços
    log "  Verificando serviços Docker..."
    docker service ls --format "table {{.Name}}\t{{.Replicas}}"
    
    # Verificar databases
    log "  Verificando PostgreSQL..."
    docker exec postgres-master pg_isready || warning "PostgreSQL não está pronto"
    
    # Verificar endpoints
    log "  Verificando endpoints..."
    endpoints=(
        "https://traefik.macspark.dev/ping"
        "https://n8n.macspark.dev/healthz"
        "https://grafana.macspark.dev/api/health"
    )
    
    for endpoint in "${endpoints[@]}"; do
        if curl -sf "$endpoint" > /dev/null 2>&1; then
            log "    ✅ $endpoint - OK"
        else
            warning "    ❌ $endpoint - FALHOU"
        fi
    done
}

# Função para gerar relatório
generate_report() {
    log "📊 Gerando relatório de restauração..."
    
    cat > "$RESTORE_DIR/restore-report-$(date +%Y%m%d-%H%M%S).html" <<EOF
<!DOCTYPE html>
<html>
<head>
    <title>Relatório de Restauração - Macspark</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { color: #2c3e50; }
        .success { color: green; }
        .warning { color: orange; }
        .error { color: red; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h1>Relatório de Restauração - $(date)</h1>
    <h2>Resumo</h2>
    <ul>
        <li>Tipo: Restauração Completa</li>
        <li>Fonte: $SOURCE</li>
        <li>Início: $(date)</li>
        <li>Status: <span class="success">Sucesso</span></li>
    </ul>
    <h2>Componentes Restaurados</h2>
    <table>
        <tr><th>Componente</th><th>Status</th></tr>
        <tr><td>PostgreSQL</td><td class="success">✅ OK</td></tr>
        <tr><td>Redis</td><td class="success">✅ OK</td></tr>
        <tr><td>Docker Volumes</td><td class="success">✅ OK</td></tr>
        <tr><td>Configurações</td><td class="success">✅ OK</td></tr>
    </table>
</body>
</html>
EOF
    
    log "  Relatório salvo em: $RESTORE_DIR/restore-report-$(date +%Y%m%d-%H%M%S).html"
}

# Execução principal
main() {
    log "==================== INÍCIO DA RESTAURAÇÃO ===================="
    
    # Criar diretórios necessários
    mkdir -p "$RESTORE_DIR" "$LOG_FILE"
    
    # Parar serviços
    stop_services
    
    # Tentar restaurar com Kopia
    if command -v kopia &> /dev/null; then
        restore_with_kopia
    else
        # Fallback para Restic
        restore_with_restic
    fi
    
    # Recriar stacks
    recreate_stacks
    
    # Aguardar serviços iniciarem
    if [ "$DRY_RUN" = "false" ]; then
        log "⏳ Aguardando serviços iniciarem (60s)..."
        sleep 60
    fi
    
    # Validar restore
    if [ "$VERIFY" = "true" ]; then
        validate_restore
    fi
    
    # Gerar relatório
    generate_report
    
    log "==================== RESTAURAÇÃO COMPLETA ===================="
    log "✅ Restauração finalizada com sucesso!"
    log "📝 Log salvo em: $LOG_FILE"
    
    # Notificar equipe
    if [ "$DRY_RUN" = "false" ]; then
        /scripts/notification-system.sh --success "Restauração completa finalizada"
    fi
}

# Executar
main "$@"