#!/bin/bash
# Restaurar Serviços Críticos - MacSpark Setup
# Gerado automaticamente em 2025-08-23

echo "🔧 Iniciando restauração de serviços críticos..."

# Verificar Docker Swarm
if ! docker node ls > /dev/null 2>&1; then
    echo "❌ Docker Swarm não está ativo"
    exit 1
fi

# Restaurar serviços essenciais um por um
echo "📊 Restaurando PostgreSQL principal..."
docker service scale postgres-mega_postgres-mega=1

echo "🔴 Restaurando Redis principal..."
docker service scale redis-consolidated_redis-master=1

echo "📱 Restaurando MacSpark App..."
docker service scale macspark-production_macspark-app=1

echo "🤖 Restaurando Agente Ultimate..."
docker service scale agente-ultimate_agente-ultimate=1

echo "🔄 Restaurando N8N..."
docker service scale n8n_n8n-postgres=1

echo "🦾 Restaurando Ollama..."
docker service scale ollama_ollama=1
docker service scale ollama_ollama-webui=1

echo "📊 Restaurando Prometheus..."
docker service scale prometheus_prometheus=1

echo "⏳ Aguardando serviços iniciarem (60s)..."
sleep 60

echo "🔍 Status final dos serviços:"
docker service ls | grep -E "(postgres-mega|redis-consolidated|macspark-production|agente-ultimate|n8n|ollama|prometheus)"

echo "✅ Restauração concluída!"