#!/bin/bash
# ============================================================================
# MACSPARK BACKUP SYSTEM - Database Backup Library
# ============================================================================
# Biblioteca unificada para backup de bancos de dados
# Suporta: PostgreSQL, MySQL, MariaDB, MongoDB, Redis
# Versão: 2025.1.0
# ============================================================================

# Carregar biblioteca de logging
source "$(dirname "${BASH_SOURCE[0]}")/logging.sh"

# Configurações padrão
BACKUP_ROOT="${BACKUP_ROOT:-/opt/macspark/backups}"
DB_BACKUP_PATH="${BACKUP_ROOT}/databases"
COMPRESSION_ENABLED="${COMPRESSION_ENABLED:-true}"
ENCRYPTION_ENABLED="${ENCRYPTION_ENABLED:-true}"

# Criar diretório de backup de databases
mkdir -p "$DB_BACKUP_PATH"

# ============================================================================
# PostgreSQL Backup
# ============================================================================
backup_postgresql() {
    local container_name=$1
    local backup_name=${2:-"postgres"}
    local timestamp=$(date +"%Y%m%d_%H%M%S")
    local backup_file="${DB_BACKUP_PATH}/${backup_name}_${timestamp}.sql"
    
    log INFO "Starting PostgreSQL backup for container: $container_name"
    
    # Verificar se o container existe e está rodando
    if ! docker ps --filter "name=$container_name" --format '{{.Names}}' | grep -q "^${container_name}$"; then
        log WARNING "PostgreSQL container $container_name not found or not running"
        return 1
    fi
    
    # Executar backup
    if docker exec "$container_name" pg_dumpall -U postgres > "$backup_file" 2>/dev/null; then
        local size=$(du -h "$backup_file" | cut -f1)
        log SUCCESS "PostgreSQL backup completed: $backup_file ($size)"
        
        # Comprimir se habilitado
        if [[ "$COMPRESSION_ENABLED" == "true" ]]; then
            gzip -9 "$backup_file"
            backup_file="${backup_file}.gz"
            size=$(du -h "$backup_file" | cut -f1)
            log INFO "Compressed to: $backup_file ($size)"
        fi
        
        log_metric "backup.database.postgresql.size" "$(stat -c%s "$backup_file")" "gauge"
        return 0
    else
        log ERROR "Failed to backup PostgreSQL container: $container_name"
        return 1
    fi
}

# ============================================================================
# MySQL/MariaDB Backup
# ============================================================================
backup_mysql() {
    local container_name=$1
    local backup_name=${2:-"mysql"}
    local timestamp=$(date +"%Y%m%d_%H%M%S")
    local backup_file="${DB_BACKUP_PATH}/${backup_name}_${timestamp}.sql"
    
    log INFO "Starting MySQL/MariaDB backup for container: $container_name"
    
    # Verificar se o container existe e está rodando
    if ! docker ps --filter "name=$container_name" --format '{{.Names}}' | grep -q "^${container_name}$"; then
        log WARNING "MySQL container $container_name not found or not running"
        return 1
    fi
    
    # Obter senha do root (tentar várias variáveis de ambiente comuns)
    local root_password=$(docker exec "$container_name" printenv MYSQL_ROOT_PASSWORD 2>/dev/null || \
                         docker exec "$container_name" printenv MARIADB_ROOT_PASSWORD 2>/dev/null || \
                         echo "")
    
    if [[ -z "$root_password" ]]; then
        log WARNING "Could not determine MySQL root password for $container_name"
        return 1
    fi
    
    # Executar backup
    if docker exec "$container_name" mysqldump --all-databases --single-transaction --routines --triggers --events \
            -u root -p"$root_password" > "$backup_file" 2>/dev/null; then
        local size=$(du -h "$backup_file" | cut -f1)
        log SUCCESS "MySQL backup completed: $backup_file ($size)"
        
        # Comprimir se habilitado
        if [[ "$COMPRESSION_ENABLED" == "true" ]]; then
            gzip -9 "$backup_file"
            backup_file="${backup_file}.gz"
            size=$(du -h "$backup_file" | cut -f1)
            log INFO "Compressed to: $backup_file ($size)"
        fi
        
        log_metric "backup.database.mysql.size" "$(stat -c%s "$backup_file")" "gauge"
        return 0
    else
        log ERROR "Failed to backup MySQL container: $container_name"
        return 1
    fi
}

# ============================================================================
# MongoDB Backup
# ============================================================================
backup_mongodb() {
    local container_name=$1
    local backup_name=${2:-"mongodb"}
    local timestamp=$(date +"%Y%m%d_%H%M%S")
    local backup_dir="${DB_BACKUP_PATH}/${backup_name}_${timestamp}"
    
    log INFO "Starting MongoDB backup for container: $container_name"
    
    # Verificar se o container existe e está rodando
    if ! docker ps --filter "name=$container_name" --format '{{.Names}}' | grep -q "^${container_name}$"; then
        log WARNING "MongoDB container $container_name not found or not running"
        return 1
    fi
    
    # Criar diretório temporário
    mkdir -p "$backup_dir"
    
    # Executar backup
    if docker exec "$container_name" mongodump --out "/tmp/mongodump" 2>/dev/null && \
       docker cp "$container_name:/tmp/mongodump" "$backup_dir/" 2>/dev/null; then
        
        # Criar arquivo tar
        tar -czf "${backup_dir}.tar.gz" -C "$(dirname "$backup_dir")" "$(basename "$backup_dir")"
        rm -rf "$backup_dir"
        
        local size=$(du -h "${backup_dir}.tar.gz" | cut -f1)
        log SUCCESS "MongoDB backup completed: ${backup_dir}.tar.gz ($size)"
        
        log_metric "backup.database.mongodb.size" "$(stat -c%s "${backup_dir}.tar.gz")" "gauge"
        return 0
    else
        log ERROR "Failed to backup MongoDB container: $container_name"
        rm -rf "$backup_dir"
        return 1
    fi
}

# ============================================================================
# Redis Backup
# ============================================================================
backup_redis() {
    local container_name=$1
    local backup_name=${2:-"redis"}
    local timestamp=$(date +"%Y%m%d_%H%M%S")
    local backup_file="${DB_BACKUP_PATH}/${backup_name}_${timestamp}.rdb"
    
    log INFO "Starting Redis backup for container: $container_name"
    
    # Verificar se o container existe e está rodando
    if ! docker ps --filter "name=$container_name" --format '{{.Names}}' | grep -q "^${container_name}$"; then
        log WARNING "Redis container $container_name not found or not running"
        return 1
    fi
    
    # Forçar BGSAVE e aguardar conclusão
    docker exec "$container_name" redis-cli BGSAVE 2>/dev/null
    sleep 2
    
    # Aguardar conclusão do BGSAVE
    while [[ $(docker exec "$container_name" redis-cli LASTSAVE 2>/dev/null) == "0" ]]; do
        sleep 1
    done
    
    # Copiar arquivo dump.rdb
    if docker cp "$container_name:/data/dump.rdb" "$backup_file" 2>/dev/null; then
        local size=$(du -h "$backup_file" | cut -f1)
        log SUCCESS "Redis backup completed: $backup_file ($size)"
        
        # Comprimir se habilitado
        if [[ "$COMPRESSION_ENABLED" == "true" ]]; then
            gzip -9 "$backup_file"
            backup_file="${backup_file}.gz"
            size=$(du -h "$backup_file" | cut -f1)
            log INFO "Compressed to: $backup_file ($size)"
        fi
        
        log_metric "backup.database.redis.size" "$(stat -c%s "$backup_file")" "gauge"
        return 0
    else
        log ERROR "Failed to backup Redis container: $container_name"
        return 1
    fi
}

# ============================================================================
# Função de descoberta automática de databases
# ============================================================================
discover_and_backup_databases() {
    log INFO "Starting automatic database discovery and backup"
    
    local total_backups=0
    local successful_backups=0
    
    # PostgreSQL
    for container in $(docker ps --filter "ancestor=postgres" --format '{{.Names}}'); do
        ((total_backups++))
        if backup_postgresql "$container"; then
            ((successful_backups++))
        fi
    done
    
    # MySQL/MariaDB
    for container in $(docker ps --filter "ancestor=mysql" --format '{{.Names}}' && \
                       docker ps --filter "ancestor=mariadb" --format '{{.Names}}'); do
        ((total_backups++))
        if backup_mysql "$container"; then
            ((successful_backups++))
        fi
    done
    
    # MongoDB
    for container in $(docker ps --filter "ancestor=mongo" --format '{{.Names}}'); do
        ((total_backups++))
        if backup_mongodb "$container"; then
            ((successful_backups++))
        fi
    done
    
    # Redis
    for container in $(docker ps --filter "ancestor=redis" --format '{{.Names}}'); do
        ((total_backups++))
        if backup_redis "$container"; then
            ((successful_backups++))
        fi
    done
    
    log INFO "Database backup summary: $successful_backups/$total_backups successful"
    log_metric "backup.database.total" "$total_backups" "gauge"
    log_metric "backup.database.successful" "$successful_backups" "gauge"
    
    return $((total_backups - successful_backups))
}

# Export das funções
export -f backup_postgresql
export -f backup_mysql
export -f backup_mongodb
export -f backup_redis
export -f discover_and_backup_databases