#!/bin/bash
# ============================================================================
# MACSPARK BACKUP SYSTEM - Docker Volumes Backup Library
# ============================================================================
# Biblioteca unificada para backup de volumes Docker
# Versão: 2025.1.0
# ============================================================================

# Carregar biblioteca de logging
source "$(dirname "${BASH_SOURCE[0]}")/logging.sh"

# Configurações padrão
BACKUP_ROOT="${BACKUP_ROOT:-/opt/macspark/backups}"
VOLUMES_BACKUP_PATH="${BACKUP_ROOT}/volumes"
COMPRESSION_ENABLED="${COMPRESSION_ENABLED:-true}"
PARALLEL_JOBS="${PARALLEL_JOBS:-$(nproc)}"

# Criar diretório de backup de volumes
mkdir -p "$VOLUMES_BACKUP_PATH"

# ============================================================================
# Backup de volume individual
# ============================================================================
backup_volume() {
    local volume_name=$1
    local timestamp=$(date +"%Y%m%d_%H%M%S")
    local backup_file="${VOLUMES_BACKUP_PATH}/${volume_name}_${timestamp}.tar"
    
    log INFO "Backing up volume: $volume_name"
    
    # Verificar se o volume existe
    if ! docker volume ls --format '{{.Name}}' | grep -q "^${volume_name}$"; then
        log WARNING "Volume $volume_name not found"
        return 1
    fi
    
    # Criar backup usando container auxiliar
    if docker run --rm \
            -v "${volume_name}:/data:ro" \
            -v "${VOLUMES_BACKUP_PATH}:/backup" \
            alpine tar -cf "/backup/$(basename "$backup_file")" -C /data . 2>/dev/null; then
        
        # Comprimir se habilitado
        if [[ "$COMPRESSION_ENABLED" == "true" ]]; then
            gzip -9 "$backup_file"
            backup_file="${backup_file}.gz"
        fi
        
        local size=$(du -h "$backup_file" | cut -f1)
        log SUCCESS "Volume backup completed: $backup_file ($size)"
        log_metric "backup.volume.${volume_name}.size" "$(stat -c%s "$backup_file")" "gauge"
        return 0
    else
        log ERROR "Failed to backup volume: $volume_name"
        return 1
    fi
}

# ============================================================================
# Backup de volumes por serviço/stack
# ============================================================================
backup_service_volumes() {
    local service_name=$1
    local volumes_found=0
    local volumes_backed_up=0
    
    log INFO "Backing up volumes for service: $service_name"
    
    # Listar containers do serviço
    local containers=$(docker ps --filter "label=com.docker.swarm.service.name=${service_name}" --format '{{.ID}}')
    
    if [[ -z "$containers" ]]; then
        # Tentar sem Swarm labels
        containers=$(docker ps --filter "name=${service_name}" --format '{{.ID}}')
    fi
    
    for container_id in $containers; do
        # Obter volumes montados no container
        local mounts=$(docker inspect "$container_id" --format '{{range .Mounts}}{{if eq .Type "volume"}}{{.Name}}{{"\n"}}{{end}}{{end}}')
        
        for volume in $mounts; do
            ((volumes_found++))
            if backup_volume "$volume"; then
                ((volumes_backed_up++))
            fi
        done
    done
    
    log INFO "Service $service_name: $volumes_backed_up/$volumes_found volumes backed up"
    return $((volumes_found - volumes_backed_up))
}

# ============================================================================
# Backup de todos os volumes nomeados
# ============================================================================
backup_all_volumes() {
    log INFO "Starting backup of all Docker volumes"
    
    local total_volumes=0
    local successful_backups=0
    local failed_backups=0
    
    # Obter lista de todos os volumes
    local volumes=$(docker volume ls --format '{{.Name}}')
    
    # Contar total
    total_volumes=$(echo "$volumes" | wc -l)
    
    log INFO "Found $total_volumes volumes to backup"
    
    # Processar volumes em paralelo
    export -f backup_volume
    export -f log
    export -f log_metric
    export VOLUMES_BACKUP_PATH
    export COMPRESSION_ENABLED
    
    echo "$volumes" | xargs -P "$PARALLEL_JOBS" -I {} bash -c '
        if backup_volume "{}"; then
            exit 0
        else
            exit 1
        fi
    '
    
    # Contar resultados
    successful_backups=$(find "$VOLUMES_BACKUP_PATH" -name "*_$(date +%Y%m%d)*.tar*" -mmin -5 | wc -l)
    failed_backups=$((total_volumes - successful_backups))
    
    log INFO "Volume backup summary: $successful_backups/$total_volumes successful"
    log_metric "backup.volumes.total" "$total_volumes" "gauge"
    log_metric "backup.volumes.successful" "$successful_backups" "gauge"
    log_metric "backup.volumes.failed" "$failed_backups" "gauge"
    
    return $failed_backups
}

# ============================================================================
# Backup seletivo de volumes críticos
# ============================================================================
backup_critical_volumes() {
    local critical_patterns=${1:-"postgres|mysql|mongo|redis|data|config"}
    
    log INFO "Backing up critical volumes matching: $critical_patterns"
    
    local volumes=$(docker volume ls --format '{{.Name}}' | grep -E "$critical_patterns")
    local total=0
    local success=0
    
    for volume in $volumes; do
        ((total++))
        if backup_volume "$volume"; then
            ((success++))
        fi
    done
    
    log INFO "Critical volumes backup: $success/$total successful"
    return $((total - success))
}

# ============================================================================
# Limpeza de backups antigos de volumes
# ============================================================================
cleanup_old_volume_backups() {
    local retention_days=${1:-7}
    
    log INFO "Cleaning up volume backups older than $retention_days days"
    
    local count=$(find "$VOLUMES_BACKUP_PATH" -name "*.tar*" -mtime +$retention_days | wc -l)
    
    if [[ $count -gt 0 ]]; then
        find "$VOLUMES_BACKUP_PATH" -name "*.tar*" -mtime +$retention_days -delete
        log SUCCESS "Removed $count old volume backup files"
    else
        log INFO "No old volume backups to remove"
    fi
    
    log_metric "backup.volumes.cleaned" "$count" "counter"
}

# ============================================================================
# Verificação de integridade dos backups
# ============================================================================
verify_volume_backup() {
    local backup_file=$1
    
    log DEBUG "Verifying backup integrity: $backup_file"
    
    # Verificar arquivo tar
    if [[ "$backup_file" == *.gz ]]; then
        if gzip -t "$backup_file" 2>/dev/null && tar -tzf "$backup_file" >/dev/null 2>&1; then
            log DEBUG "Backup verified successfully: $backup_file"
            return 0
        fi
    else
        if tar -tf "$backup_file" >/dev/null 2>&1; then
            log DEBUG "Backup verified successfully: $backup_file"
            return 0
        fi
    fi
    
    log ERROR "Backup verification failed: $backup_file"
    return 1
}

# Export das funções
export -f backup_volume
export -f backup_service_volumes
export -f backup_all_volumes
export -f backup_critical_volumes
export -f cleanup_old_volume_backups
export -f verify_volume_backup