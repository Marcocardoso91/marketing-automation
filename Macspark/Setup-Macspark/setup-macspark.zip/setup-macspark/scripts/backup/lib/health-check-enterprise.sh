#!/bin/bash
# MACSPARK ENTERPRISE BACKUP - SISTEMA DE MONITORAMENTO E SAÚDE 2025
# Version: 2.0 - Health Monitoring with OpenTelemetry & Enterprise Observability  
# Created: 2025-08-24 - Enterprise-grade health monitoring system
# Author: MacSpark Infrastructure Team

set -euo pipefail
IFS=$'\n\t'

# ==============================================================================
# ENTERPRISE HEALTH MONITORING CONFIGURATION
# ==============================================================================

# Base Configuration
readonly SCRIPT_NAME="$(basename "$0" .sh)"
readonly SCRIPT_VERSION="2.0.0"
readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly BACKUP_HOME="${BACKUP_HOME:-$(cd "$SCRIPT_DIR/../../.." && pwd)}"
readonly ENVIRONMENT="${ENVIRONMENT:-production}"

# Enterprise Health Monitoring Paths
readonly LOG_DIR="$BACKUP_HOME/logs/health"
readonly METRICS_DIR="$BACKUP_HOME/metrics"
readonly TRACE_DIR="$BACKUP_HOME/traces"
readonly STATUS_DIR="$BACKUP_HOME/status"
readonly ALERT_DIR="$BACKUP_HOME/alerts"

# Observability Configuration
readonly OTEL_SERVICE_NAME="macspark-health-monitor"
readonly OTEL_SERVICE_VERSION="$SCRIPT_VERSION"
readonly PROMETHEUS_PUSHGATEWAY="${PROMETHEUS_PUSHGATEWAY:-http://localhost:9091}"
readonly JAEGER_ENDPOINT="${JAEGER_ENDPOINT:-http://localhost:14268/api/traces}"
readonly GRAFANA_ENDPOINT="${GRAFANA_ENDPOINT:-http://localhost:3000}"

# Enterprise Health Files
readonly LOG_FILE="$LOG_DIR/health-monitor.log"
readonly ERROR_LOG="$LOG_DIR/health-errors.log" 
readonly AUDIT_LOG="$LOG_DIR/health-audit.log"
readonly STATUS_FILE="$STATUS_DIR/health-status.json"
readonly METRICS_FILE="$METRICS_DIR/health-metrics.prom"
readonly ALERT_FILE="$ALERT_DIR/active-alerts.json"

# Session Tracking
readonly SESSION_ID="$(uuidgen 2>/dev/null || openssl rand -hex 8)"
readonly START_TIME="$(date +%s)"
readonly TIMESTAMP="$(date '+%Y%m%d_%H%M%S')"

# Enterprise Alert Thresholds
readonly DISK_USAGE_WARNING=75
readonly DISK_USAGE_ERROR=85
readonly DISK_USAGE_CRITICAL=95
readonly BACKUP_AGE_WARNING_HOURS=6
readonly BACKUP_AGE_ERROR_HOURS=25
readonly BACKUP_AGE_CRITICAL_HOURS=48
readonly SYNC_AGE_WARNING_HOURS=2
readonly SYNC_AGE_ERROR_HOURS=5
readonly MIN_BACKUP_SIZE_KB=100
readonly MEMORY_WARNING_THRESHOLD=80
readonly MEMORY_CRITICAL_THRESHOLD=90
readonly CPU_WARNING_THRESHOLD=80
readonly CPU_CRITICAL_THRESHOLD=90
readonly LOAD_WARNING_MULTIPLIER=0.8
readonly LOAD_CRITICAL_MULTIPLIER=1.2

# Enterprise UI Colors
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly PURPLE='\033[0;35m'
readonly CYAN='\033[0;36m'
readonly WHITE='\033[1;37m'
readonly NC='\033[0m'

# Enterprise Icons
readonly ICON_HEALTHY="💚"
readonly ICON_WARNING="⚠️"
readonly ICON_ERROR="❌"
readonly ICON_CRITICAL="🚨"
readonly ICON_MONITORING="🔍"
readonly ICON_METRICS="📊"
readonly ICON_SYSTEM="🖥️"
readonly ICON_NETWORK="🌐"
readonly ICON_BACKUP="💾"

# Ensure enterprise directory structure
for dir in "$LOG_DIR" "$METRICS_DIR" "$TRACE_DIR" "$STATUS_DIR" "$ALERT_DIR"; do
    mkdir -p "$dir" || {
        echo "CRITICAL: Cannot create directory: $dir" >&2
        exit 1
    }
done

# Initialize enterprise tracking
declare -A HEALTH_CHECKS=()
declare -a WARNINGS=()
declare -a ERRORS=()
declare -a CRITICAL_ISSUES=()
OVERALL_HEALTH_SCORE=100
OVERALL_STATUS="HEALTHY"

# ==============================================================================
# ENTERPRISE OBSERVABILITY & LOGGING
# ==============================================================================

# Enhanced structured logging with OpenTelemetry
log_structured() {
    local level="$1"
    local message="$2"
    local component="${3:-health-monitor}"
    local trace_id="${4:-$SESSION_ID}"
    local check_name="${5:-general}"
    local metrics="${6:-{}}"
    
    local timestamp="$(date -Iseconds)"
    local hostname="$(hostname)"
    
    # Create structured log entry
    local log_entry=$(cat << EOF
{
  "timestamp": "$timestamp",
  "level": "$level",
  "message": "$message",
  "service": "$OTEL_SERVICE_NAME",
  "version": "$OTEL_SERVICE_VERSION", 
  "component": "$component",
  "check_name": "$check_name",
  "session_id": "$SESSION_ID",
  "trace_id": "$trace_id",
  "hostname": "$hostname",
  "environment": "$ENVIRONMENT",
  "pid": $$,
  "metrics": $metrics
}
EOF
    )
    
    echo "$log_entry" >> "$LOG_FILE"
    
    # Route to appropriate logs
    case "$level" in
        "ERROR"|"CRITICAL")
            echo "$log_entry" >> "$ERROR_LOG"
            echo "[$(date '+%Y-%m-%d %H:%M:%S')] [$level] $message" >&2
            ;;
        "AUDIT")
            echo "$log_entry" >> "$AUDIT_LOG"
            ;;
    esac
    
    # Console output with enterprise formatting
    local color="" icon=""
    case "$level" in
        "ERROR") color="$RED"; icon="$ICON_ERROR" ;;
        "CRITICAL") color="$RED"; icon="$ICON_CRITICAL" ;;
        "WARN") color="$YELLOW"; icon="$ICON_WARNING" ;;
        "SUCCESS") color="$GREEN"; icon="$ICON_HEALTHY" ;;
        "INFO") color="$BLUE"; icon="$ICON_MONITORING" ;;
        "DEBUG") color="$CYAN"; icon="$ICON_METRICS" ;;
        *) color="$WHITE"; icon="$ICON_SYSTEM" ;;
    esac
    
    echo -e "${color}${icon} [$(date '+%H:%M:%S')] [$level] $message${NC}"
}

# OpenTelemetry distributed tracing
create_health_span() {
    local operation_name="$1"
    local parent_span="${2:-}"
    local tags="${3:-{}}"
    
    local span_id="$(openssl rand -hex 8 2>/dev/null || echo "$(date +%s%N | cut -b1-16)")"
    local trace_id="${parent_span:-$SESSION_ID}"
    
    cat << EOF >> "$TRACE_DIR/health-spans.json"
{
  "traceID": "$trace_id",
  "spanID": "$span_id", 
  "operationName": "$operation_name",
  "startTime": $(date +%s%N),
  "tags": $(echo "$tags" | jq '. + {
    "service.name": "'$OTEL_SERVICE_NAME'",
    "service.version": "'$OTEL_SERVICE_VERSION'",
    "component": "health-monitor",
    "environment": "'$ENVIRONMENT'"
  }'),
  "process": {
    "serviceName": "$OTEL_SERVICE_NAME",
    "tags": [
      {"key": "hostname", "value": "$(hostname)"},
      {"key": "pid", "value": "$$"}
    ]
  }
}
EOF
    
    echo "$span_id"
}

# Enterprise metrics collection
record_health_metric() {
    local metric_name="$1"
    local metric_value="$2"
    local metric_type="${3:-gauge}"
    local labels="${4:-}"
    local help_text="${5:-Health check metric}"
    
    local timestamp="$(date +%s)000"
    
    # Add to Prometheus metrics file
    {
        echo "# HELP health_${metric_name} $help_text"
        echo "# TYPE health_${metric_name} $metric_type"
        echo "health_${metric_name}${labels} $metric_value $timestamp"
    } >> "$METRICS_FILE"
    
    # Push to Prometheus if available
    if command -v curl >/dev/null 2>&1 && [[ -n "${PROMETHEUS_PUSHGATEWAY:-}" ]]; then
        curl -s -X POST "$PROMETHEUS_PUSHGATEWAY/metrics/job/health-monitoring/instance/$(hostname)" \
            --data-binary "health_${metric_name}${labels} $metric_value" >/dev/null 2>&1 || true
    fi
}

# Performance monitoring wrapper for health checks
monitor_health_check() {
    local check_name="$1"
    local check_function="$2"
    shift 2
    
    local span_id="$(create_health_span "$check_name" "" "{\"check.type\":\"health\",\"check.name\":\"$check_name\"}")"
    local start_time="$(date +%s%N)"
    
    log_structured "DEBUG" "Starting health check: $check_name" "health-monitor" "$span_id" "$check_name"
    
    # Execute health check with comprehensive error handling
    local exit_code=0
    local check_result=""
    
    if check_result=$("$check_function" "$@" 2>&1); then
        exit_code=0
        HEALTH_CHECKS["$check_name"]="PASS"
    else
        exit_code=$?
        HEALTH_CHECKS["$check_name"]="FAIL"
    fi
    
    local end_time="$(date +%s%N)"
    local duration="$(echo "scale=3; ($end_time - $start_time) / 1000000000" | bc -l 2>/dev/null || echo "0")"
    
    # Record comprehensive metrics
    record_health_metric "check_duration_seconds" "$duration" "histogram" "{check=\"$check_name\"}" "Duration of health check in seconds"
    record_health_metric "check_status" "$([ $exit_code -eq 0 ] && echo "1" || echo "0")" "gauge" "{check=\"$check_name\"}" "Health check status (1=pass, 0=fail)"
    record_health_metric "checks_total" "1" "counter" "{check=\"$check_name\",status=\"$([ $exit_code -eq 0 ] && echo "success" || echo "failure")\"}" "Total health checks performed"
    
    if [[ $exit_code -eq 0 ]]; then
        log_structured "SUCCESS" "Health check passed: $check_name (${duration}s)" "health-monitor" "$span_id" "$check_name" "{\"duration\":$duration,\"status\":\"pass\"}"
    else
        log_structured "ERROR" "Health check failed: $check_name (${duration}s, exit_code=$exit_code)" "health-monitor" "$span_id" "$check_name" "{\"duration\":$duration,\"status\":\"fail\",\"exit_code\":$exit_code}"
        echo "$check_result" | log_structured "DEBUG" "Check output: $check_name" "health-monitor" "$span_id" "$check_name"
    fi
    
    return $exit_code
}

# ==============================================================================
# ENTERPRISE HEALTH STATUS MANAGEMENT 
# ==============================================================================

# Add warning with health score impact
add_warning() {
    local message="$1"
    local score_impact="${2:-5}"
    
    WARNINGS+=("$message")
    OVERALL_HEALTH_SCORE=$((OVERALL_HEALTH_SCORE - score_impact))
    
    log_structured "WARN" "$message" "health-status" "$SESSION_ID" "warning" "{\"score_impact\":$score_impact,\"current_score\":$OVERALL_HEALTH_SCORE}"
    
    # Record warning metric
    record_health_metric "warnings_total" "1" "counter" "{message=\"$(echo "$message" | tr ' ' '_' | tr -cd 'a-zA-Z0-9_')\"}" "Total warnings generated"
}

# Add error with health score impact
add_error() {
    local message="$1"
    local score_impact="${2:-15}"
    
    ERRORS+=("$message")
    OVERALL_HEALTH_SCORE=$((OVERALL_HEALTH_SCORE - score_impact))
    OVERALL_STATUS="DEGRADED"
    
    log_structured "ERROR" "$message" "health-status" "$SESSION_ID" "error" "{\"score_impact\":$score_impact,\"current_score\":$OVERALL_HEALTH_SCORE}"
    
    # Record error metric
    record_health_metric "errors_total" "1" "counter" "{message=\"$(echo "$message" | tr ' ' '_' | tr -cd 'a-zA-Z0-9_')\"}" "Total errors generated"
}

# Add critical issue with major health score impact
add_critical() {
    local message="$1"
    local score_impact="${2:-30}"
    
    CRITICAL_ISSUES+=("$message")
    OVERALL_HEALTH_SCORE=$((OVERALL_HEALTH_SCORE - score_impact))
    OVERALL_STATUS="CRITICAL"
    
    log_structured "CRITICAL" "$message" "health-status" "$SESSION_ID" "critical" "{\"score_impact\":$score_impact,\"current_score\":$OVERALL_HEALTH_SCORE}"
    
    # Record critical metric
    record_health_metric "critical_issues_total" "1" "counter" "{message=\"$(echo "$message" | tr ' ' '_' | tr -cd 'a-zA-Z0-9_')\"}" "Total critical issues generated"
}

# ==============================================================================
# ENTERPRISE HEALTH CHECK FUNCTIONS
# ==============================================================================

# Enhanced disk space monitoring with multiple filesystem support
check_enterprise_disk_space() {
    local filesystems=(
        "$BACKUP_HOME:backup"
        "/:root"
        "/var:var"
        "/tmp:tmp"
        "/home:home"
    )
    
    for fs_info in "${filesystems[@]}"; do
        local path="${fs_info%:*}"
        local name="${fs_info#*:}"
        
        if [[ -d "$path" ]]; then
            local usage_percent=$(df "$path" | tail -1 | awk '{print $5}' | sed 's/%//')
            local available_gb=$(df -BG "$path" | tail -1 | awk '{print $4}' | sed 's/G//')
            local total_gb=$(df -BG "$path" | tail -1 | awk '{print $2}' | sed 's/G//')
            local used_gb=$(df -BG "$path" | tail -1 | awk '{print $3}' | sed 's/G//')
            
            # Record detailed metrics
            record_health_metric "disk_usage_percent" "$usage_percent" "gauge" "{filesystem=\"$name\",path=\"$path\"}" "Disk usage percentage"
            record_health_metric "disk_available_gb" "$available_gb" "gauge" "{filesystem=\"$name\",path=\"$path\"}" "Available disk space in GB"
            record_health_metric "disk_total_gb" "$total_gb" "gauge" "{filesystem=\"$name\",path=\"$path\"}" "Total disk space in GB"
            record_health_metric "disk_used_gb" "$used_gb" "gauge" "{filesystem=\"$name\",path=\"$path\"}" "Used disk space in GB"
            
            # Health assessment with enterprise thresholds
            if [[ $usage_percent -gt $DISK_USAGE_CRITICAL ]]; then
                add_critical "Disk space critically low on $name: ${usage_percent}% used (${available_gb}GB available)" 30
            elif [[ $usage_percent -gt $DISK_USAGE_ERROR ]]; then
                add_error "Disk space high on $name: ${usage_percent}% used (${available_gb}GB available)" 15
            elif [[ $usage_percent -gt $DISK_USAGE_WARNING ]]; then
                add_warning "Disk space warning on $name: ${usage_percent}% used (${available_gb}GB available)" 5
            fi
            
            # Critical space thresholds
            if [[ $available_gb -lt 1 ]]; then
                add_critical "Less than 1GB available on $name filesystem" 25
            elif [[ $available_gb -lt 5 ]]; then
                add_error "Less than 5GB available on $name filesystem" 10
            fi
            
            log_structured "INFO" "Filesystem $name: ${usage_percent}% used, ${available_gb}GB available" "disk-check" "$SESSION_ID" "disk_space"
        fi
    done
}

# Enhanced backup freshness check with multiple backup types
check_enterprise_backup_freshness() {
    local backup_locations=(
        "$BACKUP_HOME/local-backups/daily:daily:$BACKUP_AGE_ERROR_HOURS"
        "$BACKUP_HOME/local-backups/databases:database:$BACKUP_AGE_WARNING_HOURS" 
        "$BACKUP_HOME/local-backups/applications:application:$BACKUP_AGE_ERROR_HOURS"
        "$BACKUP_HOME/google-drive-sync/critical-backups:critical:$BACKUP_AGE_WARNING_HOURS"
        "$BACKUP_HOME/google-drive-sync/databases:remote-db:$BACKUP_AGE_ERROR_HOURS"
        "$BACKUP_HOME/google-drive-sync/code-repos:code:$BACKUP_AGE_CRITICAL_HOURS"
    )
    
    for backup_info in "${backup_locations[@]}"; do
        IFS=':' read -r path type threshold_hours <<< "$backup_info"
        
        if [[ -d "$path" ]]; then
            # Find most recent backup files
            local newest_backup=$(find "$path" -type f \( -name "*.tar.gz" -o -name "*.sql.gz" -o -name "*.zip" -o -name "*.7z" \) -printf '%T@ %p\n' 2>/dev/null | sort -nr | head -1 | cut -d' ' -f2-)
            
            if [[ -n "$newest_backup" ]]; then
                local backup_age_seconds=$(($(date +%s) - $(stat -c %Y "$newest_backup")))
                local backup_age_hours=$((backup_age_seconds / 3600))
                local backup_size_bytes=$(stat -c %s "$newest_backup" 2>/dev/null || echo "0")
                local backup_size_mb=$((backup_size_bytes / 1024 / 1024))
                
                # Record backup metrics
                record_health_metric "backup_age_hours" "$backup_age_hours" "gauge" "{type=\"$type\",path=\"$(basename "$path")\"}" "Age of most recent backup in hours"
                record_health_metric "backup_size_mb" "$backup_size_mb" "gauge" "{type=\"$type\",path=\"$(basename "$path")\"}" "Size of most recent backup in MB"
                record_health_metric "backup_timestamp" "$(stat -c %Y "$newest_backup")" "gauge" "{type=\"$type\",path=\"$(basename "$path")\"}" "Timestamp of most recent backup"
                
                # Health assessment with dynamic thresholds
                if [[ $backup_age_hours -gt $BACKUP_AGE_CRITICAL_HOURS ]]; then
                    add_critical "$type backup critically old: ${backup_age_hours}h (threshold: ${BACKUP_AGE_CRITICAL_HOURS}h)" 25
                elif [[ $backup_age_hours -gt $threshold_hours ]]; then
                    add_error "$type backup too old: ${backup_age_hours}h (threshold: ${threshold_hours}h)" 15
                elif [[ $backup_age_hours -gt $BACKUP_AGE_WARNING_HOURS ]]; then
                    add_warning "$type backup aging: ${backup_age_hours}h (warning threshold: ${BACKUP_AGE_WARNING_HOURS}h)" 5
                fi
                
                # Size validation
                if [[ $backup_size_mb -lt 1 ]]; then
                    add_error "$type backup suspiciously small: ${backup_size_mb}MB" 10
                fi
                
                log_structured "INFO" "$type backup: ${backup_age_hours}h old, ${backup_size_mb}MB" "backup-check" "$SESSION_ID" "backup_freshness"
            else
                add_error "No $type backup files found in $(basename "$path")" 20
                record_health_metric "backup_missing" "1" "gauge" "{type=\"$type\",path=\"$(basename "$path")\"}" "Backup missing indicator"
            fi
        else
            add_warning "$type backup directory missing: $(basename "$path")" 10
        fi
    done
}

# Enhanced cloud sync monitoring with multiple providers
check_enterprise_cloud_sync() {
    local sync_providers=(
        "$BACKUP_HOME/google-drive-sync:gdrive:rclone"
        "$BACKUP_HOME/aws-s3-sync:s3:aws"
        "$BACKUP_HOME/azure-sync:azure:az"
    )
    
    for sync_info in "${sync_providers[@]}"; do
        IFS=':' read -r sync_dir provider tool <<< "$sync_info"
        
        if [[ -d "$sync_dir" ]]; then
            # Check for recent sync reports
            local newest_report=$(find "$sync_dir" -name "sync_report_*.txt" -o -name "*_sync_*.log" -type f -printf '%T@ %p\n' 2>/dev/null | sort -nr | head -1 | cut -d' ' -f2-)
            
            if [[ -n "$newest_report" ]]; then
                local sync_age_seconds=$(($(date +%s) - $(stat -c %Y "$newest_report")))
                local sync_age_hours=$((sync_age_seconds / 3600))
                
                record_health_metric "sync_age_hours" "$sync_age_hours" "gauge" "{provider=\"$provider\"}" "Age of last sync in hours"
                
                if [[ $sync_age_hours -gt 12 ]]; then
                    add_error "$provider sync too old: ${sync_age_hours}h" 15
                elif [[ $sync_age_hours -gt $SYNC_AGE_ERROR_HOURS ]]; then
                    add_warning "$provider sync aging: ${sync_age_hours}h" 8
                fi
                
                # Check sync report for errors
                if grep -qi "error\|failed\|exception" "$newest_report" 2>/dev/null; then
                    add_error "$provider sync report contains errors" 12
                fi
            else
                add_warning "No $provider sync reports found" 8
                record_health_metric "sync_missing" "1" "gauge" "{provider=\"$provider\"}" "Sync report missing indicator"
            fi
            
            # Check tool availability and configuration
            if command -v "$tool" >/dev/null 2>&1; then
                case "$tool" in
                    "rclone")
                        if rclone listremotes 2>/dev/null | grep -q "$provider:"; then
                            log_structured "INFO" "$provider configuration verified with $tool" "sync-check" "$SESSION_ID" "cloud_sync"
                        else
                            add_error "$provider not configured in $tool" 10
                        fi
                        ;;
                    "aws")
                        if aws configure list >/dev/null 2>&1; then
                            log_structured "INFO" "AWS CLI configuration verified" "sync-check" "$SESSION_ID" "cloud_sync"
                        else
                            add_warning "AWS CLI not configured" 8
                        fi
                        ;;
                    "az")
                        if az account show >/dev/null 2>&1; then
                            log_structured "INFO" "Azure CLI configuration verified" "sync-check" "$SESSION_ID" "cloud_sync"
                        else
                            add_warning "Azure CLI not authenticated" 8
                        fi
                        ;;
                esac
            else
                add_warning "$tool not available for $provider sync" 5
            fi
        fi
    done
}

# Enhanced system resource monitoring
check_enterprise_system_resources() {
    # Enhanced memory monitoring
    local memory_info=$(free -m)
    local total_mem=$(echo "$memory_info" | awk '/^Mem:/ {print $2}')
    local used_mem=$(echo "$memory_info" | awk '/^Mem:/ {print $3}')
    local available_mem=$(echo "$memory_info" | awk '/^Mem:/ {print $7}')
    local memory_usage_percent=$((used_mem * 100 / total_mem))
    local swap_total=$(echo "$memory_info" | awk '/^Swap:/ {print $2}')
    local swap_used=$(echo "$memory_info" | awk '/^Swap:/ {print $3}')
    local swap_usage_percent=0
    
    if [[ $swap_total -gt 0 ]]; then
        swap_usage_percent=$((swap_used * 100 / swap_total))
    fi
    
    # Record memory metrics
    record_health_metric "memory_usage_percent" "$memory_usage_percent" "gauge" "" "Memory usage percentage"
    record_health_metric "memory_total_mb" "$total_mem" "gauge" "" "Total memory in MB"
    record_health_metric "memory_used_mb" "$used_mem" "gauge" "" "Used memory in MB"
    record_health_metric "memory_available_mb" "$available_mem" "gauge" "" "Available memory in MB"
    record_health_metric "swap_usage_percent" "$swap_usage_percent" "gauge" "" "Swap usage percentage"
    
    # Memory health assessment
    if [[ $memory_usage_percent -gt $MEMORY_CRITICAL_THRESHOLD ]]; then
        add_critical "Memory usage critical: ${memory_usage_percent}%" 20
    elif [[ $memory_usage_percent -gt $MEMORY_WARNING_THRESHOLD ]]; then
        add_warning "Memory usage high: ${memory_usage_percent}%" 8
    fi
    
    if [[ $swap_usage_percent -gt 50 ]]; then
        add_warning "High swap usage: ${swap_usage_percent}%" 10
    fi
    
    # Enhanced CPU monitoring
    local cpu_count=$(nproc)
    local load_avg=$(uptime | awk -F'load average:' '{print $2}' | awk '{gsub(/,/, ""); print $1 " " $2 " " $3}')
    read -r load_1min load_5min load_15min <<< "$load_avg"
    
    local load_1min_percent=$(echo "$load_1min $cpu_count" | awk '{printf "%.0f", $1/$2*100}')
    local load_5min_percent=$(echo "$load_5min $cpu_count" | awk '{printf "%.0f", $1/$2*100}')
    local load_15min_percent=$(echo "$load_15min $cpu_count" | awk '{printf "%.0f", $1/$2*100}')
    
    # Record CPU metrics
    record_health_metric "cpu_load_1min" "$load_1min" "gauge" "" "1-minute load average"
    record_health_metric "cpu_load_5min" "$load_5min" "gauge" "" "5-minute load average"
    record_health_metric "cpu_load_15min" "$load_15min" "gauge" "" "15-minute load average"
    record_health_metric "cpu_load_1min_percent" "$load_1min_percent" "gauge" "" "1-minute load average as percentage"
    record_health_metric "cpu_count" "$cpu_count" "gauge" "" "Number of CPU cores"
    
    # CPU health assessment
    local critical_load_threshold=$(echo "$cpu_count * $LOAD_CRITICAL_MULTIPLIER" | bc -l | cut -d. -f1)
    local warning_load_threshold=$(echo "$cpu_count * $LOAD_WARNING_MULTIPLIER" | bc -l | cut -d. -f1)
    
    if [[ $(echo "$load_5min > $critical_load_threshold" | bc -l) -eq 1 ]]; then
        add_critical "CPU load critical: ${load_5min} (${load_5min_percent}% on ${cpu_count} cores)" 20
    elif [[ $(echo "$load_5min > $warning_load_threshold" | bc -l) -eq 1 ]]; then
        add_warning "CPU load high: ${load_5min} (${load_5min_percent}% on ${cpu_count} cores)" 10
    fi
    
    # Disk I/O monitoring (if iostat available)
    if command -v iostat >/dev/null 2>&1; then
        local io_stats=$(iostat -x 1 2 | tail -n +7 | tail -1)
        if [[ -n "$io_stats" ]]; then
            local io_wait=$(echo "$io_stats" | awk '{print $10}')
            record_health_metric "disk_io_wait_percent" "$io_wait" "gauge" "" "Disk I/O wait percentage"
            
            if [[ $(echo "$io_wait > 30" | bc -l) -eq 1 ]]; then
                add_warning "High disk I/O wait: ${io_wait}%" 8
            fi
        fi
    fi
    
    log_structured "INFO" "System resources - Memory: ${memory_usage_percent}%, CPU Load: ${load_5min} (${load_5min_percent}%)" "system-check" "$SESSION_ID" "system_resources"
}

# Enhanced network connectivity monitoring  
check_enterprise_network_connectivity() {
    local endpoints=(
        "8.8.8.8:google-dns:icmp"
        "1.1.1.1:cloudflare-dns:icmp"
        "google.com:443:tcp"
        "github.com:443:tcp"
        "macspark.dev:443:tcp"
    )
    
    local connectivity_score=100
    
    for endpoint_info in "${endpoints[@]}"; do
        IFS=':' read -r target name protocol <<< "$endpoint_info"
        
        local connection_successful=0
        local response_time="0"
        
        case "$protocol" in
            "icmp")
                if ping_output=$(ping -c 3 -W 5 "$target" 2>&1); then
                    connection_successful=1
                    response_time=$(echo "$ping_output" | grep 'avg' | awk -F'/' '{print $5}' || echo "0")
                fi
                ;;
            "tcp")
                local port="${endpoint_info##*:}"
                if timeout 10 bash -c "</dev/tcp/$target/$port" 2>/dev/null; then
                    connection_successful=1
                fi
                ;;
        esac
        
        # Record connectivity metrics
        record_health_metric "network_connectivity" "$connection_successful" "gauge" "{endpoint=\"$name\",protocol=\"$protocol\"}" "Network connectivity status"
        if [[ -n "$response_time" && "$response_time" != "0" ]]; then
            record_health_metric "network_response_time_ms" "$response_time" "gauge" "{endpoint=\"$name\"}" "Network response time in milliseconds"
        fi
        
        if [[ $connection_successful -eq 1 ]]; then
            log_structured "INFO" "Network connectivity OK to $name ($target)" "network-check" "$SESSION_ID" "network_connectivity"
        else
            connectivity_score=$((connectivity_score - 20))
            add_error "Cannot connect to $name ($target via $protocol)" 12
        fi
    done
    
    record_health_metric "network_connectivity_score" "$connectivity_score" "gauge" "" "Overall network connectivity score"
    
    # DNS resolution test
    if nslookup google.com >/dev/null 2>&1; then
        log_structured "INFO" "DNS resolution working" "network-check" "$SESSION_ID" "network_connectivity"
    else
        add_error "DNS resolution failed" 15
    fi
}

# Enhanced service monitoring with Docker integration
check_enterprise_services() {
    # System services
    local system_services=("cron" "ssh" "systemd-resolved")
    
    for service in "${system_services[@]}"; do
        if systemctl list-unit-files | grep -q "^$service.service"; then
            if systemctl is-active --quiet "$service" 2>/dev/null; then
                record_health_metric "service_status" "1" "gauge" "{service=\"$service\",type=\"system\"}" "Service status (1=running, 0=stopped)"
                log_structured "INFO" "System service $service is running" "service-check" "$SESSION_ID" "services"
            else
                record_health_metric "service_status" "0" "gauge" "{service=\"$service\",type=\"system\"}" "Service status (1=running, 0=stopped)"
                add_error "System service $service is not running" 10
            fi
        fi
    done
    
    # Database services  
    local db_services=("postgresql" "mysql" "redis" "mongodb")
    
    for service in "${db_services[@]}"; do
        if systemctl list-unit-files | grep -q "^$service"; then
            if systemctl is-active --quiet "$service" 2>/dev/null; then
                record_health_metric "service_status" "1" "gauge" "{service=\"$service\",type=\"database\"}" "Database service status"
                log_structured "INFO" "Database service $service is running" "service-check" "$SESSION_ID" "services"
            else
                record_health_metric "service_status" "0" "gauge" "{service=\"$service\",type=\"database\"}" "Database service status" 
                log_structured "INFO" "Database service $service is not running (may be expected)" "service-check" "$SESSION_ID" "services"
            fi
        fi
    done
    
    # Docker services
    if command -v docker >/dev/null 2>&1; then
        if systemctl is-active --quiet docker 2>/dev/null; then
            local running_containers=$(docker ps -q | wc -l)
            local total_containers=$(docker ps -aq | wc -l)
            
            record_health_metric "docker_containers_running" "$running_containers" "gauge" "" "Number of running Docker containers"
            record_health_metric "docker_containers_total" "$total_containers" "gauge" "" "Total number of Docker containers"
            
            # Check specific backup-related containers
            local backup_containers=(
                "backup-enterprise"
                "kopia-server"
                "restic-rest-server"
                "postgres"
                "redis"
            )
            
            for container in "${backup_containers[@]}"; do
                if docker ps --format "table {{.Names}}" | grep -q "$container"; then
                    record_health_metric "container_status" "1" "gauge" "{container=\"$container\"}" "Container status"
                    log_structured "INFO" "Container $container is running" "service-check" "$SESSION_ID" "services"
                else
                    record_health_metric "container_status" "0" "gauge" "{container=\"$container\"}" "Container status"
                    log_structured "DEBUG" "Container $container is not running" "service-check" "$SESSION_ID" "services"
                fi
            done
            
            log_structured "INFO" "Docker: $running_containers/$total_containers containers running" "service-check" "$SESSION_ID" "services"
        else
            add_warning "Docker service is not running" 8
        fi
    fi
    
    # Check cron jobs
    if crontab -l 2>/dev/null | grep -q "macspark\|backup"; then
        record_health_metric "cron_jobs_configured" "1" "gauge" "" "Backup cron jobs configured"
        log_structured "INFO" "Backup cron jobs are configured" "service-check" "$SESSION_ID" "services"
    else
        add_warning "No backup cron jobs found in crontab" 8
        record_health_metric "cron_jobs_configured" "0" "gauge" "" "Backup cron jobs configured"
    fi
}

# ==============================================================================
# ENTERPRISE HEALTH REPORTING & ALERTING
# ==============================================================================

# Generate comprehensive enterprise status report
generate_enterprise_health_report() {
    local span_id="$(create_health_span "generate_report")"
    
    log_structured "INFO" "Generating enterprise health report" "reporting" "$span_id" "reporting"
    
    # Calculate final health scores
    if [[ $OVERALL_HEALTH_SCORE -lt 50 ]]; then
        OVERALL_STATUS="CRITICAL"
    elif [[ $OVERALL_HEALTH_SCORE -lt 80 ]]; then
        OVERALL_STATUS="DEGRADED" 
    elif [[ ${#WARNINGS[@]} -gt 0 ]]; then
        OVERALL_STATUS="WARNING"
    else
        OVERALL_STATUS="HEALTHY"
    fi
    
    # Record overall health metrics
    record_health_metric "overall_health_score" "$OVERALL_HEALTH_SCORE" "gauge" "" "Overall system health score (0-100)"
    record_health_metric "total_warnings" "${#WARNINGS[@]}" "gauge" "" "Total number of warnings"
    record_health_metric "total_errors" "${#ERRORS[@]}" "gauge" "" "Total number of errors"
    record_health_metric "total_critical_issues" "${#CRITICAL_ISSUES[@]}" "gauge" "" "Total number of critical issues"
    
    # Create comprehensive JSON status report
    cat > "$STATUS_FILE" << EOF
{
  "timestamp": "$(date -Iseconds)",
  "session_id": "$SESSION_ID",
  "environment": "$ENVIRONMENT",
  "hostname": "$(hostname)",
  "health_assessment": {
    "overall_status": "$OVERALL_STATUS",
    "health_score": $OVERALL_HEALTH_SCORE,
    "status_color": "$(case "$OVERALL_STATUS" in
      "HEALTHY") echo "green" ;;
      "WARNING") echo "yellow" ;;
      "DEGRADED") echo "orange" ;;
      "CRITICAL") echo "red" ;;
    esac)"
  },
  "summary": {
    "warnings": ${#WARNINGS[@]},
    "errors": ${#ERRORS[@]},
    "critical_issues": ${#CRITICAL_ISSUES[@]},
    "checks_performed": $(echo "${!HEALTH_CHECKS[@]}" | wc -w),
    "checks_passed": $(printf "%s\n" "${HEALTH_CHECKS[@]}" | grep -c "PASS"),
    "checks_failed": $(printf "%s\n" "${HEALTH_CHECKS[@]}" | grep -c "FAIL")
  },
  "details": {
    "warnings": $(printf '%s\n' "${WARNINGS[@]}" | jq -R . | jq -s .),
    "errors": $(printf '%s\n' "${ERRORS[@]}" | jq -R . | jq -s .),
    "critical_issues": $(printf '%s\n' "${CRITICAL_ISSUES[@]}" | jq -R . | jq -s .),
    "health_checks": $(echo '{' && for check in "${!HEALTH_CHECKS[@]}"; do echo "\"$check\": \"${HEALTH_CHECKS[$check]}\","; done | sed '$ s/,$//' && echo '}')
  },
  "system_info": {
    "uptime": "$(uptime -p)",
    "kernel": "$(uname -r)",
    "architecture": "$(uname -m)",
    "cpu_cores": $(nproc),
    "total_memory_gb": "$(free -g | awk '/^Mem:/ {print $2}')",
    "disk_mounts": $(df -h | grep -E '^/dev' | jq -R 'split(" ") | {device: .[0], size: .[1], used: .[2], available: .[3], usage: .[4], mount: .[5]}' | jq -s .)
  },
  "observability": {
    "metrics_file": "$METRICS_FILE",
    "trace_file": "$TRACE_DIR/health-spans.json",
    "log_file": "$LOG_FILE",
    "prometheus_endpoint": "$PROMETHEUS_PUSHGATEWAY",
    "jaeger_endpoint": "$JAEGER_ENDPOINT"
  }
}
EOF
    
    # Create enterprise HTML report
    local html_report="$STATUS_DIR/health-report-$TIMESTAMP.html"
    cat > "$html_report" << EOF
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MacSpark Enterprise Health Report</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; border-radius: 10px; margin-bottom: 20px; }
        .status-card { background: white; padding: 20px; border-radius: 10px; margin: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .status-healthy { border-left: 5px solid #27ae60; }
        .status-warning { border-left: 5px solid #f39c12; }
        .status-degraded { border-left: 5px solid #e67e22; }
        .status-critical { border-left: 5px solid #e74c3c; }
        .metrics-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }
        .metric { text-align: center; }
        .metric-value { font-size: 2.5em; font-weight: bold; margin: 10px 0; }
        .issues-list { background: #ecf0f1; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .footer { text-align: center; margin: 30px 0; color: #7f8c8d; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🏢 MacSpark Enterprise Health Report</h1>
            <p>Generated: $(date '+%Y-%m-%d %H:%M:%S %Z') | Session: $SESSION_ID</p>
        </div>
        
        <div class="status-card status-$(echo "$OVERALL_STATUS" | tr '[:upper:]' '[:lower:]')">
            <h2>Overall System Status: $OVERALL_STATUS</h2>
            <div class="metrics-grid">
                <div class="metric">
                    <div class="metric-value" style="color: $(case "$OVERALL_STATUS" in "HEALTHY") echo "#27ae60" ;; "WARNING") echo "#f39c12" ;; "DEGRADED") echo "#e67e22" ;; "CRITICAL") echo "#e74c3c" ;; esac)">$OVERALL_HEALTH_SCORE</div>
                    <div>Health Score</div>
                </div>
                <div class="metric">
                    <div class="metric-value" style="color: #e74c3c">${#CRITICAL_ISSUES[@]}</div>
                    <div>Critical Issues</div>
                </div>
                <div class="metric">
                    <div class="metric-value" style="color: #e67e22">${#ERRORS[@]}</div>
                    <div>Errors</div>
                </div>
                <div class="metric">
                    <div class="metric-value" style="color: #f39c12">${#WARNINGS[@]}</div>
                    <div>Warnings</div>
                </div>
            </div>
        </div>
        
        $(if [[ ${#CRITICAL_ISSUES[@]} -gt 0 ]]; then
            echo '<div class="status-card status-critical">'
            echo '<h3>🚨 Critical Issues</h3>'
            echo '<div class="issues-list">'
            printf '<p>• %s</p>\n' "${CRITICAL_ISSUES[@]}"
            echo '</div>'
            echo '</div>'
        fi)
        
        $(if [[ ${#ERRORS[@]} -gt 0 ]]; then
            echo '<div class="status-card status-degraded">'
            echo '<h3>❌ Errors</h3>'
            echo '<div class="issues-list">'
            printf '<p>• %s</p>\n' "${ERRORS[@]}"
            echo '</div>'
            echo '</div>'
        fi)
        
        $(if [[ ${#WARNINGS[@]} -gt 0 ]]; then
            echo '<div class="status-card status-warning">'
            echo '<h3>⚠️ Warnings</h3>'
            echo '<div class="issues-list">'
            printf '<p>• %s</p>\n' "${WARNINGS[@]}"
            echo '</div>'
            echo '</div>'
        fi)
        
        <div class="status-card">
            <h3>📊 Enterprise Monitoring</h3>
            <p><strong>Metrics:</strong> <a href="file://$METRICS_FILE">$METRICS_FILE</a></p>
            <p><strong>Traces:</strong> <a href="file://$TRACE_DIR/health-spans.json">$TRACE_DIR/health-spans.json</a></p>
            <p><strong>Logs:</strong> <a href="file://$LOG_FILE">$LOG_FILE</a></p>
            <p><strong>Environment:</strong> $ENVIRONMENT</p>
            <p><strong>Hostname:</strong> $(hostname)</p>
        </div>
        
        <div class="footer">
            <p>MacSpark Enterprise Infrastructure Team | Health Monitoring System v$SCRIPT_VERSION</p>
        </div>
    </div>
</body>
</html>
EOF
    
    log_structured "SUCCESS" "Enterprise health report generated: $html_report" "reporting" "$span_id" "reporting"
    echo "$html_report"
}

# Enterprise alerting integration
send_enterprise_health_alerts() {
    if [[ ${#CRITICAL_ISSUES[@]} -gt 0 || ${#ERRORS[@]} -gt 0 || ${#WARNINGS[@]} -gt 3 ]]; then
        local alert_level="INFO"
        
        if [[ ${#CRITICAL_ISSUES[@]} -gt 0 ]]; then
            alert_level="CRITICAL"
        elif [[ ${#ERRORS[@]} -gt 0 ]]; then
            alert_level="ERROR"
        elif [[ ${#WARNINGS[@]} -gt 3 ]]; then
            alert_level="WARNING"
        fi
        
        # Create alert summary
        local alert_message="🏢 **MacSpark Enterprise Health Alert**

**Overall Status:** $OVERALL_STATUS (Score: $OVERALL_HEALTH_SCORE/100)

**Issue Summary:**
• Critical: ${#CRITICAL_ISSUES[@]}
• Errors: ${#ERRORS[@]} 
• Warnings: ${#WARNINGS[@]}

**Environment:** $ENVIRONMENT
**Hostname:** $(hostname)
**Session:** $SESSION_ID

**Action Required:** $([ ${#CRITICAL_ISSUES[@]} -gt 0 ] && echo "IMMEDIATE" || [ ${#ERRORS[@]} -gt 0 ] && echo "URGENT" || echo "REVIEW")"
        
        # Send via notification system if available
        if [[ -f "$SCRIPT_DIR/notification-system.sh" ]]; then
            case "$alert_level" in
                "CRITICAL")
                    "$SCRIPT_DIR/notification-system.sh" --failure-enterprise "Health Check" "$alert_message" "999" "$(hostname)"
                    ;;
                "ERROR"|"WARNING")
                    "$SCRIPT_DIR/notification-system.sh" --warning "Health Check Issues" "$alert_message"
                    ;;
            esac
        fi
        
        # Create alert record
        local alert_record=$(cat << EOF
{
  "timestamp": "$(date -Iseconds)",
  "alert_id": "$(uuidgen)",
  "session_id": "$SESSION_ID",
  "level": "$alert_level",
  "status": "$OVERALL_STATUS",
  "health_score": $OVERALL_HEALTH_SCORE,
  "critical_count": ${#CRITICAL_ISSUES[@]},
  "error_count": ${#ERRORS[@]},
  "warning_count": ${#WARNINGS[@]},
  "hostname": "$(hostname)",
  "environment": "$ENVIRONMENT"
}
EOF
        )
        
        echo "$alert_record" >> "$ALERT_FILE"
        
        log_structured "AUDIT" "Health alert sent: $alert_level" "alerting" "$SESSION_ID" "alerting"
    fi
}

# ==============================================================================
# MAIN ENTERPRISE EXECUTION
# ==============================================================================

main() {
    local main_span_id="$(create_health_span "enterprise_health_check")"
    
    log_structured "INFO" "Starting MacSpark Enterprise Health Monitoring v$SCRIPT_VERSION" "main" "$main_span_id" "main"
    
    # Initialize metrics file
    echo "# MacSpark Enterprise Health Metrics - $(date)" > "$METRICS_FILE"
    
    # Record session start metrics
    record_health_metric "health_check_started" "$(date +%s)" "gauge" "" "Health check start timestamp"
    record_health_metric "health_check_version" "1" "gauge" "{version=\"$SCRIPT_VERSION\"}" "Health check script version"
    
    # Execute comprehensive health checks
    monitor_health_check "disk_space" "check_enterprise_disk_space"
    monitor_health_check "backup_freshness" "check_enterprise_backup_freshness"  
    monitor_health_check "cloud_sync" "check_enterprise_cloud_sync"
    monitor_health_check "system_resources" "check_enterprise_system_resources"
    monitor_health_check "network_connectivity" "check_enterprise_network_connectivity"
    monitor_health_check "services" "check_enterprise_services"
    
    # Generate comprehensive reporting
    local report_file="$(generate_enterprise_health_report)"
    
    # Send alerts if needed
    send_enterprise_health_alerts
    
    # Final metrics
    local session_duration="$(($(date +%s) - START_TIME))"
    record_health_metric "health_check_duration_seconds" "$session_duration" "histogram" "" "Total health check duration"
    record_health_metric "health_check_completed" "$(date +%s)" "gauge" "" "Health check completion timestamp"
    
    # Cleanup old reports (enterprise retention)
    find "$STATUS_DIR" -name "health-report-*.html" -type f -mtime +90 -delete 2>/dev/null || true
    find "$LOG_DIR" -name "*.log" -type f -mtime +365 -delete 2>/dev/null || true
    
    # Display final status
    case "$OVERALL_STATUS" in
        "HEALTHY")
            log_structured "SUCCESS" "Enterprise health check completed successfully - System is HEALTHY (Score: $OVERALL_HEALTH_SCORE/100)" "main" "$main_span_id" "main"
            ;;
        "WARNING")
            log_structured "WARN" "Enterprise health check completed with warnings (Score: $OVERALL_HEALTH_SCORE/100)" "main" "$main_span_id" "main"
            ;;
        "DEGRADED")
            log_structured "ERROR" "Enterprise health check found issues - System is DEGRADED (Score: $OVERALL_HEALTH_SCORE/100)" "main" "$main_span_id" "main"
            ;;
        "CRITICAL")
            log_structured "CRITICAL" "Enterprise health check found critical issues - System is CRITICAL (Score: $OVERALL_HEALTH_SCORE/100)" "main" "$main_span_id" "main"
            ;;
    esac
    
    echo -e "\n${WHITE}Enterprise Health Report: ${CYAN}file://$report_file${NC}"
    echo -e "${WHITE}Metrics File: ${CYAN}$METRICS_FILE${NC}"
    echo -e "${WHITE}Status JSON: ${CYAN}$STATUS_FILE${NC}\n"
    
    # Return appropriate exit code
    case "$OVERALL_STATUS" in
        "CRITICAL") exit 2 ;;
        "DEGRADED") exit 1 ;;
        "WARNING") exit 1 ;;
        *) exit 0 ;;
    esac
}

# Initialize enterprise health monitoring
main "$@"