#!/bin/bash
# ============================================================================
# MACSPARK BACKUP SYSTEM - Logging Library
# ============================================================================
# Biblioteca centralizada de logging para todos os scripts de backup
# Versão: 2025.1.0
# ============================================================================

# Cores para output
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly PURPLE='\033[0;35m'
readonly CYAN='\033[0;36m'
readonly WHITE='\033[1;37m'
readonly NC='\033[0m'

# Configuração de logs
LOGS_PATH="${LOGS_PATH:-/opt/macspark/logs}"
LOGFILE="${LOGS_PATH}/backup_$(date +%Y%m%d).log"
STRUCTURED_LOG="${LOGS_PATH}/backup-structured.log"
MONITORING_ENABLED="${MONITORING_ENABLED:-true}"

# Garantir que o diretório de logs existe
mkdir -p "$LOGS_PATH"

# Função principal de logging
log() {
    local level=$1
    shift
    local message="$*"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    case $level in
        INFO)    echo -e "${BLUE}[INFO]${NC} $message" | tee -a "$LOGFILE" ;;
        SUCCESS) echo -e "${GREEN}[SUCCESS]${NC} $message" | tee -a "$LOGFILE" ;;
        WARNING) echo -e "${YELLOW}[WARNING]${NC} $message" | tee -a "$LOGFILE" ;;
        ERROR)   echo -e "${RED}[ERROR]${NC} $message" | tee -a "$LOGFILE" ;;
        DEBUG)   [[ "${DEBUG:-false}" == "true" ]] && echo -e "${CYAN}[DEBUG]${NC} $message" | tee -a "$LOGFILE" ;;
        CRITICAL) echo -e "${RED}${WHITE}[CRITICAL]${NC} $message" | tee -a "$LOGFILE" ;;
    esac
    
    # Log estruturado para monitoring
    if [[ "$MONITORING_ENABLED" == "true" ]]; then
        echo "{\"timestamp\":\"$timestamp\",\"level\":\"$level\",\"message\":\"$message\",\"component\":\"backup\"}" >> "$STRUCTURED_LOG"
    fi
}

# Log com métricas
log_metric() {
    local metric_name=$1
    local metric_value=$2
    local metric_type=${3:-gauge}
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    if [[ "$MONITORING_ENABLED" == "true" ]]; then
        echo "{\"timestamp\":\"$timestamp\",\"metric\":\"$metric_name\",\"value\":$metric_value,\"type\":\"$metric_type\"}" >> "${LOGS_PATH}/metrics.json"
    fi
    
    log DEBUG "Metric: $metric_name=$metric_value ($metric_type)"
}

# Função para log de início de operação
log_operation_start() {
    local operation=$1
    echo "════════════════════════════════════════════════════════════════" | tee -a "$LOGFILE"
    log INFO "Starting operation: $operation"
    echo "Start time: $(date)" | tee -a "$LOGFILE"
    echo "════════════════════════════════════════════════════════════════" | tee -a "$LOGFILE"
}

# Função para log de fim de operação
log_operation_end() {
    local operation=$1
    local status=$2
    echo "════════════════════════════════════════════════════════════════" | tee -a "$LOGFILE"
    if [[ "$status" == "success" ]]; then
        log SUCCESS "Operation completed: $operation"
    else
        log ERROR "Operation failed: $operation"
    fi
    echo "End time: $(date)" | tee -a "$LOGFILE"
    echo "════════════════════════════════════════════════════════════════" | tee -a "$LOGFILE"
}

# Rotação de logs
rotate_logs() {
    local max_logs=${1:-30}
    log INFO "Rotating logs older than $max_logs days"
    find "$LOGS_PATH" -name "backup_*.log" -mtime +$max_logs -delete
    find "$LOGS_PATH" -name "*.json" -mtime +$max_logs -delete
}

# Export das funções
export -f log
export -f log_metric
export -f log_operation_start
export -f log_operation_end
export -f rotate_logs