#!/bin/bash
# ============================================================================
# MACSPARK BACKUP SYSTEM MANAGER
# ============================================================================
# Script de gerenciamento do sistema de backup
# Deploy, teste, monitoramento e manutenção
# Versão: 2025.1.0
# ============================================================================

set -euo pipefail

# Diretório base do script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LIB_DIR="${SCRIPT_DIR}/lib"

# Carregar biblioteca de logging
source "${LIB_DIR}/logging.sh"

# Comando principal
COMMAND="${1:-help}"
shift || true

# ============================================================================
# FUNÇÕES DE GERENCIAMENTO
# ============================================================================

show_help() {
    cat << EOF
╔══════════════════════════════════════════════════════════════════════════════╗
║                    MACSPARK BACKUP SYSTEM MANAGER                             ║
╚══════════════════════════════════════════════════════════════════════════════╝

Usage: $0 COMMAND [OPTIONS]

COMMANDS:
    deploy              Deploy backup system infrastructure
    test                Run backup/restore tests
    schedule            Configure backup schedules (cron)
    status              Show backup system status
    verify              Verify recent backups integrity
    cleanup             Clean old backups based on retention
    report              Generate backup reports
    monitor             Start monitoring dashboard
    migrate             Migrate from old backup system
    help                Show this help message

DEPLOY OPTIONS:
    deploy local        Deploy for local environment
    deploy docker       Deploy Docker-based backup services
    deploy cloud        Deploy cloud backup infrastructure

TEST OPTIONS:
    test unit           Run unit tests
    test integration    Run integration tests
    test restore        Test restore procedures
    test all            Run all tests

SCHEDULE OPTIONS:
    schedule show       Show current schedules
    schedule add        Add new backup schedule
    schedule remove     Remove backup schedule
    schedule enable     Enable scheduled backups
    schedule disable    Disable scheduled backups

Examples:
    $0 deploy local             # Deploy local backup system
    $0 test all                 # Run all tests
    $0 schedule add hourly      # Add hourly backup schedule
    $0 status                   # Show system status
    $0 cleanup --days=7         # Clean backups older than 7 days

EOF
    exit 0
}

# ============================================================================
# DEPLOY FUNCTIONS
# ============================================================================
deploy_system() {
    local environment="${1:-local}"
    
    log_operation_start "Deploy Backup System - $environment"
    
    case "$environment" in
        local)
            deploy_local
            ;;
        docker)
            deploy_docker
            ;;
        cloud)
            deploy_cloud
            ;;
        *)
            log ERROR "Unknown environment: $environment"
            exit 1
            ;;
    esac
    
    log_operation_end "Deploy Backup System" "success"
}

deploy_local() {
    log INFO "Deploying local backup system"
    
    # Criar estrutura de diretórios
    local dirs=(
        "/opt/macspark/backups/databases"
        "/opt/macspark/backups/volumes"
        "/opt/macspark/backups/configs"
        "/opt/macspark/backups/logs"
    )
    
    for dir in "${dirs[@]}"; do
        if [[ ! -d "$dir" ]]; then
            log INFO "Creating directory: $dir"
            sudo mkdir -p "$dir"
            sudo chown -R "$USER:$USER" "/opt/macspark"
        fi
    done
    
    # Instalar dependências
    log INFO "Checking dependencies"
    local deps=("gzip" "tar" "docker" "jq")
    
    for dep in "${deps[@]}"; do
        if ! command -v "$dep" &> /dev/null; then
            log WARNING "Missing dependency: $dep"
            log INFO "Please install $dep manually"
        else
            log SUCCESS "✓ $dep installed"
        fi
    done
    
    # Configurar permissões
    log INFO "Setting permissions"
    chmod +x "${SCRIPT_DIR}/backup.sh"
    chmod +x "${SCRIPT_DIR}/restore.sh"
    chmod +x "${SCRIPT_DIR}/manage.sh"
    chmod +x "${LIB_DIR}"/*.sh
    
    log SUCCESS "Local backup system deployed successfully"
}

deploy_docker() {
    log INFO "Deploying Docker-based backup services"
    
    # Deploy Kopia server se configurado
    if [[ -f "${SCRIPT_DIR}/../../stacks/infrastructure/backup/kopia-server.yml" ]]; then
        log INFO "Deploying Kopia backup server"
        docker stack deploy -c "${SCRIPT_DIR}/../../stacks/infrastructure/backup/kopia-server.yml" backup
    fi
    
    log SUCCESS "Docker backup services deployed"
}

deploy_cloud() {
    log INFO "Deploying cloud backup infrastructure"
    
    # Verificar configurações AWS/Azure/GCP
    log INFO "Cloud deployment requires manual configuration"
    log INFO "Please configure your cloud provider settings in config/targets/"
    
    log SUCCESS "Cloud backup preparation complete"
}

# ============================================================================
# TEST FUNCTIONS
# ============================================================================
run_tests() {
    local test_type="${1:-all}"
    
    log_operation_start "Running Tests - $test_type"
    
    case "$test_type" in
        unit)
            run_unit_tests
            ;;
        integration)
            run_integration_tests
            ;;
        restore)
            run_restore_tests
            ;;
        all)
            run_unit_tests
            run_integration_tests
            run_restore_tests
            ;;
        *)
            log ERROR "Unknown test type: $test_type"
            exit 1
            ;;
    esac
    
    log_operation_end "Tests" "success"
}

run_unit_tests() {
    log INFO "Running unit tests"
    
    # Testar bibliotecas
    for lib in "${LIB_DIR}"/*.sh; do
        log INFO "Testing: $(basename "$lib")"
        if bash -n "$lib"; then
            log SUCCESS "✓ Syntax check passed: $(basename "$lib")"
        else
            log ERROR "✗ Syntax check failed: $(basename "$lib")"
            return 1
        fi
    done
}

run_integration_tests() {
    log INFO "Running integration tests"
    
    # Criar container de teste
    log INFO "Creating test container"
    docker run -d --name test_postgres_backup \
        -e POSTGRES_PASSWORD=testpass \
        postgres:latest
    
    sleep 5
    
    # Testar backup
    log INFO "Testing backup functionality"
    "${SCRIPT_DIR}/backup.sh" databases all --dry-run
    
    # Limpar
    docker rm -f test_postgres_backup
    
    log SUCCESS "Integration tests completed"
}

run_restore_tests() {
    log INFO "Running restore tests"
    
    # Teste de restore dry-run
    "${SCRIPT_DIR}/restore.sh" latest full --dry-run
    
    log SUCCESS "Restore tests completed"
}

# ============================================================================
# SCHEDULE FUNCTIONS
# ============================================================================
manage_schedule() {
    local action="${1:-show}"
    
    case "$action" in
        show)
            show_schedules
            ;;
        add)
            add_schedule "${2:-daily}"
            ;;
        remove)
            remove_schedule "${2:-}"
            ;;
        enable)
            enable_schedules
            ;;
        disable)
            disable_schedules
            ;;
        *)
            log ERROR "Unknown schedule action: $action"
            exit 1
            ;;
    esac
}

show_schedules() {
    log INFO "Current backup schedules:"
    crontab -l 2>/dev/null | grep -E "(backup\.sh|macspark)" || echo "No schedules configured"
}

add_schedule() {
    local frequency="${1:-daily}"
    local cron_expr=""
    
    case "$frequency" in
        hourly)
            cron_expr="0 * * * *"
            ;;
        daily)
            cron_expr="0 2 * * *"
            ;;
        weekly)
            cron_expr="0 2 * * 0"
            ;;
        monthly)
            cron_expr="0 2 1 * *"
            ;;
        *)
            log ERROR "Unknown frequency: $frequency"
            exit 1
            ;;
    esac
    
    # Adicionar ao crontab
    (crontab -l 2>/dev/null || true; echo "$cron_expr ${SCRIPT_DIR}/backup.sh full all --retention=30") | crontab -
    
    log SUCCESS "Added $frequency backup schedule"
}

remove_schedule() {
    local pattern="${1:-backup.sh}"
    
    crontab -l 2>/dev/null | grep -v "$pattern" | crontab -
    
    log SUCCESS "Removed schedules matching: $pattern"
}

enable_schedules() {
    log INFO "Enabling backup schedules"
    sudo systemctl enable cron 2>/dev/null || sudo systemctl enable crond 2>/dev/null || true
    sudo systemctl start cron 2>/dev/null || sudo systemctl start crond 2>/dev/null || true
    log SUCCESS "Backup schedules enabled"
}

disable_schedules() {
    log INFO "Disabling backup schedules"
    remove_schedule "backup.sh"
    log SUCCESS "Backup schedules disabled"
}

# ============================================================================
# STATUS FUNCTIONS
# ============================================================================
show_status() {
    log_operation_start "Backup System Status"
    
    # Verificar serviços
    echo ""
    echo "═══════════════════════════════════════════════════════════════"
    echo "SERVICES STATUS"
    echo "═══════════════════════════════════════════════════════════════"
    
    # Docker status
    if systemctl is-active docker >/dev/null 2>&1; then
        echo "✅ Docker: Running"
    else
        echo "❌ Docker: Not running"
    fi
    
    # Cron status
    if systemctl is-active cron >/dev/null 2>&1 || systemctl is-active crond >/dev/null 2>&1; then
        echo "✅ Cron: Running"
    else
        echo "⚠️  Cron: Not running"
    fi
    
    # Backup directories
    echo ""
    echo "═══════════════════════════════════════════════════════════════"
    echo "BACKUP STORAGE"
    echo "═══════════════════════════════════════════════════════════════"
    
    local backup_root="${BACKUP_ROOT:-/opt/macspark/backups}"
    if [[ -d "$backup_root" ]]; then
        echo "Location: $backup_root"
        echo "Total size: $(du -sh "$backup_root" 2>/dev/null | cut -f1)"
        echo ""
        echo "Breakdown:"
        for dir in databases volumes configs; do
            if [[ -d "$backup_root/$dir" ]]; then
                local size=$(du -sh "$backup_root/$dir" 2>/dev/null | cut -f1)
                local count=$(find "$backup_root/$dir" -type f 2>/dev/null | wc -l)
                echo "  $dir: $count files, $size"
            fi
        done
    else
        echo "❌ Backup directory not found: $backup_root"
    fi
    
    # Recent backups
    echo ""
    echo "═══════════════════════════════════════════════════════════════"
    echo "RECENT BACKUPS (Last 24h)"
    echo "═══════════════════════════════════════════════════════════════"
    
    find "$backup_root" -type f -mtime -1 -name "*.gz" -o -name "*.tar" 2>/dev/null | \
        head -5 | while read -r file; do
        echo "  $(date -r "$file" '+%Y-%m-%d %H:%M') - $(basename "$file") ($(du -h "$file" | cut -f1))"
    done || echo "  No recent backups found"
    
    # Scheduled backups
    echo ""
    echo "═══════════════════════════════════════════════════════════════"
    echo "SCHEDULED BACKUPS"
    echo "═══════════════════════════════════════════════════════════════"
    show_schedules
    
    echo ""
    log_operation_end "Backup System Status" "success"
}

# ============================================================================
# VERIFY FUNCTIONS
# ============================================================================
verify_backups() {
    log_operation_start "Verify Recent Backups"
    
    local backup_root="${BACKUP_ROOT:-/opt/macspark/backups}"
    local errors=0
    local verified=0
    
    # Verificar backups das últimas 24h
    for backup in $(find "$backup_root" -type f -mtime -1 \( -name "*.gz" -o -name "*.tar" \) 2>/dev/null); do
        if [[ -f "$backup" ]]; then
            ((verified++))
            if gzip -t "$backup" 2>/dev/null || tar -tf "$backup" >/dev/null 2>&1; then
                log SUCCESS "✓ Verified: $(basename "$backup")"
            else
                log ERROR "✗ Corrupted: $(basename "$backup")"
                ((errors++))
            fi
        fi
    done
    
    log INFO "Verified $verified backups, $errors errors found"
    
    log_operation_end "Verify Backups" $([ $errors -eq 0 ] && echo "success" || echo "failed")
}

# ============================================================================
# CLEANUP FUNCTIONS
# ============================================================================
cleanup_backups() {
    local days="${1:-30}"
    
    log_operation_start "Cleanup Old Backups"
    log INFO "Removing backups older than $days days"
    
    local backup_root="${BACKUP_ROOT:-/opt/macspark/backups}"
    local count=0
    
    # Contar arquivos a serem removidos
    count=$(find "$backup_root" -type f -mtime +$days \( -name "*.gz" -o -name "*.tar" \) 2>/dev/null | wc -l)
    
    if [[ $count -gt 0 ]]; then
        log INFO "Found $count files to remove"
        
        # Remover arquivos
        find "$backup_root" -type f -mtime +$days \( -name "*.gz" -o -name "*.tar" \) -delete 2>/dev/null
        
        log SUCCESS "Removed $count old backup files"
    else
        log INFO "No old backups to remove"
    fi
    
    # Limpar logs também
    rotate_logs $days
    
    log_operation_end "Cleanup" "success"
}

# ============================================================================
# REPORT FUNCTIONS
# ============================================================================
generate_report() {
    log_operation_start "Generate Backup Report"
    
    local report_file="${BACKUP_ROOT:-/opt/macspark/backups}/logs/system_report_$(date +%Y%m%d_%H%M%S).html"
    
    cat > "$report_file" << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <title>MacSpark Backup System Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; }
        h1 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 10px; }
        h2 { color: #555; margin-top: 30px; }
        .stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin: 20px 0; }
        .stat-card { background: #f8f9fa; padding: 15px; border-radius: 5px; border-left: 4px solid #007bff; }
        .stat-value { font-size: 24px; font-weight: bold; color: #007bff; }
        .stat-label { color: #666; margin-top: 5px; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #007bff; color: white; }
        .success { color: #28a745; }
        .warning { color: #ffc107; }
        .error { color: #dc3545; }
    </style>
</head>
<body>
    <div class="container">
        <h1>MacSpark Backup System Report</h1>
        <p>Generated: $(date)</p>
        
        <h2>System Overview</h2>
        <div class="stat-grid">
            <div class="stat-card">
                <div class="stat-value">$(find "${BACKUP_ROOT:-/opt/macspark/backups}" -type f -name "*.gz" -o -name "*.tar" 2>/dev/null | wc -l)</div>
                <div class="stat-label">Total Backup Files</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">$(du -sh "${BACKUP_ROOT:-/opt/macspark/backups}" 2>/dev/null | cut -f1)</div>
                <div class="stat-label">Total Storage Used</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">$(find "${BACKUP_ROOT:-/opt/macspark/backups}" -type f -mtime -1 2>/dev/null | wc -l)</div>
                <div class="stat-label">Backups (Last 24h)</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">$(find "${BACKUP_ROOT:-/opt/macspark/backups}" -type f -mtime -7 2>/dev/null | wc -l)</div>
                <div class="stat-label">Backups (Last 7 days)</div>
            </div>
        </div>
        
        <h2>Recent Backup Activity</h2>
        <table>
            <tr>
                <th>Date</th>
                <th>File</th>
                <th>Size</th>
                <th>Type</th>
            </tr>
EOF
    
    # Adicionar backups recentes à tabela
    find "${BACKUP_ROOT:-/opt/macspark/backups}" -type f -mtime -7 \( -name "*.gz" -o -name "*.tar" \) 2>/dev/null | \
        head -20 | while read -r file; do
        local date=$(date -r "$file" '+%Y-%m-%d %H:%M')
        local name=$(basename "$file")
        local size=$(du -h "$file" | cut -f1)
        local type="Unknown"
        
        [[ "$file" == */databases/* ]] && type="Database"
        [[ "$file" == */volumes/* ]] && type="Volume"
        [[ "$file" == */configs/* ]] && type="Configuration"
        
        echo "<tr><td>$date</td><td>$name</td><td>$size</td><td>$type</td></tr>" >> "$report_file"
    done
    
    cat >> "$report_file" << 'EOF'
        </table>
        
        <h2>Storage Distribution</h2>
        <div class="stat-grid">
EOF
    
    # Adicionar distribuição de storage
    for dir in databases volumes configs; do
        if [[ -d "${BACKUP_ROOT:-/opt/macspark/backups}/$dir" ]]; then
            local size=$(du -sh "${BACKUP_ROOT:-/opt/macspark/backups}/$dir" 2>/dev/null | cut -f1)
            local count=$(find "${BACKUP_ROOT:-/opt/macspark/backups}/$dir" -type f 2>/dev/null | wc -l)
            cat >> "$report_file" << EOF
            <div class="stat-card">
                <div class="stat-value">$size</div>
                <div class="stat-label">$dir ($count files)</div>
            </div>
EOF
        fi
    done
    
    cat >> "$report_file" << 'EOF'
        </div>
        
        <p style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #ddd; color: #666;">
            MacSpark Backup System v2025.1.0 | 
            <a href="https://github.com/macspark">GitHub</a> | 
            <a href="https://macspark.dev">Documentation</a>
        </p>
    </div>
</body>
</html>
EOF
    
    log SUCCESS "Report generated: $report_file"
    
    # Tentar abrir no navegador se disponível
    if command -v xdg-open &> /dev/null; then
        xdg-open "$report_file" 2>/dev/null || true
    fi
    
    log_operation_end "Generate Report" "success"
}

# ============================================================================
# MAIN EXECUTION
# ============================================================================
main() {
    case "$COMMAND" in
        deploy)
            deploy_system "$@"
            ;;
        test)
            run_tests "$@"
            ;;
        schedule)
            manage_schedule "$@"
            ;;
        status)
            show_status
            ;;
        verify)
            verify_backups
            ;;
        cleanup)
            cleanup_backups "${1:-30}"
            ;;
        report)
            generate_report
            ;;
        monitor)
            log INFO "Starting monitoring dashboard..."
            log INFO "Access Grafana at: http://localhost:3000"
            log INFO "Default credentials: admin/admin"
            ;;
        migrate)
            log INFO "Migration from old system"
            log WARNING "This will import settings from the old backup system"
            log INFO "Please run: ./backup-migration-master.sh"
            ;;
        help|*)
            show_help
            ;;
    esac
}

# Executar se não estiver sendo sourced
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi