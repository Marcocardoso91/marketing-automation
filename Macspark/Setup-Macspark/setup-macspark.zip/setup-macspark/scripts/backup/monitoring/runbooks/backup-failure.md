# 🚨 Runbook: Backup Failure

## Alert: BackupFailed

### Severity: CRITICAL

### Description
O job de backup falhou e não foi concluído com sucesso.

### Impact
- Dados não estão sendo protegidos
- RPO (Recovery Point Objective) pode ser violado
- Risco de perda de dados em caso de falha

### Diagnosis Steps

1. **Verificar logs do backup:**
```bash
tail -f /opt/macspark/backups/logs/backup_$(date +%Y%m%d).log
```

2. **Verificar status dos serviços:**
```bash
./scripts/backup/manage.sh status
```

3. **Verificar espaço em disco:**
```bash
df -h /opt/macspark/backups
```

4. **Verificar conectividade com storage remoto:**
```bash
# Para S3
aws s3 ls s3://backup-bucket/ --profile backup

# Para Azure
az storage blob list --container-name backups
```

5. **Verificar containers Docker:**
```bash
docker ps -a | grep -E "(postgres|mysql|redis)"
```

### Resolution Steps

#### Problema: Espaço em disco insuficiente
```bash
# Limpar backups antigos
./scripts/backup/manage.sh cleanup --days=3

# Verificar volumes Docker não utilizados
docker volume prune -f
```

#### Problema: Container de database down
```bash
# Reiniciar container
docker restart <container_name>

# Verificar logs do container
docker logs <container_name> --tail 100
```

#### Problema: Credenciais expiradas
```bash
# Atualizar credenciais no .env
vim /opt/macspark/.env

# Recarregar configurações
source /opt/macspark/.env
```

#### Problema: Rede/Conectividade
```bash
# Testar conectividade
ping -c 4 backup.server.com

# Verificar firewall
sudo iptables -L -n | grep 443
```

### Validation

1. **Executar backup manual:**
```bash
./scripts/backup/backup.sh full all --verify
```

2. **Verificar integridade:**
```bash
./scripts/backup/manage.sh verify
```

3. **Testar restore:**
```bash
./scripts/backup/restore.sh latest full --dry-run
```

### Escalation

Se o problema persistir após 30 minutos:

1. **Notificar:** Team Lead de Infraestrutura
2. **Slack:** #infrastructure-critical
3. **PagerDuty:** Escalar para on-call engineer
4. **Fallback:** Ativar backup secundário manual

### Prevention

1. Monitorar espaço em disco continuamente
2. Testar restore semanalmente
3. Rotacionar credenciais mensalmente
4. Manter documentação atualizada

### Related Documents
- [Backup Architecture](../../../docs/architecture/backup-system.md)
- [Disaster Recovery Plan](../../../docs/operations/disaster-recovery.md)
- [SLA Requirements](../../../docs/compliance/sla.md)

---

**Last Updated:** 25/08/2025  
**Owner:** Infrastructure Team  
**Review Cycle:** Monthly