#!/bin/bash
# ============================================================================
# MACSPARK UNIFIED RESTORE ORCHESTRATOR
# ============================================================================
# Script consolidado para restauração de backups
# Versão: 2025.1.0
# ============================================================================

set -euo pipefail

# Diretório base do script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LIB_DIR="${SCRIPT_DIR}/lib"

# Carregar bibliotecas
source "${LIB_DIR}/logging.sh"

# Carregar configurações do ambiente se existir
if [[ -f "${SCRIPT_DIR}/../../.env" ]]; then
    source "${SCRIPT_DIR}/../../.env"
fi

# ============================================================================
# CONFIGURAÇÕES
# ============================================================================
BACKUP_ROOT="${BACKUP_ROOT:-/opt/macspark/backups}"
RESTORE_DATE="${1:-latest}"  # latest ou YYYYMMDD
RESTORE_TYPE="${2:-full}"    # full, databases, volumes, configs
RESTORE_TARGET="${3:-}"      # Específico para restore parcial

# ============================================================================
# FUNÇÕES DE SUPORTE
# ============================================================================

show_usage() {
    cat << EOF
Usage: $0 [DATE] [TYPE] [TARGET] [OPTIONS]

DATE:
    latest      - Use most recent backup (default)
    YYYYMMDD    - Use backup from specific date

TYPE:
    full        - Complete restore (databases + volumes + configs)
    databases   - Restore databases only
    volumes     - Restore Docker volumes only
    configs     - Restore configuration files only
    
TARGET:
    (optional)  - Specific service/volume/database to restore

OPTIONS:
    --dry-run           - Show what would be restored
    --force             - Skip confirmation prompts
    --verify            - Verify backup before restore
    --parallel=N        - Number of parallel restore jobs
    --help              - Show this help message

Examples:
    $0 latest full                     # Restore everything from latest backup
    $0 20250825 databases postgres     # Restore PostgreSQL from specific date
    $0 latest volumes redis_data        # Restore specific volume
    
WARNING: Restore operations will overwrite existing data!

EOF
    exit 0
}

# Parse argumentos adicionais
parse_options() {
    for arg in "${@:4}"; do
        case $arg in
            --dry-run)
                DRY_RUN=true
                log INFO "Dry run mode enabled"
                ;;
            --force)
                FORCE_RESTORE=true
                log INFO "Force mode enabled - skipping confirmations"
                ;;
            --verify)
                VERIFY_BEFORE_RESTORE=true
                log INFO "Backup verification enabled"
                ;;
            --parallel=*)
                PARALLEL_JOBS="${arg#*=}"
                log INFO "Parallel jobs set to: $PARALLEL_JOBS"
                ;;
            --help)
                show_usage
                ;;
            *)
                log WARNING "Unknown option: $arg"
                ;;
        esac
    done
}

# ============================================================================
# CONFIRMAÇÃO DE RESTORE
# ============================================================================
confirm_restore() {
    if [[ "${FORCE_RESTORE:-false}" == "true" ]]; then
        return 0
    fi
    
    echo ""
    echo "════════════════════════════════════════════════════════════════"
    echo "⚠️  WARNING: This will OVERWRITE existing data!"
    echo "════════════════════════════════════════════════════════════════"
    echo ""
    echo "Restore configuration:"
    echo "  Date: $RESTORE_DATE"
    echo "  Type: $RESTORE_TYPE"
    echo "  Target: ${RESTORE_TARGET:-ALL}"
    echo ""
    read -p "Are you sure you want to continue? (yes/no): " confirmation
    
    if [[ "$confirmation" != "yes" ]]; then
        log WARNING "Restore cancelled by user"
        exit 1
    fi
}

# ============================================================================
# ENCONTRAR BACKUP MAIS RECENTE
# ============================================================================
find_latest_backup() {
    local backup_type=$1
    local backup_dir="${BACKUP_ROOT}/${backup_type}"
    
    if [[ ! -d "$backup_dir" ]]; then
        log ERROR "Backup directory not found: $backup_dir"
        return 1
    fi
    
    local latest_file=$(ls -t "$backup_dir"/*.{sql.gz,tar.gz,rdb.gz} 2>/dev/null | head -1)
    
    if [[ -z "$latest_file" ]]; then
        log ERROR "No backup files found in: $backup_dir"
        return 1
    fi
    
    echo "$latest_file"
}

# ============================================================================
# RESTORE DATABASE
# ============================================================================
restore_database() {
    local backup_file=$1
    local container_name=$2
    
    log INFO "Restoring database to container: $container_name"
    log INFO "Backup file: $backup_file"
    
    # Verificar se o container existe
    if ! docker ps --filter "name=$container_name" --format '{{.Names}}' | grep -q "^${container_name}$"; then
        log ERROR "Container $container_name not found or not running"
        return 1
    fi
    
    # Detectar tipo de database pelo nome do arquivo
    local db_type=""
    if [[ "$backup_file" == *postgres* ]]; then
        db_type="postgresql"
    elif [[ "$backup_file" == *mysql* ]] || [[ "$backup_file" == *mariadb* ]]; then
        db_type="mysql"
    elif [[ "$backup_file" == *mongo* ]]; then
        db_type="mongodb"
    elif [[ "$backup_file" == *redis* ]]; then
        db_type="redis"
    else
        log ERROR "Cannot determine database type from filename"
        return 1
    fi
    
    # Executar restore baseado no tipo
    case "$db_type" in
        postgresql)
            log INFO "Restoring PostgreSQL database"
            if [[ "$backup_file" == *.gz ]]; then
                gunzip -c "$backup_file" | docker exec -i "$container_name" psql -U postgres
            else
                docker exec -i "$container_name" psql -U postgres < "$backup_file"
            fi
            ;;
        mysql)
            log INFO "Restoring MySQL database"
            local root_password=$(docker exec "$container_name" printenv MYSQL_ROOT_PASSWORD 2>/dev/null || \
                                 docker exec "$container_name" printenv MARIADB_ROOT_PASSWORD 2>/dev/null)
            if [[ "$backup_file" == *.gz ]]; then
                gunzip -c "$backup_file" | docker exec -i "$container_name" mysql -u root -p"$root_password"
            else
                docker exec -i "$container_name" mysql -u root -p"$root_password" < "$backup_file"
            fi
            ;;
        mongodb)
            log INFO "Restoring MongoDB database"
            local temp_dir="/tmp/mongorestore_$$"
            mkdir -p "$temp_dir"
            tar -xzf "$backup_file" -C "$temp_dir"
            docker cp "$temp_dir" "$container_name:/tmp/"
            docker exec "$container_name" mongorestore "/tmp/$(basename "$temp_dir")"
            rm -rf "$temp_dir"
            ;;
        redis)
            log INFO "Restoring Redis database"
            if [[ "$backup_file" == *.gz ]]; then
                gunzip -c "$backup_file" > /tmp/dump.rdb
                docker cp /tmp/dump.rdb "$container_name:/data/dump.rdb"
                rm /tmp/dump.rdb
            else
                docker cp "$backup_file" "$container_name:/data/dump.rdb"
            fi
            docker exec "$container_name" redis-cli SHUTDOWN NOSAVE
            docker restart "$container_name"
            ;;
    esac
    
    if [[ $? -eq 0 ]]; then
        log SUCCESS "Database restored successfully: $container_name"
        return 0
    else
        log ERROR "Database restore failed: $container_name"
        return 1
    fi
}

# ============================================================================
# RESTORE VOLUME
# ============================================================================
restore_volume() {
    local backup_file=$1
    local volume_name=$2
    
    log INFO "Restoring volume: $volume_name"
    log INFO "Backup file: $backup_file"
    
    # Verificar se o volume existe, criar se não existir
    if ! docker volume ls --format '{{.Name}}' | grep -q "^${volume_name}$"; then
        log WARNING "Volume $volume_name not found, creating it"
        docker volume create "$volume_name"
    fi
    
    # Limpar volume existente
    log INFO "Cleaning existing volume data"
    docker run --rm -v "${volume_name}:/data" alpine sh -c "rm -rf /data/*"
    
    # Restaurar dados
    if [[ "$backup_file" == *.gz ]]; then
        docker run --rm \
            -v "${volume_name}:/data" \
            -v "$(dirname "$backup_file"):/backup:ro" \
            alpine sh -c "tar -xzf /backup/$(basename "$backup_file") -C /data"
    else
        docker run --rm \
            -v "${volume_name}:/data" \
            -v "$(dirname "$backup_file"):/backup:ro" \
            alpine sh -c "tar -xf /backup/$(basename "$backup_file") -C /data"
    fi
    
    if [[ $? -eq 0 ]]; then
        log SUCCESS "Volume restored successfully: $volume_name"
        return 0
    else
        log ERROR "Volume restore failed: $volume_name"
        return 1
    fi
}

# ============================================================================
# RESTORE CONFIGURATIONS
# ============================================================================
restore_configs() {
    local backup_file=$1
    
    log INFO "Restoring configurations from: $backup_file"
    
    # Criar diretório temporário
    local temp_dir="/tmp/config_restore_$$"
    mkdir -p "$temp_dir"
    
    # Extrair backup
    tar -xzf "$backup_file" -C "$temp_dir"
    
    # Restaurar stacks
    if [[ -f "$temp_dir/*/stacks.tar.gz" ]]; then
        log INFO "Restoring stack definitions"
        tar -xzf "$temp_dir/*/stacks.tar.gz" -C "${SCRIPT_DIR}/../.."
    fi
    
    # Restaurar scripts
    if [[ -f "$temp_dir/*/scripts.tar.gz" ]]; then
        log INFO "Restoring scripts"
        tar -xzf "$temp_dir/*/scripts.tar.gz" -C "${SCRIPT_DIR}/../.."
    fi
    
    # Mostrar informações sobre serviços para recriar
    if [[ -f "$temp_dir/*/docker-services.txt" ]]; then
        log INFO "Services to recreate:"
        cat "$temp_dir/*/docker-services.txt"
    fi
    
    # Limpar
    rm -rf "$temp_dir"
    
    log SUCCESS "Configuration restored successfully"
}

# ============================================================================
# VERIFICAR BACKUP ANTES DO RESTORE
# ============================================================================
verify_backup_file() {
    local backup_file=$1
    
    log INFO "Verifying backup file: $backup_file"
    
    if [[ ! -f "$backup_file" ]]; then
        log ERROR "Backup file not found: $backup_file"
        return 1
    fi
    
    # Verificar integridade do arquivo
    if [[ "$backup_file" == *.gz ]]; then
        if gzip -t "$backup_file" 2>/dev/null; then
            log SUCCESS "Backup file verified successfully"
            return 0
        else
            log ERROR "Backup file is corrupted: $backup_file"
            return 1
        fi
    fi
    
    return 0
}

# ============================================================================
# RESTORE COMPLETO
# ============================================================================
restore_full() {
    log_operation_start "Full System Restore"
    
    local errors=0
    
    # Restaurar databases
    log INFO "Restoring all databases"
    for backup in $(find "${BACKUP_ROOT}/databases" -name "*${RESTORE_DATE}*.gz" -type f 2>/dev/null); do
        # Extrair nome do container do nome do arquivo
        local filename=$(basename "$backup")
        local container_name=$(echo "$filename" | cut -d'_' -f1)
        
        if restore_database "$backup" "$container_name"; then
            log SUCCESS "Restored: $container_name"
        else
            ((errors++))
        fi
    done
    
    # Restaurar volumes
    log INFO "Restoring all volumes"
    for backup in $(find "${BACKUP_ROOT}/volumes" -name "*${RESTORE_DATE}*.tar.gz" -type f 2>/dev/null); do
        # Extrair nome do volume do nome do arquivo
        local filename=$(basename "$backup")
        local volume_name=$(echo "$filename" | cut -d'_' -f1)
        
        if restore_volume "$backup" "$volume_name"; then
            log SUCCESS "Restored: $volume_name"
        else
            ((errors++))
        fi
    done
    
    # Restaurar configurações
    local config_backup=$(find "${BACKUP_ROOT}/configs" -name "*${RESTORE_DATE}*.tar.gz" -type f 2>/dev/null | head -1)
    if [[ -n "$config_backup" ]]; then
        restore_configs "$config_backup" || ((errors++))
    fi
    
    if [[ $errors -eq 0 ]]; then
        log_operation_end "Full System Restore" "success"
        return 0
    else
        log_operation_end "Full System Restore" "failed"
        log ERROR "Restore completed with $errors errors"
        return 1
    fi
}

# ============================================================================
# MAIN EXECUTION
# ============================================================================
main() {
    # Parse opções
    parse_options "$@"
    
    # Confirmar restore
    confirm_restore
    
    # Verificar modo dry-run
    if [[ "${DRY_RUN:-false}" == "true" ]]; then
        log INFO "DRY RUN MODE - No actual restore will be performed"
        log INFO "Would restore: $RESTORE_TYPE from $RESTORE_DATE"
        exit 0
    fi
    
    # Iniciar restore
    log_operation_start "MacSpark Unified Restore"
    log INFO "Restore date: $RESTORE_DATE"
    log INFO "Restore type: $RESTORE_TYPE"
    log INFO "Restore target: ${RESTORE_TARGET:-ALL}"
    
    local restore_status="success"
    
    # Executar restore baseado no tipo
    case "$RESTORE_TYPE" in
        full)
            restore_full || restore_status="failed"
            ;;
        databases)
            if [[ -n "$RESTORE_TARGET" ]]; then
                # Restore específico
                local backup_file=$(find "${BACKUP_ROOT}/databases" -name "${RESTORE_TARGET}*${RESTORE_DATE}*.gz" -type f | head -1)
                if [[ -n "$backup_file" ]]; then
                    restore_database "$backup_file" "$RESTORE_TARGET" || restore_status="failed"
                else
                    log ERROR "No backup found for database: $RESTORE_TARGET"
                    restore_status="failed"
                fi
            else
                log ERROR "Database restore requires a target container name"
                restore_status="failed"
            fi
            ;;
        volumes)
            if [[ -n "$RESTORE_TARGET" ]]; then
                # Restore específico
                local backup_file=$(find "${BACKUP_ROOT}/volumes" -name "${RESTORE_TARGET}*${RESTORE_DATE}*.tar.gz" -type f | head -1)
                if [[ -n "$backup_file" ]]; then
                    restore_volume "$backup_file" "$RESTORE_TARGET" || restore_status="failed"
                else
                    log ERROR "No backup found for volume: $RESTORE_TARGET"
                    restore_status="failed"
                fi
            else
                log ERROR "Volume restore requires a target volume name"
                restore_status="failed"
            fi
            ;;
        configs)
            local config_backup=$(find "${BACKUP_ROOT}/configs" -name "*${RESTORE_DATE}*.tar.gz" -type f | head -1)
            if [[ -n "$config_backup" ]]; then
                restore_configs "$config_backup" || restore_status="failed"
            else
                log ERROR "No configuration backup found for date: $RESTORE_DATE"
                restore_status="failed"
            fi
            ;;
        *)
            log ERROR "Unknown restore type: $RESTORE_TYPE"
            show_usage
            ;;
    esac
    
    # Finalizar
    log_operation_end "MacSpark Unified Restore" "$restore_status"
    
    if [[ "$restore_status" == "success" ]]; then
        log SUCCESS "✅ Restore completed successfully!"
        log INFO "Please verify your services are working correctly"
        exit 0
    else
        log ERROR "❌ Restore completed with errors"
        exit 1
    fi
}

# Executar se não estiver sendo sourced
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi