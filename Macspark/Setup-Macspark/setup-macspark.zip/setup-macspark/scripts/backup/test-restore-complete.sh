#!/bin/bash
set -euo pipefail

REPO="${KOPIA_REPOSITORY:-/backups/kopia}"
RESTORE_DIR="${RESTORE_DIR:-/tmp/restore-test}"
SOURCE_PATH="${SOURCE_PATH:-/data/critical}"
CHECK_FILE="${CHECK_FILE:-}"

echo "Validando repositório Kopia..."
kopia repository status || exit 1

echo "Criando diretório de restore: ${RESTORE_DIR}"
mkdir -p "${RESTORE_DIR}"

echo "Selecionando snapshot mais recente de ${SOURCE_PATH}"
SNAP=$(kopia snapshot list "${SOURCE_PATH}" --json | jq -r '.[0].id')
if [ -z "$SNAP" ] || [ "$SNAP" = "null" ]; then
  echo "Nenhum snapshot encontrado para ${SOURCE_PATH}" >&2
  exit 1
fi

echo "Restaurando snapshot ${SNAP} para ${RESTORE_DIR}"
kopia restore "${SNAP}" "${RESTORE_DIR}"

if [ -n "${CHECK_FILE}" ] && [ -f "${CHECK_FILE}" ]; then
  echo "Verificando integridade por checksum (sha256)..."
  ORI_SUM=$(sha256sum "${CHECK_FILE}" | awk '{print $1}')
  RES_SUM=$(sha256sum "${RESTORE_DIR}${CHECK_FILE}" | awk '{print $1}')
  if [ "$ORI_SUM" != "$RES_SUM" ]; then
    echo "Falha: Checksums diferentes" >&2
    exit 1
  fi
fi

echo "OK: Restore validado."


