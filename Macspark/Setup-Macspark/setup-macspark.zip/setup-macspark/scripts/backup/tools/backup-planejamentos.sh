#!/bin/bash
# SISTEMA DE BACKUP AUTOMÁTICO DOS PLANEJAMENTOS CONSOLIDADOS
# Backup incremental com compressão e log detalhado
set -e

# CONFIGURAÇÕES
PLANEJAMENTOS_DIR="/home/marcocardoso/PLANEJAMENTOS_CONSOLIDADOS_2025"
BACKUP_BASE_DIR="/backup/planejamentos"
DATE_STAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="$BACKUP_BASE_DIR/backup_$DATE_STAMP"
LOG_FILE="$PLANEJAMENTOS_DIR/backup_history.log"

# CORES
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}💾 INICIANDO BACKUP DOS PLANEJAMENTOS CONSOLIDADOS${NC}"
echo -e "${YELLOW}Data: $(date)${NC}"
echo -e "${YELLOW}Destino: $BACKUP_DIR${NC}"

# CRIAR DIRETÓRIOS
mkdir -p "$BACKUP_BASE_DIR"
mkdir -p "$BACKUP_DIR"

# LOG INICIAL
echo "=== BACKUP INICIADO ===" >> "$LOG_FILE"
echo "Data: $(date)" >> "$LOG_FILE"
echo "Destino: $BACKUP_DIR" >> "$LOG_FILE"

# FUNÇÃO PARA LOG COM TIMESTAMP
log_with_timestamp() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# VERIFICAR FONTE
if [ ! -d "$PLANEJAMENTOS_DIR" ]; then
    log_with_timestamp "❌ ERRO: Diretório fonte não encontrado: $PLANEJAMENTOS_DIR"
    exit 1
fi

# CONTAR ARQUIVOS FONTE
TOTAL_FILES=$(find "$PLANEJAMENTOS_DIR" -type f -name "*.md" | wc -l)
log_with_timestamp "📊 Total de arquivos MD para backup: $TOTAL_FILES"

# BACKUP COMPLETO COM ESTRUTURA
log_with_timestamp "📦 Iniciando cópia dos arquivos..."

# Copiar estrutura completa mantendo permissões
cp -r "$PLANEJAMENTOS_DIR" "$BACKUP_DIR/" 2>/dev/null || {
    log_with_timestamp "❌ ERRO na cópia dos arquivos"
    exit 1
}

# CRIAR ARQUIVO DE METADADOS
METADATA_FILE="$BACKUP_DIR/BACKUP_METADATA.txt"
cat > "$METADATA_FILE" << EOF
=== BACKUP METADATA ===
Data: $(date)
Origem: $PLANEJAMENTOS_DIR
Destino: $BACKUP_DIR
Total Arquivos MD: $TOTAL_FILES
Tamanho Origem: $(du -sh "$PLANEJAMENTOS_DIR" | cut -f1)
Usuario: $(whoami)
Hostname: $(hostname)
Versao Script: 1.0

=== ESTRUTURA BACKUP ===
$(find "$BACKUP_DIR" -type f -name "*.md" | wc -l) arquivos MD copiados
$(find "$BACKUP_DIR" -type d | wc -l) diretórios criados

=== VERIFICACAO INTEGRIDADE ===
$(find "$BACKUP_DIR" -type f -name "*.md" -exec wc -l {} \; | awk '{sum+=$1} END {print "Total linhas MD:", sum}')

=== ARQUIVOS POR CATEGORIA ===
Planejamentos: $(ls "$BACKUP_DIR"/*/planejamentos/ 2>/dev/null | wc -l)
Análises: $(ls "$BACKUP_DIR"/*/analises/ 2>/dev/null | wc -l)
Guias: $(ls "$BACKUP_DIR"/*/guias/ 2>/dev/null | wc -l)
Backups: $(ls "$BACKUP_DIR"/*/backups/ 2>/dev/null | wc -l)
Estratégias: $(ls "$BACKUP_DIR"/*/estrategias/ 2>/dev/null | wc -l)
Documentação: $(ls "$BACKUP_DIR"/*/documentacao/ 2>/dev/null | wc -l)
EOF

log_with_timestamp "✅ Backup estrutural completo"

# CRIAR ARQUIVO COMPRESSADO
COMPRESSED_FILE="$BACKUP_BASE_DIR/planejamentos_${DATE_STAMP}.tar.gz"
log_with_timestamp "🗜️ Criando arquivo compressado: $COMPRESSED_FILE"

tar -czf "$COMPRESSED_FILE" -C "$BACKUP_BASE_DIR" "backup_$DATE_STAMP" 2>/dev/null || {
    log_with_timestamp "❌ ERRO na compressão"
    exit 1
}

# VERIFICAR INTEGRIDADE DO BACKUP
BACKUP_FILES=$(find "$BACKUP_DIR" -type f -name "*.md" | wc -l)
BACKUP_SIZE=$(du -sh "$COMPRESSED_FILE" | cut -f1)

if [ "$BACKUP_FILES" -eq "$TOTAL_FILES" ]; then
    log_with_timestamp "✅ Verificação de integridade: $BACKUP_FILES/$TOTAL_FILES arquivos - OK"
else
    log_with_timestamp "⚠️ Verificação de integridade: $BACKUP_FILES/$TOTAL_FILES arquivos - DIFERENÇA DETECTADA"
fi

# LIMPEZA DE BACKUPS ANTIGOS (manter últimos 10)
log_with_timestamp "🧹 Limpando backups antigos (mantendo 10 mais recentes)..."
ls -t "$BACKUP_BASE_DIR"/backup_* 2>/dev/null | tail -n +11 | xargs rm -rf 2>/dev/null || true
ls -t "$BACKUP_BASE_DIR"/planejamentos_*.tar.gz 2>/dev/null | tail -n +11 | xargs rm -f 2>/dev/null || true

# CRIAR LINK SIMBÓLICO PARA ÚLTIMO BACKUP
ln -sf "$BACKUP_DIR" "$BACKUP_BASE_DIR/ultimo_backup" 2>/dev/null || true
ln -sf "$COMPRESSED_FILE" "$BACKUP_BASE_DIR/ultimo_backup.tar.gz" 2>/dev/null || true

# RELATÓRIO FINAL
log_with_timestamp "📊 BACKUP CONCLUÍDO COM SUCESSO!"
log_with_timestamp "📁 Diretório: $BACKUP_DIR"
log_with_timestamp "🗜️ Compressado: $COMPRESSED_FILE ($BACKUP_SIZE)"
log_with_timestamp "📋 Metadados: $METADATA_FILE"

echo -e "\n${GREEN}✅ BACKUP DOS PLANEJAMENTOS CONCLUÍDO!${NC}"
echo -e "${BLUE}📊 Estatísticas:${NC}"
echo -e "   📁 Arquivos MD: $BACKUP_FILES"
echo -e "   📦 Tamanho: $BACKUP_SIZE"
echo -e "   📋 Local: $BACKUP_DIR"
echo -e "   🗜️ Compressado: $COMPRESSED_FILE"

# EXIBIR BACKUPS DISPONÍVEIS
echo -e "\n${BLUE}📚 Backups Disponíveis:${NC}"
ls -lth "$BACKUP_BASE_DIR"/*.tar.gz 2>/dev/null | head -5 | while read linha; do
    echo -e "${YELLOW}   $linha${NC}"
done

# LOG FINAL
echo "=== BACKUP CONCLUÍDO ===" >> "$LOG_FILE"
echo "Tamanho: $BACKUP_SIZE" >> "$LOG_FILE"
echo "Arquivos: $BACKUP_FILES" >> "$LOG_FILE"
echo "Status: SUCESSO" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"

# CRIAR SCRIPT DE RESTAURAÇÃO
RESTORE_SCRIPT="$BACKUP_DIR/RESTORE_BACKUP.sh"
cat > "$RESTORE_SCRIPT" << 'EOF'
#!/bin/bash
# SCRIPT DE RESTAURAÇÃO DO BACKUP
set -e

BACKUP_DIR="$(dirname "$0")"
RESTORE_TARGET="/home/marcocardoso/PLANEJAMENTOS_CONSOLIDADOS_2025_RESTORED"

echo "🔄 Restaurando backup..."
echo "📁 De: $BACKUP_DIR"
echo "📁 Para: $RESTORE_TARGET"

# Restaurar
cp -r "$BACKUP_DIR/PLANEJAMENTOS_CONSOLIDADOS_2025" "$RESTORE_TARGET"

echo "✅ Restauração concluída!"
echo "📁 Verificar: $RESTORE_TARGET"
EOF

chmod +x "$RESTORE_SCRIPT"
log_with_timestamp "📜 Script de restauração criado: $RESTORE_SCRIPT"

echo -e "\n${GREEN}🎉 SISTEMA DE BACKUP IMPLEMENTADO COM SUCESSO!${NC}"