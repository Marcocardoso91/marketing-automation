#!/bin/bash
# Script para extrair TODAS as configurações da VPS antes da formatação
# Criado em: 23/08/2025

echo "🚨 EXTRAINDO TODAS AS CONFIGURAÇÕES DA VPS ATUAL"
echo "=============================================="

BACKUP_DIR="/home/marcocardoso/Setup-Macspark/backup-vps-atual"
mkdir -p "$BACKUP_DIR"/{stacks,configs,volumes,secrets,networks}

echo "📦 1. Extraindo todas as stacks Docker..."
mkdir -p "$BACKUP_DIR/stacks"
docker stack ls --format "{{.Name}}" | while read stack; do
    echo "   Extraindo stack: $stack"
    docker service ls --filter "name=$stack" --format "table {{.Name}}\t{{.Image}}\t{{.Replicas}}" > "$BACKUP_DIR/stacks/${stack}_services.txt"
done

echo "🔧 2. Extraindo configurações de serviços..."
docker service ls --format "{{.Name}}\t{{.Image}}\t{{.Replicas}}" > "$BACKUP_DIR/all_services_details.txt"

echo "🌐 3. Backup de networks..."
docker network ls --format "{{.Name}}\t{{.Driver}}\t{{.Scope}}" > "$BACKUP_DIR/networks/networks.txt"

echo "💾 4. Backup de volumes..."
docker volume ls --format "{{.Name}}\t{{.Driver}}" > "$BACKUP_DIR/volumes/volumes.txt"

echo "🔐 5. Backup de secrets..."
docker secret ls --format "{{.Name}}\t{{.CreatedAt}}" > "$BACKUP_DIR/secrets/secrets.txt"

echo "📋 6. Backup de configs..."
docker config ls --format "{{.Name}}\t{{.CreatedAt}}" > "$BACKUP_DIR/configs/configs.txt"

echo "🔍 7. Extraindo configurações específicas por stack..."

# Traefik
echo "   Extraindo Traefik..."
docker service inspect traefik_traefik > "$BACKUP_DIR/stacks/traefik_config.json" 2>/dev/null || echo "Traefik não encontrado"

# N8N  
echo "   Extraindo N8N..."
docker service inspect n8n_n8n > "$BACKUP_DIR/stacks/n8n_config.json" 2>/dev/null || echo "N8N não encontrado"

# Evolution
echo "   Extraindo Evolution..."
docker service inspect evolution_evolution-api > "$BACKUP_DIR/stacks/evolution_config.json" 2>/dev/null || echo "Evolution não encontrado"

# PostgreSQL
echo "   Extraindo PostgreSQL..."
docker service inspect postgres_postgres > "$BACKUP_DIR/stacks/postgres_config.json" 2>/dev/null || echo "PostgreSQL não encontrado"

# Redis
echo "   Extraindo Redis..."
docker service inspect redis_redis > "$BACKUP_DIR/stacks/redis_config.json" 2>/dev/null || echo "Redis não encontrado"

# Monitoring stack
echo "   Extraindo Monitoring..."
docker service inspect lgtm_prometheus > "$BACKUP_DIR/stacks/prometheus_config.json" 2>/dev/null
docker service inspect lgtm_grafana > "$BACKUP_DIR/stacks/grafana_config.json" 2>/dev/null
docker service inspect lgtm_loki > "$BACKUP_DIR/stacks/loki_config.json" 2>/dev/null

# Ollama
echo "   Extraindo Ollama..."
docker service inspect ollama_ollama > "$BACKUP_DIR/stacks/ollama_config.json" 2>/dev/null

# Qwen Enterprise
echo "   Extraindo Qwen..."
for service in $(docker service ls --filter "name=qwen-enterprise" --format "{{.Name}}"); do
    docker service inspect $service > "$BACKUP_DIR/stacks/qwen_${service##*_}_config.json" 2>/dev/null
done

echo "📊 8. Gerando relatório de cobertura..."
cat > "$BACKUP_DIR/RELATORIO_COBERTURA.md" << EOF
# RELATÓRIO DE COBERTURA - VPS ATUAL vs SETUP-MACSPARK

## SERVIÇOS NA VPS ATUAL:
$(docker service ls --format "{{.Name}}" | wc -l) serviços rodando

## ARQUIVOS NO SETUP-MACSPARK:
$(find /home/marcocardoso/Setup-Macspark/stacks -name "*.yml" | wc -l) arquivos YML

## SERVIÇOS NÃO COBERTOS:
$(docker service ls --format "{{.Name}}" | sort > /tmp/vps_services.txt)
$(find /home/marcocardoso/Setup-Macspark/stacks -name "*.yml" -exec basename {} .yml \; | sort > /tmp/setup_services.txt)
$(comm -23 /tmp/vps_services.txt /tmp/setup_services.txt)

## AÇÃO RECOMENDADA:
⚠️  NÃO FORMATAR ainda! Faltam $(comm -23 /tmp/vps_services.txt /tmp/setup_services.txt | wc -l) serviços para backup.

EOF

echo ""
echo "✅ BACKUP COMPLETO CRIADO EM: $BACKUP_DIR"
echo "📋 Verificar arquivo: $BACKUP_DIR/RELATORIO_COBERTURA.md"
echo ""
echo "⚠️  PRÓXIMO PASSO: Converter configurações em arquivos YML do Setup-Macspark"