#!/bin/bash
# ============================================================================
# MACSPARK POINT-IN-TIME RECOVERY SCRIPT
# ============================================================================
# Restaura o sistema para um ponto específico no tempo
# Versão: 2025.1.0
# ============================================================================

set -euo pipefail

# Configurações
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RESTORE_SCRIPT="${SCRIPT_DIR}/../../../scripts/backup/restore.sh"

# Parâmetros
TIMESTAMP="${1:-}"
SERVICE="${2:-all}"

# Validações
if [[ -z "$TIMESTAMP" ]]; then
    echo "❌ Erro: Timestamp é obrigatório"
    echo "Uso: $0 <TIMESTAMP> [SERVICE]"
    echo "Exemplo: $0 '2025-01-25 14:30:00' postgresql"
    exit 1
fi

# Converter timestamp para formato de backup
BACKUP_DATE=$(date -d "$TIMESTAMP" +"%Y%m%d" 2>/dev/null || echo "")
if [[ -z "$BACKUP_DATE" ]]; then
    echo "❌ Erro: Timestamp inválido: $TIMESTAMP"
    exit 1
fi

echo "🔄 Iniciando Point-in-Time Recovery"
echo "📅 Target: $TIMESTAMP"
echo "📦 Service: $SERVICE"
echo "📁 Backup Date: $BACKUP_DATE"

# Executar restore com data específica
if [[ "$SERVICE" == "all" ]]; then
    exec "$RESTORE_SCRIPT" "$BACKUP_DATE" "full"
else
    exec "$RESTORE_SCRIPT" "$BACKUP_DATE" "partial" "$SERVICE"
fi