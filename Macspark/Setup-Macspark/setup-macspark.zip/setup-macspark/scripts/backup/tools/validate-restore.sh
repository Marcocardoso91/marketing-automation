#!/bin/bash
# ============================================================================
# MACSPARK RESTORE VALIDATION SCRIPT
# ============================================================================
# Valida a integridade de uma restauração
# Versão: 2025.1.0
# ============================================================================

set -euo pipefail

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Configurações
LOG_DIR="../logs/validation"
LOG_FILE="${LOG_DIR}/validation-$(date +%Y%m%d-%H%M%S).log"
ERRORS=0
WARNINGS=0

# Criar diretório de logs
mkdir -p "$LOG_DIR"

# Função de log
log() {
    echo "$1" | tee -a "$LOG_FILE"
}

# Função de validação
validate() {
    local service=$1
    local check_cmd=$2
    local expected=$3
    
    log "Validando $service..."
    
    if eval "$check_cmd" 2>/dev/null | grep -q "$expected"; then
        log "  ✅ $service: OK"
        return 0
    else
        log "  ❌ $service: FALHOU"
        ((ERRORS++))
        return 1
    fi
}

# Início da validação
log "========================================="
log "🔍 VALIDAÇÃO DE RESTORE - $(date)"
log "========================================="

# 1. Validar serviços Docker
log ""
log "📦 Validando serviços Docker..."
for service in $(docker service ls --format "{{.Name}}"); do
    replicas=$(docker service ls --filter "name=$service" --format "{{.Replicas}}")
    if [[ "$replicas" =~ ([0-9]+)/([0-9]+) ]]; then
        current="${BASH_REMATCH[1]}"
        desired="${BASH_REMATCH[2]}"
        if [[ "$current" == "$desired" ]]; then
            log "  ✅ $service: $replicas"
        else
            log "  ⚠️ $service: $replicas (aguardando convergência)"
            ((WARNINGS++))
        fi
    fi
done

# 2. Validar bancos de dados
log ""
log "🗄️ Validando bancos de dados..."

# PostgreSQL
if docker exec $(docker ps -q -f name=postgres) pg_isready &>/dev/null; then
    log "  ✅ PostgreSQL: Respondendo"
else
    log "  ❌ PostgreSQL: Não está respondendo"
    ((ERRORS++))
fi

# Redis
if docker exec $(docker ps -q -f name=redis) redis-cli ping &>/dev/null; then
    log "  ✅ Redis: Respondendo"
else
    log "  ❌ Redis: Não está respondendo"
    ((ERRORS++))
fi

# 3. Validar volumes
log ""
log "💾 Validando volumes Docker..."
for volume in $(docker volume ls -q); do
    size=$(docker run --rm -v "$volume:/data" alpine du -sh /data 2>/dev/null | cut -f1)
    if [[ -n "$size" ]]; then
        log "  ✅ $volume: $size"
    else
        log "  ⚠️ $volume: Vazio ou inacessível"
        ((WARNINGS++))
    fi
done

# 4. Validar conectividade de rede
log ""
log "🌐 Validando conectividade..."
networks=("traefik-public" "internal" "monitoring")
for network in "${networks[@]}"; do
    if docker network ls | grep -q "$network"; then
        log "  ✅ Rede $network: OK"
    else
        log "  ❌ Rede $network: Não encontrada"
        ((ERRORS++))
    fi
done

# 5. Validar endpoints HTTP
log ""
log "🔗 Validando endpoints..."
endpoints=(
    "http://localhost:80|Traefik"
    "http://localhost:3000|Grafana"
    "http://localhost:9090|Prometheus"
)

for endpoint in "${endpoints[@]}"; do
    IFS='|' read -r url name <<< "$endpoint"
    if curl -s -o /dev/null -w "%{http_code}" "$url" | grep -q "200\|301\|302"; then
        log "  ✅ $name: Respondendo"
    else
        log "  ⚠️ $name: Não acessível"
        ((WARNINGS++))
    fi
done

# Resultado final
log ""
log "========================================="
log "📊 RESULTADO DA VALIDAÇÃO"
log "========================================="
log "Erros: $ERRORS"
log "Avisos: $WARNINGS"

if [[ $ERRORS -eq 0 ]]; then
    if [[ $WARNINGS -eq 0 ]]; then
        log "✅ Restauração validada com sucesso!"
        exit 0
    else
        log "⚠️ Restauração concluída com avisos. Verifique os logs."
        exit 0
    fi
else
    log "❌ Restauração falhou na validação. Verifique os erros acima."
    exit 1
fi