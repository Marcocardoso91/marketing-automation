#!/bin/bash
# File Consolidation and Validation Pipeline
# Enterprise-grade validation for Setup-Macspark
# Author: MacSpark Team
# Date: 2025-08-22

set -euo pipefail

# Configuration
readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly PROJECT_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
readonly MIGRATION_DIR="${PROJECT_ROOT}/migration"
readonly VALIDATION_REPORT="${MIGRATION_DIR}/validation-report.json"
readonly COMPLIANCE_REPORT="${MIGRATION_DIR}/compliance-report.md"
readonly LOG_FILE="${MIGRATION_DIR}/consolidation.log"

# Color codes for output
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly NC='\033[0m' # No Color

# Initialize logging
log() {
    echo -e "${1}" | tee -a "${LOG_FILE}"
}

log_info() {
    log "${BLUE}[INFO]${NC} ${1}"
}

log_success() {
    log "${GREEN}[SUCCESS]${NC} ${1}"
}

log_warning() {
    log "${YELLOW}[WARNING]${NC} ${1}"
}

log_error() {
    log "${RED}[ERROR]${NC} ${1}"
}

# Create directory structure
setup_directories() {
    log_info "Setting up migration directories..."
    
    mkdir -p "${MIGRATION_DIR}"/{discovered,validated,rejected,archive}
    mkdir -p "${MIGRATION_DIR}/reports"
    
    # Initialize validation report
    cat > "${VALIDATION_REPORT}" <<EOF
{
    "timestamp": "$(date -Iseconds)",
    "summary": {
        "total_files": 0,
        "validated": 0,
        "rejected": 0,
        "warnings": 0
    },
    "files": []
}
EOF
    
    log_success "Directory structure created"
}

# Discover all configuration files
discover_files() {
    log_info "Discovering configuration files..."
    
    local sources=(
        "/opt/macspark/migration-data"
        "${HOME}/Macspark-Setup"
        "${PROJECT_ROOT}/stacks"
    )
    
    local file_count=0
    
    for source in "${sources[@]}"; do
        if [[ -d "${source}" ]]; then
            log_info "Scanning ${source}..."
            
            # Find all relevant files
            find "${source}" \
                -type f \
                \( -name "*.yml" -o -name "*.yaml" -o -name "*.json" \
                   -o -name "*.sh" -o -name "*.sql" -o -name "*.conf" \
                   -o -name "Dockerfile*" -o -name "docker-compose*" \) \
                -exec cp --parents {} "${MIGRATION_DIR}/discovered/" \; 2>/dev/null || true
            
            file_count=$((file_count + $(find "${source}" -type f | wc -l)))
        fi
    done
    
    log_success "Discovered ${file_count} files"
    
    # Update report
    jq ".summary.total_files = ${file_count}" "${VALIDATION_REPORT}" > "${VALIDATION_REPORT}.tmp"
    mv "${VALIDATION_REPORT}.tmp" "${VALIDATION_REPORT}"
}

# Validate Docker Compose files
validate_docker_compose() {
    local file="${1}"
    local errors=()
    
    # Check syntax
    if ! docker compose -f "${file}" config > /dev/null 2>&1; then
        errors+=("Invalid Docker Compose syntax")
    fi
    
    # Check version
    local version=$(grep -E "^version:" "${file}" | awk '{print $2}' | tr -d "'\"")
    if [[ "${version}" < "3.8" ]]; then
        errors+=("Outdated version: ${version} (minimum: 3.8)")
    fi
    
    # Check for secrets in environment variables
    if grep -qE "(PASSWORD|SECRET|KEY|TOKEN)=" "${file}"; then
        errors+=("Hardcoded secrets detected")
    fi
    
    # Check network configuration
    if ! grep -q "networks:" "${file}"; then
        errors+=("No network configuration")
    fi
    
    # Check resource limits
    if ! grep -q "deploy:" "${file}"; then
        errors+=("No deploy configuration (resource limits)")
    fi
    
    echo "${errors[@]}"
}

# Validate shell scripts
validate_shell_script() {
    local file="${1}"
    local errors=()
    
    # Check syntax with shellcheck
    if command -v shellcheck &> /dev/null; then
        if ! shellcheck -S error "${file}" > /dev/null 2>&1; then
            errors+=("ShellCheck validation failed")
        fi
    fi
    
    # Check for dangerous commands
    if grep -qE "(rm -rf /|dd if=/dev/zero)" "${file}"; then
        errors+=("Dangerous commands detected")
    fi
    
    # Check shebang
    if ! head -1 "${file}" | grep -qE "^#!/bin/(bash|sh)"; then
        errors+=("Missing or invalid shebang")
    fi
    
    # Check set options
    if ! grep -q "set -e" "${file}"; then
        errors+=("Missing 'set -e' for error handling")
    fi
    
    echo "${errors[@]}"
}

# Validate SQL files
validate_sql() {
    local file="${1}"
    local errors=()
    
    # Check for DROP DATABASE without WHERE
    if grep -qE "DROP (DATABASE|SCHEMA|TABLE)" "${file}" && ! grep -q "IF EXISTS" "${file}"; then
        errors+=("Unsafe DROP statement without IF EXISTS")
    fi
    
    # Check for missing transactions
    if grep -qE "(INSERT|UPDATE|DELETE)" "${file}" && ! grep -qE "(BEGIN|START TRANSACTION)" "${file}"; then
        errors+=("DML operations without transaction")
    fi
    
    echo "${errors[@]}"
}

# Main validation function
validate_file() {
    local file="${1}"
    local filename=$(basename "${file}")
    local extension="${filename##*.}"
    local validation_result="valid"
    local errors=()
    
    log_info "Validating ${filename}..."
    
    case "${extension}" in
        yml|yaml)
            errors=($(validate_docker_compose "${file}"))
            ;;
        sh)
            errors=($(validate_shell_script "${file}"))
            ;;
        sql)
            errors=($(validate_sql "${file}"))
            ;;
        json)
            if ! jq empty "${file}" 2>/dev/null; then
                errors+=("Invalid JSON syntax")
            fi
            ;;
    esac
    
    # Version validation
    if [[ "${filename}" =~ postgres ]] && ! grep -qE "(postgres:17|postgres:16)" "${file}" 2>/dev/null; then
        errors+=("Outdated PostgreSQL version")
    fi
    
    if [[ "${filename}" =~ redis ]] && ! grep -qE "(redis:7|redis:alpine)" "${file}" 2>/dev/null; then
        errors+=("Outdated Redis version")
    fi
    
    if [[ "${filename}" =~ traefik ]] && ! grep -qE "(traefik:3|traefik:v3)" "${file}" 2>/dev/null; then
        errors+=("Outdated Traefik version")
    fi
    
    # Process validation results
    if [[ ${#errors[@]} -gt 0 ]]; then
        validation_result="rejected"
        log_error "${filename}: ${errors[*]}"
        cp "${file}" "${MIGRATION_DIR}/rejected/"
        
        # Add to report
        jq ".files += [{
            \"name\": \"${filename}\",
            \"path\": \"${file}\",
            \"status\": \"rejected\",
            \"errors\": $(printf '%s\n' "${errors[@]}" | jq -R . | jq -s .)
        }]" "${VALIDATION_REPORT}" > "${VALIDATION_REPORT}.tmp"
        mv "${VALIDATION_REPORT}.tmp" "${VALIDATION_REPORT}"
    else
        log_success "${filename}: Validated"
        cp "${file}" "${MIGRATION_DIR}/validated/"
        
        # Add to report
        jq ".files += [{
            \"name\": \"${filename}\",
            \"path\": \"${file}\",
            \"status\": \"validated\",
            \"errors\": []
        }]" "${VALIDATION_REPORT}" > "${VALIDATION_REPORT}.tmp"
        mv "${VALIDATION_REPORT}.tmp" "${VALIDATION_REPORT}"
    fi
}

# Process all discovered files
validate_all_files() {
    log_info "Starting validation process..."
    
    local validated=0
    local rejected=0
    
    # Find all files in discovered directory
    while IFS= read -r -d '' file; do
        validate_file "${file}"
        
        # Update counters
        if [[ -f "${MIGRATION_DIR}/validated/$(basename "${file}")" ]]; then
            ((validated++))
        else
            ((rejected++))
        fi
    done < <(find "${MIGRATION_DIR}/discovered" -type f -print0)
    
    # Update summary
    jq ".summary.validated = ${validated} | .summary.rejected = ${rejected}" \
        "${VALIDATION_REPORT}" > "${VALIDATION_REPORT}.tmp"
    mv "${VALIDATION_REPORT}.tmp" "${VALIDATION_REPORT}"
    
    log_info "Validation complete: ${validated} validated, ${rejected} rejected"
}

# Security validation
security_validation() {
    log_info "Running security validation..."
    
    local security_issues=0
    
    # Check for exposed ports
    for file in "${MIGRATION_DIR}/validated"/*.{yml,yaml}; do
        if [[ -f "${file}" ]]; then
            if grep -qE "ports:.*:3306|ports:.*:5432|ports:.*:6379" "${file}"; then
                log_warning "$(basename "${file}"): Database ports exposed"
                ((security_issues++))
            fi
        fi
    done
    
    # Check for default passwords
    for file in "${MIGRATION_DIR}/validated"/*; do
        if [[ -f "${file}" ]]; then
            if grep -qiE "(admin|password|123456|default)" "${file}"; then
                log_warning "$(basename "${file}"): Potential default credentials"
                ((security_issues++))
            fi
        fi
    done
    
    # Check SSL/TLS configuration
    for file in "${MIGRATION_DIR}/validated"/*.{yml,yaml}; do
        if [[ -f "${file}" ]]; then
            if grep -q "traefik" "${file}" && ! grep -q "tls:" "${file}"; then
                log_warning "$(basename "${file}"): Missing TLS configuration"
                ((security_issues++))
            fi
        fi
    done
    
    log_info "Security validation complete: ${security_issues} issues found"
    
    # Update report
    jq ".summary.security_issues = ${security_issues}" "${VALIDATION_REPORT}" > "${VALIDATION_REPORT}.tmp"
    mv "${VALIDATION_REPORT}.tmp" "${VALIDATION_REPORT}"
}

# Best practices validation
best_practices_validation() {
    log_info "Validating best practices..."
    
    local warnings=0
    
    # Check health checks
    for file in "${MIGRATION_DIR}/validated"/*.{yml,yaml}; do
        if [[ -f "${file}" ]]; then
            if ! grep -q "healthcheck:" "${file}"; then
                log_warning "$(basename "${file}"): Missing health check"
                ((warnings++))
            fi
        fi
    done
    
    # Check restart policies
    for file in "${MIGRATION_DIR}/validated"/*.{yml,yaml}; do
        if [[ -f "${file}" ]]; then
            if ! grep -qE "restart_policy:|restart:" "${file}"; then
                log_warning "$(basename "${file}"): Missing restart policy"
                ((warnings++))
            fi
        fi
    done
    
    # Check logging configuration
    for file in "${MIGRATION_DIR}/validated"/*.{yml,yaml}; do
        if [[ -f "${file}" ]]; then
            if ! grep -q "logging:" "${file}"; then
                log_warning "$(basename "${file}"): Missing logging configuration"
                ((warnings++))
            fi
        fi
    done
    
    log_info "Best practices validation complete: ${warnings} warnings"
    
    # Update report
    jq ".summary.warnings = ${warnings}" "${VALIDATION_REPORT}" > "${VALIDATION_REPORT}.tmp"
    mv "${VALIDATION_REPORT}.tmp" "${VALIDATION_REPORT}"
}

# Transfer validated files to project
transfer_validated_files() {
    log_info "Transferring validated files..."
    
    # Organize by type
    for file in "${MIGRATION_DIR}/validated"/*; do
        if [[ -f "${file}" ]]; then
            local filename=$(basename "${file}")
            local target_dir=""
            
            # Determine target directory
            if [[ "${filename}" =~ docker-compose|\.yml|\.yaml ]]; then
                if [[ "${filename}" =~ traefik ]]; then
                    target_dir="${PROJECT_ROOT}/stacks/core/traefik"
                elif [[ "${filename}" =~ postgres|redis ]]; then
                    target_dir="${PROJECT_ROOT}/stacks/core/database"
                elif [[ "${filename}" =~ n8n|evolution ]]; then
                    target_dir="${PROJECT_ROOT}/stacks/applications/ai"
                elif [[ "${filename}" =~ monitoring|prometheus|grafana|loki ]]; then
                    target_dir="${PROJECT_ROOT}/stacks/core/monitoring"
                else
                    target_dir="${PROJECT_ROOT}/stacks/applications"
                fi
            elif [[ "${filename}" =~ \.sh$ ]]; then
                target_dir="${PROJECT_ROOT}/scripts/migration"
            elif [[ "${filename}" =~ \.sql$ ]]; then
                target_dir="${PROJECT_ROOT}/data/sql"
            elif [[ "${filename}" =~ \.json$ ]]; then
                target_dir="${PROJECT_ROOT}/configs"
            fi
            
            if [[ -n "${target_dir}" ]]; then
                mkdir -p "${target_dir}"
                cp "${file}" "${target_dir}/"
                log_success "Transferred ${filename} to ${target_dir}"
            fi
        fi
    done
}

# Setup CI/CD validation
setup_cicd_validation() {
    log_info "Setting up CI/CD validation..."
    
    # Create GitHub Actions workflow
    mkdir -p "${PROJECT_ROOT}/.github/workflows"
    
    cat > "${PROJECT_ROOT}/.github/workflows/validate-consolidation.yml" <<'EOF'
name: Validate Consolidation

on:
  push:
    branches: [main, develop]
    paths:
      - 'stacks/**'
      - 'scripts/**'
      - 'configs/**'
  pull_request:
    branches: [main]

jobs:
  validate:
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v4
      
      - name: Setup tools
        run: |
          sudo apt-get update
          sudo apt-get install -y shellcheck jq
          
      - name: Validate Docker Compose files
        run: |
          for file in $(find stacks -name "*.yml" -o -name "*.yaml"); do
            docker compose -f "$file" config > /dev/null
          done
          
      - name: Validate shell scripts
        run: |
          shellcheck scripts/**/*.sh
          
      - name: Security scan
        uses: aquasecurity/trivy-action@master
        with:
          scan-type: 'config'
          scan-ref: '.'
          
      - name: Generate report
        if: always()
        run: |
          ./scripts/consolidation/generate-report.sh
          
      - name: Upload report
        if: always()
        uses: actions/upload-artifact@v3
        with:
          name: validation-report
          path: migration/compliance-report.md
EOF
    
    log_success "CI/CD validation configured"
}

# Generate compliance report
generate_compliance_report() {
    log_info "Generating compliance report..."
    
    local validated=$(jq '.summary.validated' "${VALIDATION_REPORT}")
    local rejected=$(jq '.summary.rejected' "${VALIDATION_REPORT}")
    local warnings=$(jq '.summary.warnings // 0' "${VALIDATION_REPORT}")
    local security_issues=$(jq '.summary.security_issues // 0' "${VALIDATION_REPORT}")
    local total=$(jq '.summary.total_files' "${VALIDATION_REPORT}")
    local compliance_rate=0
    
    if [[ ${total} -gt 0 ]]; then
        compliance_rate=$((validated * 100 / total))
    fi
    
    cat > "${COMPLIANCE_REPORT}" <<EOF
# File Consolidation Compliance Report

**Generated:** $(date)
**Project:** Setup-Macspark

## Executive Summary

- **Total Files Discovered:** ${total}
- **Files Validated:** ${validated}
- **Files Rejected:** ${rejected}
- **Warnings:** ${warnings}
- **Security Issues:** ${security_issues}
- **Compliance Rate:** ${compliance_rate}%

## Validation Results

### ✅ Validated Files (${validated})

Files that passed all validation checks and are ready for production:

\`\`\`
$(ls -la "${MIGRATION_DIR}/validated" 2>/dev/null | tail -n +2 || echo "No validated files")
\`\`\`

### ❌ Rejected Files (${rejected})

Files that failed validation and require remediation:

\`\`\`
$(if [[ ${rejected} -gt 0 ]]; then
    jq -r '.files[] | select(.status == "rejected") | "- \(.name): \(.errors | join(", "))"' "${VALIDATION_REPORT}"
else
    echo "No rejected files"
fi)
\`\`\`

### ⚠️ Warnings (${warnings})

Best practice violations that should be addressed:

\`\`\`
$(grep "WARNING" "${LOG_FILE}" | tail -20 || echo "No warnings")
\`\`\`

### 🔒 Security Issues (${security_issues})

Security vulnerabilities requiring immediate attention:

\`\`\`
$(grep "security\|password\|exposed" "${LOG_FILE}" | tail -20 || echo "No security issues")
\`\`\`

## Recommendations

### Immediate Actions
1. Review and fix all rejected files
2. Address security issues in validated files
3. Apply best practice recommendations

### Next Steps
1. Run remediation scripts for rejected files
2. Update documentation with new structure
3. Configure automated validation in CI/CD
4. Schedule regular compliance audits

## Compliance Matrix

| Category | Status | Score |
|----------|--------|-------|
| Syntax Validation | $([ ${rejected} -eq 0 ] && echo "✅ Pass" || echo "❌ Fail") | ${compliance_rate}% |
| Version Compliance | $([ ${warnings} -lt 10 ] && echo "✅ Pass" || echo "⚠️ Warning") | $((100 - warnings * 2))% |
| Security Standards | $([ ${security_issues} -eq 0 ] && echo "✅ Pass" || echo "❌ Fail") | $((100 - security_issues * 5))% |
| Best Practices | $([ ${warnings} -lt 5 ] && echo "✅ Pass" || echo "⚠️ Warning") | $((100 - warnings * 3))% |

## File Categories

### By Type
\`\`\`
Docker Compose: $(find "${MIGRATION_DIR}/validated" -name "*.yml" -o -name "*.yaml" 2>/dev/null | wc -l)
Shell Scripts: $(find "${MIGRATION_DIR}/validated" -name "*.sh" 2>/dev/null | wc -l)
SQL Files: $(find "${MIGRATION_DIR}/validated" -name "*.sql" 2>/dev/null | wc -l)
JSON Files: $(find "${MIGRATION_DIR}/validated" -name "*.json" 2>/dev/null | wc -l)
\`\`\`

### By Service
\`\`\`
Traefik: $(find "${MIGRATION_DIR}/validated" -name "*traefik*" 2>/dev/null | wc -l)
PostgreSQL: $(find "${MIGRATION_DIR}/validated" -name "*postgres*" 2>/dev/null | wc -l)
Redis: $(find "${MIGRATION_DIR}/validated" -name "*redis*" 2>/dev/null | wc -l)
N8N: $(find "${MIGRATION_DIR}/validated" -name "*n8n*" 2>/dev/null | wc -l)
Evolution: $(find "${MIGRATION_DIR}/validated" -name "*evolution*" 2>/dev/null | wc -l)
\`\`\`

## Validation Log

### Last 10 Validations
\`\`\`
$(tail -10 "${LOG_FILE}")
\`\`\`

---

**Report generated by Setup-Macspark Consolidation Pipeline**
EOF
    
    log_success "Compliance report generated: ${COMPLIANCE_REPORT}"
}

# Cleanup and archive
cleanup_and_archive() {
    log_info "Cleaning up and archiving..."
    
    # Create archive
    local archive_name="consolidation-$(date +%Y%m%d-%H%M%S).tar.gz"
    tar -czf "${MIGRATION_DIR}/archive/${archive_name}" \
        -C "${MIGRATION_DIR}" \
        discovered validated rejected reports validation-report.json compliance-report.md
    
    # Clean temporary files
    find "${MIGRATION_DIR}/discovered" -type f -mtime +7 -delete
    
    log_success "Archive created: ${archive_name}"
}

# Main execution
main() {
    log_info "Starting File Consolidation and Validation Pipeline"
    log_info "=========================================="
    
    # Setup
    setup_directories
    
    # Discovery
    discover_files
    
    # Validation
    validate_all_files
    security_validation
    best_practices_validation
    
    # Transfer
    transfer_validated_files
    
    # CI/CD Setup
    setup_cicd_validation
    
    # Reporting
    generate_compliance_report
    
    # Cleanup
    cleanup_and_archive
    
    log_success "=========================================="
    log_success "Pipeline completed successfully!"
    log_success "Compliance Report: ${COMPLIANCE_REPORT}"
    log_success "Validation Report: ${VALIDATION_REPORT}"
    
    # Display summary
    echo ""
    echo -e "${GREEN}Summary:${NC}"
    echo "- Files Validated: $(jq '.summary.validated' "${VALIDATION_REPORT}")"
    echo "- Files Rejected: $(jq '.summary.rejected' "${VALIDATION_REPORT}")"
    echo "- Compliance Rate: ${compliance_rate}%"
    echo ""
    echo -e "${BLUE}Next Steps:${NC}"
    echo "1. Review compliance report: ${COMPLIANCE_REPORT}"
    echo "2. Fix rejected files in: ${MIGRATION_DIR}/rejected/"
    echo "3. Deploy validated files from: ${PROJECT_ROOT}/stacks/"
}

# Run main function
main "$@"