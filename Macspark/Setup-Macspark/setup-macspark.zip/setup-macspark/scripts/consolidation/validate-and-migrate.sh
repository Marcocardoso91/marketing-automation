#!/bin/bash
# Enhanced File Consolidation and Validation Pipeline with Deduplication
# Enterprise-grade validation for Setup-Macspark 2025
# Author: MacSpark Team
# Version: 2.0.0

set -euo pipefail

# ========================================
# Configuration
# ========================================
readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly PROJECT_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
readonly MIGRATION_DIR="${PROJECT_ROOT}/migration"
readonly VALIDATION_REPORT="${MIGRATION_DIR}/validation-report.json"
readonly COMPLIANCE_REPORT="${MIGRATION_DIR}/compliance-report.md"
readonly DEDUP_REPORT="${MIGRATION_DIR}/deduplication-report.json"
readonly LOG_FILE="${MIGRATION_DIR}/consolidation.log"
readonly TIMESTAMP=$(date +%Y%m%d-%H%M%S)

# Source locations
readonly VPS_SOURCE="/opt/macspark/migration-data"
readonly MACSPARK_SETUP="/home/marcocardoso/Macspark-Setup"

# Color codes
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly MAGENTA='\033[0;35m'
readonly CYAN='\033[0;36m'
readonly NC='\033[0m'

# Deduplication settings
declare -A FILE_HASHES
declare -A FILE_VERSIONS
declare -A SERVICE_CONFIGS
DUPLICATES_FOUND=0
DUPLICATES_REMOVED=0

# ========================================
# Logging Functions
# ========================================
log() {
    echo -e "${1}" | tee -a "${LOG_FILE}"
}

log_info() {
    log "${BLUE}[INFO]${NC} ${1}"
}

log_success() {
    log "${GREEN}[SUCCESS]${NC} ${1}"
}

log_warning() {
    log "${YELLOW}[WARNING]${NC} ${1}"
}

log_error() {
    log "${RED}[ERROR]${NC} ${1}"
}

log_debug() {
    if [[ "${DEBUG:-false}" == "true" ]]; then
        log "${CYAN}[DEBUG]${NC} ${1}"
    fi
}

# ========================================
# Setup Functions
# ========================================
setup_directories() {
    log_info "Setting up migration directories..."
    
    mkdir -p "${MIGRATION_DIR}"/{discovered,validated,rejected,deduplicated,archive}
    mkdir -p "${MIGRATION_DIR}/reports"
    mkdir -p "${PROJECT_ROOT}/stacks"/{core,applications,infrastructure}/{.deprecated,.backup}
    
    # Initialize reports
    cat > "${VALIDATION_REPORT}" <<EOF
{
    "timestamp": "$(date -Iseconds)",
    "version": "2.0.0",
    "summary": {
        "total_files": 0,
        "validated": 0,
        "rejected": 0,
        "duplicates": 0,
        "warnings": 0
    },
    "files": [],
    "deduplication": {}
}
EOF
    
    cat > "${DEDUP_REPORT}" <<EOF
{
    "timestamp": "$(date -Iseconds)",
    "duplicates_found": 0,
    "duplicates_removed": 0,
    "space_saved": "0",
    "conflicts_resolved": [],
    "version_matrix": {}
}
EOF
    
    log_success "Directory structure created"
}

# ========================================
# Discovery Functions
# ========================================
discover_files() {
    log_info "Discovering configuration files..."
    
    local sources=("${VPS_SOURCE}" "${MACSPARK_SETUP}" "${PROJECT_ROOT}/stacks")
    local file_count=0
    
    for source in "${sources[@]}"; do
        if [[ -d "${source}" ]]; then
            log_info "Scanning ${source}..."
            
            # Find relevant files with proper filtering
            find "${source}" \
                -type f \
                \( -name "*.yml" -o -name "*.yaml" -o -name "*.json" \
                   -o -name "*.sh" -o -name "*.sql" -o -name "*.conf" \
                   -o -name "*.env.example" -o -name "Dockerfile*" \
                   -o -name "docker-compose*" -o -name "Makefile" \) \
                ! -path "*/\.git/*" \
                ! -path "*/node_modules/*" \
                ! -path "*/vendor/*" \
                ! -path "*/\.terraform/*" \
                -exec cp --parents {} "${MIGRATION_DIR}/discovered/" \; 2>/dev/null || true
            
            local count=$(find "${source}" -type f ! -path "*/\.*" | wc -l)
            file_count=$((file_count + count))
        fi
    done
    
    log_success "Discovered ${file_count} files"
    jq ".summary.total_files = ${file_count}" "${VALIDATION_REPORT}" > "${VALIDATION_REPORT}.tmp"
    mv "${VALIDATION_REPORT}.tmp" "${VALIDATION_REPORT}"
}

# ========================================
# Deduplication Functions
# ========================================
calculate_file_hash() {
    local file="${1}"
    
    # Create comprehensive hash including metadata
    local content_hash=$(sha256sum "${file}" | cut -d' ' -f1)
    local size=$(stat -c%s "${file}")
    local mtime=$(stat -c%Y "${file}")
    
    echo "${content_hash}-${size}-${mtime}"
}

extract_service_info() {
    local file="${1}"
    local service_name=""
    local version=""
    local environment=""
    
    # Extract service name from file
    if grep -q "services:" "${file}" 2>/dev/null; then
        service_name=$(grep -A1 "services:" "${file}" | tail -1 | sed 's/[: ]//g' || echo "unknown")
    fi
    
    # Extract version
    if grep -q "image:" "${file}" 2>/dev/null; then
        version=$(grep "image:" "${file}" | head -1 | sed 's/.*://;s/ .*//' || echo "latest")
    fi
    
    # Detect environment
    if [[ "${file}" =~ production|prod ]]; then
        environment="production"
    elif [[ "${file}" =~ staging|stage ]]; then
        environment="staging"
    elif [[ "${file}" =~ development|dev ]]; then
        environment="development"
    else
        environment="unknown"
    fi
    
    echo "${service_name}|${version}|${environment}"
}

deduplicate_files() {
    log_info "Starting intelligent deduplication..."
    
    local total_size_before=0
    local total_size_after=0
    
    # First pass: Build hash map
    while IFS= read -r -d '' file; do
        local hash=$(calculate_file_hash "${file}")
        local basename=$(basename "${file}")
        local service_info=$(extract_service_info "${file}")
        
        FILE_HASHES["${file}"]="${hash}"
        SERVICE_CONFIGS["${file}"]="${service_info}"
        
        total_size_before=$((total_size_before + $(stat -c%s "${file}")))
    done < <(find "${MIGRATION_DIR}/discovered" -type f -print0)
    
    # Second pass: Identify and resolve duplicates
    declare -A seen_hashes
    declare -A best_versions
    
    for file in "${!FILE_HASHES[@]}"; do
        local hash="${FILE_HASHES[$file]}"
        local basename=$(basename "${file}")
        local service_info="${SERVICE_CONFIGS[$file]}"
        
        IFS='|' read -r service version environment <<< "${service_info}"
        
        if [[ -n "${seen_hashes[$hash]}" ]]; then
            # Duplicate found
            ((DUPLICATES_FOUND++))
            log_debug "Duplicate found: ${basename}"
            
            local existing="${seen_hashes[$hash]}"
            local existing_info="${SERVICE_CONFIGS[$existing]}"
            IFS='|' read -r ex_service ex_version ex_environment <<< "${existing_info}"
            
            # Determine which to keep based on rules
            local keep_existing=true
            
            # Rule 1: Prefer production over staging over dev
            if [[ "${environment}" == "production" && "${ex_environment}" != "production" ]]; then
                keep_existing=false
            elif [[ "${environment}" == "staging" && "${ex_environment}" == "development" ]]; then
                keep_existing=false
            fi
            
            # Rule 2: Prefer newer versions (simple comparison)
            if [[ "${version}" > "${ex_version}" ]]; then
                keep_existing=false
            fi
            
            # Rule 3: Prefer files with more complete configuration
            local lines_new=$(wc -l < "${file}")
            local lines_old=$(wc -l < "${existing}")
            if [[ ${lines_new} -gt $((lines_old * 2)) ]]; then
                keep_existing=false
            fi
            
            if [[ "${keep_existing}" == "false" ]]; then
                # Replace with newer version
                log_debug "  Replacing ${existing} with ${file}"
                mv "${file}" "${MIGRATION_DIR}/deduplicated/"
                rm -f "${existing}"
                ((DUPLICATES_REMOVED++))
                seen_hashes["${hash}"]="${file}"
            else
                # Keep existing, remove duplicate
                log_debug "  Keeping ${existing}, removing ${file}"
                rm -f "${file}"
                ((DUPLICATES_REMOVED++))
            fi
            
            # Log conflict resolution
            jq ".deduplication.conflicts_resolved += [{
                \"file1\": \"${existing}\",
                \"file2\": \"${file}\",
                \"kept\": \"$([ ${keep_existing} == true ] && echo ${existing} || echo ${file})\",
                \"reason\": \"environment_priority\"
            }]" "${DEDUP_REPORT}" > "${DEDUP_REPORT}.tmp"
            mv "${DEDUP_REPORT}.tmp" "${DEDUP_REPORT}"
            
        else
            # First occurrence
            seen_hashes["${hash}"]="${file}"
            mv "${file}" "${MIGRATION_DIR}/deduplicated/" 2>/dev/null || true
        fi
    done
    
    # Calculate space saved
    total_size_after=$(find "${MIGRATION_DIR}/deduplicated" -type f -exec stat -c%s {} \; | awk '{sum+=$1} END {print sum}')
    local space_saved=$((total_size_before - total_size_after))
    local space_saved_mb=$((space_saved / 1024 / 1024))
    
    # Update deduplication report
    jq ".duplicates_found = ${DUPLICATES_FOUND} |
        .duplicates_removed = ${DUPLICATES_REMOVED} |
        .space_saved = \"${space_saved_mb} MB\"" "${DEDUP_REPORT}" > "${DEDUP_REPORT}.tmp"
    mv "${DEDUP_REPORT}.tmp" "${DEDUP_REPORT}"
    
    log_success "Deduplication complete: ${DUPLICATES_REMOVED} duplicates removed, ${space_saved_mb}MB saved"
}

# ========================================
# Enhanced Validation Functions
# ========================================
validate_docker_compose() {
    local file="${1}"
    local errors=()
    
    # Syntax validation
    if ! docker compose -f "${file}" config > /dev/null 2>&1; then
        errors+=("Invalid Docker Compose syntax")
    fi
    
    # Version check (must be 3.8+)
    local version=$(grep -E "^version:" "${file}" | awk '{print $2}' | tr -d "'\"")
    if [[ "${version}" < "3.8" ]]; then
        errors+=("Outdated version: ${version} (minimum: 3.8)")
    fi
    
    # Security checks
    if grep -qE "(PASSWORD|SECRET|KEY|TOKEN)=[^$]" "${file}"; then
        errors+=("Hardcoded secrets detected")
    fi
    
    # Best practices
    if ! grep -q "restart:" "${file}"; then
        errors+=("Missing restart policy")
    fi
    
    if ! grep -q "healthcheck:" "${file}"; then
        errors+=("Missing health check")
    fi
    
    if ! grep -q "networks:" "${file}"; then
        errors+=("No network configuration")
    fi
    
    if ! grep -q "deploy:" "${file}" && ! grep -q "resources:" "${file}"; then
        errors+=("No resource limits defined")
    fi
    
    # 2025 standards
    if grep -qE "postgres:1[0-5]" "${file}"; then
        errors+=("PostgreSQL version below 16 (2025 standard: 17+)")
    fi
    
    if grep -qE "redis:[1-6]" "${file}"; then
        errors+=("Redis version below 7 (2025 standard: 7.4+)")
    fi
    
    if grep -qE "traefik:v?[1-2]" "${file}"; then
        errors+=("Traefik version below 3 (2025 standard: 3.5+)")
    fi
    
    echo "${errors[@]}"
}

validate_and_categorize() {
    log_info "Validating and categorizing files..."
    
    local validated=0
    local rejected=0
    
    while IFS= read -r -d '' file; do
        local filename=$(basename "${file}")
        local extension="${filename##*.}"
        local validation_result="valid"
        local errors=()
        local category=""
        
        log_debug "Validating ${filename}..."
        
        # Determine file type and validate
        case "${extension}" in
            yml|yaml)
                errors=($(validate_docker_compose "${file}"))
                
                # Categorize by content
                if grep -q "traefik" "${file}"; then
                    category="core/traefik"
                elif grep -qE "postgres|mysql|mariadb" "${file}"; then
                    category="core/database"
                elif grep -qE "redis|memcached|rabbitmq" "${file}"; then
                    category="core/cache"
                elif grep -qE "prometheus|grafana|loki" "${file}"; then
                    category="core/monitoring"
                elif grep -qE "n8n|evolution|ollama|qwen" "${file}"; then
                    category="applications/ai"
                elif grep -qE "vault|keycloak" "${file}"; then
                    category="infrastructure/security"
                elif grep -qE "minio|restic|backup" "${file}"; then
                    category="infrastructure/backup"
                else
                    category="applications/general"
                fi
                ;;
                
            sh)
                # Validate shell scripts
                if command -v shellcheck &> /dev/null; then
                    if ! shellcheck -S error "${file}" > /dev/null 2>&1; then
                        errors+=("ShellCheck validation failed")
                    fi
                fi
                category="scripts"
                ;;
                
            sql)
                # Validate SQL files
                if grep -qE "DROP (DATABASE|SCHEMA|TABLE)" "${file}" && ! grep -q "IF EXISTS" "${file}"; then
                    errors+=("Unsafe DROP statement")
                fi
                category="data/sql"
                ;;
                
            json)
                # Validate JSON
                if ! jq empty "${file}" 2>/dev/null; then
                    errors+=("Invalid JSON syntax")
                fi
                category="configs"
                ;;
        esac
        
        # Process validation results
        if [[ ${#errors[@]} -gt 0 ]]; then
            validation_result="rejected"
            ((rejected++))
            log_error "${filename}: ${errors[*]}"
            
            # Move to rejected with reason
            mkdir -p "${MIGRATION_DIR}/rejected/${category}"
            cp "${file}" "${MIGRATION_DIR}/rejected/${category}/"
            
            # Create rejection report
            cat > "${MIGRATION_DIR}/rejected/${category}/${filename}.rejection" <<EOF
File: ${filename}
Category: ${category}
Rejected: $(date)
Reasons:
$(printf '%s\n' "${errors[@]}" | sed 's/^/  - /')
EOF
            
        else
            ((validated++))
            log_success "${filename}: Validated [${category}]"
            
            # Move to validated category
            mkdir -p "${MIGRATION_DIR}/validated/${category}"
            cp "${file}" "${MIGRATION_DIR}/validated/${category}/"
        fi
        
        # Update validation report
        jq ".files += [{
            \"name\": \"${filename}\",
            \"path\": \"${file}\",
            \"category\": \"${category}\",
            \"status\": \"${validation_result}\",
            \"errors\": $(printf '%s\n' "${errors[@]}" | jq -R . | jq -s .)
        }]" "${VALIDATION_REPORT}" > "${VALIDATION_REPORT}.tmp"
        mv "${VALIDATION_REPORT}.tmp" "${VALIDATION_REPORT}"
        
    done < <(find "${MIGRATION_DIR}/deduplicated" -type f -print0)
    
    # Update summary
    jq ".summary.validated = ${validated} | .summary.rejected = ${rejected}" \
        "${VALIDATION_REPORT}" > "${VALIDATION_REPORT}.tmp"
    mv "${VALIDATION_REPORT}.tmp" "${VALIDATION_REPORT}"
    
    log_info "Validation complete: ${validated} validated, ${rejected} rejected"
}

# ========================================
# Best Version Selection
# ========================================
select_best_versions() {
    log_info "Selecting best versions for each service..."
    
    declare -A service_versions
    
    # Analyze all validated files
    while IFS= read -r -d '' file; do
        local service_info=$(extract_service_info "${file}")
        IFS='|' read -r service version environment <<< "${service_info}"
        
        if [[ -n "${service}" && "${service}" != "unknown" ]]; then
            local current_best="${service_versions[$service]:-}"
            
            if [[ -z "${current_best}" ]]; then
                service_versions["${service}"]="${file}|${version}|${environment}"
            else
                IFS='|' read -r best_file best_version best_env <<< "${current_best}"
                
                # Compare and update if better
                if [[ "${environment}" == "production" && "${best_env}" != "production" ]] ||
                   [[ "${version}" > "${best_version}" ]]; then
                    service_versions["${service}"]="${file}|${version}|${environment}"
                    
                    # Archive older version
                    mkdir -p "${MIGRATION_DIR}/archive/superseded"
                    mv "${best_file}" "${MIGRATION_DIR}/archive/superseded/"
                fi
            fi
        fi
    done < <(find "${MIGRATION_DIR}/validated" -type f -name "*.yml" -o -name "*.yaml" -print0)
    
    # Create version matrix report
    {
        echo "# Service Version Matrix"
        echo "Generated: $(date)"
        echo ""
        echo "| Service | Best Version | Environment | File |"
        echo "|---------|--------------|-------------|------|"
        
        for service in "${!service_versions[@]}"; do
            IFS='|' read -r file version environment <<< "${service_versions[$service]}"
            echo "| ${service} | ${version} | ${environment} | $(basename ${file}) |"
        done
    } > "${MIGRATION_DIR}/reports/version-matrix.md"
    
    log_success "Best version selection complete"
}

# ========================================
# Transfer Functions
# ========================================
transfer_validated_files() {
    log_info "Transferring validated files to project structure..."
    
    local transferred=0
    
    # Process each category
    for category_path in "${MIGRATION_DIR}"/validated/*; do
        if [[ -d "${category_path}" ]]; then
            local category=$(basename "${category_path}")
            
            # Map category to target directory
            local target_dir="${PROJECT_ROOT}/stacks/${category}"
            
            # Special handling for scripts
            if [[ "${category}" == "scripts" ]]; then
                target_dir="${PROJECT_ROOT}/scripts/migrated"
            elif [[ "${category}" == "configs" ]]; then
                target_dir="${PROJECT_ROOT}/configs"
            elif [[ "${category}" == "data" ]]; then
                target_dir="${PROJECT_ROOT}/data"
            fi
            
            mkdir -p "${target_dir}"
            
            # Transfer files
            for file in "${category_path}"/*; do
                if [[ -f "${file}" ]]; then
                    local filename=$(basename "${file}")
                    
                    # Check if file exists in target
                    if [[ -f "${target_dir}/${filename}" ]]; then
                        # Backup existing file
                        mkdir -p "${target_dir}/.backup"
                        cp "${target_dir}/${filename}" "${target_dir}/.backup/${filename}.${TIMESTAMP}"
                        log_warning "Backed up existing ${filename}"
                    fi
                    
                    cp "${file}" "${target_dir}/"
                    ((transferred++))
                    log_success "Transferred ${filename} to ${target_dir}"
                fi
            done
        fi
    done
    
    log_success "Transfer complete: ${transferred} files moved to project structure"
}

# ========================================
# Reporting Functions
# ========================================
generate_compliance_report() {
    log_info "Generating comprehensive compliance report..."
    
    local validated=$(jq '.summary.validated' "${VALIDATION_REPORT}")
    local rejected=$(jq '.summary.rejected' "${VALIDATION_REPORT}")
    local duplicates=$(jq '.duplicates_removed' "${DEDUP_REPORT}")
    local space_saved=$(jq -r '.space_saved' "${DEDUP_REPORT}")
    local total=$(jq '.summary.total_files' "${VALIDATION_REPORT}")
    local compliance_rate=0
    
    if [[ ${total} -gt 0 ]]; then
        compliance_rate=$((validated * 100 / total))
    fi
    
    cat > "${COMPLIANCE_REPORT}" <<EOF
# File Consolidation Compliance Report

**Generated:** $(date)
**Version:** 2.0.0
**Project:** Setup-Macspark

## Executive Summary

- **Total Files Discovered:** ${total}
- **Files Validated:** ${validated}
- **Files Rejected:** ${rejected}
- **Duplicates Removed:** ${duplicates}
- **Space Saved:** ${space_saved}
- **Compliance Rate:** ${compliance_rate}%

## Deduplication Analysis

### Statistics
- Duplicates Found: ${DUPLICATES_FOUND}
- Duplicates Removed: ${DUPLICATES_REMOVED}
- Space Optimization: ${space_saved}

### Conflict Resolution
$(jq -r '.deduplication.conflicts_resolved[] | "- Kept: \(.kept) (Reason: \(.reason))"' "${DEDUP_REPORT}" 2>/dev/null || echo "No conflicts")

## Validation Results

### ✅ Validated Files by Category

| Category | Count | Status |
|----------|-------|--------|
$(for dir in "${MIGRATION_DIR}"/validated/*/; do
    if [[ -d "$dir" ]]; then
        category=$(basename "$dir")
        count=$(find "$dir" -type f | wc -l)
        echo "| $category | $count | ✅ Ready |"
    fi
done)

### ❌ Rejected Files

| File | Category | Reason |
|------|----------|--------|
$(jq -r '.files[] | select(.status == "rejected") | "| \(.name) | \(.category) | \(.errors | join(", ")) |"' "${VALIDATION_REPORT}" | head -20)

## Version Compliance

### Service Versions (2025 Standards)

| Service | Required | Status |
|---------|----------|--------|
| PostgreSQL | 17+ | $(grep -q "postgres:17" "${MIGRATION_DIR}"/validated/**/*.yml 2>/dev/null && echo "✅ Compliant" || echo "⚠️ Update needed") |
| Redis | 7.4+ | $(grep -q "redis:7" "${MIGRATION_DIR}"/validated/**/*.yml 2>/dev/null && echo "✅ Compliant" || echo "⚠️ Update needed") |
| Traefik | 3.5+ | $(grep -q "traefik:v3" "${MIGRATION_DIR}"/validated/**/*.yml 2>/dev/null && echo "✅ Compliant" || echo "⚠️ Update needed") |

## Security Assessment

### Critical Findings
$(grep -l "PASSWORD\|SECRET\|KEY" "${MIGRATION_DIR}"/validated/**/* 2>/dev/null | wc -l) files with potential secrets

### Recommendations
1. Review and remediate all rejected files
2. Update services to 2025-compliant versions
3. Move secrets to Vault or environment variables
4. Implement resource limits on all services
5. Add health checks to all containers

## Compliance Matrix

| Criteria | Target | Actual | Status |
|----------|--------|--------|--------|
| Syntax Valid | 100% | ${compliance_rate}% | $([ ${compliance_rate} -ge 95 ] && echo "✅" || echo "⚠️") |
| Version Current | 100% | TBD | 🔄 |
| Security Scan | 0 Critical | TBD | 🔄 |
| Best Practices | 90% | TBD | 🔄 |
| Documentation | 100% | TBD | 🔄 |

## File Organization

### Project Structure
\`\`\`
Setup-Macspark/
├── stacks/
│   ├── core/
│   │   ├── database/ ($(find "${PROJECT_ROOT}"/stacks/core/database -type f 2>/dev/null | wc -l) files)
│   │   ├── cache/ ($(find "${PROJECT_ROOT}"/stacks/core/cache -type f 2>/dev/null | wc -l) files)
│   │   ├── monitoring/ ($(find "${PROJECT_ROOT}"/stacks/core/monitoring -type f 2>/dev/null | wc -l) files)
│   │   └── traefik/ ($(find "${PROJECT_ROOT}"/stacks/core/traefik -type f 2>/dev/null | wc -l) files)
│   ├── applications/
│   │   ├── ai/ ($(find "${PROJECT_ROOT}"/stacks/applications/ai -type f 2>/dev/null | wc -l) files)
│   │   └── general/ ($(find "${PROJECT_ROOT}"/stacks/applications/general -type f 2>/dev/null | wc -l) files)
│   └── infrastructure/
│       ├── security/ ($(find "${PROJECT_ROOT}"/stacks/infrastructure/security -type f 2>/dev/null | wc -l) files)
│       └── backup/ ($(find "${PROJECT_ROOT}"/stacks/infrastructure/backup -type f 2>/dev/null | wc -l) files)
├── scripts/
│   └── migrated/ ($(find "${PROJECT_ROOT}"/scripts/migrated -type f 2>/dev/null | wc -l) files)
└── configs/ ($(find "${PROJECT_ROOT}"/configs -type f 2>/dev/null | wc -l) files)
\`\`\`

## Next Steps

### Immediate Actions
1. Review rejected files in \`${MIGRATION_DIR}/rejected/\`
2. Update outdated service versions
3. Remove hardcoded secrets
4. Add missing health checks and resource limits

### Short-term (1 week)
1. Deploy validated stacks to staging
2. Run integration tests
3. Performance benchmarking
4. Security scanning with Trivy

### Medium-term (1 month)
1. Complete production deployment
2. Monitor and optimize
3. Documentation update
4. Team training

## Appendix

### Validation Log
Last 20 entries from consolidation.log:
\`\`\`
$(tail -20 "${LOG_FILE}")
\`\`\`

### Generated Reports
- Validation Report: ${VALIDATION_REPORT}
- Deduplication Report: ${DEDUP_REPORT}
- Version Matrix: ${MIGRATION_DIR}/reports/version-matrix.md
- This Report: ${COMPLIANCE_REPORT}

---

**Report generated by Setup-Macspark Enhanced Consolidation Pipeline v2.0**
**Timestamp:** $(date -Iseconds)
EOF
    
    log_success "Compliance report generated: ${COMPLIANCE_REPORT}"
}

# ========================================
# Cleanup Functions
# ========================================
cleanup_and_archive() {
    log_info "Cleaning up and archiving..."
    
    # Create archive
    local archive_name="consolidation-${TIMESTAMP}.tar.gz"
    tar -czf "${MIGRATION_DIR}/archive/${archive_name}" \
        -C "${MIGRATION_DIR}" \
        discovered deduplicated validated rejected reports \
        validation-report.json deduplication-report.json compliance-report.md \
        consolidation.log 2>/dev/null || true
    
    # Clean temporary files older than 7 days
    find "${MIGRATION_DIR}" -type f -mtime +7 -name "*.tmp" -delete
    find "${MIGRATION_DIR}/archive" -type f -mtime +30 -name "*.tar.gz" -delete
    
    # Generate archive manifest
    cat > "${MIGRATION_DIR}/archive/manifest-${TIMESTAMP}.json" <<EOF
{
    "archive": "${archive_name}",
    "timestamp": "$(date -Iseconds)",
    "statistics": {
        "files_processed": ${total:-0},
        "files_validated": ${validated:-0},
        "files_rejected": ${rejected:-0},
        "duplicates_removed": ${DUPLICATES_REMOVED},
        "space_saved": "${space_saved:-0}",
        "compliance_rate": "${compliance_rate:-0}%"
    }
}
EOF
    
    log_success "Archive created: ${archive_name}"
}

# ========================================
# Main Execution
# ========================================
main() {
    log_info "==========================================")
    log_info "Enhanced File Consolidation Pipeline v2.0")
    log_info "==========================================")
    log_info "Timestamp: ${TIMESTAMP}")
    
    # Parse arguments
    local MODE="${1:-full}"
    local DEBUG="${2:-false}"
    
    export DEBUG
    
    case "${MODE}" in
        discover)
            setup_directories
            discover_files
            ;;
        deduplicate)
            setup_directories
            discover_files
            deduplicate_files
            ;;
        validate)
            setup_directories
            discover_files
            deduplicate_files
            validate_and_categorize
            ;;
        full|*)
            # Full pipeline execution
            setup_directories
            discover_files
            deduplicate_files
            validate_and_categorize
            select_best_versions
            transfer_validated_files
            generate_compliance_report
            cleanup_and_archive
            ;;
    esac
    
    # Summary
    log_success "=========================================="
    log_success "Pipeline completed successfully!"
    log_success "=========================================="
    
    if [[ -f "${COMPLIANCE_REPORT}" ]]; then
        echo ""
        echo -e "${GREEN}Summary:${NC}"
        echo "- Files Validated: $(jq '.summary.validated' "${VALIDATION_REPORT}")"
        echo "- Files Rejected: $(jq '.summary.rejected' "${VALIDATION_REPORT}")"
        echo "- Duplicates Removed: ${DUPLICATES_REMOVED}"
        echo "- Space Saved: $(jq -r '.space_saved' "${DEDUP_REPORT}")"
        echo "- Compliance Rate: ${compliance_rate:-0}%"
        echo ""
        echo -e "${BLUE}Reports:${NC}"
        echo "- Compliance: ${COMPLIANCE_REPORT}"
        echo "- Validation: ${VALIDATION_REPORT}"
        echo "- Deduplication: ${DEDUP_REPORT}"
    fi
}

# Run main function
main "$@"