-- PostgreSQL Consolidated Database Initialization
-- Creates all application databases in a single PostgreSQL cluster
-- Version: 2.0 | Date: 2025-08-22

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "hstore";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
CREATE EXTENSION IF NOT EXISTS "btree_gin";
CREATE EXTENSION IF NOT EXISTS "btree_gist";

-- =====================================
-- APPLICATION DATABASES
-- =====================================

-- N8N Workflow Automation
CREATE DATABASE n8n_db 
  WITH ENCODING = 'UTF8' 
  LC_COLLATE = 'en_US.utf8' 
  LC_CTYPE = 'en_US.utf8' 
  TEMPLATE = template0;

-- Chatwoot Customer Support
CREATE DATABASE chatwoot_db 
  WITH ENCODING = 'UTF8' 
  LC_COLLATE = 'en_US.utf8' 
  LC_CTYPE = 'en_US.utf8' 
  TEMPLATE = template0;

-- BookStack Documentation
CREATE DATABASE bookstack_db 
  WITH ENCODING = 'UTF8' 
  LC_COLLATE = 'en_US.utf8' 
  LC_CTYPE = 'en_US.utf8' 
  TEMPLATE = template0;

-- Evolution API (WhatsApp Business)
CREATE DATABASE evolution_api_db 
  WITH ENCODING = 'UTF8' 
  LC_COLLATE = 'en_US.utf8' 
  LC_CTYPE = 'en_US.utf8' 
  TEMPLATE = template0;

-- Grafana Dashboards
CREATE DATABASE grafana_db 
  WITH ENCODING = 'UTF8' 
  LC_COLLATE = 'en_US.utf8' 
  LC_CTYPE = 'en_US.utf8' 
  TEMPLATE = template0;

-- Keycloak Identity Management
CREATE DATABASE keycloak_db 
  WITH ENCODING = 'UTF8' 
  LC_COLLATE = 'en_US.utf8' 
  LC_CTYPE = 'en_US.utf8' 
  TEMPLATE = template0;

-- Nextcloud File Storage
CREATE DATABASE nextcloud_db 
  WITH ENCODING = 'UTF8' 
  LC_COLLATE = 'en_US.utf8' 
  LC_CTYPE = 'en_US.utf8' 
  TEMPLATE = template0;

-- =====================================
-- APPLICATION USERS
-- =====================================

-- N8N User
CREATE USER n8n_user WITH 
  PASSWORD 'CHANGE_ME_N8N_2025!'
  NOSUPERUSER 
  NOCREATEDB 
  NOCREATEROLE 
  NOINHERIT 
  LOGIN 
  NOREPLICATION 
  NOBYPASSRLS;

GRANT CONNECT ON DATABASE n8n_db TO n8n_user;
GRANT USAGE ON SCHEMA public TO n8n_user;
GRANT CREATE ON SCHEMA public TO n8n_user;

-- Chatwoot User
CREATE USER chatwoot_user WITH 
  PASSWORD 'CHANGE_ME_CHATWOOT_2025!'
  NOSUPERUSER 
  NOCREATEDB 
  NOCREATEROLE 
  NOINHERIT 
  LOGIN 
  NOREPLICATION 
  NOBYPASSRLS;

GRANT CONNECT ON DATABASE chatwoot_db TO chatwoot_user;

-- BookStack User
CREATE USER bookstack_user WITH 
  PASSWORD 'CHANGE_ME_BOOKSTACK_2025!'
  NOSUPERUSER 
  NOCREATEDB 
  NOCREATEROLE 
  NOINHERIT 
  LOGIN 
  NOREPLICATION 
  NOBYPASSRLS;

GRANT CONNECT ON DATABASE bookstack_db TO bookstack_user;

-- Evolution API User
CREATE USER evolution_user WITH 
  PASSWORD 'CHANGE_ME_EVOLUTION_2025!'
  NOSUPERUSER 
  NOCREATEDB 
  NOCREATEROLE 
  NOINHERIT 
  LOGIN 
  NOREPLICATION 
  NOBYPASSRLS;

GRANT CONNECT ON DATABASE evolution_api_db TO evolution_user;

-- Grafana User
CREATE USER grafana_user WITH 
  PASSWORD 'CHANGE_ME_GRAFANA_2025!'
  NOSUPERUSER 
  NOCREATEDB 
  NOCREATEROLE 
  NOINHERIT 
  LOGIN 
  NOREPLICATION 
  NOBYPASSRLS;

GRANT CONNECT ON DATABASE grafana_db TO grafana_user;

-- Keycloak User
CREATE USER keycloak_user WITH 
  PASSWORD 'CHANGE_ME_KEYCLOAK_2025!'
  NOSUPERUSER 
  NOCREATEDB 
  NOCREATEROLE 
  NOINHERIT 
  LOGIN 
  NOREPLICATION 
  NOBYPASSRLS;

GRANT CONNECT ON DATABASE keycloak_db TO keycloak_user;

-- Nextcloud User
CREATE USER nextcloud_user WITH 
  PASSWORD 'CHANGE_ME_NEXTCLOUD_2025!'
  NOSUPERUSER 
  NOCREATEDB 
  NOCREATEROLE 
  NOINHERIT 
  LOGIN 
  NOREPLICATION 
  NOBYPASSRLS;

GRANT CONNECT ON DATABASE nextcloud_db TO nextcloud_user;

-- =====================================
-- REPLICATION USER
-- =====================================

CREATE USER replication_user WITH 
  PASSWORD 'CHANGE_ME_REPLICATION_2025!'
  NOSUPERUSER 
  NOCREATEDB 
  NOCREATEROLE 
  NOINHERIT 
  LOGIN 
  REPLICATION 
  NOBYPASSRLS;

-- =====================================
-- MONITORING AND BACKUP USERS
-- =====================================

-- Monitoring User (Prometheus Exporter)
CREATE USER monitoring_user WITH 
  PASSWORD 'CHANGE_ME_MONITORING_2025!'
  NOSUPERUSER 
  NOCREATEDB 
  NOCREATEROLE 
  NOINHERIT 
  LOGIN 
  NOREPLICATION 
  NOBYPASSRLS;

-- Grant necessary permissions for monitoring
GRANT pg_monitor TO monitoring_user;
GRANT CONNECT ON DATABASE macspark_consolidated TO monitoring_user;
GRANT USAGE ON SCHEMA public TO monitoring_user;

-- Backup User
CREATE USER backup_user WITH 
  PASSWORD 'CHANGE_ME_BACKUP_2025!'
  NOSUPERUSER 
  NOCREATEDB 
  NOCREATEROLE 
  NOINHERIT 
  LOGIN 
  NOREPLICATION 
  NOBYPASSRLS;

-- Grant backup permissions (pg_dump, etc.)
GRANT CONNECT ON DATABASE n8n_db TO backup_user;
GRANT CONNECT ON DATABASE chatwoot_db TO backup_user;
GRANT CONNECT ON DATABASE bookstack_db TO backup_user;
GRANT CONNECT ON DATABASE evolution_api_db TO backup_user;
GRANT CONNECT ON DATABASE grafana_db TO backup_user;
GRANT CONNECT ON DATABASE keycloak_db TO backup_user;
GRANT CONNECT ON DATABASE nextcloud_db TO backup_user;

-- =====================================
-- DATABASE-SPECIFIC PERMISSIONS
-- =====================================

-- N8N specific permissions
\c n8n_db;
GRANT USAGE ON SCHEMA public TO n8n_user;
GRANT CREATE ON SCHEMA public TO n8n_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO n8n_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO n8n_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO n8n_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO n8n_user;

-- Chatwoot specific permissions
\c chatwoot_db;
GRANT USAGE ON SCHEMA public TO chatwoot_user;
GRANT CREATE ON SCHEMA public TO chatwoot_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO chatwoot_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO chatwoot_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO chatwoot_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO chatwoot_user;

-- BookStack specific permissions
\c bookstack_db;
GRANT USAGE ON SCHEMA public TO bookstack_user;
GRANT CREATE ON SCHEMA public TO bookstack_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO bookstack_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO bookstack_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO bookstack_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO bookstack_user;

-- Evolution API specific permissions
\c evolution_api_db;
GRANT USAGE ON SCHEMA public TO evolution_user;
GRANT CREATE ON SCHEMA public TO evolution_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO evolution_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO evolution_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO evolution_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO evolution_user;

-- Grafana specific permissions
\c grafana_db;
GRANT USAGE ON SCHEMA public TO grafana_user;
GRANT CREATE ON SCHEMA public TO grafana_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO grafana_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO grafana_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO grafana_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO grafana_user;

-- Keycloak specific permissions
\c keycloak_db;
GRANT USAGE ON SCHEMA public TO keycloak_user;
GRANT CREATE ON SCHEMA public TO keycloak_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO keycloak_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO keycloak_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO keycloak_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO keycloak_user;

-- Nextcloud specific permissions
\c nextcloud_db;
GRANT USAGE ON SCHEMA public TO nextcloud_user;
GRANT CREATE ON SCHEMA public TO nextcloud_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO nextcloud_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO nextcloud_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO nextcloud_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO nextcloud_user;

-- =====================================
-- PERFORMANCE OPTIMIZATIONS
-- =====================================

-- Back to main database for system-wide settings
\c macspark_consolidated;

-- Enable query statistics collection
SELECT pg_stat_statements_reset();

-- Create indexes for performance
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_pg_stat_activity_state 
  ON pg_stat_activity(state) WHERE state IS NOT NULL;

-- Set up automated VACUUM and ANALYZE
ALTER SYSTEM SET autovacuum = on;
ALTER SYSTEM SET autovacuum_analyze_scale_factor = 0.05;
ALTER SYSTEM SET autovacuum_vacuum_scale_factor = 0.1;
ALTER SYSTEM SET autovacuum_naptime = '30s';
ALTER SYSTEM SET autovacuum_max_workers = 4;

-- =====================================
-- SECURITY CONFIGURATIONS
-- =====================================

-- Password policy
ALTER SYSTEM SET password_encryption = 'scram-sha-256';
ALTER SYSTEM SET ssl = on;
ALTER SYSTEM SET ssl_ciphers = 'HIGH:!aNULL:!MD5';
ALTER SYSTEM SET ssl_prefer_server_ciphers = on;

-- Connection security
ALTER SYSTEM SET log_connections = on;
ALTER SYSTEM SET log_disconnections = on;
ALTER SYSTEM SET log_statement = 'all';
ALTER SYSTEM SET log_min_duration_statement = 1000;

-- Apply configuration changes
SELECT pg_reload_conf();

-- =====================================
-- COMPLETION MESSAGE
-- =====================================

DO $$ 
BEGIN
    RAISE NOTICE 'PostgreSQL Consolidated Database Setup Complete!';
    RAISE NOTICE 'Databases created: n8n_db, chatwoot_db, bookstack_db, evolution_api_db, grafana_db, keycloak_db, nextcloud_db';
    RAISE NOTICE 'Users created with appropriate permissions';
    RAISE NOTICE 'IMPORTANT: Change all default passwords before production!';
    RAISE NOTICE 'Setup completed at: %', now();
END $$;