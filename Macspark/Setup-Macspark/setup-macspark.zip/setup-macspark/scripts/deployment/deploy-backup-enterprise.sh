#!/bin/bash
# MACSPARK ENTERPRISE BACKUP - DEPLOY SCRIPT
# Version: 2.0 - Deploy enterprise backup stack to Docker Swarm
# Created: 2025-08-24 - Integrated deployment for Setup-Macspark
# Author: MacSpark Infrastructure Team

set -euo pipefail
IFS=$'\n\t'

# ==============================================================================
# DEPLOYMENT CONFIGURATION
# ==============================================================================

# Base Configuration
readonly SCRIPT_NAME="$(basename "$0" .sh)"
readonly SCRIPT_VERSION="2.0.0"
readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly SETUP_MACSPARK_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
readonly ENVIRONMENT="${ENVIRONMENT:-production}"

# Stack Configuration
readonly STACK_NAME="backup-enterprise"
readonly STACK_FILE="$SETUP_MACSPARK_ROOT/stacks/infrastructure/backup/backup-enterprise-stack.yml"
readonly CONFIGS_DIR="$SETUP_MACSPARK_ROOT/stacks/infrastructure/backup/configs"
readonly SCRIPTS_DIR="$SETUP_MACSPARK_ROOT/scripts/backup"

# Enterprise Paths
readonly BACKUP_ROOT="/opt/macspark/backup"
readonly LOG_DIR="$BACKUP_ROOT/logs/deployment"
readonly SECRETS_DIR="$BACKUP_ROOT/secrets"
readonly CONFIG_DIR="$BACKUP_ROOT/config"

# Session Tracking
readonly SESSION_ID="$(uuidgen 2>/dev/null || openssl rand -hex 8)"
readonly START_TIME="$(date +%s)"
readonly TIMESTAMP="$(date '+%Y%m%d_%H%M%S')"

# Colors for Enterprise UI
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly PURPLE='\033[0;35m'
readonly CYAN='\033[0;36m'
readonly WHITE='\033[1;37m'
readonly NC='\033[0m'

# Enterprise Icons
readonly ICON_SUCCESS="✅"
readonly ICON_ERROR="❌"
readonly ICON_WARNING="⚠️"
readonly ICON_INFO="ℹ️"
readonly ICON_DEPLOY="🚀"
readonly ICON_BACKUP="💾"
readonly ICON_ENTERPRISE="🏢"

# Ensure directories exist
for dir in "$LOG_DIR" "$SECRETS_DIR" "$CONFIG_DIR"; do
    sudo mkdir -p "$dir" || {
        echo -e "${RED}${ICON_ERROR} Cannot create directory: $dir${NC}" >&2
        exit 1
    }
done

# ==============================================================================
# ENTERPRISE LOGGING & UTILITIES
# ==============================================================================

# Enhanced logging with enterprise formatting
log_enterprise() {
    local level="$1"
    local message="$2"
    local component="${3:-deploy}"
    
    local timestamp="$(date -Iseconds)"
    local color="" icon=""
    
    case "$level" in
        "SUCCESS") color="$GREEN"; icon="$ICON_SUCCESS" ;;
        "ERROR") color="$RED"; icon="$ICON_ERROR" ;;
        "WARN") color="$YELLOW"; icon="$ICON_WARNING" ;;
        "INFO") color="$BLUE"; icon="$ICON_INFO" ;;
        "DEPLOY") color="$PURPLE"; icon="$ICON_DEPLOY" ;;
        *) color="$WHITE"; icon="$ICON_ENTERPRISE" ;;
    esac
    
    # Console output
    echo -e "${color}${icon} [$(date '+%H:%M:%S')] [$level] $message${NC}"
    
    # File logging
    echo "[$timestamp] [$level] [$component] $message" >> "$LOG_DIR/deployment.log"
}

# Check Docker Swarm status
check_swarm_status() {
    log_enterprise "INFO" "Checking Docker Swarm status..." "swarm"
    
    if ! docker info --format '{{.Swarm.LocalNodeState}}' | grep -q "active"; then
        log_enterprise "ERROR" "Docker Swarm is not active. Please initialize swarm mode first." "swarm"
        return 1
    fi
    
    local node_role="$(docker info --format '{{.Swarm.ControlAvailable}}')"
    if [[ "$node_role" != "true" ]]; then
        log_enterprise "ERROR" "Node is not a swarm manager. Deploy must run on manager node." "swarm"
        return 1
    fi
    
    log_enterprise "SUCCESS" "Docker Swarm is active and node is manager" "swarm"
    return 0
}

# Check required networks
check_networks() {
    log_enterprise "INFO" "Checking required networks..." "networks"
    
    local required_networks=("traefik-public" "monitoring")
    
    for network in "${required_networks[@]}"; do
        if docker network ls --format '{{.Name}}' | grep -q "^${network}$"; then
            log_enterprise "SUCCESS" "Network $network exists" "networks"
        else
            log_enterprise "WARN" "Network $network does not exist, will create..." "networks"
            
            case "$network" in
                "traefik-public")
                    docker network create \
                        --driver overlay \
                        --attachable \
                        --opt encrypted=true \
                        --label "macspark.network.type=public" \
                        traefik-public
                    ;;
                "monitoring")
                    docker network create \
                        --driver overlay \
                        --attachable \
                        --opt encrypted=true \
                        --label "macspark.network.type=monitoring" \
                        monitoring
                    ;;
            esac
            
            log_enterprise "SUCCESS" "Created network $network" "networks"
        fi
    done
}

# Generate enterprise secrets
generate_secrets() {
    log_enterprise "INFO" "Generating enterprise secrets..." "secrets"
    
    # Generate strong passwords
    local kopia_password="$(openssl rand -base64 32)"
    local restic_password="$(openssl rand -base64 32)"
    local encryption_key="$(openssl rand -base64 64)"
    
    # Create secrets in Docker Swarm
    if ! docker secret ls --format '{{.Name}}' | grep -q "^kopia-password$"; then
        echo "$kopia_password" | docker secret create kopia-password -
        log_enterprise "SUCCESS" "Created kopia-password secret" "secrets"
    else
        log_enterprise "INFO" "Secret kopia-password already exists" "secrets"
    fi
    
    if ! docker secret ls --format '{{.Name}}' | grep -q "^restic-password$"; then
        echo "$restic_password" | docker secret create restic-password -
        log_enterprise "SUCCESS" "Created restic-password secret" "secrets"
    else
        log_enterprise "INFO" "Secret restic-password already exists" "secrets"
    fi
    
    if ! docker secret ls --format '{{.Name}}' | grep -q "^backup-encryption-key$"; then
        echo "$encryption_key" | docker secret create backup-encryption-key -
        log_enterprise "SUCCESS" "Created backup-encryption-key secret" "secrets"
    else
        log_enterprise "INFO" "Secret backup-encryption-key already exists" "secrets"
    fi
    
    # Create empty cloud credentials secret if not exists
    if ! docker secret ls --format '{{.Name}}' | grep -q "^cloud-credentials$"; then
        echo '{}' | docker secret create cloud-credentials -
        log_enterprise "SUCCESS" "Created cloud-credentials secret (empty)" "secrets"
    else
        log_enterprise "INFO" "Secret cloud-credentials already exists" "secrets"
    fi
    
    # Store secrets locally for reference (encrypted)
    cat > "$SECRETS_DIR/secrets.env.enc" << EOF
# MacSpark Enterprise Backup Secrets - $(date)
# WARNING: This file contains encrypted secrets
KOPIA_PASSWORD_HASH=$(echo "$kopia_password" | sha256sum | cut -d' ' -f1)
RESTIC_PASSWORD_HASH=$(echo "$restic_password" | sha256sum | cut -d' ' -f1)
ENCRYPTION_KEY_HASH=$(echo "$encryption_key" | sha256sum | cut -d' ' -f1)
CREATED_TIMESTAMP=$START_TIME
SESSION_ID=$SESSION_ID
EOF
    
    sudo chmod 600 "$SECRETS_DIR/secrets.env.enc"
    log_enterprise "SUCCESS" "Secrets generated and stored securely" "secrets"
}

# Setup storage directories
setup_storage() {
    log_enterprise "INFO" "Setting up enterprise storage directories..." "storage"
    
    local storage_dirs=(
        "$BACKUP_ROOT/kopia"
        "$BACKUP_ROOT/restic" 
        "$BACKUP_ROOT/config"
        "$BACKUP_ROOT/logs"
        "$BACKUP_ROOT/metrics"
        "$BACKUP_ROOT/traces"
        "$BACKUP_ROOT/repositories/kopia-primary"
        "$BACKUP_ROOT/repositories/restic-secondary"
        "$BACKUP_ROOT/local-backups/daily"
        "$BACKUP_ROOT/local-backups/databases"
        "$BACKUP_ROOT/local-backups/applications"
        "$BACKUP_ROOT/n8n-workflows"
        "$BACKUP_ROOT/status"
        "$BACKUP_ROOT/alerts"
    )
    
    for dir in "${storage_dirs[@]}"; do
        sudo mkdir -p "$dir"
        sudo chown 1000:1000 "$dir" 2>/dev/null || true
        sudo chmod 755 "$dir"
    done
    
    # Setup specific permissions for sensitive directories
    sudo chmod 700 "$BACKUP_ROOT/repositories"
    sudo chmod 700 "$BACKUP_ROOT/secrets"
    
    log_enterprise "SUCCESS" "Storage directories created with proper permissions" "storage"
}

# Deploy node labels
setup_node_labels() {
    log_enterprise "INFO" "Setting up Docker Swarm node labels..." "labels"
    
    local node_id="$(docker info --format '{{.Swarm.NodeID}}')"
    
    # Set backup-related labels
    docker node update --label-add macspark.backup.kopia=true "$node_id"
    docker node update --label-add macspark.backup.restic=true "$node_id"
    docker node update --label-add macspark.backup.orchestrator=true "$node_id"
    docker node update --label-add macspark.backup.monitoring=true "$node_id"
    
    # Set zone label for placement preferences
    docker node update --label-add zone=primary "$node_id"
    
    log_enterprise "SUCCESS" "Node labels configured for backup services" "labels"
}

# Copy and setup configurations
setup_configurations() {
    log_enterprise "INFO" "Setting up enterprise configurations..." "configs"
    
    # Copy configuration files to backup directory
    sudo cp -r "$CONFIGS_DIR"/* "$CONFIG_DIR/"
    sudo chown -R 1000:1000 "$CONFIG_DIR"
    
    # Copy scripts to backup directory
    sudo cp -r "$SCRIPTS_DIR"/* "$BACKUP_ROOT/scripts/" 2>/dev/null || sudo mkdir -p "$BACKUP_ROOT/scripts"
    sudo cp -r "$SCRIPTS_DIR"/* "$BACKUP_ROOT/scripts/"
    sudo chown -R 1000:1000 "$BACKUP_ROOT/scripts"
    sudo chmod +x "$BACKUP_ROOT/scripts"/*.sh 2>/dev/null || true
    sudo chmod +x "$BACKUP_ROOT/scripts/core"/*.sh 2>/dev/null || true
    
    # Create TLS certificates directory (self-signed for internal use)
    sudo mkdir -p "$CONFIG_DIR/tls"
    
    if [[ ! -f "$CONFIG_DIR/tls/cert.pem" ]]; then
        sudo openssl req -x509 -newkey rsa:4096 -keyout "$CONFIG_DIR/tls/key.pem" -out "$CONFIG_DIR/tls/cert.pem" -days 365 -nodes -subj "/C=US/ST=CA/L=SF/O=MacSpark/CN=kopia.macspark.dev" 2>/dev/null
        sudo chown 1000:1000 "$CONFIG_DIR/tls"/*
        sudo chmod 600 "$CONFIG_DIR/tls"/*
        log_enterprise "SUCCESS" "TLS certificates generated" "configs"
    fi
    
    log_enterprise "SUCCESS" "Configurations and scripts deployed" "configs"
}

# Deploy the stack
deploy_stack() {
    log_enterprise "DEPLOY" "Deploying MacSpark Enterprise Backup Stack..." "deploy"
    
    if [[ ! -f "$STACK_FILE" ]]; then
        log_enterprise "ERROR" "Stack file not found: $STACK_FILE" "deploy"
        return 1
    fi
    
    # Deploy with Docker Swarm
    cd "$SETUP_MACSPARK_ROOT/stacks/infrastructure/backup"
    
    if docker stack deploy -c backup-enterprise-stack.yml "$STACK_NAME"; then
        log_enterprise "SUCCESS" "Stack $STACK_NAME deployed successfully" "deploy"
    else
        log_enterprise "ERROR" "Failed to deploy stack $STACK_NAME" "deploy"
        return 1
    fi
    
    # Wait for services to start
    log_enterprise "INFO" "Waiting for services to start..." "deploy"
    sleep 30
    
    # Check service status
    local services=(
        "${STACK_NAME}_kopia-server"
        "${STACK_NAME}_restic-server"
        "${STACK_NAME}_backup-orchestrator"
        "${STACK_NAME}_backup-monitor"
        "${STACK_NAME}_backup-exporter"
    )
    
    for service in "${services[@]}"; do
        local replicas_running="$(docker service ls --filter name="$service" --format '{{.Replicas}}' | cut -d'/' -f1)"
        local replicas_desired="$(docker service ls --filter name="$service" --format '{{.Replicas}}' | cut -d'/' -f2)"
        
        if [[ "$replicas_running" -eq "$replicas_desired" ]] && [[ "$replicas_running" -gt 0 ]]; then
            log_enterprise "SUCCESS" "Service $service is running ($replicas_running/$replicas_desired)" "deploy"
        else
            log_enterprise "WARN" "Service $service status: $replicas_running/$replicas_desired" "deploy"
        fi
    done
}

# Setup cron jobs for backup orchestration
setup_cron_jobs() {
    log_enterprise "INFO" "Setting up enterprise cron jobs..." "cron"
    
    # Create cron entries
    cat > /tmp/backup-cron << 'EOF'
# MacSpark Enterprise Backup Cron Jobs
# Generated automatically - do not edit manually

# Critical backup every 30 minutes
*/30 * * * * /opt/macspark/backup/scripts/core/backup-critical-complete.sh >/dev/null 2>&1

# Health check every 5 minutes
*/5 * * * * /opt/macspark/backup/scripts/core/health-check-enterprise.sh >/dev/null 2>&1

# Daily report at 6 AM
0 6 * * * /opt/macspark/backup/scripts/core/notification-system.sh --daily-report-enterprise >/dev/null 2>&1

# Weekly system maintenance on Sunday at 2 AM
0 2 * * 0 /opt/macspark/backup/scripts/maintenance/weekly-maintenance.sh >/dev/null 2>&1

# Cleanup old logs daily at midnight
0 0 * * * find /opt/macspark/backup/logs -name "*.log" -mtime +30 -delete >/dev/null 2>&1
EOF
    
    sudo crontab /tmp/backup-cron
    rm /tmp/backup-cron
    
    log_enterprise "SUCCESS" "Cron jobs installed for backup orchestration" "cron"
}

# Verify deployment
verify_deployment() {
    log_enterprise "INFO" "Verifying enterprise deployment..." "verify"
    
    local all_healthy=true
    
    # Check stack status
    if docker stack ls | grep -q "$STACK_NAME"; then
        log_enterprise "SUCCESS" "Stack $STACK_NAME is deployed" "verify"
    else
        log_enterprise "ERROR" "Stack $STACK_NAME not found" "verify"
        all_healthy=false
    fi
    
    # Check service health
    local unhealthy_services=()
    for service in $(docker stack services "$STACK_NAME" --format '{{.Name}}'); do
        local health_status="$(docker service inspect "$service" --format '{{range .Spec.TaskTemplate.ContainerSpec.Healthcheck}}{{.Test}}{{end}}' 2>/dev/null || echo "none")"
        if [[ "$health_status" != "none" ]]; then
            # Service has health check, verify it
            local healthy_replicas="$(docker service ps "$service" --filter 'desired-state=running' --format '{{.CurrentState}}' | grep -c "Running" || echo "0")"
            if [[ "$healthy_replicas" -gt 0 ]]; then
                log_enterprise "SUCCESS" "Service $service is healthy" "verify"
            else
                log_enterprise "ERROR" "Service $service is unhealthy" "verify"
                unhealthy_services+=("$service")
                all_healthy=false
            fi
        fi
    done
    
    # Check storage accessibility
    if [[ -d "$BACKUP_ROOT" && -w "$BACKUP_ROOT" ]]; then
        log_enterprise "SUCCESS" "Backup storage is accessible" "verify"
    else
        log_enterprise "ERROR" "Backup storage is not accessible" "verify"
        all_healthy=false
    fi
    
    # Check secrets
    local missing_secrets=()
    for secret in "kopia-password" "restic-password" "backup-encryption-key" "cloud-credentials"; do
        if docker secret ls --format '{{.Name}}' | grep -q "^${secret}$"; then
            log_enterprise "SUCCESS" "Secret $secret exists" "verify"
        else
            log_enterprise "ERROR" "Secret $secret is missing" "verify"
            missing_secrets+=("$secret")
            all_healthy=false
        fi
    done
    
    if [[ "$all_healthy" == "true" ]]; then
        log_enterprise "SUCCESS" "Enterprise backup deployment verification passed" "verify"
        return 0
    else
        log_enterprise "ERROR" "Deployment verification failed" "verify"
        if [[ ${#unhealthy_services[@]} -gt 0 ]]; then
            log_enterprise "ERROR" "Unhealthy services: ${unhealthy_services[*]}" "verify"
        fi
        if [[ ${#missing_secrets[@]} -gt 0 ]]; then
            log_enterprise "ERROR" "Missing secrets: ${missing_secrets[*]}" "verify"
        fi
        return 1
    fi
}

# Generate deployment summary
generate_summary() {
    local deployment_duration="$(($(date +%s) - START_TIME))"
    
    cat > "$LOG_DIR/deployment-summary-$TIMESTAMP.json" << EOF
{
  "deployment": {
    "session_id": "$SESSION_ID",
    "timestamp": "$(date -Iseconds)",
    "duration_seconds": $deployment_duration,
    "stack_name": "$STACK_NAME",
    "stack_file": "$STACK_FILE",
    "environment": "$ENVIRONMENT",
    "status": "completed"
  },
  "services": {
    "kopia_server": {
      "image": "kopia/kopia:0.15.0",
      "url": "https://kopia.macspark.dev",
      "port": 51515
    },
    "restic_server": {
      "image": "restic/rest-server:0.12.1", 
      "url": "https://restic.macspark.dev",
      "port": 8000
    },
    "backup_monitor": {
      "image": "nginx:1.25-alpine",
      "url": "https://backup.macspark.dev",
      "port": 80
    }
  },
  "storage": {
    "backup_root": "$BACKUP_ROOT",
    "repositories": {
      "kopia": "$BACKUP_ROOT/repositories/kopia-primary",
      "restic": "$BACKUP_ROOT/repositories/restic-secondary"
    },
    "logs": "$BACKUP_ROOT/logs",
    "config": "$BACKUP_ROOT/config"
  },
  "security": {
    "secrets_created": 4,
    "tls_enabled": true,
    "encryption_enabled": true,
    "audit_logging": true
  },
  "monitoring": {
    "prometheus_metrics": true,
    "jaeger_tracing": true,
    "grafana_dashboards": true,
    "health_checks": true
  }
}
EOF
    
    echo -e "\n${WHITE}${ICON_ENTERPRISE}========================================${NC}"
    echo -e "${WHITE}${ICON_ENTERPRISE} MacSpark Enterprise Backup Deployed${NC}"
    echo -e "${WHITE}${ICON_ENTERPRISE}========================================${NC}"
    echo -e "${GREEN}${ICON_SUCCESS} Stack Name: ${WHITE}$STACK_NAME${NC}"
    echo -e "${GREEN}${ICON_SUCCESS} Deployment Time: ${WHITE}${deployment_duration}s${NC}"
    echo -e "${GREEN}${ICON_SUCCESS} Session ID: ${WHITE}$SESSION_ID${NC}"
    echo ""
    echo -e "${CYAN}${ICON_INFO} Service URLs:${NC}"
    echo -e "${WHITE}  • Kopia Server: ${CYAN}https://kopia.macspark.dev${NC}"
    echo -e "${WHITE}  • Restic Server: ${CYAN}https://restic.macspark.dev${NC}"
    echo -e "${WHITE}  • Backup Monitor: ${CYAN}https://backup.macspark.dev${NC}"
    echo ""
    echo -e "${CYAN}${ICON_INFO} Storage Locations:${NC}"
    echo -e "${WHITE}  • Backup Root: ${CYAN}$BACKUP_ROOT${NC}"
    echo -e "${WHITE}  • Logs: ${CYAN}$BACKUP_ROOT/logs${NC}"
    echo -e "${WHITE}  • Config: ${CYAN}$BACKUP_ROOT/config${NC}"
    echo ""
    echo -e "${CYAN}${ICON_INFO} Next Steps:${NC}"
    echo -e "${WHITE}  1. Configure cloud storage (optional)${NC}"
    echo -e "${WHITE}  2. Test backup functionality${NC}"
    echo -e "${WHITE}  3. Setup monitoring dashboards${NC}"
    echo -e "${WHITE}  4. Configure notification channels${NC}"
    echo -e "${WHITE}${ICON_ENTERPRISE}========================================${NC}\n"
}

# ==============================================================================
# MAIN DEPLOYMENT EXECUTION
# ==============================================================================

main() {
    log_enterprise "DEPLOY" "Starting MacSpark Enterprise Backup Deployment v$SCRIPT_VERSION" "main"
    log_enterprise "INFO" "Session ID: $SESSION_ID" "main"
    log_enterprise "INFO" "Environment: $ENVIRONMENT" "main"
    
    # Deployment steps
    check_swarm_status || exit 1
    check_networks || exit 1
    setup_storage || exit 1
    generate_secrets || exit 1
    setup_node_labels || exit 1
    setup_configurations || exit 1
    deploy_stack || exit 1
    setup_cron_jobs || exit 1
    
    # Wait for services to stabilize
    log_enterprise "INFO" "Waiting for services to stabilize..." "main"
    sleep 60
    
    # Verify deployment
    if verify_deployment; then
        log_enterprise "SUCCESS" "Enterprise backup system deployed successfully!" "main"
        generate_summary
        
        # Send success notification
        if [[ -f "$BACKUP_ROOT/scripts/core/notification-system.sh" ]]; then
            "$BACKUP_ROOT/scripts/core/notification-system.sh" --success-enterprise "Deployment" "MacSpark Enterprise Backup System v$SCRIPT_VERSION deployed successfully in ${deployment_duration}s"
        fi
        
        exit 0
    else
        log_enterprise "ERROR" "Deployment verification failed" "main"
        exit 1
    fi
}

# Handle script arguments
case "${1:-}" in
    --help|-h)
        cat << 'EOF'
MacSpark Enterprise Backup Deployment Script v2.0

USAGE:
    deploy-backup-enterprise.sh [OPTIONS]

OPTIONS:
    --help, -h          Show this help message
    --verify            Only verify existing deployment
    --cleanup           Remove the backup stack
    --status            Show deployment status

EXAMPLES:
    # Deploy enterprise backup stack
    ./deploy-backup-enterprise.sh

    # Verify existing deployment
    ./deploy-backup-enterprise.sh --verify

    # Check deployment status
    ./deploy-backup-enterprise.sh --status

EOF
        exit 0
        ;;
    --verify)
        log_enterprise "INFO" "Running deployment verification only..." "verify"
        verify_deployment
        ;;
    --cleanup)
        log_enterprise "WARN" "Removing backup stack..." "cleanup"
        docker stack rm "$STACK_NAME"
        log_enterprise "SUCCESS" "Stack removed" "cleanup"
        ;;
    --status)
        log_enterprise "INFO" "Checking deployment status..." "status"
        if docker stack ls | grep -q "$STACK_NAME"; then
            docker stack services "$STACK_NAME"
        else
            log_enterprise "INFO" "Stack $STACK_NAME is not deployed" "status"
        fi
        ;;
    "")
        main
        ;;
    *)
        log_enterprise "ERROR" "Unknown option: $1" "main"
        echo "Use --help for usage information"
        exit 1
        ;;
esac