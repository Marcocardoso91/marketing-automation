#!/bin/bash

# ============================================================================
# PIPELINE COMPLETO DE DEPLOY - MACSPARK ENTERPRISE
# ============================================================================
# Pipeline DevOps completo: Preparação → Instalação → Validação → Deploy
# Automação zero-touch para ambientes de produção e homologação
# ============================================================================

set -euo pipefail

# Configurações
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m'

# Configurações padrão
ENVIRONMENT="homolog"
AUTO_CONFIRM="false"
SKIP_PREPARATION="false"
SKIP_VALIDATION="false"

# Logging
log() {
    local level=$1; shift
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    case $level in
        "INFO") echo -e "${BLUE}[INFO]${NC} [$timestamp] $*" ;;
        "SUCCESS") echo -e "${GREEN}[✓]${NC} [$timestamp] $*" ;;
        "WARN") echo -e "${YELLOW}[⚠]${NC} [$timestamp] $*" ;;
        "ERROR") echo -e "${RED}[✗]${NC} [$timestamp] $*" ;;
        "STEP") echo -e "${MAGENTA}[STEP]${NC} [$timestamp] $*" ;;
    esac
}

# Banner
show_banner() {
    echo -e "${CYAN}"
    echo "======================================================================="
    echo "               MACSPARK DEPLOY PIPELINE v1.0"
    echo "======================================================================="
    echo "🚀 Pipeline DevOps completo para deploy enterprise"
    echo "📋 Ambiente: $ENVIRONMENT"
    echo "🔄 Etapas: Preparação → Instalação → Validação → Deploy"
    echo "======================================================================="
    echo -e "${NC}"
}

# Ajuda
show_help() {
    echo "USAGE: $0 [OPTIONS]"
    echo ""
    echo "OPTIONS:"
    echo "  -e, --environment ENV    Ambiente (homolog|production) [default: homolog]"
    echo "  -y, --yes               Confirmar automaticamente (não recomendado para prod)"
    echo "  --skip-prep             Pular preparação da VPS (assumir já preparada)"
    echo "  --skip-validation       Pular validações (não recomendado)"
    echo "  -h, --help              Mostrar esta ajuda"
    echo ""
    echo "EXAMPLES:"
    echo "  $0                                    # Deploy homolog interativo"
    echo "  $0 -e production                     # Deploy produção interativo"
    echo "  $0 -e homolog -y                     # Deploy homolog automático"
    echo "  $0 --skip-prep -e homolog            # Assumir VPS já preparada"
    echo ""
}

# Parse argumentos
parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            -e|--environment)
                ENVIRONMENT="$2"
                shift 2
                ;;
            -y|--yes)
                AUTO_CONFIRM="true"
                shift
                ;;
            --skip-prep)
                SKIP_PREPARATION="true"
                shift
                ;;
            --skip-validation)
                SKIP_VALIDATION="true"
                shift
                ;;
            -h|--help)
                show_help
                exit 0
                ;;
            *)
                log "ERROR" "Argumento inválido: $1"
                show_help
                exit 1
                ;;
        esac
    done
    
    # Validar ambiente
    if [[ ! "$ENVIRONMENT" =~ ^(homolog|production)$ ]]; then
        log "ERROR" "Ambiente inválido: $ENVIRONMENT (use: homolog|production)"
        exit 1
    fi
}

# Confirmar ação
confirm_action() {
    if [ "$AUTO_CONFIRM" = "true" ]; then
        return 0
    fi
    
    local message="$1"
    echo -e "${YELLOW}⚠️  $message${NC}"
    read -p "Continuar? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        log "INFO" "Operação cancelada pelo usuário"
        exit 0
    fi
}

# Fase 1: Preparação da VPS
phase_preparation() {
    if [ "$SKIP_PREPARATION" = "true" ]; then
        log "WARN" "Preparação da VPS pulada (--skip-prep)"
        return 0
    fi
    
    log "STEP" "🔧 FASE 1: Preparação da VPS"
    
    local prep_script="$PROJECT_ROOT/scripts/setup/prepare-vps.sh"
    
    if [ ! -f "$prep_script" ]; then
        log "ERROR" "Script de preparação não encontrado: $prep_script"
        return 1
    fi
    
    log "INFO" "Executando preparação automática da VPS..."
    
    if bash "$prep_script"; then
        log "SUCCESS" "VPS preparada com sucesso"
    else
        log "ERROR" "Falha na preparação da VPS"
        return 1
    fi
}

# Fase 2: Validação Pré-Deploy
phase_pre_validation() {
    if [ "$SKIP_VALIDATION" = "true" ]; then
        log "WARN" "Validações pré-deploy puladas (--skip-validation)"
        return 0
    fi
    
    log "STEP" "🔍 FASE 2: Validação Pré-Deploy"
    
    local preflight_script="$PROJECT_ROOT/scripts/validation/preflight.sh"
    
    if [ ! -f "$preflight_script" ]; then
        log "ERROR" "Script de validação não encontrado: $preflight_script"
        return 1
    fi
    
    log "INFO" "Executando validação completa pré-deploy..."
    
    if bash "$preflight_script"; then
        log "SUCCESS" "Validação pré-deploy passou"
    else
        log "ERROR" "Falha na validação pré-deploy"
        log "INFO" "Verificar logs acima e corrigir problemas antes de prosseguir"
        return 1
    fi
}

# Fase 3: Instalação/Deploy
phase_installation() {
    log "STEP" "⚙️  FASE 3: Instalação/Deploy"
    
    local install_script
    case "$ENVIRONMENT" in
        "homolog")
            install_script="$PROJECT_ROOT/scripts/setup/install-homolog.sh"
            if [ ! -f "$install_script" ]; then
                install_script="$PROJECT_ROOT/scripts/deployment/deploy-homolog-complete.sh"
            fi
            ;;
        "production")
            install_script="$PROJECT_ROOT/scripts/setup/install-production.sh"
            if [ ! -f "$install_script" ]; then
                install_script="$PROJECT_ROOT/scripts/deployment/deploy-production-env.sh"
            fi
            ;;
    esac
    
    if [ ! -f "$install_script" ]; then
        log "ERROR" "Script de instalação não encontrado para ambiente: $ENVIRONMENT"
        return 1
    fi
    
    log "INFO" "Executando instalação para ambiente: $ENVIRONMENT"
    log "INFO" "Script: $(basename $install_script)"
    
    if bash "$install_script"; then
        log "SUCCESS" "Instalação concluída com sucesso"
    else
        log "ERROR" "Falha na instalação"
        return 1
    fi
}

# Fase 4: Validação Pós-Deploy
phase_post_validation() {
    if [ "$SKIP_VALIDATION" = "true" ]; then
        log "WARN" "Validações pós-deploy puladas (--skip-validation)"
        return 0
    fi
    
    log "STEP" "✅ FASE 4: Validação Pós-Deploy"
    
    # Aguardar serviços inicializarem
    log "INFO" "Aguardando 30s para inicialização dos serviços..."
    sleep 30
    
    # Validar deployment específico
    local validate_script="$PROJECT_ROOT/scripts/deployment/validate-enterprise-deployment.sh"
    
    if [ -f "$validate_script" ]; then
        log "INFO" "Executando validação de deployment enterprise..."
        if bash "$validate_script"; then
            log "SUCCESS" "Validação enterprise passou"
        else
            log "WARN" "Validação enterprise falhou (mas continuando...)"
        fi
    fi
    
    # Preflight novamente para validar estado final
    local preflight_script="$PROJECT_ROOT/scripts/validation/preflight.sh"
    
    if [ -f "$preflight_script" ]; then
        log "INFO" "Executando validação final do sistema..."
        if bash "$preflight_script"; then
            log "SUCCESS" "Validação final passou"
        else
            log "ERROR" "Sistema não passou na validação final"
            return 1
        fi
    fi
}

# Fase 5: Relatório Final
phase_final_report() {
    log "STEP" "📊 FASE 5: Relatório Final"
    
    echo -e "${GREEN}"
    echo "======================================================================="
    echo "                    🎉 DEPLOY CONCLUÍDO COM SUCESSO!"
    echo "======================================================================="
    echo "✅ Ambiente: $ENVIRONMENT"
    echo "✅ Todas as fases executadas com sucesso"
    echo "✅ Sistema validado e operacional"
    echo ""
    
    # Informações úteis
    echo "🔗 INFORMAÇÕES DO SISTEMA:"
    
    # Docker Swarm
    if docker info >/dev/null 2>&1; then
        echo "   Docker Swarm: $(docker info 2>/dev/null | grep 'Swarm:' | cut -d: -f2 | xargs)"
        echo "   Nodes: $(docker node ls --format 'table {{.Hostname}}' 2>/dev/null | tail -n +2 | wc -l)"
        echo "   Services: $(docker service ls 2>/dev/null | tail -n +2 | wc -l)"
    fi
    
    # Recursos
    echo "   CPU: $(nproc) cores"
    echo "   RAM: $(free -h | awk '/^Mem:/{print $2}') total, $(free -h | awk '/^Mem:/{print $7}') disponível"
    echo "   Disk: $(df -h / | awk 'NR==2{print $4}') disponível"
    
    echo ""
    echo "🚀 PRÓXIMOS PASSOS:"
    echo "   1. Acessar Traefik Dashboard (se configurado)"
    echo "   2. Verificar logs: docker service logs <service>"
    echo "   3. Monitoramento: usar Netdata/Grafana (se configurado)"
    echo "   4. Backup: configurar rotinas de backup automático"
    echo ""
    echo "📚 DOCUMENTAÇÃO:"
    echo "   - README: $PROJECT_ROOT/README.md"
    echo "   - Docs: $PROJECT_ROOT/docs/"
    echo "   - Troubleshooting: $PROJECT_ROOT/docs/troubleshooting/"
    echo "======================================================================="
    echo -e "${NC}"
    
    log "SUCCESS" "Deploy pipeline concluído com sucesso!"
}

# Main
main() {
    parse_args "$@"
    show_banner
    
    # Confirmação para produção
    if [ "$ENVIRONMENT" = "production" ]; then
        confirm_action "DEPLOY EM PRODUÇÃO! Esta operação afeta o ambiente live."
    fi
    
    log "INFO" "🚀 Iniciando pipeline de deploy completo..."
    log "INFO" "Ambiente: $ENVIRONMENT"
    log "INFO" "Auto-confirm: $AUTO_CONFIRM"
    
    # Pipeline de fases
    local phases=(
        "phase_preparation"
        "phase_pre_validation" 
        "phase_installation"
        "phase_post_validation"
        "phase_final_report"
    )
    
    local total_phases=${#phases[@]}
    local current_phase=0
    local start_time=$(date +%s)
    
    for phase in "${phases[@]}"; do
        ((current_phase++))
        local phase_start=$(date +%s)
        
        echo -e "\n${CYAN}====================================================================="
        echo "FASE $current_phase/$total_phases: $phase"
        echo "=====================================================================${NC}\n"
        
        if $phase; then
            local phase_duration=$(( $(date +%s) - phase_start ))
            log "SUCCESS" "✅ Fase concluída: $phase (${phase_duration}s)"
        else
            log "ERROR" "❌ Falha na fase: $phase"
            log "ERROR" "Deploy interrompido"
            exit 1
        fi
    done
    
    # Tempo total
    local total_duration=$(( $(date +%s) - start_time ))
    local minutes=$(( total_duration / 60 ))
    local seconds=$(( total_duration % 60 ))
    
    log "SUCCESS" "🎉 Pipeline completo em ${minutes}m${seconds}s!"
}

# Trap para limpeza
trap 'log "ERROR" "Deploy interrompido"; exit 1' INT TERM

# Executar
main "$@"