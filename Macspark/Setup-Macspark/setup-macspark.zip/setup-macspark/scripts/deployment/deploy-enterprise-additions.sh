#!/bin/bash

# ============================================================================
# DEPLOY ENTERPRISE ADDITIONS
# ============================================================================
# Deploy dos novos serviços enterprise identificados na auditoria
# ============================================================================

set -euo pipefail

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m'
BOLD='\033[1m'

# Funções de log
log_info() { echo -e "${BLUE}${BOLD}[DEPLOY]${NC} $1"; }
log_success() { echo -e "${GREEN}${BOLD}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}${BOLD}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}${BOLD}[ERROR]${NC} $1"; }

# Verificar se está no Docker Swarm
if ! docker info | grep -q "Swarm: active"; then
    log_error "Docker Swarm não está ativo. Execute 'docker swarm init' primeiro."
    exit 1
fi

log_info "🚀 Iniciando deploy dos serviços enterprise adicionais..."

# ============================================================================
# CRIAR REDES NECESSÁRIAS
# ============================================================================
create_networks() {
    log_info "📡 Criando redes necessárias..."
    
    # Redes para os novos serviços
    docker network create --driver overlay --encrypted security-internal || true
    docker network create --driver overlay --encrypted tracing-internal || true
    docker network create --driver overlay --encrypted cicd-internal || true
    docker network create --driver overlay --encrypted --internal backup-internal || true
    docker network create --driver overlay --encrypted kong-internal || true
    docker network create --driver overlay --encrypted redis-cluster || true
    
    log_success "✅ Redes criadas"
}

# ============================================================================
# CRIAR SECRETS
# ============================================================================
create_secrets() {
    log_info "🔐 Criando secrets..."
    
    # Vulnerability Scanner
    echo "clair_secure_password_$(date +%s)" | docker secret create clair_db_password - || true
    echo "defectdojo_secret_key_$(openssl rand -hex 32)" | docker secret create defectdojo_secret - || true
    echo "$(openssl rand -hex 32)" | docker secret create defectdojo_aes_key - || true
    
    # CI/CD
    echo "jenkins_admin_$(openssl rand -hex 16)" | docker secret create jenkins_admin_password - || true
    echo "ghp_your_github_token_here" | docker secret create github_token - || true
    echo "registry_password_$(date +%s)" | docker secret create docker_registry_password - || true
    echo "sonar_db_$(openssl rand -hex 16)" | docker secret create sonar_db_password - || true
    
    # Backup
    echo "minio_$(openssl rand -hex 20)" | docker secret create minio_root_password - || true
    echo "$(openssl rand -hex 32)" | docker secret create restic_password - || true
    echo "YOUR_AWS_ACCESS_KEY" | docker secret create aws_access_key - || true
    echo "YOUR_AWS_SECRET_KEY" | docker secret create aws_secret_key - || true
    echo "backup_dash_$(openssl rand -hex 16)" | docker secret create backup_dashboard_password - || true
    
    # Kong Gateway
    echo "kong_db_$(openssl rand -hex 16)" | docker secret create kong_db_password - || true
    echo "konga_db_$(openssl rand -hex 16)" | docker secret create konga_db_password - || true
    echo "$(openssl rand -hex 20)" | docker secret create kong_redis_password - || true
    echo "api_analytics_$(openssl rand -hex 16)" | docker secret create api_analytics_password - || true
    
    # Redis Cluster
    echo "redis_cluster_$(openssl rand -hex 20)" | docker secret create redis_password - || true
    
    log_success "✅ Secrets criados"
}

# ============================================================================
# CRIAR VOLUMES
# ============================================================================
create_volumes() {
    log_info "💾 Criando diretórios de volumes..."
    
    # Criar estrutura de diretórios
    sudo mkdir -p /opt/macspark/volumes/{security,jenkins,sonarqube,nexus,backup,kong,konga,redis-cluster,tracing}
    sudo mkdir -p /opt/macspark/volumes/security/{trivy/{cache,db}}
    sudo mkdir -p /opt/macspark/volumes/jenkins/{home}
    sudo mkdir -p /opt/macspark/volumes/sonarqube/{data,logs,extensions}
    sudo mkdir -p /opt/macspark/volumes/nexus/data
    sudo mkdir -p /opt/macspark/volumes/backup/{minio,restic}
    sudo mkdir -p /opt/macspark/volumes/kong/db
    sudo mkdir -p /opt/macspark/volumes/konga/db
    sudo mkdir -p /opt/macspark/volumes/redis-cluster/{master-{1,2,3},replica-{1,2,3}}
    sudo mkdir -p /opt/macspark/volumes/tracing/elasticsearch
    sudo mkdir -p /opt/macspark/backups/data
    sudo mkdir -p /opt/macspark/configs/jenkins/casc
    
    # Definir permissões
    sudo chown -R 1000:1000 /opt/macspark/volumes/jenkins
    sudo chown -R 999:999 /opt/macspark/volumes/sonarqube
    sudo chown -R 200:200 /opt/macspark/volumes/nexus
    sudo chown -R 1000:1000 /opt/macspark/volumes/tracing/elasticsearch
    
    log_success "✅ Volumes criados"
}

# ============================================================================
# CRIAR CONFIGS
# ============================================================================
create_configs() {
    log_info "⚙️ Criando configurações..."
    
    # Clair config
    cat > /tmp/clair_config.yaml << 'EOF'
http_listen_addr: ":6060"
introspection_addr: ":6061"
log_level: "info"
indexer:
  connstring: "postgresql://clair:password@clair-db:5432/clair?sslmode=disable"
  scanlock_retry: 10
  layer_scan_concurrency: 5
  migrations: true
matcher:
  connstring: "postgresql://clair:password@clair-db:5432/clair?sslmode=disable"
  max_conn_pool: 100
  migrations: true
notifier:
  connstring: "postgresql://clair:password@clair-db:5432/clair?sslmode=disable"
  migrations: true
EOF
    
    docker config create clair_config /tmp/clair_config.yaml || true
    
    # Jenkins CASC config básico
    cat > /tmp/jenkins_casc.yaml << 'EOF'
jenkins:
  systemMessage: "MacSpark Enterprise CI/CD - Configurado via Configuration as Code"
  numExecutors: 0
  mode: NORMAL
  
security:
  globalJobDslSecurityConfiguration:
    useScriptSecurity: false
    
unclassified:
  location:
    url: "https://ci.macspark.dev/"
EOF
    
    docker config create jenkins_casc_config /tmp/jenkins_casc.yaml || true
    
    # OpenTelemetry Collector config
    cat > /tmp/otel_collector_config.yaml << 'EOF'
receivers:
  otlp:
    protocols:
      grpc:
        endpoint: 0.0.0.0:4317
      http:
        endpoint: 0.0.0.0:4318
  zipkin:
    endpoint: 0.0.0.0:9411

processors:
  batch:

exporters:
  jaeger:
    endpoint: jaeger:14250
    tls:
      insecure: true

service:
  pipelines:
    traces:
      receivers: [otlp, zipkin]
      processors: [batch]
      exporters: [jaeger]
EOF
    
    docker config create otel_collector_config /tmp/otel_collector_config.yaml || true
    
    # HAProxy config para Redis
    cat > /tmp/redis_haproxy.cfg << 'EOF'
global
    daemon

defaults
    mode tcp
    timeout connect 5000ms
    timeout client 50000ms
    timeout server 50000ms

listen redis-read
    bind *:6379
    balance roundrobin
    server redis-master-1 redis-master-1:6379 check
    server redis-master-2 redis-master-2:6379 check
    server redis-master-3 redis-master-3:6379 check
EOF
    
    docker config create redis_haproxy_config /tmp/redis_haproxy.cfg || true
    
    # Backup monitor config
    cat > /tmp/backup_monitor_config.yml << 'EOF'
modules:
  http_2xx:
    prober: http
    timeout: 5s
    http:
      method: GET
EOF
    
    docker config create backup_monitor_config /tmp/backup_monitor_config.yml || true
    
    # Cleanup
    rm -f /tmp/*.yaml /tmp/*.yml /tmp/*.cfg
    
    log_success "✅ Configurações criadas"
}

# ============================================================================
# DEPLOY DOS SERVIÇOS
# ============================================================================
deploy_services() {
    log_info "🚀 Fazendo deploy dos serviços..."
    
    # 1. Vulnerability Scanner
    log_info "📊 Deploying Vulnerability Scanner..."
    docker stack deploy -c stacks/infrastructure/security/vulnerability-scanner.yml security-scanner || {
        log_warning "Falha no deploy do vulnerability scanner - continuando..."
    }
    
    # 2. Distributed Tracing
    log_info "🔍 Deploying Distributed Tracing..."
    docker stack deploy -c stacks/core/monitoring/distributed-tracing.yml tracing || {
        log_warning "Falha no deploy do tracing - continuando..."
    }
    
    # 3. CI/CD Pipeline
    log_info "🔄 Deploying CI/CD Pipeline..."
    docker stack deploy -c stacks/infrastructure/automation/jenkins-enterprise.yml cicd || {
        log_warning "Falha no deploy do CI/CD - continuando..."
    }
    
    # 4. Backup Enterprise
    log_info "💾 Deploying Enterprise Backup..."
    docker stack deploy -c stacks/infrastructure/backup/backup-enterprise-complete.yml backup-enterprise || {
        log_warning "Falha no deploy do backup enterprise - continuando..."
    }
    
    # 5. API Gateway
    log_info "🌐 Deploying Kong API Gateway..."
    docker stack deploy -c stacks/infrastructure/gateway/kong-enterprise.yml api-gateway || {
        log_warning "Falha no deploy do API Gateway - continuando..."
    }
    
    # 6. Redis Cluster
    log_info "⚡ Deploying Redis Cluster..."
    docker stack deploy -c stacks/infrastructure/performance/redis-cluster.yml redis-enterprise || {
        log_warning "Falha no deploy do Redis Cluster - continuando..."
    }
    
    log_success "✅ Deploy dos serviços concluído"
}

# ============================================================================
# VERIFICAR STATUS
# ============================================================================
check_status() {
    log_info "🔍 Verificando status dos serviços..."
    
    echo
    log_info "📋 Status dos Stacks:"
    docker stack ls
    
    echo
    log_info "🎯 Serviços em execução:"
    docker service ls | grep -E "(security-scanner|tracing|cicd|backup-enterprise|api-gateway|redis-enterprise)" || true
    
    echo
    log_info "🌐 Endpoints disponíveis:"
    echo "  • Vulnerability Scanner: https://vuln.macspark.dev"
    echo "  • Security Dashboard:    https://security.macspark.dev"
    echo "  • Distributed Tracing:   https://tracing.macspark.dev"
    echo "  • Kibana:               https://kibana.macspark.dev"
    echo "  • Jenkins CI/CD:        https://ci.macspark.dev"
    echo "  • SonarQube:            https://sonar.macspark.dev"
    echo "  • Nexus Repository:     https://nexus.macspark.dev"
    echo "  • MinIO Backup:         https://minio.macspark.dev"
    echo "  • Backup Dashboard:     https://backup-dashboard.macspark.dev"
    echo "  • Kong Admin:           https://kong-admin.macspark.dev"
    echo "  • Kong GUI:             https://kong-gui.macspark.dev"
    echo "  • API Gateway:          https://api.macspark.dev"
    echo "  • API Analytics:        https://api-analytics.macspark.dev"
    echo "  • Redis Insight:        https://redis-insight.macspark.dev"
    
    log_success "✅ Deploy enterprise concluído com sucesso!"
    log_info "📋 Execute 'docker service logs <service_name>' para verificar logs específicos"
}

# ============================================================================
# FUNÇÃO PRINCIPAL
# ============================================================================
main() {
    log_info "🎯 Iniciando deploy dos serviços enterprise adicionais..."
    
    # Perguntar confirmação
    echo -ne "${YELLOW}${BOLD}Fazer deploy dos serviços enterprise? (s/N): ${NC}"
    read -r confirm
    if [[ ! "$confirm" =~ ^[Ss]$ ]]; then
        log_info "Deploy cancelado pelo usuário"
        exit 0
    fi
    
    create_networks
    create_secrets
    create_volumes
    create_configs
    deploy_services
    
    sleep 10  # Aguardar inicialização
    
    check_status
    
    echo
    log_success "🎉 Deploy enterprise completo!"
    log_info "⏰ Aguarde alguns minutos para todos os serviços estarem totalmente operacionais"
    log_info "🔍 Use 'docker stack ps <stack_name>' para monitorar o progresso"
}

# Executar script
main "$@"