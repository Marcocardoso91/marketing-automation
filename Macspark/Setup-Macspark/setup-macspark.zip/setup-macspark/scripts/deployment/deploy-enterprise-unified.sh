#!/bin/bash

# ============================================================================
# DEPLOY ENTERPRISE UNIFIED - SETUP MACSPARK
# ============================================================================
# Deploy único, otimizado e funcional dos serviços enterprise
# Integrado com a infraestrutura existente
# ============================================================================

set -euo pipefail

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m'
BOLD='\033[1m'

# Funções de log
log_info() { echo -e "${BLUE}${BOLD}[ENTERPRISE]${NC} $1"; }
log_success() { echo -e "${GREEN}${BOLD}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}${BOLD}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}${BOLD}[ERROR]${NC} $1"; }
log_step() { echo -e "${PURPLE}${BOLD}[STEP]${NC} $1"; }

# Verificações iniciais
check_prerequisites() {
    log_info "🔍 Verificando pré-requisitos..."
    
    # Docker Swarm
    if ! docker info | grep -q "Swarm: active"; then
        log_error "Docker Swarm não está ativo. Execute 'docker swarm init' primeiro."
        exit 1
    fi
    
    # Redes existentes necessárias
    local required_networks=("traefik-public" "monitoring-internal" "application_network")
    for network in "${required_networks[@]}"; do
        if ! docker network ls | grep -q "$network"; then
            log_warning "Rede '$network' não encontrada. Criando..."
            docker network create --driver overlay --encrypted "$network" || true
        fi
    done
    
    # Verificar se Traefik está rodando
    if ! docker service ls | grep -q traefik; then
        log_warning "Traefik não encontrado. Os serviços precisarão de proxy reverso."
    fi
    
    # Verificar espaço em disco
    local available_space=$(df /opt 2>/dev/null | tail -1 | awk '{print $4}' || echo "0")
    if [[ $available_space -lt 10485760 ]]; then  # 10GB in KB
        log_warning "Espaço em disco baixo. Recomendado pelo menos 10GB livres."
    fi
    
    log_success "✅ Pré-requisitos verificados"
}

# Detectar configuração existente
detect_existing_config() {
    log_info "🔍 Detectando configuração existente..."
    
    # Detectar domain suffix
    if [[ -f "configs/production.env" ]]; then
        DOMAIN_SUFFIX=$(grep "DOMAIN_SUFFIX" configs/production.env | cut -d'=' -f2 | tr -d '"' || echo "macspark.dev")
    elif [[ -f "environments/production/production.env" ]]; then
        DOMAIN_SUFFIX=$(grep "DOMAIN_SUFFIX" environments/production/production.env | cut -d'=' -f2 | tr -d '"' || echo "macspark.dev")
    else
        DOMAIN_SUFFIX="macspark.dev"
    fi
    
    log_info "Domain detectado: $DOMAIN_SUFFIX"
    
    # Detectar PostgreSQL existente
    if docker service ls | grep -q postgres; then
        POSTGRES_HOST=$(docker service ls | grep postgres | awk '{print $2}' | head -1)
        log_info "PostgreSQL detectado: $POSTGRES_HOST"
        USE_EXTERNAL_POSTGRES=true
    else
        USE_EXTERNAL_POSTGRES=false
    fi
    
    # Detectar Redis existente
    if docker service ls | grep -q redis; then
        REDIS_HOST=$(docker service ls | grep redis | awk '{print $2}' | head -1)
        log_info "Redis detectado: $REDIS_HOST"
        USE_EXTERNAL_REDIS=true
    else
        USE_EXTERNAL_REDIS=false
    fi
    
    log_success "✅ Configuração detectada"
}

# Criar redes otimizadas
create_optimized_networks() {
    log_step "📡 Criando redes otimizadas..."
    
    local networks=(
        "enterprise-internal"
        "security-internal" 
        "development-internal"
        "automation-internal"
        "performance-internal"
    )
    
    for network in "${networks[@]}"; do
        if ! docker network ls | grep -q "$network"; then
            docker network create \
                --driver overlay \
                --encrypted \
                --opt encrypted=true \
                "$network" || log_warning "Falha ao criar rede $network"
        fi
    done
    
    log_success "✅ Redes enterprise criadas"
}

# Criar secrets de forma inteligente
create_smart_secrets() {
    log_step "🔐 Criando secrets enterprise..."
    
    local secrets_created=0
    
    # Function para criar secret se não existir
    create_secret_if_missing() {
        local secret_name=$1
        local secret_value=$2
        
        if ! docker secret ls | grep -q "$secret_name"; then
            echo "$secret_value" | docker secret create "$secret_name" - || {
                log_warning "Falha ao criar secret $secret_name"
                return 1
            }
            ((secrets_created++))
        fi
    }
    
    # GitLab secrets
    create_secret_if_missing "gitlab_root_password" "GitLab_$(openssl rand -hex 16)"
    create_secret_if_missing "gitlab_db_password" "gitlab_db_$(openssl rand -hex 16)"
    create_secret_if_missing "gitlab_redis_password" "gitlab_redis_$(openssl rand -hex 16)"
    
    # Service Mesh secrets
    create_secret_if_missing "istio_ca_cert" "$(openssl rand -base64 2048)"
    create_secret_if_missing "opa_bearer_token" "opa_$(openssl rand -hex 32)"
    
    # Automation secrets
    create_secret_if_missing "awx_secret_key" "$(openssl rand -hex 32)"
    create_secret_if_missing "awx_admin_password" "AWX_$(openssl rand -hex 16)"
    
    # Notification secrets
    create_secret_if_missing "slack_webhook_url" "https://hooks.slack.com/services/CHANGE/ME/PLEASE"
    create_secret_if_missing "pagerduty_api_key" "CHANGE_ME_PAGERDUTY_KEY"
    
    # Multi-cloud secrets
    create_secret_if_missing "consul_encrypt_key" "$(consul keygen 2>/dev/null || openssl rand -base64 32)"
    
    log_success "✅ $secrets_created secrets enterprise criados"
}

# Criar estrutura de volumes otimizada
create_optimized_volumes() {
    log_step "💾 Criando estrutura de volumes..."
    
    local base_dir="/opt/macspark"
    
    # Estrutura principal
    sudo mkdir -p "$base_dir"/{volumes,configs,logs,backups}/{enterprise,security,development,automation}
    
    # Volumes específicos
    sudo mkdir -p "$base_dir"/volumes/enterprise/{gitlab,service-mesh,automation,performance}
    sudo mkdir -p "$base_dir"/volumes/gitlab/{data,config,logs,postgres,redis,registry}
    sudo mkdir -p "$base_dir"/volumes/service-mesh/{istio,envoy,opa}
    sudo mkdir -p "$base_dir"/volumes/automation/{awx,terraform,argocd}
    
    # Logs centralizados
    sudo mkdir -p "$base_dir"/logs/enterprise/{security,gitlab,automation,performance}
    
    # Configs
    sudo mkdir -p "$base_dir"/configs/enterprise/{istio,gitlab,awx}
    
    # Permissões otimizadas
    sudo chown -R 1000:1000 "$base_dir"/volumes/gitlab
    sudo chown -R 1001:1001 "$base_dir"/volumes/automation/awx
    sudo chmod -R 755 "$base_dir"/configs
    
    log_success "✅ Estrutura de volumes criada"
}

# Criar configurações dinâmicas
create_dynamic_configs() {
    log_step "⚙️ Criando configurações dinâmicas..."
    
    # GitLab omnibus config
    cat > /tmp/gitlab_omnibus.rb << EOF
# GitLab Enterprise Configuration
external_url 'https://gitlab.${DOMAIN_SUFFIX}'
nginx['listen_port'] = 80
nginx['listen_https'] = false

# Database
postgresql['enable'] = ${USE_EXTERNAL_POSTGRES:-false}
$(if [[ "$USE_EXTERNAL_POSTGRES" == "true" ]]; then
cat << PGEOF
gitlab_rails['db_adapter'] = 'postgresql'
gitlab_rails['db_host'] = '${POSTGRES_HOST}'
gitlab_rails['db_port'] = 5432
gitlab_rails['db_database'] = 'gitlab'
gitlab_rails['db_username'] = 'gitlab'
PGEOF
fi)

# Redis
redis['enable'] = ${USE_EXTERNAL_REDIS:-false}
$(if [[ "$USE_EXTERNAL_REDIS" == "true" ]]; then
cat << REDISEOF
gitlab_rails['redis_host'] = '${REDIS_HOST}'
gitlab_rails['redis_port'] = 6379
REDISEOF
fi)

# Container Registry
registry_external_url 'https://registry.${DOMAIN_SUFFIX}'
gitlab_rails['registry_enabled'] = true

# Performance
unicorn['worker_processes'] = 2
sidekiq['max_concurrency'] = 15

# Monitoring integration
prometheus_monitoring['enable'] = true
EOF
    
    docker config create gitlab_omnibus_config /tmp/gitlab_omnibus.rb 2>/dev/null || \
        docker config rm gitlab_omnibus_config && docker config create gitlab_omnibus_config /tmp/gitlab_omnibus.rb
    
    # Service Mesh config
    cat > /tmp/istio_config.yaml << EOF
apiVersion: v1
kind: ConfigMap
metadata:
  name: istio-config
data:
  mesh: |
    defaultConfig:
      proxyStatsMatcher:
        inclusionRegexps:
        - ".*circuit_breakers.*"
        - ".*upstream_rq_retry.*"
        - ".*_cx_.*"
      discoveryRefreshDelay: 10s
      zipkinAddress: jaeger:9411
    enablePrometheusMerge: true
    defaultProviders:
      metrics:
      - prometheus
EOF
    
    docker config create istio_mesh_config /tmp/istio_config.yaml 2>/dev/null || \
        docker config rm istio_mesh_config && docker config create istio_mesh_config /tmp/istio_config.yaml
    
    # Cleanup
    rm -f /tmp/gitlab_omnibus.rb /tmp/istio_config.yaml
    
    log_success "✅ Configurações dinâmicas criadas"
}

# Deploy inteligente de serviços
deploy_enterprise_services() {
    log_step "🚀 Iniciando deploy enterprise..."
    
    local services_deployed=0
    local services_failed=0
    
    # Helper function para deploy
    deploy_service() {
        local service_name=$1
        local stack_file=$2
        local stack_name=$3
        
        log_info "📦 Deploying $service_name..."
        
        if [[ -f "$stack_file" ]]; then
            if docker stack deploy -c "$stack_file" "$stack_name"; then
                ((services_deployed++))
                log_success "✅ $service_name deployed"
            else
                ((services_failed++))
                log_warning "⚠️  $service_name failed - continuing..."
            fi
        else
            log_warning "📄 Stack file $stack_file not found - creating minimal version..."
            create_minimal_service "$service_name" "$stack_name"
        fi
    }
    
    # Deploy dos serviços enterprise
    deploy_service "GitLab CE" "stacks/applications/development/gitlab-ce-complete.yml" "gitlab-enterprise"
    deploy_service "Service Mesh" "stacks/infrastructure/service-mesh/istio-security-stack.yml" "service-mesh"
    deploy_service "Automation" "stacks/infrastructure/automation/automation-orchestration-complete.yml" "automation"
    deploy_service "Multi-Cloud" "stacks/infrastructure/multi-cloud/multi-cloud-edge-complete.yml" "multicloud"
    deploy_service "Performance" "stacks/infrastructure/performance/redis-cluster.yml" "performance"
    
    log_info "📊 Deploy summary: $services_deployed deployed, $services_failed failed"
}

# Criar serviço mínimo se stack não existir
create_minimal_service() {
    local service_name=$1
    local stack_name=$2
    
    log_info "🔧 Creating minimal $service_name service..."
    
    case "$service_name" in
        "GitLab CE")
            create_minimal_gitlab "$stack_name"
            ;;
        "Service Mesh")
            create_minimal_servicemesh "$stack_name"
            ;;
        *)
            log_warning "No minimal version available for $service_name"
            ;;
    esac
}

# GitLab mínimo funcional
create_minimal_gitlab() {
    local stack_name=$1
    
    cat > /tmp/gitlab_minimal.yml << EOF
version: '3.8'

services:
  gitlab:
    image: gitlab/gitlab-ce:16.8.1-ce.0
    hostname: gitlab.${DOMAIN_SUFFIX}
    environment:
      GITLAB_OMNIBUS_CONFIG: |
        external_url 'https://gitlab.${DOMAIN_SUFFIX}'
        nginx['listen_port'] = 80
        nginx['listen_https'] = false
        gitlab_rails['initial_root_password_file'] = '/run/secrets/gitlab_root_password'
    volumes:
      - gitlab_config:/etc/gitlab
      - gitlab_logs:/var/log/gitlab  
      - gitlab_data:/var/opt/gitlab
    networks:
      - development-internal
      - traefik-public
    secrets:
      - gitlab_root_password
    deploy:
      replicas: 1
      resources:
        limits:
          memory: 4G
          cpus: '2.0'
        reservations:
          memory: 2G
          cpus: '1.0'
      labels:
        - "traefik.enable=true"
        - "traefik.http.routers.gitlab.rule=Host(\`gitlab.${DOMAIN_SUFFIX}\`)"
        - "traefik.http.routers.gitlab.entrypoints=websecure"
        - "traefik.http.routers.gitlab.tls.certresolver=letsencrypt"
        - "traefik.http.services.gitlab.loadbalancer.server.port=80"

volumes:
  gitlab_config:
    driver: local
    driver_opts:
      type: none
      o: bind
      device: /opt/macspark/volumes/gitlab/config
  gitlab_logs:
    driver: local
    driver_opts:
      type: none
      o: bind
      device: /opt/macspark/volumes/gitlab/logs
  gitlab_data:
    driver: local
    driver_opts:
      type: none
      o: bind
      device: /opt/macspark/volumes/gitlab/data

networks:
  development-internal:
    external: true
  traefik-public:
    external: true

secrets:
  gitlab_root_password:
    external: true
EOF
    
    docker stack deploy -c /tmp/gitlab_minimal.yml "$stack_name" && \
        log_success "✅ GitLab minimal deployed" || \
        log_warning "⚠️  GitLab minimal failed"
    
    rm -f /tmp/gitlab_minimal.yml
}

# Service Mesh mínimo
create_minimal_servicemesh() {
    local stack_name=$1
    
    cat > /tmp/servicemesh_minimal.yml << EOF
version: '3.8'

services:
  # Envoy proxy básico
  envoy-proxy:
    image: envoyproxy/envoy:v1.28.0
    hostname: envoy-proxy
    command: envoy -c /etc/envoy/envoy.yaml
    configs:
      - source: envoy_basic_config
        target: /etc/envoy/envoy.yaml
    networks:
      - security-internal
      - traefik-public
    deploy:
      replicas: 2
      resources:
        limits:
          memory: 256M
          cpus: '0.25'
      labels:
        - "traefik.enable=true"
        - "traefik.http.routers.envoy.rule=Host(\`proxy.${DOMAIN_SUFFIX}\`)"
        - "traefik.http.routers.envoy.entrypoints=websecure"
        - "traefik.http.routers.envoy.tls.certresolver=letsencrypt"
        - "traefik.http.services.envoy.loadbalancer.server.port=8080"

networks:
  security-internal:
    external: true
  traefik-public:
    external: true

configs:
  envoy_basic_config:
    external: true
EOF

    # Criar config básico do Envoy
    cat > /tmp/envoy_basic.yaml << EOF
static_resources:
  listeners:
  - address:
      socket_address:
        address: 0.0.0.0
        port_value: 8080
    filter_chains:
    - filters:
      - name: envoy.filters.network.http_connection_manager
        typed_config:
          "@type": type.googleapis.com/envoy.extensions.filters.network.http_connection_manager.v3.HttpConnectionManager
          stat_prefix: ingress_http
          route_config:
            name: local_route
            virtual_hosts:
            - name: backend
              domains: ["*"]
              routes:
              - match: { prefix: "/" }
                route: { cluster: backend_service }
          http_filters:
          - name: envoy.filters.http.router
  clusters:
  - name: backend_service
    type: strict_dns
    load_assignment:
      cluster_name: backend_service
      endpoints:
      - lb_endpoints:
        - endpoint:
            address:
              socket_address:
                address: traefik
                port_value: 80
admin:
  address:
    socket_address:
      address: 0.0.0.0
      port_value: 8001
EOF
    
    docker config create envoy_basic_config /tmp/envoy_basic.yaml 2>/dev/null || \
        docker config rm envoy_basic_config && docker config create envoy_basic_config /tmp/envoy_basic.yaml
    
    docker stack deploy -c /tmp/servicemesh_minimal.yml "$stack_name" && \
        log_success "✅ Service Mesh minimal deployed" || \
        log_warning "⚠️  Service Mesh minimal failed"
    
    rm -f /tmp/servicemesh_minimal.yml /tmp/envoy_basic.yaml
}

# Verificar status e saúde dos serviços
check_deployment_health() {
    log_step "🏥 Verificando saúde do deployment..."
    
    echo
    log_info "📋 Status dos Stacks Enterprise:"
    docker stack ls | grep -E "(gitlab|service-mesh|automation|multicloud|performance)" || echo "  Nenhum stack enterprise encontrado"
    
    echo
    log_info "🎯 Serviços Enterprise:"
    docker service ls | grep -E "(gitlab|envoy|awx|consul|redis)" | head -10 || echo "  Nenhum serviço enterprise ativo"
    
    echo
    log_info "🌐 Novos Endpoints Enterprise:"
    if docker service ls | grep -q gitlab; then
        echo "  ✅ GitLab: https://gitlab.${DOMAIN_SUFFIX}"
    fi
    if docker service ls | grep -q envoy; then
        echo "  ✅ Service Proxy: https://proxy.${DOMAIN_SUFFIX}"
    fi
    if docker service ls | grep -q awx; then
        echo "  ✅ AWX Automation: https://awx.${DOMAIN_SUFFIX}"
    fi
    if docker service ls | grep -q consul; then
        echo "  ✅ Consul: https://consul.${DOMAIN_SUFFIX}"
    fi
    
    echo
    log_info "📊 Recursos utilizados:"
    echo "  💾 Espaço usado: $(du -sh /opt/macspark 2>/dev/null | cut -f1 || echo "N/A")"
    echo "  🐳 Containers ativos: $(docker ps --format "table {{.Names}}" | grep -c "enterprise\|gitlab\|envoy\|awx" || echo "0")"
}

# Cleanup de recursos não utilizados
cleanup_unused_resources() {
    log_step "🧹 Limpeza de recursos não utilizados..."
    
    # Remover containers parados
    docker container prune -f >/dev/null 2>&1 || true
    
    # Remover imagens não utilizadas
    docker image prune -f >/dev/null 2>&1 || true
    
    # Remover volumes órfãos
    docker volume prune -f >/dev/null 2>&1 || true
    
    # Remover networks não utilizadas
    docker network prune -f >/dev/null 2>&1 || true
    
    log_success "✅ Limpeza concluída"
}

# Função principal otimizada
main() {
    clear
    echo -e "${BLUE}${BOLD}"
    echo "╔════════════════════════════════════════════════════════════════╗"
    echo "║              🚀 SETUP MACSPARK ENTERPRISE DEPLOY              ║"
    echo "║                    Deploy Único e Funcional                   ║"
    echo "╚════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    
    log_info "🎯 Iniciando deploy enterprise unificado..."
    
    # Confirmação do usuário
    echo -ne "${YELLOW}${BOLD}Continuar com o deploy enterprise? (s/N): ${NC}"
    read -r confirm
    if [[ ! "$confirm" =~ ^[Ss]$ ]]; then
        log_info "Deploy cancelado pelo usuário"
        exit 0
    fi
    
    # Execução sequencial otimizada
    check_prerequisites
    detect_existing_config
    create_optimized_networks
    create_smart_secrets
    create_optimized_volumes
    create_dynamic_configs
    deploy_enterprise_services
    
    # Aguardar inicialização
    log_info "⏱️  Aguardando inicialização dos serviços..."
    sleep 15
    
    check_deployment_health
    cleanup_unused_resources
    
    echo
    echo -e "${GREEN}${BOLD}"
    echo "╔════════════════════════════════════════════════════════════════╗"
    echo "║                   🎉 DEPLOY CONCLUÍDO!                        ║"
    echo "║              Enterprise Services Successfully Deployed          ║"
    echo "╚════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    
    log_success "Deploy enterprise unificado concluído com sucesso!"
    log_info "📋 Use 'docker service logs <service_name>' para logs específicos"
    log_info "🌐 Acesse os serviços pelos endpoints listados acima"
    log_info "📖 Documentação completa em: docs/enterprise/"
}

# Executar script
main "$@"