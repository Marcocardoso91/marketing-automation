#!/bin/bash

# ================================================================================
# Deploy Completo Ambiente Homolog - MacSpark Enterprise
# Baseado nas configurações da VPS atual adaptadas para homolog
# ================================================================================

set -e

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging
LOG_FILE="/var/log/macspark-deploy-homolog.log"
exec 1> >(tee -a "$LOG_FILE")
exec 2> >(tee -a "$LOG_FILE" >&2)

echo -e "${BLUE}=================================================================================${NC}"
echo -e "${BLUE}🚀 DEPLOY HOMOLOG MACSPARK ENTERPRISE - $(date)${NC}"
echo -e "${BLUE}=================================================================================${NC}"

# Verificações iniciais
echo -e "\n${YELLOW}📋 Verificações iniciais...${NC}"

# Verificar se é Docker Swarm
if ! docker info | grep -q "Swarm: active"; then
    echo -e "${RED}❌ Docker Swarm não está ativo. Inicializando...${NC}"
    docker swarm init --advertise-addr $(hostname -I | awk '{print $1}')
fi

# Verificar se diretório existe
if [ ! -d "/home/marcocardoso/Setup-Macspark" ]; then
    echo -e "${RED}❌ Diretório Setup-Macspark não encontrado!${NC}"
    exit 1
fi

cd /home/marcocardoso/Setup-Macspark

# Função para criar networks
create_networks() {
    echo -e "\n${YELLOW}🌐 Criando networks Docker...${NC}"
    
    networks=(
        "traefik-public"
        "internal"
        "database"
        "cache" 
        "n8n-network"
        "evolution-network"
        "monitoring"
    )
    
    for network in "${networks[@]}"; do
        if ! docker network ls | grep -q "$network"; then
            echo -e "${GREEN}📡 Criando network: $network${NC}"
            docker network create --driver overlay --attachable "$network"
        else
            echo -e "${BLUE}✅ Network $network já existe${NC}"
        fi
    done
}

# Função para criar secrets
create_secrets() {
    echo -e "\n${YELLOW}🔐 Criando secrets Docker...${NC}"
    
    # Gerar senhas seguras se não existirem
    if ! docker secret ls | grep -q "db_password"; then
        echo "$(openssl rand -base64 32)" | docker secret create db_password -
        echo -e "${GREEN}✅ Secret db_password criado${NC}"
    fi
    
    if ! docker secret ls | grep -q "n8n_db_password"; then
        echo "$(openssl rand -base64 32)" | docker secret create n8n_db_password -
        echo -e "${GREEN}✅ Secret n8n_db_password criado${NC}"
    fi
    
    if ! docker secret ls | grep -q "evolution_db_password"; then
        echo "$(openssl rand -base64 32)" | docker secret create evolution_db_password -
        echo -e "${GREEN}✅ Secret evolution_db_password criado${NC}"
    fi
    
    if ! docker secret ls | grep -q "redis_password"; then
        echo "$(openssl rand -base64 32)" | docker secret create redis_password -
        echo -e "${GREEN}✅ Secret redis_password criado${NC}"
    fi
    
    if ! docker secret ls | grep -q "evolution_redis_password"; then
        echo "$(openssl rand -base64 32)" | docker secret create evolution_redis_password -
        echo -e "${GREEN}✅ Secret evolution_redis_password criado${NC}"
    fi
    
    if ! docker secret ls | grep -q "redis_web_password"; then
        echo "$(openssl rand -base64 32)" | docker secret create redis_web_password -
        echo -e "${GREEN}✅ Secret redis_web_password criado${NC}"
    fi
}

# Função para fazer deploy dos stacks
deploy_stacks() {
    echo -e "\n${YELLOW}🚀 Fazendo deploy dos stacks...${NC}"
    
    # 1. Traefik (Proxy Reverso)
    echo -e "\n${GREEN}1️⃣ Deployando Traefik...${NC}"
    if [ -f "stacks/core/traefik/traefik-homolog.yml" ]; then
        docker stack deploy -c stacks/core/traefik/traefik-homolog.yml traefik-homolog
        echo -e "${GREEN}✅ Traefik deployado${NC}"
        
        # Aguardar Traefik estar pronto
        echo -e "${BLUE}⏳ Aguardando Traefik ficar pronto (60s)...${NC}"
        sleep 60
    else
        echo -e "${RED}❌ Arquivo traefik-homolog.yml não encontrado!${NC}"
        exit 1
    fi
    
    # 2. Redis (Cache)
    echo -e "\n${GREEN}2️⃣ Deployando Redis...${NC}"
    if [ -f "stacks/core/database/redis-homolog.yml" ]; then
        docker stack deploy -c stacks/core/database/redis-homolog.yml redis-homolog
        echo -e "${GREEN}✅ Redis deployado${NC}"
        
        # Aguardar Redis estar pronto
        echo -e "${BLUE}⏳ Aguardando Redis ficar pronto (30s)...${NC}"
        sleep 30
    else
        echo -e "${RED}❌ Arquivo redis-homolog.yml não encontrado!${NC}"
        exit 1
    fi
    
    # 3. PostgreSQL (Databases)
    echo -e "\n${GREEN}3️⃣ Deployando PostgreSQL...${NC}"
    if [ -f "stacks/core/database/postgresql-homolog.yml" ]; then
        docker stack deploy -c stacks/core/database/postgresql-homolog.yml postgresql-homolog
        echo -e "${GREEN}✅ PostgreSQL deployado${NC}"
        
        # Aguardar PostgreSQL estar pronto
        echo -e "${BLUE}⏳ Aguardando PostgreSQL ficar pronto (90s)...${NC}"
        sleep 90
    else
        echo -e "${RED}❌ Arquivo postgresql-homolog.yml não encontrado!${NC}"
        exit 1
    fi
    
    # 4. N8N (Automação)
    echo -e "\n${GREEN}4️⃣ Deployando N8N...${NC}"
    if [ -f "stacks/applications/productivity/n8n-homolog.yml" ]; then
        docker stack deploy -c stacks/applications/productivity/n8n-homolog.yml n8n-homolog
        echo -e "${GREEN}✅ N8N deployado${NC}"
        
        # Aguardar N8N estar pronto
        echo -e "${BLUE}⏳ Aguardando N8N ficar pronto (60s)...${NC}"
        sleep 60
    else
        echo -e "${RED}❌ Arquivo n8n-homolog.yml não encontrado!${NC}"
        exit 1
    fi
}

# Função para verificar status
check_status() {
    echo -e "\n${YELLOW}📊 Verificando status dos serviços...${NC}"
    
    echo -e "\n${BLUE}🐳 Docker Stacks:${NC}"
    docker stack ls
    
    echo -e "\n${BLUE}🔧 Serviços ativos:${NC}"
    docker service ls --format "table {{.Name}}\t{{.Replicas}}\t{{.Image}}"
    
    echo -e "\n${BLUE}🌐 Networks:${NC}"
    docker network ls --format "table {{.Name}}\t{{.Driver}}\t{{.Scope}}"
    
    echo -e "\n${BLUE}💾 Volumes:${NC}"
    docker volume ls --format "table {{.Name}}\t{{.Driver}}"
    
    echo -e "\n${BLUE}🔐 Secrets:${NC}"
    docker secret ls --format "table {{.Name}}\t{{.CreatedAt}}"
}

# Função para testar endpoints
test_endpoints() {
    echo -e "\n${YELLOW}🧪 Testando endpoints principais...${NC}"
    
    # Aguardar DNS resolver
    sleep 30
    
    endpoints=(
        "https://traefik-homolog.macspark.dev"
        "https://n8n-homolog.macspark.dev" 
        "https://redis-homolog.macspark.dev"
    )
    
    for endpoint in "${endpoints[@]}"; do
        echo -e "${BLUE}🔍 Testando: $endpoint${NC}"
        if curl -k -s -o /dev/null -w "%{http_code}" "$endpoint" | grep -q "200\|401\|403"; then
            echo -e "${GREEN}✅ $endpoint - OK${NC}"
        else
            echo -e "${YELLOW}⚠️  $endpoint - Pode estar ainda iniciando${NC}"
        fi
    done
}

# Função principal
main() {
    echo -e "\n${YELLOW}🎯 Iniciando deploy do ambiente homolog...${NC}"
    
    create_networks
    create_secrets
    deploy_stacks
    
    echo -e "\n${GREEN}✅ Deploy básico concluído! Verificando status...${NC}"
    check_status
    test_endpoints
    
    echo -e "\n${BLUE}=================================================================================${NC}"
    echo -e "${GREEN}🎉 DEPLOY HOMOLOG CONCLUÍDO COM SUCESSO!${NC}"
    echo -e "${BLUE}=================================================================================${NC}"
    
    echo -e "\n${YELLOW}📋 Endpoints disponíveis:${NC}"
    echo -e "${GREEN}🌍 Traefik Dashboard: https://traefik-homolog.macspark.dev${NC}"
    echo -e "${GREEN}🔄 N8N Workflows: https://n8n-homolog.macspark.dev${NC}"
    echo -e "${GREEN}🔴 Redis Commander: https://redis-homolog.macspark.dev${NC}"
    
    echo -e "\n${YELLOW}🔐 Credenciais padrão:${NC}"
    echo -e "${BLUE}👤 Usuário: admin${NC}"
    echo -e "${BLUE}🔑 Senha: admin123${NC}"
    
    echo -e "\n${YELLOW}📝 Logs salvos em: $LOG_FILE${NC}"
    echo -e "\n${GREEN}✨ Ambiente homolog pronto para uso!${NC}"
}

# Executar função principal
main "$@"