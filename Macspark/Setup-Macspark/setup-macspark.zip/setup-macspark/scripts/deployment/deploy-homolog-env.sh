#!/bin/bash
# ============================================================================
# HOMOLOG DEPLOYMENT SCRIPT - DOCKER SWARM
# ============================================================================

set -euo pipefail

# Configurações
ENVIRONMENT="homolog"
STACK_NAME="macspark-homolog"

# Carregar variáveis
source /opt/macspark/environments/homolog/configs/homolog.env

echo "🚀 Deploying to Homolog Environment..."

# Deploy Traefik
docker stack deploy \
    --compose-file /opt/macspark/stacks/core/traefik/traefik.yml \
    --compose-file /opt/macspark/environments/homolog/stacks/traefik-homolog-override.yml \
    ${STACK_NAME}-traefik

# Deploy Database
docker stack deploy \
    --compose-file /opt/macspark/stacks/core/database/postgres.yml \
    --compose-file /opt/macspark/environments/homolog/stacks/database-homolog-override.yml \
    ${STACK_NAME}-database

# Deploy Applications
docker stack deploy \
    --compose-file /opt/macspark/stacks/apps/n8n/n8n.yml \
    --compose-file /opt/macspark/stacks/apps/portainer/portainer.yml \
    --compose-file /opt/macspark/stacks/monitoring/prometheus-grafana.yml \
    ${STACK_NAME}-apps

# Verificar status
echo "⏳ Aguardando serviços..."
sleep 10

docker service ls --filter "name=${STACK_NAME}"

echo "✅ Deploy em homolog concluído!"
echo "🔗 Acesse: https://homolog.macspark.dev"