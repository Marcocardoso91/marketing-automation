#!/bin/bash
# ============================================================================
# PRODUCTION DEPLOYMENT SCRIPT
# ============================================================================
# Deploy com zero-downtime, health checks e rollback automático
# ============================================================================

set -euo pipefail

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configurações
ENVIRONMENT="production"
STACK_DIR="/opt/macspark/stacks"
BACKUP_DIR="/opt/macspark/backups/pre-deploy"
HEALTH_CHECK_RETRIES=30
HEALTH_CHECK_INTERVAL=10

# Função de log
log() {
    echo -e "${BLUE}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1" >&2
    exit 1
}

warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Verificar se está rodando como root
if [[ $EUID -ne 0 ]]; then
   error "Este script deve ser executado como root"
fi

# Verificar ambiente
log "Verificando ambiente de produção..."
if [[ ! -f "/opt/macspark/environments/production/configs/production.env" ]]; then
    error "Configurações de produção não encontradas"
fi

# Carregar variáveis de ambiente
source /opt/macspark/environments/production/configs/production.env

# Criar backup pré-deploy
log "Criando backup pré-deploy..."
mkdir -p "$BACKUP_DIR"
BACKUP_FILE="$BACKUP_DIR/backup-$(date +%Y%m%d-%H%M%S).tar.gz"
docker run --rm -v macspark_data:/data -v "$BACKUP_DIR":/backup alpine \
    tar czf "/backup/$(basename $BACKUP_FILE)" -C /data .
success "Backup criado: $BACKUP_FILE"

# Verificar saúde do cluster
log "Verificando saúde do Docker Swarm..."
if ! docker node ls | grep -q "Ready"; then
    error "Cluster Docker Swarm não está saudável"
fi

# Pull das novas imagens
log "Baixando novas imagens..."
for service in traefik postgres redis app; do
    docker pull "${DOCKER_REGISTRY}/${DOCKER_NAMESPACE}/${service}:${IMAGE_TAG}" || warning "Falha no pull de ${service}"
done

# Deploy com Docker Swarm
log "Iniciando deploy com Docker Swarm..."

# Deploy do stack principal
docker stack deploy \
    -c "$STACK_DIR/core/traefik/traefik-production.yml" \
    -c "$STACK_DIR/core/database/postgres-production.yml" \
    -c "$STACK_DIR/apps/macspark-app.yml" \
    macspark-prod

# Health check da nova versão
log "Verificando saúde dos novos serviços..."
for i in $(seq 1 $HEALTH_CHECK_RETRIES); do
    if docker service ls | grep "macspark-blue" | grep -q "replicated"; then
        success "Serviços blue estão rodando"
        break
    fi
    
    if [[ $i -eq $HEALTH_CHECK_RETRIES ]]; then
        error "Timeout esperando serviços blue"
    fi
    
    log "Aguardando serviços blue... ($i/$HEALTH_CHECK_RETRIES)"
    sleep $HEALTH_CHECK_INTERVAL
done

# Smoke tests
log "Executando smoke tests..."
if ! curl -f -s -o /dev/null -w "%{http_code}" https://macspark.dev/health | grep -q "200"; then
    error "Smoke test falhou - iniciando rollback"
fi

# Switch traffic (green -> blue)
log "Redirecionando tráfego para nova versão..."
docker service update --label-add version=blue traefik

# Aguardar estabilização
sleep 30

# Verificar métricas
log "Verificando métricas de produção..."
ERROR_RATE=$(curl -s http://prometheus:9090/api/v1/query?query=rate\(http_requests_total\{status=~\"5..\"\}\[5m\]\) | jq '.data.result[0].value[1]' | tr -d '"')

if (( $(echo "$ERROR_RATE > 0.01" | bc -l) )); then
    warning "Taxa de erro alta detectada: $ERROR_RATE"
    read -p "Continuar mesmo assim? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        log "Iniciando rollback..."
        ./rollback.sh
        exit 1
    fi
fi

# Remover versão antiga
log "Removendo versão antiga..."
docker stack rm macspark-green 2>/dev/null || true

# Limpeza
log "Executando limpeza pós-deploy..."
docker system prune -f

# Notificação
log "Enviando notificações..."
curl -X POST https://hooks.slack.com/services/xxx \
    -H 'Content-Type: application/json' \
    -d "{\"text\":\"✅ Deploy em produção concluído com sucesso!\"}"

success "Deploy em produção concluído com sucesso!"
log "Versão deployed: $(git rev-parse --short HEAD)"
log "Backup disponível em: $BACKUP_FILE"

# Log de auditoria
echo "$(date '+%Y-%m-%d %H:%M:%S') - Deploy production by $(whoami) - Success" >> /var/log/macspark/deployments.log