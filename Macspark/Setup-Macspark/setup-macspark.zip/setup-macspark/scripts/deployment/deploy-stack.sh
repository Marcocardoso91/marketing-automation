#!/bin/bash
# DEPLOY INDIVIDUAL DE STACKS COM VALIDAÇÃO
# Deploy inteligente com validação e rollback automático
set -euo pipefail

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configurações base
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(dirname "$SCRIPT_DIR")"
CONFIG_DIR="$BASE_DIR/configs"

# Função de ajuda
show_help() {
    echo -e "${BLUE}🚀 Deploy Individual de Stacks Macspark${NC}"
    echo ""
    echo "Uso: $0 [OPÇÕES] <stack-file> [stack-name]"
    echo ""
    echo "Opções:"
    echo "  -e, --environment ENV    Ambiente (homolog|production)"
    echo "  -v, --validate-only      Apenas validar, não fazer deploy"
    echo "  -f, --force             Forçar deploy mesmo com validações"
    echo "  -r, --rollback          Fazer rollback do último deploy"
    echo "  -h, --help              Mostrar esta ajuda"
    echo ""
    echo "Exemplos:"
    echo "  $0 stacks/ai/ollama.yml ollama"
    echo "  $0 -e production stacks/monitoring/prometheus.yml monitoring"
    echo "  $0 --validate-only stacks/apps/n8n.yml"
    echo "  $0 --rollback ollama"
    echo ""
}

# Variáveis padrão
ENVIRONMENT="production"
VALIDATE_ONLY=false
FORCE_DEPLOY=false
ROLLBACK=false
STACK_FILE=""
STACK_NAME=""

# Parse de argumentos
parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            -e|--environment)
                ENVIRONMENT="$2"
                shift 2
                ;;
            -v|--validate-only)
                VALIDATE_ONLY=true
                shift
                ;;
            -f|--force)
                FORCE_DEPLOY=true
                shift
                ;;
            -r|--rollback)
                ROLLBACK=true
                shift
                ;;
            -h|--help)
                show_help
                exit 0
                ;;
            -*)
                echo -e "${RED}❌ Opção desconhecida: $1${NC}"
                show_help
                exit 1
                ;;
            *)
                if [[ -z "$STACK_FILE" ]]; then
                    STACK_FILE="$1"
                elif [[ -z "$STACK_NAME" ]]; then
                    STACK_NAME="$1"
                else
                    echo -e "${RED}❌ Muitos argumentos${NC}"
                    show_help
                    exit 1
                fi
                shift
                ;;
        esac
    done
}

# Validar argumentos
validate_args() {
    if [[ "$ROLLBACK" == "true" ]]; then
        if [[ -z "$STACK_FILE" ]]; then
            echo -e "${RED}❌ Nome do stack é obrigatório para rollback${NC}"
            exit 1
        fi
        STACK_NAME="$STACK_FILE"
        return 0
    fi
    
    if [[ -z "$STACK_FILE" ]]; then
        echo -e "${RED}❌ Arquivo do stack é obrigatório${NC}"
        show_help
        exit 1
    fi
    
    if [[ ! -f "$STACK_FILE" ]]; then
        # Tentar encontrar o arquivo relativo ao base dir
        if [[ -f "$BASE_DIR/$STACK_FILE" ]]; then
            STACK_FILE="$BASE_DIR/$STACK_FILE"
        else
            echo -e "${RED}❌ Arquivo não encontrado: $STACK_FILE${NC}"
            exit 1
        fi
    fi
    
    if [[ -z "$STACK_NAME" ]]; then
        # Extrair nome do stack do arquivo
        STACK_NAME=$(basename "$STACK_FILE" .yml)
    fi
    
    if [[ "$ENVIRONMENT" != "homolog" && "$ENVIRONMENT" != "production" ]]; then
        echo -e "${RED}❌ Ambiente deve ser 'homolog' ou 'production'${NC}"
        exit 1
    fi
}

# Carregar configurações do ambiente
load_environment() {
    local env_file="$CONFIG_DIR/${ENVIRONMENT}.env"
    
    if [[ -f "$env_file" ]]; then
        source "$env_file"
        echo -e "${GREEN}✅ Configurações do ambiente $ENVIRONMENT carregadas${NC}"
    else
        echo -e "${YELLOW}⚠️  Arquivo de configuração não encontrado: $env_file${NC}"
    fi
}

# Validar pré-requisitos
validate_prerequisites() {
    echo -e "${BLUE}🔍 Validando pré-requisitos...${NC}"
    
    # Verificar Docker
    if ! command -v docker &> /dev/null; then
        echo -e "${RED}❌ Docker não instalado${NC}"
        exit 1
    fi
    
    # Verificar Docker Swarm
    if ! docker info | grep -q "Swarm: active"; then
        echo -e "${RED}❌ Docker Swarm não ativo${NC}"
        exit 1
    fi
    
    # Verificar sintaxe do arquivo YAML
    if ! docker-compose -f "$STACK_FILE" config &> /dev/null; then
        echo -e "${RED}❌ Arquivo YAML inválido: $STACK_FILE${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}✅ Pré-requisitos validados${NC}"
}

# Validar dependências do stack
validate_stack_dependencies() {
    echo -e "${BLUE}🔗 Validando dependências...${NC}"
    
    # Extrair redes necessárias do arquivo
    local required_networks=$(grep -o "external.*true" "$STACK_FILE" | wc -l || echo "0")
    
    if [[ $required_networks -gt 0 ]]; then
        echo -e "${YELLOW}Redes externas necessárias: $required_networks${NC}"
        
        # Verificar redes específicas comuns
        if grep -q "traefik" "$STACK_FILE"; then
            local traefik_network="traefik-public"
            if [[ "$ENVIRONMENT" == "homolog" ]]; then
                traefik_network="traefik-homolog"
            fi
            
            if ! docker network ls | grep -q "$traefik_network"; then
                echo -e "${YELLOW}⚠️  Rede $traefik_network não encontrada${NC}"
                if [[ "$FORCE_DEPLOY" != "true" ]]; then
                    read -p "Criar rede automaticamente? (y/N): " -r
                    if [[ $REPLY =~ ^[Yy]$ ]]; then
                        docker network create --driver overlay --attachable "$traefik_network"
                        echo -e "${GREEN}✅ Rede $traefik_network criada${NC}"
                    fi
                fi
            fi
        fi
    fi
}

# Fazer backup do estado atual
backup_current_state() {
    echo -e "${BLUE}💾 Fazendo backup do estado atual...${NC}"
    
    local backup_dir="/tmp/macspark-stack-backup-$(date +%Y%m%d-%H%M%S)"
    mkdir -p "$backup_dir"
    
    # Verificar se stack já existe
    if docker stack ls --format "{{.Name}}" | grep -q "^${STACK_NAME}$"; then
        echo "Stack existente detectado: $STACK_NAME" > "$backup_dir/stack-info.txt"
        docker service ls --filter label=com.docker.stack.namespace="$STACK_NAME" --format "{{.Name}} {{.Image}} {{.Replicas}}" > "$backup_dir/services.txt"
        echo "$backup_dir" > "/tmp/macspark-${STACK_NAME}-backup.txt"
        echo -e "${GREEN}✅ Backup criado em: $backup_dir${NC}"
    else
        echo -e "${YELLOW}Stack $STACK_NAME não existe - deploy inicial${NC}"
        rm -rf "$backup_dir"
    fi
}

# Fazer deploy do stack
deploy_stack() {
    echo -e "${BLUE}🚀 Deployando stack: $STACK_NAME${NC}"
    echo -e "${YELLOW}Arquivo: $STACK_FILE${NC}"
    echo -e "${YELLOW}Ambiente: $ENVIRONMENT${NC}"
    
    if [[ "$VALIDATE_ONLY" == "true" ]]; then
        echo -e "${BLUE}✅ Validação concluída - não fazendo deploy${NC}"
        return 0
    fi
    
    # Deploy do stack
    if docker stack deploy -c "$STACK_FILE" "$STACK_NAME"; then
        echo -e "${GREEN}✅ Deploy executado com sucesso${NC}"
        
        # Aguardar convergência
        echo -e "${BLUE}⏳ Aguardando convergência dos serviços...${NC}"
        sleep 15
        
        return 0
    else
        echo -e "${RED}❌ Falha no deploy${NC}"
        return 1
    fi
}

# Validar deploy
validate_deployment() {
    echo -e "${BLUE}🔍 Validando deployment...${NC}"
    
    # Verificar se serviços estão rodando
    local services=$(docker service ls --filter label=com.docker.stack.namespace="$STACK_NAME" --format "{{.Name}}")
    
    if [[ -z "$services" ]]; then
        echo -e "${RED}❌ Nenhum serviço encontrado para o stack $STACK_NAME${NC}"
        return 1
    fi
    
    echo -e "${GREEN}✅ Serviços encontrados:${NC}"
    docker service ls --filter label=com.docker.stack.namespace="$STACK_NAME" --format "table {{.Name}}\t{{.Replicas}}\t{{.Image}}"
    
    # Verificar saúde dos serviços
    local failed_services=$(docker service ls --filter label=com.docker.stack.namespace="$STACK_NAME" --format "{{.Name}} {{.Replicas}}" | grep "0/" | wc -l || echo "0")
    
    if [[ $failed_services -gt 0 ]]; then
        echo -e "${RED}❌ $failed_services serviço(s) com problemas${NC}"
        return 1
    fi
    
    echo -e "${GREEN}✅ Todos os serviços estão funcionando${NC}"
    return 0
}

# Fazer rollback
rollback_stack() {
    echo -e "${BLUE}🔄 Fazendo rollback do stack: $STACK_NAME${NC}"
    
    local backup_file="/tmp/macspark-${STACK_NAME}-backup.txt"
    
    if [[ ! -f "$backup_file" ]]; then
        echo -e "${RED}❌ Backup não encontrado para rollback${NC}"
        exit 1
    fi
    
    local backup_dir=$(cat "$backup_file")
    
    if [[ ! -d "$backup_dir" ]]; then
        echo -e "${RED}❌ Diretório de backup não encontrado: $backup_dir${NC}"
        exit 1
    fi
    
    echo -e "${YELLOW}Removendo stack atual...${NC}"
    docker stack rm "$STACK_NAME"
    
    echo -e "${YELLOW}Aguardando limpeza...${NC}"
    sleep 30
    
    echo -e "${GREEN}✅ Rollback concluído${NC}"
    echo -e "${BLUE}ℹ️  Informações do backup em: $backup_dir${NC}"
}

# Função principal
main() {
    echo -e "${BLUE}🚀 Deploy Individual de Stacks Macspark${NC}"
    
    parse_args "$@"
    validate_args
    
    if [[ "$ROLLBACK" == "true" ]]; then
        rollback_stack
        exit 0
    fi
    
    load_environment
    validate_prerequisites
    validate_stack_dependencies
    backup_current_state
    
    if ! deploy_stack; then
        echo -e "${RED}❌ Deploy falhou${NC}"
        exit 1
    fi
    
    if ! validate_deployment; then
        echo -e "${RED}❌ Validação falhou${NC}"
        
        if [[ "$FORCE_DEPLOY" != "true" ]]; then
            read -p "Fazer rollback? (y/N): " -r
            if [[ $REPLY =~ ^[Yy]$ ]]; then
                rollback_stack
            fi
        fi
        exit 1
    fi
    
    echo -e "${GREEN}🎉 Deploy concluído com sucesso!${NC}"
}

# Execução
main "$@"