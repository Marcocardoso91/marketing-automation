#!/bin/bash

# Script de Deploy do Traefik para Homologação
# Macspark Setup - Dual VPS Strategy

set -euo pipefail

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Funções de log
log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Variáveis
STACK_NAME="traefik-homolog"
STACK_FILE="/home/marcocardoso/Macspark-Setup/stacks/traefik/traefik-homolog.yml"
NETWORK_NAME="traefik-public"
VOLUME_BASE="/opt/macspark/volumes/traefik-homolog"

log_info "=== INICIANDO DEPLOY TRAEFIK HOMOLOGAÇÃO ==="

# 1. Verificar Docker Swarm
if ! docker info --format '{{.Swarm.LocalNodeState}}' | grep -q active; then
    log_warning "Docker Swarm não está ativo. Inicializando..."
    docker swarm init --advertise-addr $(hostname -I | awk '{print $1}')
    log_success "Docker Swarm inicializado"
fi

# 2. Criar rede traefik-public se não existir
if ! docker network ls | grep -q "$NETWORK_NAME"; then
    log_info "Criando rede overlay '$NETWORK_NAME'..."
    docker network create \
        --driver overlay \
        --opt encrypted=true \
        --attachable \
        "$NETWORK_NAME"
    log_success "Rede '$NETWORK_NAME' criada com criptografia"
else
    log_info "Rede '$NETWORK_NAME' já existe"
fi

# 3. Criar diretórios de volume
log_info "Preparando diretórios de volume..."
sudo mkdir -p "$VOLUME_BASE/letsencrypt"
sudo mkdir -p "$VOLUME_BASE/config"
sudo mkdir -p "$VOLUME_BASE/logs"

# Definir permissões corretas
sudo chown -R 65532:65532 "$VOLUME_BASE"
sudo chmod -R 755 "$VOLUME_BASE"

log_success "Diretórios criados em $VOLUME_BASE"

# 4. Copiar configuração dinâmica
log_info "Copiando configuração dinâmica..."
sudo cp /home/marcocardoso/Macspark-Setup/stacks/traefik/dynamic-config-homolog.yml \
    "$VOLUME_BASE/config/dynamic.yml"

log_success "Configuração dinâmica copiada"

# 5. Verificar se stack já existe e remover se necessário
if docker stack ls | grep -q "$STACK_NAME"; then
    log_warning "Stack '$STACK_NAME' já existe. Removendo para redeployar..."
    docker stack rm "$STACK_NAME"
    
    # Aguardar remoção completa
    log_info "Aguardando remoção completa..."
    while docker stack ls | grep -q "$STACK_NAME"; do
        sleep 2
    done
    sleep 5
fi

# 6. Deploy da stack
log_info "Fazendo deploy da stack '$STACK_NAME'..."
docker stack deploy -c "$STACK_FILE" "$STACK_NAME"

# 7. Aguardar serviços ficarem saudáveis
log_info "Aguardando serviços ficarem operacionais..."
sleep 10

# Verificar status dos serviços
for i in {1..30}; do
    if docker service ls --format "table {{.Name}}\t{{.Replicas}}" | grep "$STACK_NAME" | grep -q "1/1"; then
        break
    fi
    log_info "Aguardando serviços... ($i/30)"
    sleep 5
done

# 8. Verificar saúde dos serviços
log_info "=== STATUS DOS SERVIÇOS ==="
docker service ls --filter label="com.docker.stack.namespace=$STACK_NAME" \
    --format "table {{.Name}}\t{{.Replicas}}\t{{.Image}}\t{{.Ports}}"

# 9. Testes de conectividade
log_info "=== TESTANDO CONECTIVIDADE ==="

# Aguardar um pouco mais para certificados
sleep 15

# Testar HTTP redirect
log_info "Testando redirect HTTP -> HTTPS..."
if curl -s -I http://traefik-homolog.macspark.dev | grep -q "301\|302"; then
    log_success "✅ Redirect HTTP -> HTTPS funcionando"
else
    log_warning "⚠️  Redirect HTTP pode não estar funcionando ainda"
fi

# Testar HTTPS (pode falhar inicialmente devido ao certificado staging)
log_info "Testando acesso HTTPS..."
if curl -s -k -I https://traefik-homolog.macspark.dev | grep -q "200"; then
    log_success "✅ Acesso HTTPS funcionando"
else
    log_warning "⚠️  Acesso HTTPS ainda não está pronto (aguarde certificados)"
fi

# 10. Informações finais
log_info "=== INFORMAÇÕES DE ACESSO ==="
echo -e "${GREEN}Dashboard Traefik Homolog:${NC}"
echo -e "  🌐 URL: https://traefik-homolog.macspark.dev"
echo -e "  🔑 Auth: Desabilitada (ambiente de teste)"
echo -e "  📊 Status: Porta 8080 (só rede interna)"

echo -e "\n${YELLOW}Comandos úteis:${NC}"
echo -e "  docker service logs ${STACK_NAME}_traefik -f"
echo -e "  docker service ps ${STACK_NAME}_traefik"
echo -e "  curl -k https://traefik-homolog.macspark.dev/api/rawdata"

echo -e "\n${BLUE}Observações:${NC}"
echo -e "  📋 Usando Let's Encrypt STAGING (certificados de teste)"
echo -e "  🔍 Logs mais detalhados (DEBUG) habilitados"
echo -e "  ⚡ Recursos otimizados para desenvolvimento"

log_success "=== DEPLOY TRAEFIK HOMOLOGAÇÃO CONCLUÍDO ==="

# Verificar se há erros nos logs
log_info "Verificando logs por erros..."
sleep 5
ERROR_COUNT=$(docker service logs "${STACK_NAME}_traefik" 2>&1 | grep -i error | wc -l)
if [ "$ERROR_COUNT" -gt 0 ]; then
    log_warning "Encontrados $ERROR_COUNT erros nos logs. Verifique:"
    echo "docker service logs ${STACK_NAME}_traefik"
else
    log_success "Nenhum erro crítico encontrado nos logs"
fi

exit 0