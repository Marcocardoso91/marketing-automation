#!/bin/bash

# Script de Deploy do Traefik para Produção
# Macspark Setup - Dual VPS Strategy  

set -euo pipefail

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Funções de log
log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Variáveis
STACK_NAME="traefik-production"
STACK_FILE="/home/marcocardoso/Macspark-Setup/stacks/traefik/traefik-production.yml"
NETWORK_NAME="traefik-public"
VOLUME_BASE="/opt/macspark/volumes/traefik"
BACKUP_DIR="/opt/macspark/backups/traefik-$(date +%Y%m%d_%H%M%S)"

log_info "=== INICIANDO DEPLOY TRAEFIK PRODUÇÃO ==="

# Verificação de segurança - só executar em produção
read -p "⚠️  ATENÇÃO: Este é o deploy de PRODUÇÃO. Confirmar? (yes/no): " CONFIRM
if [ "$CONFIRM" != "yes" ]; then
    log_error "Deploy cancelado pelo usuário"
    exit 1
fi

# 1. Verificar Docker Swarm
if ! docker info --format '{{.Swarm.LocalNodeState}}' | grep -q active; then
    log_error "Docker Swarm não está ativo! Execute 'docker swarm init' primeiro"
    exit 1
fi

# 2. Backup de configurações existentes
if [ -d "$VOLUME_BASE" ]; then
    log_info "Fazendo backup das configurações atuais..."
    sudo mkdir -p "$BACKUP_DIR"
    sudo cp -r "$VOLUME_BASE"/* "$BACKUP_DIR"/ 2>/dev/null || true
    log_success "Backup salvo em $BACKUP_DIR"
fi

# 3. Criar rede traefik-public se não existir (com criptografia)
if ! docker network ls | grep -q "$NETWORK_NAME"; then
    log_info "Criando rede overlay criptografada '$NETWORK_NAME'..."
    docker network create \
        --driver overlay \
        --opt encrypted=true \
        --attachable \
        "$NETWORK_NAME"
    log_success "Rede '$NETWORK_NAME' criada com criptografia"
else
    log_info "Verificando criptografia da rede existente..."
    # Verificar se a rede tem criptografia habilitada
    if docker network inspect "$NETWORK_NAME" | grep -q '"Encrypted": true'; then
        log_success "Rede já existe com criptografia"
    else
        log_warning "Rede existe mas SEM criptografia. Recriar? (y/N)"
        read -r RECREATE
        if [ "$RECREATE" = "y" ] || [ "$RECREATE" = "Y" ]; then
            docker network rm "$NETWORK_NAME"
            docker network create \
                --driver overlay \
                --opt encrypted=true \
                --attachable \
                "$NETWORK_NAME"
            log_success "Rede recriada com criptografia"
        fi
    fi
fi

# 4. Criar diretórios de volume com permissões seguras
log_info "Preparando diretórios de volume com segurança enterprise..."
sudo mkdir -p "$VOLUME_BASE/letsencrypt"
sudo mkdir -p "$VOLUME_BASE/config"
sudo mkdir -p "$VOLUME_BASE/logs"
sudo mkdir -p "$VOLUME_BASE/certs"

# Permissões restritivas para produção
sudo chown -R 65532:65532 "$VOLUME_BASE"
sudo chmod -R 750 "$VOLUME_BASE"
sudo chmod 700 "$VOLUME_BASE/letsencrypt"  # Extra seguro para certificados

log_success "Diretórios criados com permissões seguras em $VOLUME_BASE"

# 5. Copiar configuração dinâmica
log_info "Copiando configuração dinâmica de produção..."
sudo cp /home/marcocardoso/Macspark-Setup/stacks/traefik/dynamic-config-production.yml \
    "$VOLUME_BASE/config/dynamic.yml"

# Permissões seguras para config
sudo chown 65532:65532 "$VOLUME_BASE/config/dynamic.yml"
sudo chmod 644 "$VOLUME_BASE/config/dynamic.yml"

log_success "Configuração dinâmica de produção copiada"

# 6. Verificar se stack já existe
if docker stack ls | grep -q "$STACK_NAME"; then
    log_warning "Stack '$STACK_NAME' já existe. Será atualizada."
    
    # Fazer backup do estado atual
    log_info "Fazendo backup do estado atual dos serviços..."
    docker service ls --format "{{.Name}}\t{{.Replicas}}\t{{.Image}}" | grep "$STACK_NAME" \
        > "$BACKUP_DIR/services-before.txt" || true
else
    log_info "Nova instalação de produção"
fi

# 7. Deploy da stack
log_info "Fazendo deploy da stack de PRODUÇÃO '$STACK_NAME'..."
docker stack deploy -c "$STACK_FILE" "$STACK_NAME"

# 8. Monitoramento detalhado do deploy
log_info "Monitorando deploy de produção..."
sleep 15

# Verificar status dos serviços com timeout mais longo
for i in {1..60}; do
    READY_SERVICES=$(docker service ls --filter label="com.docker.stack.namespace=$STACK_NAME" \
        --format "{{.Replicas}}" | grep -c "1/1" || echo "0")
    TOTAL_SERVICES=$(docker service ls --filter label="com.docker.stack.namespace=$STACK_NAME" | wc -l)
    
    if [ "$READY_SERVICES" -eq "$TOTAL_SERVICES" ] && [ "$TOTAL_SERVICES" -gt 0 ]; then
        log_success "Todos os serviços estão operacionais ($READY_SERVICES/$TOTAL_SERVICES)"
        break
    fi
    
    log_info "Serviços prontos: $READY_SERVICES/$TOTAL_SERVICES (tentativa $i/60)"
    sleep 10
done

# 9. Verificações de produção
log_info "=== VERIFICAÇÕES DE PRODUÇÃO ==="

# Status detalhado dos serviços
echo -e "\n${GREEN}Status dos Serviços:${NC}"
docker service ls --filter label="com.docker.stack.namespace=$STACK_NAME" \
    --format "table {{.Name}}\t{{.Replicas}}\t{{.Image}}\t{{.Ports}}"

# Verificar logs por erros críticos
log_info "Verificando logs por erros críticos..."
sleep 5
CRITICAL_ERRORS=$(docker service logs "${STACK_NAME}_traefik" --since 5m 2>&1 | grep -i -E "(fatal|panic|error.*cert)" | wc -l)
if [ "$CRITICAL_ERRORS" -gt 0 ]; then
    log_error "❌ Encontrados $CRITICAL_ERRORS erros críticos nos logs!"
    echo "Verificar: docker service logs ${STACK_NAME}_traefik"
else
    log_success "✅ Nenhum erro crítico encontrado nos logs"
fi

# 10. Testes de produção
log_info "=== TESTES DE PRODUÇÃO ==="

# Aguardar certificados SSL (mais tempo para produção)
log_info "Aguardando emissão de certificados SSL de produção..."
sleep 30

# Testar redirect HTTP -> HTTPS
log_info "Testando redirect HTTP -> HTTPS..."
if timeout 10 curl -s -I http://traefik.macspark.dev | grep -q "301\|302"; then
    log_success "✅ Redirect HTTP -> HTTPS funcionando"
else
    log_error "❌ Redirect HTTP -> HTTPS falhou"
fi

# Testar HTTPS
log_info "Testando acesso HTTPS seguro..."
if timeout 15 curl -s -I https://traefik.macspark.dev | grep -q "200"; then
    log_success "✅ Acesso HTTPS funcionando"
    
    # Testar certificado válido (não staging)
    if timeout 10 curl -s https://traefik.macspark.dev > /dev/null 2>&1; then
        log_success "✅ Certificado SSL válido"
    else
        log_warning "⚠️  Certificado pode estar em processo de validação"
    fi
else
    log_warning "⚠️  Acesso HTTPS ainda não está pronto (aguarde certificados de produção)"
fi

# Testar autenticação
log_info "Testando autenticação do dashboard..."
if timeout 10 curl -s -I https://traefik.macspark.dev | grep -q "401"; then
    log_success "✅ Autenticação funcionando (401 Unauthorized)"
else
    log_warning "⚠️  Verificar configuração de autenticação"
fi

# 11. Informações finais de produção
log_info "=== CONFIGURAÇÃO DE PRODUÇÃO FINALIZADA ==="
echo -e "${GREEN}🎯 Traefik Produção Operacional:${NC}"
echo -e "  🌐 Dashboard: https://traefik.macspark.dev"
echo -e "  🔐 Auth: admin / MacsparkAdmin2025!"
echo -e "  🏥 Health: https://traefik.macspark.dev/api/rawdata"
echo -e "  📊 Métricas: Porta 8080 (rede interna)"

echo -e "\n${BLUE}📋 Comandos de Produção:${NC}"
echo -e "  docker service logs ${STACK_NAME}_traefik -f"
echo -e "  docker service inspect ${STACK_NAME}_traefik"
echo -e "  docker service ps ${STACK_NAME}_traefik"

echo -e "\n${YELLOW}🔒 Recursos de Segurança:${NC}"
echo -e "  ✅ SSL/TLS Let's Encrypt Produção"
echo -e "  ✅ Headers de segurança enterprise"
echo -e "  ✅ Rate limiting configurado"
echo -e "  ✅ Rede overlay criptografada"
echo -e "  ✅ Autenticação básica obrigatória"

echo -e "\n${RED}⚠️  Backup Disponível:${NC}"
echo -e "  📁 $BACKUP_DIR"

# 12. Health check final
log_info "=== HEALTH CHECK FINAL ==="
sleep 10

HEALTH_STATUS=$(timeout 30 curl -s -k -u "admin:MacsparkAdmin2025!" \
    https://traefik.macspark.dev/api/rawdata 2>/dev/null | jq -r '.http.services | length' || echo "0")

if [ "$HEALTH_STATUS" -gt 0 ]; then
    log_success "✅ API Traefik respondendo ($HEALTH_STATUS serviços detectados)"
else
    log_warning "⚠️  API Traefik ainda não está totalmente operacional"
fi

log_success "=== DEPLOY TRAEFIK PRODUÇÃO CONCLUÍDO ==="
echo -e "\n${GREEN}🚀 Traefik Enterprise está OPERACIONAL!${NC}"

exit 0