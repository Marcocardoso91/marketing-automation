#!/bin/bash

# ============================================================================
# FEATURE FLAGS SYSTEM - MACSPARK SETUP
# ============================================================================
# Sistema de feature flags para controle de rollout gradual
# Permite ativar/desativar funcionalidades sem deploy
# ============================================================================

set -euo pipefail

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configurações
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
FLAGS_DIR="$PROJECT_ROOT/configs/feature-flags"
FLAGS_FILE="$FLAGS_DIR/flags.yml"

# Logging
log() {
    local level=$1; shift
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    case $level in
        "INFO") echo -e "${BLUE}[INFO]${NC} [$timestamp] $*" ;;
        "SUCCESS") echo -e "${GREEN}[SUCCESS]${NC} [$timestamp] $*" ;;
        "ERROR") echo -e "${RED}[ERROR]${NC} [$timestamp] $*" ;;
        "WARN") echo -e "${YELLOW}[WARN]${NC} [$timestamp] $*" ;;
    esac
}

# Inicializar sistema de feature flags
init_feature_flags() {
    log "INFO" "🚀 Inicializando sistema de feature flags..."
    
    # Criar estrutura de diretórios
    mkdir -p "$FLAGS_DIR"/{environments,templates,history}
    
    # Criar arquivo principal de flags se não existir
    if [[ ! -f "$FLAGS_FILE" ]]; then
        create_default_flags
    fi
    
    # Criar template de flag
    create_flag_template
    
    log "SUCCESS" "Sistema de feature flags inicializado"
}

# Criar flags padrão
create_default_flags() {
    cat > "$FLAGS_FILE" << 'EOF'
# ============================================================================
# FEATURE FLAGS - MACSPARK SETUP
# ============================================================================
# Controle de funcionalidades por ambiente
# Formato: flag_name: { enabled: bool, environments: [], rollout: %, description: "" }
# ============================================================================

version: "1.0"
last_updated: "$(date -u +"%Y-%m-%dT%H:%M:%SZ")"

# Flags de infraestrutura
infrastructure:
  enable_monitoring_stack:
    enabled: true
    environments: ["homolog", "production"]
    rollout_percentage: 100
    description: "Stack completa de monitoramento (Prometheus, Grafana, Loki)"
    
  enable_backup_automation:
    enabled: true
    environments: ["production"]
    rollout_percentage: 100
    description: "Backup automático com Restic"
    
  enable_ssl_auto_renewal:
    enabled: true
    environments: ["homolog", "production"]
    rollout_percentage: 100
    description: "Renovação automática SSL via Let's Encrypt"

# Flags de aplicações
applications:
  enable_ai_services:
    enabled: true
    environments: ["homolog"]
    rollout_percentage: 50
    description: "Serviços de IA (Ollama, N8N, etc)"
    
  enable_development_tools:
    enabled: true
    environments: ["homolog"]
    rollout_percentage: 100
    description: "Ferramentas de desenvolvimento (Code Server, Portainer)"
    
  enable_productivity_suite:
    enabled: false
    environments: ["homolog"]
    rollout_percentage: 25
    description: "Suite de produtividade (Nextcloud, BookStack)"

# Flags de segurança
security:
  enable_vault_integration:
    enabled: true
    environments: ["production"]
    rollout_percentage: 100
    description: "Integração com HashiCorp Vault"
    
  enable_security_scanning:
    enabled: true
    environments: ["homolog", "production"]
    rollout_percentage: 100
    description: "Scanning de segurança automático"
    
  enable_network_policies:
    enabled: false
    environments: ["production"]
    rollout_percentage: 0
    description: "Políticas de rede restritivas"

# Flags experimentais
experimental:
  enable_service_mesh:
    enabled: false
    environments: ["homolog"]
    rollout_percentage: 0
    description: "Service Mesh (Consul Connect)"
    
  enable_auto_scaling:
    enabled: false
    environments: ["homolog"]
    rollout_percentage: 10
    description: "Auto-scaling baseado em métricas"
    
  enable_chaos_engineering:
    enabled: false
    environments: ["homolog"]
    rollout_percentage: 0
    description: "Chaos engineering para testes de resiliência"
EOF
    log "SUCCESS" "Arquivo de flags padrão criado"
}

# Criar template de flag
create_flag_template() {
    cat > "$FLAGS_DIR/templates/flag-template.yml" << 'EOF'
# Template para nova feature flag
flag_name:
  enabled: false                    # true/false
  environments: ["homolog"]         # Lista de ambientes onde a flag é válida
  rollout_percentage: 0             # Porcentagem de rollout (0-100)
  description: "Descrição da funcionalidade"
  metadata:
    created_at: "$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
    created_by: "system"
    jira_ticket: "MACS-XXX"
    documentation: "https://docs.macspark.dev/flags/flag_name"
  conditions:
    min_version: "1.0.0"
    required_services: []
    dependencies: []
EOF
}

# Verificar se uma flag está habilitada
check_flag() {
    local category=$1
    local flag_name=$2
    local environment=${3:-"homolog"}
    
    if [[ ! -f "$FLAGS_FILE" ]]; then
        log "ERROR" "Arquivo de flags não encontrado: $FLAGS_FILE"
        return 1
    fi
    
    # Usar yq para verificar a flag (instalar se necessário)
    if ! command -v yq >/dev/null 2>&1; then
        install_yq
    fi
    
    local enabled=$(yq eval ".${category}.${flag_name}.enabled" "$FLAGS_FILE" 2>/dev/null || echo "false")
    local environments=$(yq eval ".${category}.${flag_name}.environments[]" "$FLAGS_FILE" 2>/dev/null | tr '\n' ' ' || echo "")
    local rollout=$(yq eval ".${category}.${flag_name}.rollout_percentage" "$FLAGS_FILE" 2>/dev/null || echo "0")
    
    # Verificar se a flag existe
    if [[ "$enabled" == "null" ]] || [[ -z "$enabled" ]]; then
        log "WARN" "Flag não encontrada: ${category}.${flag_name}"
        return 1
    fi
    
    # Verificar se está habilitada
    if [[ "$enabled" != "true" ]]; then
        log "INFO" "Flag desabilitada: ${category}.${flag_name}"
        return 1
    fi
    
    # Verificar ambiente
    if [[ "$environments" != *"$environment"* ]]; then
        log "INFO" "Flag não habilitada para ambiente '$environment': ${category}.${flag_name}"
        return 1
    fi
    
    # Verificar rollout percentage (simulação simples)
    local random_num=$(( RANDOM % 100 + 1 ))
    if [[ $random_num -gt $rollout ]]; then
        log "INFO" "Flag fora do rollout ($random_num > $rollout): ${category}.${flag_name}"
        return 1
    fi
    
    log "SUCCESS" "Flag habilitada: ${category}.${flag_name} (rollout: ${rollout}%)"
    return 0
}

# Habilitar flag
enable_flag() {
    local category=$1
    local flag_name=$2
    local environment=${3:-"homolog"}
    local rollout=${4:-100}
    
    log "INFO" "🔧 Habilitando flag: ${category}.${flag_name}"
    
    # Backup do arquivo atual
    cp "$FLAGS_FILE" "$FLAGS_DIR/history/flags-$(date +%Y%m%d-%H%M%S).yml.bak"
    
    # Habilitar flag
    yq eval ".${category}.${flag_name}.enabled = true" -i "$FLAGS_FILE"
    yq eval ".${category}.${flag_name}.rollout_percentage = ${rollout}" -i "$FLAGS_FILE"
    yq eval ".last_updated = \"$(date -u +"%Y-%m-%dT%H:%M:%SZ")\"" -i "$FLAGS_FILE"
    
    # Adicionar ambiente se não estiver presente
    if ! yq eval ".${category}.${flag_name}.environments[]" "$FLAGS_FILE" | grep -q "^${environment}$"; then
        yq eval ".${category}.${flag_name}.environments += [\"${environment}\"]" -i "$FLAGS_FILE"
    fi
    
    log "SUCCESS" "Flag habilitada: ${category}.${flag_name} (${rollout}% rollout)"
}

# Desabilitar flag
disable_flag() {
    local category=$1
    local flag_name=$2
    
    log "INFO" "🔧 Desabilitando flag: ${category}.${flag_name}"
    
    # Backup do arquivo atual
    cp "$FLAGS_FILE" "$FLAGS_DIR/history/flags-$(date +%Y%m%d-%H%M%S).yml.bak"
    
    # Desabilitar flag
    yq eval ".${category}.${flag_name}.enabled = false" -i "$FLAGS_FILE"
    yq eval ".${category}.${flag_name}.rollout_percentage = 0" -i "$FLAGS_FILE"
    yq eval ".last_updated = \"$(date -u +"%Y-%m-%dT%H:%M:%SZ")\"" -i "$FLAGS_FILE"
    
    log "SUCCESS" "Flag desabilitada: ${category}.${flag_name}"
}

# Listar todas as flags
list_flags() {
    local environment=${1:-"all"}
    
    log "INFO" "📋 Listando feature flags..."
    
    if [[ ! -f "$FLAGS_FILE" ]]; then
        log "ERROR" "Arquivo de flags não encontrado"
        return 1
    fi
    
    echo ""
    echo -e "${BLUE}========================================"
    echo "       FEATURE FLAGS STATUS"
    echo "========================================${NC}"
    echo ""
    
    # Listar por categoria
    for category in infrastructure applications security experimental; do
        echo -e "${YELLOW}📂 $category${NC}"
        echo "----------------------------------------"
        
        # Listar flags da categoria
        yq eval ".${category} | keys" "$FLAGS_FILE" 2>/dev/null | while read -r flag; do
            if [[ "$flag" == "null" ]] || [[ -z "$flag" ]]; then
                continue
            fi
            
            # Remover hífen do início
            flag=$(echo "$flag" | sed 's/^- //')
            
            local enabled=$(yq eval ".${category}.${flag}.enabled" "$FLAGS_FILE" 2>/dev/null)
            local rollout=$(yq eval ".${category}.${flag}.rollout_percentage" "$FLAGS_FILE" 2>/dev/null)
            local environments=$(yq eval ".${category}.${flag}.environments[]" "$FLAGS_FILE" 2>/dev/null | tr '\n' ' ')
            local description=$(yq eval ".${category}.${flag}.description" "$FLAGS_FILE" 2>/dev/null)
            
            # Status visual
            local status_icon="❌"
            local status_color="$RED"
            if [[ "$enabled" == "true" ]]; then
                status_icon="✅"
                status_color="$GREEN"
            fi
            
            # Filtrar por ambiente se especificado
            if [[ "$environment" != "all" ]] && [[ "$environments" != *"$environment"* ]]; then
                continue
            fi
            
            printf "  %s%s %s%s (rollout: %s%%) - %s\n" \
                "$status_color" "$status_icon" "$flag" "$NC" "$rollout" "$description"
            printf "    🌐 Ambientes: %s\n" "$environments"
        done
        echo ""
    done
}

# Instalar yq
install_yq() {
    log "INFO" "📦 Instalando yq..."
    
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        sudo wget -qO /usr/local/bin/yq https://github.com/mikefarah/yq/releases/latest/download/yq_linux_amd64
        sudo chmod +x /usr/local/bin/yq
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        if command -v brew >/dev/null 2>&1; then
            brew install yq
        else
            log "ERROR" "Homebrew não encontrado"
            return 1
        fi
    fi
    
    log "SUCCESS" "yq instalado com sucesso"
}

# Mostrar ajuda
show_help() {
    cat << EOF
🚀 Feature Flags System - Macspark Setup

USAGE:
    $0 <command> [arguments]

COMMANDS:
    init                                    # Inicializar sistema de flags
    check <category> <flag> [environment]  # Verificar status de uma flag
    enable <category> <flag> [env] [%]     # Habilitar uma flag
    disable <category> <flag>              # Desabilitar uma flag
    list [environment]                     # Listar todas as flags
    
CATEGORIES:
    infrastructure    # Flags de infraestrutura
    applications      # Flags de aplicações
    security         # Flags de segurança
    experimental     # Flags experimentais

EXAMPLES:
    $0 init                                           # Inicializar sistema
    $0 check infrastructure enable_monitoring_stack  # Verificar flag
    $0 enable applications enable_ai_services homolog 75  # Habilitar com 75% rollout
    $0 disable experimental enable_service_mesh      # Desabilitar flag
    $0 list homolog                                   # Listar flags para homolog

ENVIRONMENTS:
    homolog          # Ambiente de homologação
    production       # Ambiente de produção
EOF
}

# Main
main() {
    local command=${1:-"help"}
    
    case $command in
        "init")
            init_feature_flags
            ;;
        "check")
            if [[ $# -lt 3 ]]; then
                log "ERROR" "Uso: $0 check <category> <flag> [environment]"
                exit 1
            fi
            check_flag "${2}" "${3}" "${4:-homolog}"
            ;;
        "enable")
            if [[ $# -lt 3 ]]; then
                log "ERROR" "Uso: $0 enable <category> <flag> [environment] [rollout%]"
                exit 1
            fi
            enable_flag "${2}" "${3}" "${4:-homolog}" "${5:-100}"
            ;;
        "disable")
            if [[ $# -lt 3 ]]; then
                log "ERROR" "Uso: $0 disable <category> <flag>"
                exit 1
            fi
            disable_flag "${2}" "${3}"
            ;;
        "list")
            list_flags "${2:-all}"
            ;;
        "help"|"-h"|"--help")
            show_help
            ;;
        *)
            log "ERROR" "Comando desconhecido: $command"
            show_help
            exit 1
            ;;
    esac
}

# Executar
main "$@"