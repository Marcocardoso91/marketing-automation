#!/bin/bash

# ============================================================================
# VALIDATE ENTERPRISE DEPLOYMENT - SETUP MACSPARK
# ============================================================================
# Script de validação completa dos serviços enterprise
# ============================================================================

set -euo pipefail

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m'
BOLD='\033[1m'

# Funções de log
log_info() { echo -e "${BLUE}${BOLD}[VALIDATE]${NC} $1"; }
log_success() { echo -e "${GREEN}${BOLD}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}${BOLD}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}${BOLD}[ERROR]${NC} $1"; }
log_step() { echo -e "${PURPLE}${BOLD}[STEP]${NC} $1"; }

# Contadores de validação
tests_passed=0
tests_failed=0
tests_warnings=0

# Helper para testes
run_test() {
    local test_name="$1"
    local test_command="$2"
    local expected_result="${3:-0}"
    
    log_info "🧪 Testing: $test_name"
    
    if eval "$test_command" >/dev/null 2>&1; then
        if [[ $expected_result -eq 0 ]]; then
            log_success "✅ PASS: $test_name"
            ((tests_passed++))
        else
            log_error "❌ FAIL: $test_name (unexpected success)"
            ((tests_failed++))
        fi
    else
        if [[ $expected_result -eq 1 ]]; then
            log_success "✅ PASS: $test_name (expected failure)"
            ((tests_passed++))
        else
            log_error "❌ FAIL: $test_name"
            ((tests_failed++))
        fi
    fi
}

# Validar pré-requisitos do sistema
validate_system_prerequisites() {
    log_step "🔍 Validando pré-requisitos do sistema..."
    
    run_test "Docker Swarm ativo" "docker info | grep -q 'Swarm: active'"
    run_test "Traefik disponível" "docker service ls | grep -q traefik"
    run_test "Rede traefik-public" "docker network ls | grep -q traefik-public"
    run_test "Rede monitoring-internal" "docker network ls | grep -q monitoring-internal"
    run_test "Espaço em disco suficiente" "[[ \$(df /opt 2>/dev/null | tail -1 | awk '{print \$4}' || echo 0) -gt 5242880 ]]" # 5GB
    run_test "Memória disponível" "[[ \$(free -m | awk '/^Mem:/{print \$7}') -gt 2048 ]]" # 2GB
    
    log_success "✅ Validação de pré-requisitos concluída"
}

# Validar redes enterprise
validate_enterprise_networks() {
    log_step "📡 Validando redes enterprise..."
    
    local networks=("enterprise-internal" "security-internal" "development-internal" "automation-internal" "performance-internal")
    
    for network in "${networks[@]}"; do
        run_test "Rede $network" "docker network ls | grep -q '$network'"
        
        # Verificar se a rede é overlay e encrypted
        if docker network inspect "$network" >/dev/null 2>&1; then
            local is_encrypted=$(docker network inspect "$network" | grep -q '"Encrypted": true' && echo "true" || echo "false")
            if [[ "$is_encrypted" == "true" ]]; then
                log_success "🔐 Rede $network está criptografada"
            else
                log_warning "⚠️  Rede $network não está criptografada"
                ((tests_warnings++))
            fi
        fi
    done
    
    log_success "✅ Validação de redes concluída"
}

# Validar secrets enterprise
validate_enterprise_secrets() {
    log_step "🔐 Validando secrets enterprise..."
    
    local secrets=(
        "gitlab_root_password"
        "gitlab_db_password" 
        "istio_ca_cert"
        "awx_secret_key"
        "consul_encrypt_key"
    )
    
    for secret in "${secrets[@]}"; do
        run_test "Secret $secret" "docker secret ls | grep -q '$secret'"
    done
    
    log_success "✅ Validação de secrets concluída"
}

# Validar estrutura de volumes
validate_volume_structure() {
    log_step "💾 Validando estrutura de volumes..."
    
    local base_dir="/opt/macspark"
    
    run_test "Base directory exists" "[[ -d '$base_dir' ]]"
    run_test "Volumes directory" "[[ -d '$base_dir/volumes' ]]"
    run_test "Configs directory" "[[ -d '$base_dir/configs' ]]"
    run_test "Logs directory" "[[ -d '$base_dir/logs' ]]"
    run_test "GitLab volumes" "[[ -d '$base_dir/volumes/gitlab' ]]"
    
    # Verificar permissões
    if [[ -d "$base_dir/volumes/gitlab" ]]; then
        local owner=$(stat -c '%U:%G' "$base_dir/volumes/gitlab" 2>/dev/null || echo "unknown")
        if [[ "$owner" == "1000:1000" ]]; then
            log_success "🔒 GitLab volumes têm permissões corretas"
        else
            log_warning "⚠️  GitLab volumes com permissões inadequadas: $owner"
            ((tests_warnings++))
        fi
    fi
    
    log_success "✅ Validação de volumes concluída"
}

# Validar serviços enterprise
validate_enterprise_services() {
    log_step "🚀 Validando serviços enterprise..."
    
    # Verificar stacks
    local stacks=(
        "gitlab-enterprise"
        "service-mesh" 
        "automation"
        "multicloud"
        "performance"
    )
    
    for stack in "${stacks[@]}"; do
        if docker stack ls | grep -q "$stack"; then
            log_success "✅ Stack $stack encontrado"
            ((tests_passed++))
            
            # Verificar serviços do stack
            local services=$(docker stack services "$stack" --format "{{.Name}}" 2>/dev/null | wc -l)
            if [[ $services -gt 0 ]]; then
                log_info "  📦 $services serviços no stack $stack"
            fi
        else
            log_warning "⚠️  Stack $stack não encontrado"
            ((tests_warnings++))
        fi
    done
    
    log_success "✅ Validação de serviços concluída"
}

# Validar health dos serviços
validate_service_health() {
    log_step "🏥 Validando saúde dos serviços..."
    
    # GitLab
    if docker service ls | grep -q gitlab; then
        local gitlab_service=$(docker service ls | grep gitlab | awk '{print $2}' | head -1)
        local replicas_info=$(docker service ls | grep "$gitlab_service" | awk '{print $4}')
        
        if [[ "$replicas_info" == *"1/1"* ]]; then
            log_success "✅ GitLab está rodando corretamente"
            ((tests_passed++))
        else
            log_warning "⚠️  GitLab pode não estar totalmente inicializado: $replicas_info"
            ((tests_warnings++))
        fi
    fi
    
    # Envoy proxy
    if docker service ls | grep -q envoy; then
        local envoy_service=$(docker service ls | grep envoy | awk '{print $2}' | head -1)
        local replicas_info=$(docker service ls | grep "$envoy_service" | awk '{print $4}')
        
        if [[ "$replicas_info" == *"2/2"* ]]; then
            log_success "✅ Envoy proxy está rodando corretamente"
            ((tests_passed++))
        else
            log_warning "⚠️  Envoy proxy pode não estar totalmente inicializado: $replicas_info"
            ((tests_warnings++))
        fi
    fi
    
    log_success "✅ Validação de saúde concluída"
}

# Validar conectividade de rede
validate_network_connectivity() {
    log_step "🌐 Validando conectividade de rede..."
    
    # Testar resolução DNS interna
    if docker service ls | grep -q gitlab; then
        local gitlab_service=$(docker service ls | grep gitlab | awk '{print $2}' | head -1)
        
        # Criar container temporário para teste
        local test_container=$(docker run -d --rm --network development-internal alpine:latest sleep 60 2>/dev/null || echo "")
        
        if [[ -n "$test_container" ]]; then
            if docker exec "$test_container" nslookup "$gitlab_service" >/dev/null 2>&1; then
                log_success "✅ Resolução DNS interna funcionando"
                ((tests_passed++))
            else
                log_warning "⚠️  Problemas na resolução DNS interna"
                ((tests_warnings++))
            fi
            
            docker stop "$test_container" >/dev/null 2>&1 || true
        else
            log_warning "⚠️  Não foi possível criar container de teste"
            ((tests_warnings++))
        fi
    fi
    
    log_success "✅ Validação de conectividade concluída"
}

# Validar configurações dinâmicas
validate_dynamic_configs() {
    log_step "⚙️ Validando configurações dinâmicas..."
    
    run_test "Config gitlab_omnibus_config" "docker config ls | grep -q gitlab_omnibus_config"
    run_test "Config istio_mesh_config" "docker config ls | grep -q istio_mesh_config"
    run_test "Config envoy_basic_config" "docker config ls | grep -q envoy_basic_config"
    
    log_success "✅ Validação de configurações concluída"
}

# Validar recursos do sistema
validate_system_resources() {
    log_step "📊 Validando recursos do sistema..."
    
    # CPU usage
    local cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | sed 's/%us,//' | cut -d'.' -f1)
    if [[ $cpu_usage -lt 80 ]]; then
        log_success "✅ Uso de CPU aceitável: ${cpu_usage}%"
        ((tests_passed++))
    else
        log_warning "⚠️  Alto uso de CPU: ${cpu_usage}%"
        ((tests_warnings++))
    fi
    
    # Memory usage
    local mem_usage=$(free | grep Mem | awk '{printf("%.0f", $3/$2 * 100.0)}')
    if [[ $mem_usage -lt 85 ]]; then
        log_success "✅ Uso de memória aceitável: ${mem_usage}%"
        ((tests_passed++))
    else
        log_warning "⚠️  Alto uso de memória: ${mem_usage}%"
        ((tests_warnings++))
    fi
    
    # Disk usage
    local disk_usage=$(df /opt | tail -1 | awk '{print $5}' | sed 's/%//')
    if [[ $disk_usage -lt 90 ]]; then
        log_success "✅ Uso de disco aceitável: ${disk_usage}%"
        ((tests_passed++))
    else
        log_error "❌ Alto uso de disco: ${disk_usage}%"
        ((tests_failed++))
    fi
    
    log_success "✅ Validação de recursos concluída"
}

# Gerar relatório final
generate_final_report() {
    log_step "📋 Gerando relatório final..."
    
    local total_tests=$((tests_passed + tests_failed + tests_warnings))
    local success_rate=$((tests_passed * 100 / total_tests))
    
    echo
    echo -e "${BLUE}${BOLD}"
    echo "╔════════════════════════════════════════════════════════════════╗"
    echo "║                    RELATÓRIO DE VALIDAÇÃO                     ║"
    echo "╚════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    
    echo -e "${GREEN}✅ Testes aprovados:${NC} $tests_passed"
    echo -e "${RED}❌ Testes falharam:${NC} $tests_failed"
    echo -e "${YELLOW}⚠️  Warnings:${NC} $tests_warnings"
    echo -e "${BLUE}📊 Taxa de sucesso:${NC} ${success_rate}%"
    
    echo
    if [[ $tests_failed -eq 0 ]]; then
        if [[ $tests_warnings -eq 0 ]]; then
            log_success "🎉 DEPLOY TOTALMENTE VALIDADO!"
            echo -e "${GREEN}${BOLD}Status: PERFEITO${NC}"
        else
            log_success "✅ DEPLOY VALIDADO COM WARNINGS"
            echo -e "${YELLOW}${BOLD}Status: ACEITÁVEL${NC}"
        fi
    else
        log_error "❌ DEPLOY COM PROBLEMAS"
        echo -e "${RED}${BOLD}Status: REQUER ATENÇÃO${NC}"
    fi
    
    echo
    log_info "📖 Para troubleshooting detalhado, consulte: docs/enterprise/troubleshooting.md"
    
    # Return exit code baseado no resultado
    if [[ $tests_failed -gt 0 ]]; then
        return 1
    else
        return 0
    fi
}

# Função principal
main() {
    clear
    echo -e "${PURPLE}${BOLD}"
    echo "╔════════════════════════════════════════════════════════════════╗"
    echo "║            🔍 SETUP MACSPARK ENTERPRISE VALIDATION            ║"
    echo "║                  Validação Completa do Deploy                 ║"
    echo "╚════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    
    log_info "🧪 Iniciando validação completa do deployment enterprise..."
    
    # Executar todas as validações
    validate_system_prerequisites
    validate_enterprise_networks
    validate_enterprise_secrets
    validate_volume_structure
    validate_enterprise_services
    validate_service_health
    validate_network_connectivity
    validate_dynamic_configs
    validate_system_resources
    
    # Gerar relatório final
    if generate_final_report; then
        log_success "✅ Validação concluída com sucesso!"
        exit 0
    else
        log_error "❌ Validação detectou problemas que requerem atenção"
        exit 1
    fi
}

# Executar script
main "$@"