#!/bin/bash
set -euo pipefail

# Requisitos: yq v4, bash
if ! command -v yq >/dev/null 2>&1; then
  echo "Erro: 'yq' não encontrado. Instale: https://github.com/mikefarah/yq" >&2
  exit 1
fi

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
STACKS_DIR="${ROOT_DIR}/setup-macspark/stacks"

# Defaults (ajuste conforme necessário)
LIMIT_CPU="0.50"
LIMIT_MEM="512M"
RESV_CPU="0.25"
RESV_MEM="256M"

apply_limits() {
  local file="$1"
  local tmp="${file}.tmp"

  # Garante objetos existentes
  yq -y '
    .services |= with(.[]; .deploy //= {} ) |
    .services |= with(.[]; .deploy.resources //= {} ) |
    .services |= with(.[]; .deploy.resources.limits //= {} ) |
    .services |= with(.[]; .deploy.resources.reservations //= {} ) |
    .services |= with(.[]; .labels //= {} ) |
    .services |= with(.[]; .security_opt //= [] ) |
    .services |= with(.[]; .cap_drop //= [] )
  ' "$file" > "$tmp" && mv "$tmp" "$file"

  # Aplica limites e hardening base
  yq -y "
    .services |= with(.[];
      .deploy.resources.limits.cpus = \"${LIMIT_CPU}\" |
      .deploy.resources.limits.memory = \"${LIMIT_MEM}\" |
      .deploy.resources.reservations.cpus = \"${RESV_CPU}\" |
      .deploy.resources.reservations.memory = \"${RESV_MEM}\" |
      .read_only = true |
      .security_opt += [\"no-new-privileges:true\"] |
      .cap_drop = ( .cap_drop + [\"ALL\"] | unique )
    )
  " "$file" > "$tmp" && mv "$tmp" "$file"

  # Estratégias de atualização e rollback (Swarm)
  yq -y '
    .services |= with(.[];
      .deploy.update_config //= {} |
      .deploy.update_config.order = "start-first" |
      .deploy.update_config.parallelism = 1 |
      .deploy.update_config.delay = "10s" |
      .deploy.update_config.failure_action = "rollback" |
      .deploy.rollback_config //= {} |
      .deploy.rollback_config.parallelism = 1
    )
  ' "$file" > "$tmp" && mv "$tmp" "$file"

  # Labels padrão úteis
  yq -y '
    .services |= with(.[];
      .labels."com.macspark.owner" //= "platform" |
      .labels."com.macspark.tier" //= "backend" |
      .labels."com.macspark.slo" //= "99.9"
    )
  ' "$file" > "$tmp" && mv "$tmp" "$file"
}

export -f apply_limits

find "$STACKS_DIR" -type f \( -name "*.yml" -o -name "*.yaml" \) ! -path "*/deprecated/*" -print0 \
| while IFS= read -r -d '' f; do
  echo "Aplicando limites em: $f"
  apply_limits "$f"
done

echo "OK: Limites e hardening base aplicados."

#!/bin/bash

echo "📊 Adicionando resource limits aos serviços..."
echo "=============================================="

UPDATED=0
SKIPPED=0

# Configurações de resources por tipo de serviço
declare -A SERVICE_LIMITS=(
    ["traefik"]="2.0:2G:0.5:512M"       # cpus_limit:mem_limit:cpus_res:mem_res
    ["postgres"]="4.0:4G:1.0:1G"
    ["redis"]="2.0:2G:0.5:512M"
    ["prometheus"]="2.0:2G:0.5:512M"
    ["grafana"]="1.0:1G:0.25:256M"
    ["loki"]="1.0:1G:0.25:256M"
    ["n8n"]="2.0:2G:0.5:512M"
    ["ollama"]="8.0:8G:2.0:2G"
    ["vault"]="2.0:2G:0.5:512M"
    ["default"]="1.0:1G:0.25:256M"      # Padrão para serviços não especificados
)

echo "🔍 Analisando arquivos de stack..."
echo ""

# Processar cada arquivo YAML
find stacks/ -name "*.yml" -o -name "*.yaml" ! -path "*/deprecated/*" | while read -r file; do
    # Pular backups
    if [[ "$file" == *.backup ]] || [[ "$file" == *.ha-backup ]]; then
        continue
    fi
    
    # Verificar se tem deploy mas não tem resources
    if grep -q "deploy:" "$file" && ! grep -q "resources:" "$file"; then
        echo "📄 Processando: $(basename $file)"
        
        # Fazer backup
        cp "$file" "$file.resources-backup"
        
        # Identificar o tipo de serviço principal
        SERVICE_TYPE="default"
        for service in "${!SERVICE_LIMITS[@]}"; do
            if [[ "$service" != "default" ]] && grep -qi "$service" "$file"; then
                SERVICE_TYPE="$service"
                break
            fi
        done
        
        # Obter limites para o serviço
        IFS=':' read -r CPU_LIMIT MEM_LIMIT CPU_RES MEM_RES <<< "${SERVICE_LIMITS[$SERVICE_TYPE]}"
        
        # Criar configuração de resources
        RESOURCES_CONFIG="      resources:\\n        limits:\\n          cpus: '$CPU_LIMIT'\\n          memory: $MEM_LIMIT\\n        reservations:\\n          cpus: '$CPU_RES'\\n          memory: $MEM_RES"
        
        # Adicionar resources após cada deploy:
        # Usar awk para adicionar a configuração corretamente
        awk -v resources="$RESOURCES_CONFIG" '
            /^  [a-zA-Z]/ { in_service=1; service=$0 }
            /^    deploy:/ && in_service {
                print
                # Verificar se já tem replicas ou update_config
                getline nextline
                if (nextline ~ /^      (replicas|update_config|restart_policy|placement)/) {
                    # Adicionar resources antes dessas configurações
                    printf "%s\n", gensub(/\\\\n/, "\n", "g", resources)
                    print nextline
                } else {
                    # Adicionar resources imediatamente
                    printf "%s\n", gensub(/\\\\n/, "\n", "g", resources)
                    print nextline
                }
                next
            }
            { print }
        ' "$file" > "$file.tmp" && mv "$file.tmp" "$file"
        
        echo "   ✅ Resources adicionados ($SERVICE_TYPE): CPU=$CPU_LIMIT/$CPU_RES, Mem=$MEM_LIMIT/$MEM_RES"
        ((UPDATED++))
        
        # Remover backup se sucesso
        rm "$file.resources-backup"
    else
        if grep -q "resources:" "$file"; then
            ((SKIPPED++))
        fi
    fi
done

# Ajustar resources específicos para serviços pesados
echo ""
echo "🔧 Ajustando resources para serviços especiais..."

# Ollama precisa de mais recursos
find stacks/ -name "*.yml" ! -path "*/deprecated/*" -exec grep -l "ollama" {} \; | while read -r file; do
    if grep -q "resources:" "$file"; then
        sed -i "/ollama/,/deploy:/{/cpus:/s/'[0-9.]*'/'8.0'/; /memory:/s/[0-9]*[MG]/8G/}" "$file"
        echo "   ✅ Resources ajustados para Ollama em: $(basename $file)"
    fi
done

# Databases precisam de recursos garantidos
find stacks/ -name "*.yml" ! -path "*/deprecated/*" -exec grep -l "postgres\|mysql\|mongo" {} \; | while read -r file; do
    if grep -q "resources:" "$file" && ! grep -q "cpus: '4" "$file"; then
        sed -i "/postgres\|mysql\|mongo/,/resources:/{/limits:/,/reservations:/{/cpus:/s/'[0-9.]*'/'4.0'/; /memory:/s/[0-9]*[MG]/4G/}}" "$file"
        echo "   ✅ Resources ajustados para Database em: $(basename $file)"
    fi
done

echo ""
echo "=============================================="
echo "📊 Resultado da adição de resource limits:"
echo "   ✅ Serviços atualizados: $UPDATED"
echo "   ⏩ Serviços já configurados: $SKIPPED"
echo ""
echo "⚠️  RECOMENDAÇÕES:"
echo "   - Ajuste os limits conforme recursos disponíveis"
echo "   - Monitore uso real com 'docker stats'"
echo "   - Use Grafana para acompanhar métricas"
echo "=============================================="