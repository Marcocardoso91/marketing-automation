#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
STACKS_DIR="${ROOT_DIR}/setup-macspark/stacks"
FIX_MODE=${1:-}
DEFAULT_MW="sec-headers@file"

ensure_yq() {
  if command -v yq >/dev/null 2>&1; then
    return
  fi
  echo "yq não encontrado, baixando binário..."
  TMP_YQ="${TMPDIR:-/tmp}/yq"
  curl -sSL -o "$TMP_YQ" "https://github.com/mikefarah/yq/releases/download/v4.43.1/yq_linux_amd64" || {
    echo "Falha ao baixar yq" >&2; exit 1; }
  chmod +x "$TMP_YQ"
  export PATH="${TMPDIR:-/tmp}:$PATH"
  hash -r
}

is_exposed_service() {
  local file=$1
  # Verifica se tem traefik.enable=true ou algum router rule definido
  if grep -q "traefik.enable.*true" "$file" || grep -q "traefik.http.routers.*rule" "$file"; then
    return 0
  fi
  # Ignora services internos (db, cache, monitoring interno)
  if [[ "$file" =~ (postgres|redis|mongo|mysql|elasticsearch|opentelemetry) ]]; then
    return 1
  fi
  return 0
}

missing=0
fixed=0
while IFS= read -r -d '' f; do
  if grep -qi "traefik" "$f"; then
    if ! grep -q "middlewares" "$f"; then
      echo "[WARN] Falta middlewares de segurança em: $f"
      missing=$((missing+1))
      
      if [[ "$FIX_MODE" =~ (--fix|--fix-selective) ]]; then
        # Fix seletivo: só aplica em serviços realmente expostos
        if [ "$FIX_MODE" = "--fix-selective" ] && ! is_exposed_service "$f"; then
          echo "[SKIP] Serviço interno/não-exposto: $f"
          continue
        fi
        
        # Injeta middleware usando sed - mais confiável
        if grep -q "labels:" "$f"; then
          # Adiciona middleware nas labels existentes
          sed -i '/labels:/a\      - "traefik.http.routers.default.middlewares='"${DEFAULT_MW}"'"' "$f"
        else
          # Cria bloco de labels com middleware
          sed -i '/image:/a\    labels:\n      - "traefik.http.routers.default.middlewares='"${DEFAULT_MW}"'"' "$f"
        fi
        echo "[FIX] Middleware padrão adicionado em: $f"
        ((fixed++))
      fi
    fi
  fi
done < <(find "$STACKS_DIR" -type f \( -name "*.yml" -o -name "*.yaml" \) -print0)

echo ""
echo "🔍 AUDITORIA DE MIDDLEWARES TRAEFIK CONCLUÍDA"
echo "============================================="
echo "Arquivos sem middlewares: $missing"
if [[ "$FIX_MODE" =~ (--fix|--fix-selective) ]]; then
  echo "Arquivos corrigidos: $fixed"
fi

if [ "$missing" -eq 0 ]; then
  echo "✅ Todos os stacks com Traefik têm middlewares de segurança!"
else
  echo "⚠️ $missing stacks precisam de middlewares de segurança"
  if [ "$FIX_MODE" != "--fix" ] && [ "$FIX_MODE" != "--fix-selective" ]; then
    echo ""
    echo "Para corrigir automaticamente:"
    echo "  $0 --fix           # Corrige todos os arquivos"
    echo "  $0 --fix-selective # Corrige apenas serviços expostos"
  fi
fi


