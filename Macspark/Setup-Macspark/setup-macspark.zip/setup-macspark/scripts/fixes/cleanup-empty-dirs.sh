#!/bin/bash

echo "🧹 Limpando diretórios vazios e arquivos desnecessários..."
echo "========================================================="

REMOVED_DIRS=0
REMOVED_GITKEEP=0

# Lista de diretórios vazios identificados
DIRS_TO_CHECK=(
    "backups/restore/logs/errors"
    "backups/restore/logs/summary"
    "backups/restore/logs/validation"
    "backups/restore/recovery-tests"
    "backups/restore/templates"
    "backups/restore/scripts/backups/restore/scripts"
    "scripts/backup/config/environments"
    "scripts/backup/config/policies"
    "scripts/backup/config/targets"
    "scripts/backup/monitoring/dashboards"
    "scripts/backup/tests/integration"
    "scripts/backup/tests/unit"
    "stacks/applications/development/deprecated"
    "stacks/applications/productivity/deprecated"
    "stacks/infrastructure/backup/configs"
    "stacks-backup-20250825-211257"
)

echo "📁 Removendo diretórios vazios específicos..."
for dir in "${DIRS_TO_CHECK[@]}"; do
    if [ -d "$dir" ]; then
        if [ -z "$(ls -A "$dir" 2>/dev/null)" ]; then
            echo "   Removendo: $dir"
            rm -rf "$dir"
            ((REMOVED_DIRS++))
        else
            echo "   ⏩ Não vazio: $dir"
        fi
    fi
done

# Remover diretório de backup antigo completamente
if [ -d "stacks-backup-20250825-211257" ]; then
    echo "   Removendo backup antigo: stacks-backup-20250825-211257"
    rm -rf "stacks-backup-20250825-211257"
    ((REMOVED_DIRS++))
fi

echo ""
echo "📁 Procurando e removendo outros diretórios vazios..."
# Encontrar e remover todos os diretórios vazios (exceto .git)
find . -type d -empty ! -path "./.git/*" 2>/dev/null | while read -r dir; do
    echo "   Removendo: $dir"
    rmdir "$dir" 2>/dev/null && ((REMOVED_DIRS++))
done

echo ""
echo "📄 Removendo arquivos .gitkeep desnecessários..."
# Remover .gitkeep de diretórios que não estão vazios
find . -name ".gitkeep" -type f ! -path "./.git/*" | while read -r file; do
    dir=$(dirname "$file")
    # Contar arquivos no diretório (excluindo .gitkeep)
    count=$(find "$dir" -maxdepth 1 -type f ! -name ".gitkeep" | wc -l)
    if [ "$count" -gt 0 ]; then
        echo "   Removendo .gitkeep desnecessário: $file"
        rm "$file"
        ((REMOVED_GITKEEP++))
    fi
done

echo ""
echo "========================================================="
echo "✅ Limpeza concluída!"
echo "   📁 Diretórios removidos: $REMOVED_DIRS"
echo "   📄 .gitkeep removidos: $REMOVED_GITKEEP"
echo "========================================================="