#!/bin/bash

# ============================================================================
# SCRIPT DE CRIAÇÃO DE NETWORKS DOCKER
# ============================================================================
# Cria todas as redes overlay necessárias para o Docker Swarm
# ============================================================================

set -e

echo "=========================================="
echo "CRIANDO NETWORKS DOCKER SWARM"
echo "=========================================="

# Lista de networks identificadas nos stacks
NETWORKS=(
    "traefik-public"
    "traefik-network"
    "apps-internal"
    "database-internal"
    "monitoring"
    "postgres-network"
    "redis-network"
    "qwen-redis-cluster-network"
    "qwen-postgres-network"
    "prometheus-network"
    "loki-network"
    "grafana-network"
    "ollama-network"
    "qwen-mcp-api-network"
    "qwen-security-scanner-network"
    "qwen-autoscaler-network"
    "qwen-metrics-collector-network"
    "n8n-network"
    "ai-internal"
    "cloudflared-network"
    "netdata-network"
    "appsmith-network"
    "authentik-network"
    "budibase-network"
    "chatwoot-network"
    "directus-network"
    "nocodb-network"
    "strapi-network"
    "tooljet-network"
    "windmill-network"
    "typebot-network"
    "evolution-network"
    "formbricks-network"
    "calcom-network"
    "twenty-network"
    "outline-network"
    "affine-network"
    "excalidraw-network"
    "diagrams-network"
    "drawio-network"
    "langflow-network"
    "litellm-network"
    "open-webui-network"
    "promptflow-network"
    "qdrant-network"
    "plane-network"
    "gitea-network"
    "vault-network"
    "boundary-network"
    "teleport-network"
    "zitadel-network"
    "casdoor-network"
    "keycloak-network"
    "hanko-network"
    "logto-network"
    "kinde-network"
)

# Função para criar network
create_network() {
    local network_name=$1
    
    # Verifica se a network já existe
    if docker network ls | grep -q "$network_name"; then
        echo "✓ Network '$network_name' já existe"
    else
        echo "→ Criando network '$network_name'..."
        docker network create \
            --driver overlay \
            --attachable \
            --opt encrypted=true \
            "$network_name" 2>/dev/null || {
                echo "⚠ Erro ao criar network '$network_name' - pode já existir ou haver problema de permissão"
            }
        echo "✓ Network '$network_name' criada com sucesso"
    fi
}

# Verifica se está em modo Swarm
if ! docker info 2>/dev/null | grep -q "Swarm: active"; then
    echo "⚠ AVISO: Docker não está em modo Swarm!"
    echo "Execute 'docker swarm init' primeiro"
    exit 1
fi

# Cria todas as networks
echo ""
echo "Criando networks..."
echo "------------------"

for network in "${NETWORKS[@]}"; do
    create_network "$network"
done

echo ""
echo "=========================================="
echo "✓ CRIAÇÃO DE NETWORKS CONCLUÍDA"
echo "=========================================="
echo ""
echo "Total de networks processadas: ${#NETWORKS[@]}"
echo ""
echo "Para verificar as networks criadas:"
echo "  docker network ls --filter driver=overlay"
echo ""
echo "Para inspecionar uma network:"
echo "  docker network inspect <network_name>"
echo ""