#!/bin/bash

echo "🔄 Configurando Alta Disponibilidade para serviços críticos..."
echo "=============================================================="

UPDATED=0
SKIPPED=0

# Serviços críticos que precisam de HA
declare -A CRITICAL_SERVICES=(
    ["traefik"]=2
    ["postgres"]=2
    ["postgresql"]=2
    ["redis"]=3
    ["prometheus"]=2
    ["grafana"]=2
    ["loki"]=2
    ["vault"]=3
)

# Configuração de HA padrão
HA_CONFIG='      replicas: REPLICA_COUNT
      update_config:
        parallelism: 1
        delay: 10s
        failure_action: rollback
        monitor: 30s
        max_failure_ratio: 0.1
      restart_policy:
        condition: any
        delay: 5s
        max_attempts: 3
        window: 120s'

echo "📋 Processando arquivos de stack..."
echo ""

# Processar cada arquivo YAML
find stacks/ -name "*.yml" -o -name "*.yaml" ! -path "*/deprecated/*" | while read -r file; do
    MODIFIED=false
    
    # Verificar se o arquivo contém algum serviço crítico
    for service in "${!CRITICAL_SERVICES[@]}"; do
        if grep -q "${service}:" "$file" && grep -q "deploy:" "$file"; then
            echo "📄 Processando: $(basename $file)"
            
            # Fazer backup
            cp "$file" "$file.ha-backup"
            
            # Verificar se já tem configuração de réplicas
            if grep -q "replicas:" "$file"; then
                # Atualizar réplicas existentes
                REPLICAS=${CRITICAL_SERVICES[$service]}
                sed -i "/replicas:/c\      replicas: $REPLICAS" "$file"
                echo "   ✅ Réplicas atualizadas para $service: $REPLICAS"
                
                # Adicionar update_config se não existir
                if ! grep -q "update_config:" "$file"; then
                    # Adicionar configuração de update após replicas
                    sed -i "/replicas: $REPLICAS/a\\      update_config:\\n        parallelism: 1\\n        delay: 10s\\n        failure_action: rollback" "$file"
                    echo "   ✅ Update config adicionado"
                fi
                
                # Adicionar restart_policy se não existir
                if ! grep -q "restart_policy:" "$file"; then
                    sed -i "/deploy:/a\\      restart_policy:\\n        condition: any\\n        delay: 5s\\n        max_attempts: 3" "$file"
                    echo "   ✅ Restart policy adicionado"
                fi
                
                ((UPDATED++))
                MODIFIED=true
            else
                # Adicionar configuração completa de HA
                REPLICAS=${CRITICAL_SERVICES[$service]}
                HA_CONFIG_TEMP="${HA_CONFIG//REPLICA_COUNT/$REPLICAS}"
                
                # Adicionar após deploy:
                awk -v config="$HA_CONFIG_TEMP" '
                    /deploy:/ {
                        print
                        print config
                        next
                    }
                    {print}
                ' "$file" > "$file.tmp" && mv "$file.tmp" "$file"
                
                echo "   ✅ HA completo configurado para $service"
                ((UPDATED++))
                MODIFIED=true
            fi
            
            # Se não houve mudanças, remover backup
            if [ "$MODIFIED" = false ]; then
                rm "$file.ha-backup"
            fi
            
            break
        fi
    done
done

# Adicionar configurações específicas para PostgreSQL
echo ""
echo "🐘 Configurando PostgreSQL para HA..."
PG_FILES=$(find stacks/ -name "*.yml" ! -path "*/deprecated/*" -exec grep -l "postgres" {} \;)
for file in $PG_FILES; do
    if grep -q "POSTGRES_" "$file"; then
        # Adicionar configurações de replicação se não existirem
        if ! grep -q "POSTGRES_REPLICATION" "$file"; then
            sed -i "/environment:/a\\      - POSTGRES_REPLICATION_MODE=master\\n      - POSTGRES_REPLICATION_USER=replicator\\n      - POSTGRES_REPLICATION_PASSWORD=\${POSTGRES_REPLICATION_PASSWORD}" "$file"
            echo "   ✅ Configuração de replicação adicionada em: $(basename $file)"
        fi
    fi
done

# Adicionar configurações específicas para Redis
echo ""
echo "🔴 Configurando Redis para HA..."
REDIS_FILES=$(find stacks/ -name "*.yml" ! -path "*/deprecated/*" -exec grep -l "redis:" {} \;)
for file in $REDIS_FILES; do
    if grep -q "image:.*redis" "$file"; then
        # Adicionar comando para modo cluster se não existir
        if ! grep -q "redis-server --cluster-enabled" "$file"; then
            sed -i "/image:.*redis/a\\    command: redis-server --cluster-enabled yes --cluster-config-file nodes.conf --cluster-node-timeout 5000 --appendonly yes" "$file"
            echo "   ✅ Modo cluster habilitado em: $(basename $file)"
        fi
    fi
done

echo ""
echo "=============================================================="
echo "📊 Resultado da configuração de HA:"
echo "   ✅ Serviços atualizados: $UPDATED"
echo "   ⏩ Serviços ignorados: $SKIPPED"
echo ""
echo "⚠️  IMPORTANTE:"
echo "   - Configure as variáveis POSTGRES_REPLICATION_PASSWORD"
echo "   - Certifique-se de ter recursos suficientes para as réplicas"
echo "   - Teste em ambiente de homologação primeiro"
echo "=============================================================="