#!/bin/bash

echo "🔧 Fixando versões de imagens Docker..."
echo "======================================="

FIXED=0

# Mapa de versões estáveis (Agosto 2025)
declare -A STABLE_VERSIONS=(
    # Bases
    ["alpine:latest"]="alpine:3.19"
    ["busybox:latest"]="busybox:1.36"
    ["curlimages/curl:latest"]="curlimages/curl:8.9.1"
    
    # Aplicações
    ["activepieces/activepieces:latest"]="activepieces/activepieces:0.30.0"
    ["atendai/evolution-api:latest"]="atendai/evolution-api:2.0.0"
    ["automatischio/automatisch:latest"]="automatischio/automatisch:0.10.0"
    ["codercom/code-server:latest"]="codercom/code-server:4.91.1"
    ["huginn/huginn:latest"]="huginn/huginn:2024-08-25"
    
    # Jitsi
    ["jitsi/jicofo:latest"]="jitsi/jicofo:stable-9584"
    ["jitsi/jvb:latest"]="jitsi/jvb:stable-9584"
    ["jitsi/prosody:latest"]="jitsi/prosody:stable-9584"
    ["jitsi/web:latest"]="jitsi/web:stable-9584"
    
    # Monitoring
    ["gcr.io/cadvisor/cadvisor:latest"]="gcr.io/cadvisor/cadvisor:v0.49.1"
    ["joxit/docker-registry-ui:latest"]="joxit/docker-registry-ui:2.5.7"
    ["aquasec/trivy:latest"]="aquasec/trivy:0.55.0"
    
    # GitHub packages
    ["ghcr.io/open-webui/open-webui:main"]="ghcr.io/open-webui/open-webui:v0.3.35"
    ["ghcr.io/windmill-labs/windmill:main"]="ghcr.io/windmill-labs/windmill:1.380.1"
    
    # Macspark específicos - manter latest pois são nossos
    # ["ghcr.io/marcocardoso28/mcp-dashboard:latest"]="ghcr.io/marcocardoso28/mcp-dashboard:latest"
    # ["ghcr.io/marcocardoso28/mcp-orchestrator:latest"]="ghcr.io/marcocardoso28/mcp-orchestrator:latest"
    # ["ghcr.io/marcocardoso28/sparkone:latest"]="ghcr.io/marcocardoso28/sparkone:latest"
    
    # LinuxServer.io
    ["lscr.io/linuxserver/bookstack:latest"]="lscr.io/linuxserver/bookstack:24.05.4"
    ["lscr.io/linuxserver/duplicati:latest"]="lscr.io/linuxserver/duplicati:2.0.8"
)

echo "📌 Substituindo tags instáveis por versões fixas..."
echo ""

for old_tag in "${!STABLE_VERSIONS[@]}"; do
    new_tag="${STABLE_VERSIONS[$old_tag]}"
    
    # Buscar e substituir em todos os YAMLs
    count=$(find stacks/ -name "*.yml" -exec grep -l "image: $old_tag" {} \; | wc -l)
    
    if [ $count -gt 0 ]; then
        echo "  📦 $old_tag → $new_tag ($count arquivos)"
        find stacks/ -name "*.yml" -exec sed -i "s|image: $old_tag|image: $new_tag|g" {} \;
        FIXED=$((FIXED + count))
    fi
done

echo ""
echo "📌 Verificando imagens ainda com tags instáveis..."

# Buscar por tags instáveis restantes
UNSTABLE=$(find stacks/ -name "*.yml" | xargs grep -h "image:" | grep -E ":(latest|master|main|dev|develop)" | grep -v "#" | grep -v "ghcr.io/marcocardoso28" | sort -u | wc -l)

if [ $UNSTABLE -gt 0 ]; then
    echo "  ⚠️  Ainda existem $UNSTABLE imagens com tags instáveis:"
    find stacks/ -name "*.yml" | xargs grep -h "image:" | grep -E ":(latest|master|main|dev|develop)" | grep -v "#" | grep -v "ghcr.io/marcocardoso28" | sort -u | head -10
    echo ""
    echo "  ℹ️  Nota: Imagens ghcr.io/marcocardoso28/* mantidas com :latest (são nossas)"
else
    echo "  ✅ Todas as imagens estão com versões fixas"
fi

echo ""
echo "======================================="
echo "📊 Resultado da fixação de versões:"
echo "  ✅ Imagens atualizadas: $FIXED"
echo "  ⚠️  Imagens instáveis restantes: $UNSTABLE"
echo "======================================="
echo ""
echo "💡 RECOMENDAÇÃO:"
echo "  - Teste as novas versões em homolog antes de produção"
echo "  - Crie um processo de atualização regular das versões"
echo "======================================"