#!/bin/bash

echo "🔧 Corrigindo referências localhost..."
echo "======================================"

FIXED=0
FILES_CHANGED=0

# Fazer backup antes de modificar
echo "📌 Criando backup das configurações..."
mkdir -p backups/localhost-fixes
find stacks/ -name "*.yml" ! -path "*/deprecated/*" -exec cp {} backups/localhost-fixes/ \; 2>/dev/null

echo "📌 Substituindo localhost por nomes de serviço..."

# Mapeamento de localhost para nomes de serviço
declare -A SERVICE_MAP=(
    ["localhost:11434"]="ollama:11434"
    ["localhost:5000"]="registry:5000"
    ["localhost:5432"]="postgres:5432"
    ["localhost:6379"]="redis:6379"
    ["localhost:9090"]="prometheus:9090"
    ["localhost:3000"]="grafana:3000"
    ["localhost:8080"]="traefik:8080"
)

# Corrigir cada arquivo
find stacks/ -name "*.yml" ! -path "*/deprecated/*" | while read -r file; do
    CHANGES_IN_FILE=0
    
    # Para health checks, usar 127.0.0.1 (localhost interno do container)
    if grep -q "localhost" "$file"; then
        # Health checks devem usar 127.0.0.1
        sed -i 's|"http://localhost:|"http://127.0.0.1:|g' "$file"
        sed -i "s|'http://localhost:|'http://127.0.0.1:|g" "$file"
        sed -i 's|\[.*"http://localhost:|\["CMD", "curl", "-f", "http://127.0.0.1:|g' "$file"
        
        # URLs de serviço devem usar nome do serviço
        for localhost_ref in "${!SERVICE_MAP[@]}"; do
            service_name="${SERVICE_MAP[$localhost_ref]}"
            sed -i "s|$localhost_ref|$service_name|g" "$file"
        done
        
        # Casos específicos
        sed -i 's|localhost:5000/qwen-mcp-api|registry:5000/qwen-mcp-api|g' "$file"
        sed -i 's|http://localhost/|http://127.0.0.1/|g' "$file"
        
        ((FILES_CHANGED++))
        CHANGES_IN_FILE=$(grep -c "127.0.0.1" "$file" 2>/dev/null || echo 0)
        FIXED=$((FIXED + CHANGES_IN_FILE))
        
        if [ $CHANGES_IN_FILE -gt 0 ]; then
            echo "  ✅ Corrigido: $(basename $file) ($CHANGES_IN_FILE referências)"
        fi
    fi
done

echo ""
echo "📌 Verificando correções..."

# Verificar se ainda existem referências problemáticas
REMAINING=$(find stacks/ -name "*.yml" ! -path "*/deprecated/*" -exec grep -l "localhost" {} \; 2>/dev/null | wc -l)

if [ $REMAINING -gt 0 ]; then
    echo "  ⚠️  Ainda existem $REMAINING arquivos com 'localhost'"
    echo "  Estas podem ser referências válidas em comentários ou variáveis"
else
    echo "  ✅ Todas as referências localhost foram corrigidas"
fi

echo ""
echo "======================================"
echo "📊 Resultado da correção de localhost:"
echo "  ✅ Arquivos modificados: $FILES_CHANGED"
echo "  ✅ Referências corrigidas: ~$FIXED"
echo "  📁 Backup salvo em: backups/localhost-fixes/"
echo "======================================"