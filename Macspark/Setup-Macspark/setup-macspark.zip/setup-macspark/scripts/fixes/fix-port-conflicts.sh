#!/bin/bash

echo "🔧 Corrigindo conflitos de porta..."
echo "======================================="

FIXED=0
COMMENTED=0

# Primeiro, comentar todas as portas 80/443 exceto no Traefik
echo "📌 Etapa 1: Desabilitando portas 80/443 em serviços não-Traefik..."
find stacks/ -name "*.yml" ! -path "*/deprecated/*" | while read -r file; do
    filename=$(basename "$file")
    dirname=$(basename $(dirname "$file"))
    
    # Pular arquivos do Traefik
    if [[ "$filename" == "traefik"* ]] || [[ "$dirname" == "traefik" ]]; then
        continue
    fi
    
    # Verificar se tem porta 80 ou 443
    if grep -qE "^\s*-\s*(\")?80:80|^\s*-\s*(\")?443:443" "$file"; then
        echo "  Corrigindo: $file"
        
        # Comentar portas 80 e 443
        sed -i 's/^\(\s*\)-\s*"*80:80/\1# - 80:80  # Exposto via Traefik/g' "$file"
        sed -i 's/^\(\s*\)-\s*"*443:443/\1# - 443:443  # Exposto via Traefik/g' "$file"
        sed -i 's/^\(\s*\)-\s*"*0\.0\.0\.0:80:80/\1# - 0.0.0.0:80:80  # Exposto via Traefik/g' "$file"
        sed -i 's/^\(\s*\)-\s*"*0\.0\.0\.0:443:443/\1# - 0.0.0.0:443:443  # Exposto via Traefik/g' "$file"
        
        ((COMMENTED++))
    fi
done

echo "  ✅ $COMMENTED arquivos corrigidos para portas 80/443"
echo ""

# Corrigir conflitos em outras portas comuns
echo "📌 Etapa 2: Resolvendo conflitos em outras portas..."

# Mapa de serviços e suas portas únicas
declare -A SERVICE_PORTS=(
    ["prometheus-modern"]="9090"
    ["prometheus"]="9091"  # Segunda instância em porta diferente
    ["grafana"]="3000"
    ["grafana-loki"]="3001"  # Segunda instância
    ["minio"]="9000"
    ["sonarqube"]="9001"  # Mudar para evitar conflito com Minio
    ["portainer"]="9002"  # Mudar para evitar conflito
)

# Aplicar correções específicas
for service in "${!SERVICE_PORTS[@]}"; do
    port="${SERVICE_PORTS[$service]}"
    
    # Buscar arquivo do serviço
    file=$(find stacks/ -name "${service}*.yml" ! -path "*/deprecated/*" | head -1)
    
    if [ -n "$file" ] && [ -f "$file" ]; then
        # Extrair porta original
        original_port=$(grep -oE "^\s*-\s*[0-9]+:" "$file" | head -1 | grep -oE "[0-9]+" | head -1)
        
        if [ -n "$original_port" ] && [ "$original_port" != "$port" ]; then
            echo "  Ajustando $service: porta $original_port → $port"
            sed -i "s/^\(\s*-\s*\)${original_port}:/\1${port}:/" "$file"
            ((FIXED++))
        fi
    fi
done

echo "  ✅ $FIXED conflitos de porta resolvidos"
echo ""

# Verificar portas duplicadas restantes
echo "📌 Etapa 3: Verificando portas duplicadas restantes..."
DUPLICATES=$(find stacks/ -name "*.yml" ! -path "*/deprecated/*" | xargs grep -h "^\s*-\s*[0-9]" | grep -oE "[0-9]+:" | cut -d: -f1 | sort | uniq -c | sort -rn | awk '$1 > 1 {print $2}' | head -5)

if [ -n "$DUPLICATES" ]; then
    echo "  ⚠️  Ainda existem portas duplicadas:"
    echo "$DUPLICATES" | while read port; do
        count=$(find stacks/ -name "*.yml" ! -path "*/deprecated/*" | xargs grep -c "^\s*-\s*${port}:" | grep -v ":0$" | wc -l)
        echo "    - Porta $port usada por $count serviços"
    done
else
    echo "  ✅ Nenhuma porta duplicada detectada"
fi

echo ""
echo "======================================="
echo "📊 Resultado da correção de portas:"
echo "  ✅ Portas 80/443 comentadas: $COMMENTED serviços"
echo "  ✅ Outras portas ajustadas: $FIXED serviços"
echo "======================================="