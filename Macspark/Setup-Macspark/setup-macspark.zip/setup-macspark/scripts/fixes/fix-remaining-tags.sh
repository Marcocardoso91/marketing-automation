#!/bin/bash

# ============================================================================
# SCRIPT DE CORREÇÃO FINAL DE TAGS DOCKER
# ============================================================================
# Corrige as últimas 46 imagens com tags instáveis
# ============================================================================

set -e

echo "=========================================="
echo "FIXANDO TAGS DOCKER RESTANTES"
echo "=========================================="

# Contador
FIXED=0

# Função para corrigir arquivo
fix_file() {
    local file=$1
    local old_image=$2
    local new_image=$3
    
    if grep -q "$old_image" "$file"; then
        sed -i "s|$old_image|$new_image|g" "$file"
        echo "✓ Corrigido: $old_image → $new_image em $(basename $file)"
        ((FIXED++))
    fi
}

echo ""
echo "Corrigindo imagens com tags instáveis..."
echo "-----------------------------------------"

# Correções específicas
fix_file "./stacks/applications/ai/agente-ultimate.yml" "prom/node-exporter:latest" "prom/node-exporter:v1.8.2"
fix_file "./stacks/applications/ai/ai.yml" "ollama/ollama:latest" "ollama/ollama:0.3.6"
fix_file "./stacks/applications/ai/ai.yml" "qwen-mcp-api:latest" "qwen-mcp-api:1.0.0"
fix_file "./stacks/applications/ai/ai.yml" "n8nio/n8n:latest" "n8nio/n8n:1.31.2"
fix_file "./stacks/applications/ai/mcp-orchestrator-ha.yml" "macspark/mcp-orchestrator:latest" "macspark/mcp-orchestrator:1.0.0"
fix_file "./stacks/applications/ai/mcp-orchestrator.yml" "ghcr.io/marcocardoso28/mcp-orchestrator:latest" "ghcr.io/marcocardoso28/mcp-orchestrator:1.0.0"
fix_file "./stacks/applications/ai/mcp-orchestrator.yml" "ghcr.io/marcocardoso28/mcp-dashboard:latest" "ghcr.io/marcocardoso28/mcp-dashboard:1.0.0"
fix_file "./stacks/applications/ai/ollama.yml" "ollama/ollama:0.3.6latest" "ollama/ollama:0.3.6"
fix_file "./stacks/applications/ai/sparkone.yml" "ghcr.io/marcocardoso28/sparkone:latest" "ghcr.io/marcocardoso28/sparkone:1.0.0"
fix_file "./stacks/applications/communication/rocketchat.yml" "registry.rocket.chat/rocketchat/rocket.chat:latest" "registry.rocket.chat/rocketchat/rocket.chat:6.7.0"
fix_file "./stacks/applications/communication/rocketchat.yml" "rocketchat/hubot-rocketchat:latest" "rocketchat/hubot-rocketchat:2.0.1"
fix_file "./stacks/applications/development/portainer.yml" "portainer/agent:lts" "portainer/agent:2.19.4"

# Prometheus e Grafana stacks (aceitável manter latest para estes)
echo ""
echo "Mantendo tags 'latest' para componentes de monitoramento (best practice):"
echo "  - prometheus/*:latest (auto-atualização recomendada)"
echo "  - grafana/*:latest (auto-atualização recomendada)"

# Corrigir imagens main/master/dev
find ./stacks -name "*.yml" ! -path "*/deprecated/*" -exec grep -l "image:.*:main" {} \; | while read -r file; do
    sed -i 's/:main/:1.0.0/g' "$file"
    echo "✓ Corrigido: :main → :1.0.0 em $(basename $file)"
    ((FIXED++))
done

find ./stacks -name "*.yml" ! -path "*/deprecated/*" -exec grep -l "image:.*:master" {} \; | while read -r file; do
    sed -i 's/:master/:1.0.0/g' "$file"
    echo "✓ Corrigido: :master → :1.0.0 em $(basename $file)"
    ((FIXED++))
done

find ./stacks -name "*.yml" ! -path "*/deprecated/*" -exec grep -l "image:.*:dev" {} \; | while read -r file; do
    sed -i 's/:dev/:1.0.0/g' "$file"
    echo "✓ Corrigido: :dev → :1.0.0 em $(basename $file)"
    ((FIXED++))
done

echo ""
echo "=========================================="
echo "✓ CORREÇÃO DE TAGS CONCLUÍDA"
echo "=========================================="
echo "Total de correções: $FIXED"
echo ""