#!/bin/bash

echo "🔧 Corrigindo erros de sintaxe YAML..."
echo "======================================="

FIXED=0
FAILED=0
TOTAL=0

# Encontrar e corrigir YAMLs com problemas
find . -type f \( -name "*.yml" -o -name "*.yaml" \) ! -path "./.git/*" ! -path "./stacks-backup-*/*" | while read -r file; do
    ((TOTAL++))
    
    # Tentar validar
    if ! python3 -c "import yaml; yaml.safe_load(open('$file'))" 2>/dev/null; then
        echo "❌ Erro encontrado em: $file"
        
        # Fazer backup
        cp "$file" "$file.broken"
        
        # Aplicar correções comuns
        # 1. Remove espaços em branco no final
        sed -i 's/[[:space:]]*$//' "$file"
        
        # 2. Corrige tabs para espaços
        sed -i 's/\t/  /g' "$file"
        
        # 3. Remove caracteres invisíveis/não-ASCII
        LC_ALL=C sed -i 's/[^[:print:]\n\t]//g' "$file"
        
        # 4. Corrige indentação de listas
        sed -i 's/^-/  -/g' "$file"
        sed -i 's/^  -    /    - /g' "$file"
        
        # 5. Remove linhas vazias múltiplas
        sed -i '/^$/N;/\n$/d' "$file"
        
        # Validar novamente
        if python3 -c "import yaml; yaml.safe_load(open('$file'))" 2>/dev/null; then
            echo "✅ Corrigido automaticamente: $file"
            rm "$file.broken"
            ((FIXED++))
        else
            echo "⚠️  Requer correção manual: $file"
            echo "    Backup salvo em: $file.broken"
            mv "$file.broken" "$file"
            ((FAILED++))
        fi
    fi
done

echo ""
echo "======================================="
echo "📊 Resultado da correção de YAMLs:"
echo "   Total analisados: $TOTAL"
echo "   ✅ Corrigidos: $FIXED"
echo "   ⚠️  Requerem correção manual: $FAILED"
echo "======================================="

if [ $FAILED -gt 0 ]; then
    echo ""
    echo "⚠️  Arquivos que precisam de correção manual:"
    find . -name "*.yml.broken" -o -name "*.yaml.broken" | while read -r f; do
        echo "   - ${f%.broken}"
    done
fi