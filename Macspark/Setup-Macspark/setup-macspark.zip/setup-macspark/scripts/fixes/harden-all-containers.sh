#!/bin/bash

# ============================================================================
# SCRIPT DE HARDENING COMPLETO PARA CONTAINERS
# ============================================================================
# Implementa hardening de segurança enterprise em todos os serviços Docker
# - Security contexts e capabilities
# - Read-only root filesystems
# - User namespaces
# - Resource constraints
# - Health checks
# ============================================================================

set -e

echo "==========================================="
echo "🔒 HARDENING ENTERPRISE DE CONTAINERS"
echo "==========================================="

FIXED=0
TOTAL_FILES=0

# Função para aplicar hardening em arquivo
harden_containers_in_file() {
    local file=$1
    local file_changed=false
    
    echo "🛡️ Aplicando hardening: $(basename "$file")"
    
    # Backup do arquivo original
    cp "$file" "$file.bak"
    
    # Aplicar security_opt padrão
    if ! grep -q "security_opt:" "$file" 2>/dev/null; then
        # Adicionar security_opt após cada definição de serviço
        sed -i '/^  [a-zA-Z0-9_-]*:$/a\    security_opt:\n      - no-new-privileges:true\n      - apparmor:docker-default' "$file"
        file_changed=true
        echo "  ✓ Security opts aplicados"
    fi
    
    # Aplicar read-only root filesystem para serviços seguros
    if ! grep -q "read_only:" "$file" 2>/dev/null; then
        # Adicionar read_only para serviços que suportam
        if [[ "$file" =~ (monitoring|security|backup) ]]; then
            sed -i '/security_opt:/a\    read_only: true' "$file"
            file_changed=true
            echo "  ✓ Read-only filesystem aplicado"
        fi
    fi
    
    # Aplicar user namespacing
    if ! grep -q "user:" "$file" 2>/dev/null; then
        # Definir usuário não-root quando possível
        sed -i '/security_opt:/a\    user: "1000:1000"' "$file"
        file_changed=true
        echo "  ✓ User namespacing aplicado"
    fi
    
    # Remover capabilities desnecessárias
    if ! grep -q "cap_drop:" "$file" 2>/dev/null; then
        sed -i '/security_opt:/a\    cap_drop:\n      - ALL' "$file"
        file_changed=true
        echo "  ✓ Capabilities removidas"
    fi
    
    # Adicionar capabilities apenas quando necessário
    if [[ "$file" =~ (traefik|nginx) ]] && ! grep -q "cap_add:" "$file" 2>/dev/null; then
        sed -i '/cap_drop:/a\    cap_add:\n      - NET_BIND_SERVICE' "$file"
        file_changed=true
        echo "  ✓ Capabilities necessárias adicionadas"
    fi
    
    # Aplicar tmpfs para diretórios temporários
    if ! grep -q "tmpfs:" "$file" 2>/dev/null; then
        sed -i '/user:/a\    tmpfs:\n      - /tmp:noexec,nosuid,size=100m\n      - /var/tmp:noexec,nosuid,size=100m' "$file"
        file_changed=true
        echo "  ✓ Tmpfs seguro configurado"
    fi
    
    # Aplicar resource limits se não existirem
    if ! grep -q "deploy:" "$file" 2>/dev/null; then
        cat >> "$file" << 'EOL'
    deploy:
      resources:
        limits:
          cpus: '1.0'
          memory: 512M
        reservations:
          cpus: '0.1'
          memory: 128M
      restart_policy:
        condition: on-failure
        delay: 5s
        max_attempts: 3
        window: 120s
      update_config:
        parallelism: 1
        delay: 10s
        failure_action: rollback
        order: start-first
EOL
        file_changed=true
        echo "  ✓ Resource limits aplicados"
    fi
    
    # Adicionar health checks básicos
    if ! grep -q "healthcheck:" "$file" 2>/dev/null; then
        # Health check genérico baseado no tipo de serviço
        if [[ "$file" =~ postgres ]]; then
            sed -i '/tmpfs:/a\    healthcheck:\n      test: ["CMD-SHELL", "pg_isready -U postgres"]\n      interval: 30s\n      timeout: 10s\n      retries: 3\n      start_period: 60s' "$file"
        elif [[ "$file" =~ redis ]]; then
            sed -i '/tmpfs:/a\    healthcheck:\n      test: ["CMD", "redis-cli", "ping"]\n      interval: 30s\n      timeout: 10s\n      retries: 3\n      start_period: 30s' "$file"
        elif [[ "$file" =~ (nginx|traefik|web) ]]; then
            sed -i '/tmpfs:/a\    healthcheck:\n      test: ["CMD", "wget", "--no-verbose", "--tries=1", "--spider", "http://localhost/"]\n      interval: 30s\n      timeout: 10s\n      retries: 3\n      start_period: 30s' "$file"
        else
            sed -i '/tmpfs:/a\    healthcheck:\n      test: ["CMD-SHELL", "ps aux | grep -v grep | grep -q $0 || exit 1"]\n      interval: 60s\n      timeout: 10s\n      retries: 3\n      start_period: 60s' "$file"
        fi
        file_changed=true
        echo "  ✓ Health check configurado"
    fi
    
    # Aplicar logging controlado
    if ! grep -q "logging:" "$file" 2>/dev/null; then
        sed -i '/healthcheck:/a\    logging:\n      driver: "json-file"\n      options:\n        max-size: "10m"\n        max-file: "3"' "$file"
        file_changed=true
        echo "  ✓ Logging configurado"
    fi
    
    # Adicionar labels de segurança
    if ! grep -q "security.scan" "$file" 2>/dev/null; then
        sed -i '/logging:/a\    labels:\n      - "security.scan=required"\n      - "compliance.level=high"\n      - "backup.required=true"' "$file"
        file_changed=true
        echo "  ✓ Labels de segurança adicionados"
    fi
    
    # Validar sintaxe YAML
    if command -v docker-compose >/dev/null 2>&1; then
        if ! docker-compose -f "$file" config >/dev/null 2>&1; then
            echo "  ❌ Erro de sintaxe YAML - restaurando backup"
            mv "$file.bak" "$file"
            file_changed=false
        else
            rm "$file.bak"
        fi
    else
        rm "$file.bak"
    fi
    
    if [ "$file_changed" = true ]; then
        ((FIXED++))
        echo "  ✅ $(basename "$file") protegido com hardening"
    fi
}

# Processar todos os arquivos YAML
echo ""
echo "Aplicando hardening em stacks..."
echo "--------------------------------"

find ./stacks -name "*.yml" -type f ! -path "*/deprecated/*" | while read -r file; do
    ((TOTAL_FILES++))
    harden_containers_in_file "$file"
done

# Processar configs
find ./configs -name "*.yml" -type f ! -path "*/deprecated/*" | while read -r file; do
    ((TOTAL_FILES++))
    harden_containers_in_file "$file"
done

# Criar arquivo de configurações de hardening padrão
cat > "./configs/hardening-defaults.yml" << 'EOF'
# ============================================================================
# CONFIGURAÇÕES DE HARDENING PADRÃO - MACSPARK ENTERPRISE
# ============================================================================
# Configurações de segurança aplicadas a todos os containers
# Baseado em CIS Docker Benchmark e NIST Container Security Guidelines
# ============================================================================

version: '3.8'

# ============================================================================
# SECURITY CONTEXT PADRÃO
# ============================================================================
x-security-defaults: &security-defaults
  security_opt:
    - no-new-privileges:true
    - apparmor:docker-default
    - seccomp:unconfined  # Apenas se necessário
  cap_drop:
    - ALL
  read_only: false  # Ajustar por serviço
  user: "1000:1000"  # Non-root user

# ============================================================================
# RESOURCE LIMITS PADRÃO
# ============================================================================
x-resource-defaults: &resource-defaults
  deploy:
    resources:
      limits:
        cpus: '1.0'
        memory: 512M
        pids: 100
      reservations:
        cpus: '0.1' 
        memory: 128M
    restart_policy:
      condition: on-failure
      delay: 5s
      max_attempts: 3
      window: 120s
    update_config:
      parallelism: 1
      delay: 10s
      failure_action: rollback
      order: start-first

# ============================================================================
# TMPFS SEGURO
# ============================================================================
x-tmpfs-defaults: &tmpfs-defaults
  tmpfs:
    - /tmp:noexec,nosuid,nodev,size=100m
    - /var/tmp:noexec,nosuid,nodev,size=100m

# ============================================================================
# LOGGING CONTROLADO
# ============================================================================
x-logging-defaults: &logging-defaults
  logging:
    driver: "json-file"
    options:
      max-size: "10m"
      max-file: "3"
      labels: "service,version,environment"

# ============================================================================
# HEALTH CHECKS POR TIPO DE SERVIÇO
# ============================================================================
x-healthcheck-web: &healthcheck-web
  healthcheck:
    test: ["CMD", "wget", "--no-verbose", "--tries=1", "--spider", "http://localhost/"]
    interval: 30s
    timeout: 10s
    retries: 3
    start_period: 30s

x-healthcheck-database: &healthcheck-database
  healthcheck:
    test: ["CMD-SHELL", "pg_isready"]
    interval: 30s
    timeout: 10s
    retries: 3
    start_period: 60s

x-healthcheck-cache: &healthcheck-cache
  healthcheck:
    test: ["CMD", "redis-cli", "ping"]
    interval: 30s
    timeout: 10s
    retries: 3
    start_period: 30s

# ============================================================================
# LABELS DE COMPLIANCE
# ============================================================================
x-compliance-labels: &compliance-labels
  labels:
    - "security.scan=required"
    - "compliance.level=high"
    - "backup.required=true"
    - "monitoring.enabled=true"
    - "hardening.applied=true"
    - "version.pinned=true"

# ============================================================================
# CONFIGURAÇÕES ESPECÍFICAS POR CATEGORIA
# ============================================================================

# Serviços de alta exposição (Traefik, Nginx)
x-exposed-service: &exposed-service
  <<: *security-defaults
  <<: *resource-defaults
  <<: *tmpfs-defaults
  <<: *logging-defaults
  <<: *healthcheck-web
  <<: *compliance-labels
  cap_add:
    - NET_BIND_SERVICE
  read_only: true

# Serviços de database
x-database-service: &database-service
  <<: *security-defaults
  <<: *resource-defaults
  <<: *logging-defaults
  <<: *healthcheck-database
  <<: *compliance-labels
  read_only: false  # Databases precisam escrever

# Serviços de monitoramento
x-monitoring-service: &monitoring-service
  <<: *security-defaults
  <<: *resource-defaults
  <<: *tmpfs-defaults
  <<: *logging-defaults
  <<: *compliance-labels
  read_only: true

# ============================================================================
# EXEMPLO DE USO
# ============================================================================
# services:
#   web-service:
#     <<: *exposed-service
#     image: nginx:1.27-alpine
#     ports:
#       - "80:80"
#
#   database:
#     <<: *database-service
#     image: postgres:16.4-alpine
#     volumes:
#       - db_data:/var/lib/postgresql/data
# ============================================================================
EOF

echo ""
echo "🔧 Criando scripts de validação de hardening..."

# Script de validação de hardening
cat > "./scripts/validation/validate-hardening.sh" << 'EOF'
#!/bin/bash

# ============================================================================
# VALIDAÇÃO DE HARDENING DE CONTAINERS
# ============================================================================

set -e

echo "🔍 VALIDAÇÃO DE HARDENING ENTERPRISE"
echo "===================================="

TOTAL_FILES=0
COMPLIANT_FILES=0
ISSUES_FOUND=0

validate_file_hardening() {
    local file=$1
    local issues=0
    
    echo "📄 Validando: $(basename "$file")"
    
    # Verificar security_opt
    if ! grep -q "security_opt:" "$file" 2>/dev/null; then
        echo "  ❌ Security opts não configurados"
        ((issues++))
    fi
    
    # Verificar capabilities
    if ! grep -q "cap_drop:" "$file" 2>/dev/null; then
        echo "  ❌ Capabilities não restringidas"
        ((issues++))
    fi
    
    # Verificar resource limits
    if ! grep -q "resources:" "$file" 2>/dev/null; then
        echo "  ❌ Resource limits não definidos"
        ((issues++))
    fi
    
    # Verificar health checks
    if ! grep -q "healthcheck:" "$file" 2>/dev/null; then
        echo "  ⚠️ Health check não configurado"
        ((issues++))
    fi
    
    # Verificar user namespace
    if ! grep -q "user:" "$file" 2>/dev/null; then
        echo "  ⚠️ User namespace não definido"
        ((issues++))
    fi
    
    if [ $issues -eq 0 ]; then
        echo "  ✅ Totalmente compatível com hardening"
        ((COMPLIANT_FILES++))
    else
        echo "  ⚠️ $issues problemas de hardening encontrados"
        ((ISSUES_FOUND+=issues))
    fi
    
    ((TOTAL_FILES++))
}

# Validar todos os arquivos
find ./stacks -name "*.yml" -type f ! -path "*/deprecated/*" | while read -r file; do
    validate_file_hardening "$file"
done

echo ""
echo "📊 RESUMO DA VALIDAÇÃO DE HARDENING"
echo "=================================="
echo "Arquivos analisados: $TOTAL_FILES"
echo "Arquivos conformes: $COMPLIANT_FILES"
echo "Problemas encontrados: $ISSUES_FOUND"

if [ $ISSUES_FOUND -eq 0 ]; then
    echo "🎉 TODOS OS ARQUIVOS ESTÃO CONFORMES!"
else
    echo "⚠️ $ISSUES_FOUND problemas de hardening precisam ser corrigidos"
fi
EOF

chmod +x ./scripts/validation/validate-hardening.sh

# Validação final
echo ""
echo "🔍 Executando validação de hardening..."
echo "====================================="

./scripts/validation/validate-hardening.sh

echo ""
echo "==========================================="
echo "✅ HARDENING ENTERPRISE FINALIZADO"
echo "==========================================="
echo "📊 Arquivos processados: $TOTAL_FILES"
echo "🔒 Arquivos protegidos: $FIXED"
echo ""
echo "📋 Próximos passos:"
echo "  1. ./scripts/validation/validate-hardening.sh"
echo "  2. ./scripts/fixes/add-resource-limits.sh"
echo "  3. docker system prune -f"
echo ""