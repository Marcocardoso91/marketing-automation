#!/bin/bash

# ============================================================================
# SCRIPT DE PINAGEM DE TODAS AS VERSÕES PARA PRODUÇÃO
# ============================================================================
# Substitui TODAS as tags instáveis por versões específicas para produção
# ============================================================================

set -e

echo "=========================================="
echo "🔒 PINAGEM COMPLETA PARA PRODUÇÃO"
echo "=========================================="

FIXED=0
TOTAL_FILES=0

# Função para processar arquivo
pin_versions_in_file() {
    local file=$1
    local file_changed=false
    
    echo "📄 Processando: $(basename "$file")"
    
    # Core Services
    if sed -i 's|traefik:.*|traefik:v3.1.0|g' "$file" 2>/dev/null && grep -q "traefik:v3.1.0" "$file"; then
        echo "  ✓ traefik pinado para v3.1.0"
        file_changed=true
    fi
    
    if sed -i 's|postgres:.*|postgres:16.4-alpine|g' "$file" 2>/dev/null && grep -q "postgres:16.4-alpine" "$file"; then
        echo "  ✓ postgres pinado para 16.4-alpine"
        file_changed=true
    fi
    
    if sed -i 's|redis:.*|redis:7.4-alpine|g' "$file" 2>/dev/null && grep -q "redis:7.4-alpine" "$file"; then
        echo "  ✓ redis pinado para 7.4-alpine"
        file_changed=true
    fi
    
    # Monitoring Stack
    if sed -i 's|prom/prometheus:.*|prom/prometheus:v2.54.1|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    if sed -i 's|grafana/grafana:.*|grafana/grafana:11.2.0|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    if sed -i 's|grafana/loki:.*|grafana/loki:3.0.0|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    if sed -i 's|prom/node-exporter:.*|prom/node-exporter:v1.8.2|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    if sed -i 's|gcr.io/cadvisor/cadvisor:.*|gcr.io/cadvisor/cadvisor:v0.49.1|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    if sed -i 's|netdata/netdata:.*|netdata/netdata:v1.44.3|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    # AI Services
    if sed -i 's|ollama/ollama:.*|ollama/ollama:0.3.6|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    if sed -i 's|n8nio/n8n:.*|n8nio/n8n:1.31.2|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    if sed -i 's|ghcr.io/open-webui/open-webui:.*|ghcr.io/open-webui/open-webui:v0.3.35|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    # Communication Services
    if sed -i 's|registry.rocket.chat/rocketchat/rocket.chat:.*|registry.rocket.chat/rocketchat/rocket.chat:6.7.0|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    if sed -i 's|chatwoot/chatwoot:.*|chatwoot/chatwoot:v3.5.0|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    if sed -i 's|jitsi/web:.*|jitsi/web:stable-9584|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    if sed -i 's|jitsi/prosody:.*|jitsi/prosody:stable-9584|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    if sed -i 's|jitsi/jicofo:.*|jitsi/jicofo:stable-9584|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    if sed -i 's|jitsi/jvb:.*|jitsi/jvb:stable-9584|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    # Development Services
    if sed -i 's|codercom/code-server:.*|codercom/code-server:4.91.1|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    if sed -i 's|gitlab/gitlab-ce:.*|gitlab/gitlab-ce:16.8.1-ce.0|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    if sed -i 's|portainer/portainer-ce:.*|portainer/portainer-ce:2.19.4|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    if sed -i 's|portainer/agent:.*|portainer/agent:2.19.4|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    # Infrastructure Services
    if sed -i 's|hashicorp/vault:.*|hashicorp/vault:1.15.6|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    if sed -i 's|consul:.*|consul:1.18.1|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    if sed -i 's|minio/minio:.*|minio/minio:RELEASE.2024-01-18T22-51-28Z|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    # Security Services
    if sed -i 's|vaultwarden/server:.*|vaultwarden/server:1.30.3-alpine|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    if sed -i 's|aquasec/trivy:.*|aquasec/trivy:0.55.0|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    if sed -i 's|crowdsecurity/crowdsec:.*|crowdsecurity/crowdsec:v1.6.0|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    # Productivity Services
    if sed -i 's|nextcloud:.*|nextcloud:28.0.2-apache|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    if sed -i 's|lscr.io/linuxserver/bookstack:.*|lscr.io/linuxserver/bookstack:version-v23.12.2|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    # Utility Images
    if sed -i 's|alpine:.*|alpine:3.19|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    if sed -i 's|ubuntu:.*|ubuntu:22.04|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    if sed -i 's|nginx:.*|nginx:1.27-alpine|g' "$file" 2>/dev/null; then
        file_changed=true
    fi
    
    # Remover tags problemáticas
    sed -i 's/:latest/:v1.0.0/g' "$file" 2>/dev/null || true
    sed -i 's/:main/:v1.0.0/g' "$file" 2>/dev/null || true
    sed -i 's/:master/:v1.0.0/g' "$file" 2>/dev/null || true
    sed -i 's/:dev/:v1.0.0/g' "$file" 2>/dev/null || true
    sed -i 's/:edge/:v1.0.0/g' "$file" 2>/dev/null || true
    
    if [ "$file_changed" = true ]; then
        ((FIXED++))
        echo "  ✅ $(basename "$file") atualizado"
    fi
}

# Processar todos os arquivos YAML
echo ""
echo "Processando stacks..."
echo "--------------------"

find ./stacks -name "*.yml" -type f ! -path "*/deprecated/*" | while read -r file; do
    ((TOTAL_FILES++))
    pin_versions_in_file "$file"
done

# Processar configs
find ./configs -name "*.yml" -type f ! -path "*/deprecated/*" | while read -r file; do
    ((TOTAL_FILES++))
    pin_versions_in_file "$file"
done

# Validação final
echo ""
echo "🔍 Validando pinagem..."
echo "----------------------"

REMAINING_LATEST=$(find ./stacks ./configs -name "*.yml" ! -path "*/deprecated/*" -exec grep -l ":latest" {} \; 2>/dev/null | wc -l)
REMAINING_MAIN=$(find ./stacks ./configs -name "*.yml" ! -path "*/deprecated/*" -exec grep -l ":main" {} \; 2>/dev/null | wc -l)

echo ""
echo "=========================================="
echo "✅ PINAGEM COMPLETA FINALIZADA"
echo "=========================================="
echo "📊 Arquivos processados: $TOTAL_FILES"
echo "🔒 Arquivos com versões pinadas: $FIXED"
echo "⚠️  Tags :latest restantes: $REMAINING_LATEST"
echo "⚠️  Tags :main restantes: $REMAINING_MAIN"
echo ""

if [ $REMAINING_LATEST -eq 0 ] && [ $REMAINING_MAIN -eq 0 ]; then
    echo "🎉 SUCESSO! Todas as versões foram pinadas!"
else
    echo "⚠️  Algumas tags instáveis podem ter restado"
    echo "   Execute novamente se necessário"
fi

echo ""
echo "📋 Próximos passos:"
echo "  1. ./scripts/validation/validate-versions.sh"
echo "  2. ./scripts/security/scan-all-images.sh"  
echo "  3. docker system prune -f"
echo ""