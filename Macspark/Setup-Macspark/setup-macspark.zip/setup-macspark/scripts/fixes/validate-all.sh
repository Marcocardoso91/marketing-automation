#!/bin/bash

echo "=========================================="
echo "🔍 VALIDAÇÃO FINAL DO PROJETO SETUP-MACSPARK"
echo "=========================================="
echo ""

ERRORS=0
WARNINGS=0
SUCCESS=0

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# 1. Validar YAMLs
echo "📄 1. Validando sintaxe YAML..."
YAML_ERRORS=0
find . -type f \( -name "*.yml" -o -name "*.yaml" \) ! -path "./.git/*" ! -path "./stacks-backup*/*" ! -path "*/deprecated/*" | while read -r file; do
    if ! python3 -c "import yaml; yaml.safe_load(open('$file'))" 2>/dev/null; then
        echo -e "   ${RED}❌ Erro em: $file${NC}"
        ((YAML_ERRORS++))
    fi
done

if [ $YAML_ERRORS -eq 0 ]; then
    echo -e "   ${GREEN}✅ Todos os YAMLs válidos${NC}"
    ((SUCCESS++))
else
    echo -e "   ${RED}❌ $YAML_ERRORS YAMLs com erro${NC}"
    ((ERRORS++))
fi

# 2. Verificar secrets expostos
echo ""
echo "🔒 2. Verificando secrets expostos..."
SECRETS_FOUND=$(find . -name "*.env" ! -name "*.example" ! -name "*.template" ! -path "./.git/*" | wc -l)
if [ $SECRETS_FOUND -eq 0 ]; then
    echo -e "   ${GREEN}✅ Nenhum secret exposto${NC}"
    ((SUCCESS++))
else
    echo -e "   ${RED}❌ $SECRETS_FOUND arquivos .env encontrados!${NC}"
    find . -name "*.env" ! -name "*.example" ! -name "*.template" ! -path "./.git/*"
    ((ERRORS++))
fi

# 3. Verificar permissões de scripts
echo ""
echo "🔧 3. Verificando permissões de scripts..."
SCRIPTS_NO_EXEC=$(find . -name "*.sh" ! -executable | wc -l)
if [ $SCRIPTS_NO_EXEC -eq 0 ]; then
    echo -e "   ${GREEN}✅ Todos os scripts executáveis${NC}"
    ((SUCCESS++))
else
    echo -e "   ${YELLOW}⚠️  $SCRIPTS_NO_EXEC scripts sem permissão de execução${NC}"
    ((WARNINGS++))
fi

# 4. Verificar diretórios vazios
echo ""
echo "📁 4. Verificando diretórios vazios..."
EMPTY_DIRS=$(find . -type d -empty ! -path "./.git/*" | wc -l)
if [ $EMPTY_DIRS -lt 5 ]; then
    echo -e "   ${GREEN}✅ Apenas $EMPTY_DIRS diretórios vazios (aceitável)${NC}"
    ((SUCCESS++))
else
    echo -e "   ${YELLOW}⚠️  $EMPTY_DIRS diretórios vazios${NC}"
    ((WARNINGS++))
fi

# 5. Verificar configuração de HA
echo ""
echo "🔄 5. Verificando Alta Disponibilidade..."
SINGLE_REPLICA=$(grep -r "replicas: 1" stacks/ --include="*.yml" | grep -E "traefik|postgres|redis|prometheus|grafana" | wc -l)
if [ $SINGLE_REPLICA -eq 0 ]; then
    echo -e "   ${GREEN}✅ Serviços críticos com HA configurado${NC}"
    ((SUCCESS++))
else
    echo -e "   ${YELLOW}⚠️  $SINGLE_REPLICA serviços críticos sem HA${NC}"
    ((WARNINGS++))
fi

# 6. Verificar resource limits
echo ""
echo "📊 6. Verificando Resource Limits..."
NO_RESOURCES=$(find stacks/ -name "*.yml" ! -path "*/deprecated/*" -exec grep -l "deploy:" {} \; | xargs grep -L "resources:" | wc -l)
if [ $NO_RESOURCES -eq 0 ]; then
    echo -e "   ${GREEN}✅ Todos os serviços com resource limits${NC}"
    ((SUCCESS++))
else
    echo -e "   ${YELLOW}⚠️  $NO_RESOURCES serviços sem resource limits${NC}"
    ((WARNINGS++))
fi

# 7. Verificar health checks
echo ""
echo "🏥 7. Verificando Health Checks..."
WITH_HEALTHCHECK=$(find stacks/ -name "*.yml" ! -path "*/deprecated/*" -exec grep -l "healthcheck:" {} \; | wc -l)
TOTAL_SERVICES=$(find stacks/ -name "*.yml" ! -path "*/deprecated/*" | wc -l)
if [ $WITH_HEALTHCHECK -gt 40 ]; then
    echo -e "   ${GREEN}✅ $WITH_HEALTHCHECK/$TOTAL_SERVICES serviços com health checks${NC}"
    ((SUCCESS++))
else
    echo -e "   ${YELLOW}⚠️  Apenas $WITH_HEALTHCHECK/$TOTAL_SERVICES serviços com health checks${NC}"
    ((WARNINGS++))
fi

# 8. Verificar versão Docker Compose
echo ""
echo "🐳 8. Verificando versões Docker Compose..."
OLD_VERSIONS=$(find . -name "*.yml" -o -name "*.yaml" ! -path "*/deprecated/*" | xargs grep -h "^version:" | grep -v "3.9" | wc -l)
if [ $OLD_VERSIONS -eq 0 ]; then
    echo -e "   ${GREEN}✅ Todas as versões padronizadas em 3.9${NC}"
    ((SUCCESS++))
else
    echo -e "   ${YELLOW}⚠️  $OLD_VERSIONS arquivos com versão diferente de 3.9${NC}"
    ((WARNINGS++))
fi

# 9. Verificar TODOs pendentes
echo ""
echo "📝 9. Verificando TODOs/FIXMEs..."
TODOS=$(grep -r "TODO\|FIXME" --include="*.sh" --include="*.yml" --include="*.yaml" . 2>/dev/null | wc -l)
if [ $TODOS -lt 10 ]; then
    echo -e "   ${GREEN}✅ Apenas $TODOS TODOs (aceitável)${NC}"
    ((SUCCESS++))
else
    echo -e "   ${YELLOW}⚠️  $TODOS TODOs/FIXMEs pendentes${NC}"
    ((WARNINGS++))
fi

# 10. Verificar estrutura de diretórios
echo ""
echo "🏗️ 10. Verificando estrutura de diretórios..."
REQUIRED_DIRS=("stacks" "scripts" "docs" "configs" "environments" "templates")
MISSING_DIRS=0
for dir in "${REQUIRED_DIRS[@]}"; do
    if [ ! -d "$dir" ]; then
        echo -e "   ${RED}❌ Diretório ausente: $dir${NC}"
        ((MISSING_DIRS++))
    fi
done

if [ $MISSING_DIRS -eq 0 ]; then
    echo -e "   ${GREEN}✅ Estrutura de diretórios correta${NC}"
    ((SUCCESS++))
else
    ((ERRORS++))
fi

# Resultado Final
echo ""
echo "=========================================="
echo "📊 RESULTADO DA VALIDAÇÃO"
echo "=========================================="
echo -e "${GREEN}✅ Sucessos: $SUCCESS/10${NC}"
echo -e "${YELLOW}⚠️  Avisos: $WARNINGS${NC}"
echo -e "${RED}❌ Erros: $ERRORS${NC}"
echo ""

if [ $ERRORS -eq 0 ]; then
    echo -e "${GREEN}🎉 PROJETO PRONTO PARA PRODUÇÃO!${NC}"
    echo "Todos os requisitos críticos foram atendidos."
    exit 0
elif [ $ERRORS -lt 3 ]; then
    echo -e "${YELLOW}⚠️  PROJETO QUASE PRONTO${NC}"
    echo "Corrija os $ERRORS erros restantes antes do deploy."
    exit 1
else
    echo -e "${RED}❌ PROJETO NÃO ESTÁ PRONTO${NC}"
    echo "$ERRORS problemas críticos precisam ser corrigidos."
    exit 2
fi