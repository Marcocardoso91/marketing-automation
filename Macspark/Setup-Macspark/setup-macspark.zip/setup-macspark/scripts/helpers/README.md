# Helper Scripts

Scripts auxiliares para manutenção e automação do repositório.

## 🧹 cleanup-gitkeep.sh

Remove automaticamente arquivos `.gitkeep` de pastas que já contêm outros arquivos.

### Uso:

```bash
# Executar na raiz do repositório
./scripts/helpers/cleanup-gitkeep.sh
```

### Como funciona:

1. **Escaneia** todos os arquivos `.gitkeep` no repositório
2. **Verifica** se a pasta contém outros arquivos além do `.gitkeep`
3. **Remove** o `.gitkeep` se houver outros arquivos
4. **Mantém** o `.gitkeep` se a pasta estiver vazia
5. **Oferece** fazer commit automático das alterações

### Exemplo de saída:

```
🧹 Iniciando limpeza de arquivos .gitkeep desnecessários...
🗑️  Removido: ./stacks/core/traefik/.gitkeep (pasta tem 3 arquivo(s))
📁 Mantido: ./stacks/experimental/.gitkeep (pasta vazia)
✅ Limpeza concluída!
📊 Estatísticas:
   🗑️  Removidos: 15 .gitkeep
   📁 Mantidos: 8 .gitkeep
```

### Quando usar:

- **Após migrar** arquivos da VPS para o repositório
- **Periodicamente** durante o desenvolvimento
- **Antes de releases** para manter o repositório limpo
- **Automaticamente** via GitHub Actions (opcional)

### Segurança:

✅ **Seguro de usar** - apenas remove `.gitkeep` desnecessários  
✅ **Preserva estrutura** - mantém pastas vazias importantes  
✅ **Oferece confirmação** antes de fazer commit  
✅ **Log detalhado** de todas as ações