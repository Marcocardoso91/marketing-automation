#!/bin/bash

# Script para remover arquivos .gitkeep desnecessários
# Remove .gitkeep apenas de pastas que já contêm outros arquivos

set -euo pipefail

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Função para logging
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date +'%Y-%m-%d %H:%M:%S')] WARNING: $1${NC}"
}

info() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')] INFO: $1${NC}"
}

# Verificar se estamos no diretório correto
if [[ ! -d ".git" ]]; then
    echo -e "${RED}❌ Este script deve ser executado na raiz do repositório Git${NC}"
    exit 1
fi

log "🧹 Iniciando limpeza de arquivos .gitkeep desnecessários..."

removed_count=0
kept_count=0

# Encontrar todos os arquivos .gitkeep
while IFS= read -r -d '' gitkeep_file; do
    # Obter o diretório do .gitkeep
    dir=$(dirname "$gitkeep_file")
    
    # Contar arquivos no diretório (excluindo .gitkeep)
    file_count=$(find "$dir" -maxdepth 1 -type f ! -name ".gitkeep" | wc -l)
    
    if [[ $file_count -gt 0 ]]; then
        # Há outros arquivos, remover .gitkeep
        rm "$gitkeep_file"
        info "🗑️  Removido: $gitkeep_file (pasta tem $file_count arquivo(s))"
        ((removed_count++))
    else
        # Pasta vazia, manter .gitkeep
        info "📁 Mantido: $gitkeep_file (pasta vazia)"
        ((kept_count++))
    fi
done < <(find . -name ".gitkeep" -type f -print0)

log "✅ Limpeza concluída!"
log "📊 Estatísticas:"
log "   🗑️  Removidos: $removed_count .gitkeep"
log "   📁 Mantidos: $kept_count .gitkeep"

# Se algum arquivo foi removido, oferecer commit
if [[ $removed_count -gt 0 ]]; then
    echo
    warn "💡 $removed_count arquivo(s) .gitkeep foram removidos."
    read -p "Deseja fazer commit das alterações? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        git add .
        git commit -m "chore: remover .gitkeep desnecessários

- Removidos $removed_count arquivos .gitkeep de pastas que já contêm arquivos
- Mantidos $kept_count .gitkeep em pastas vazias para preservar estrutura

🤖 Generated with Claude Code
Co-Authored-By: Claude <noreply@anthropic.com>"
        log "✅ Commit realizado com sucesso!"
    else
        info "ℹ️  Execute 'git add . && git commit' manualmente para commitar as alterações"
    fi
fi

log "🎯 Script concluído!"