#!/bin/bash

# ============================================================================
# SCRIPT DE COMPATIBILIDADE CROSS-PLATFORM
# ============================================================================
# Detecta sistema operacional e ajusta comandos para Windows/macOS/Linux
# ============================================================================

set -e

# Detectar sistema operacional
detect_os() {
    case "$(uname -s)" in
        Linux*)     PLATFORM=Linux ;;
        Darwin*)    PLATFORM=macOS ;;
        CYGWIN*|MINGW*|MSYS*) PLATFORM=Windows ;;
        *)          PLATFORM=Unknown ;;
    esac
    echo "$PLATFORM"
}

# Configurar comandos baseado na plataforma
setup_platform() {
    local platform=$(detect_os)
    
    echo "🖥️ Sistema detectado: $platform"
    
    case "$platform" in
        "Linux")
            DOCKER_CMD="docker"
            YQ_CMD="yq"
            SED_CMD="sed"
            GREP_CMD="grep"
            FIND_CMD="find"
            ;;
        "macOS")
            DOCKER_CMD="docker"
            YQ_CMD="yq"
            SED_CMD="gsed"  # GNU sed no macOS
            GREP_CMD="ggrep" # GNU grep no macOS
            FIND_CMD="gfind" # GNU find no macOS
            
            # Verificar se GNU tools estão instalados
            if ! command -v gsed >/dev/null 2>&1; then
                echo "⚠️ GNU tools não encontrados no macOS"
                echo "Instale com: brew install gnu-sed grep findutils"
                echo "Usando versões BSD (compatibilidade limitada)"
                SED_CMD="sed"
                GREP_CMD="grep"
                FIND_CMD="find"
            fi
            ;;
        "Windows")
            DOCKER_CMD="docker.exe"
            YQ_CMD="yq.exe"
            SED_CMD="sed"
            GREP_CMD="grep"
            FIND_CMD="find"
            
            # Verificar se está no WSL
            if grep -qi microsoft /proc/version 2>/dev/null; then
                echo "✅ WSL detectado - usando comandos Linux"
                PLATFORM="WSL"
                DOCKER_CMD="docker"
            fi
            ;;
    esac
    
    # Exportar variáveis para uso em outros scripts
    export PLATFORM
    export DOCKER_CMD
    export YQ_CMD
    export SED_CMD
    export GREP_CMD
    export FIND_CMD
}

# Função para normalizar paths
normalize_path() {
    local path="$1"
    
    case "$PLATFORM" in
        "Windows")
            # Converter / para \ no Windows
            echo "${path//\//\\}"
            ;;
        *)
            # Manter / nos sistemas Unix
            echo "$path"
            ;;
    esac
}

# Verificar dependências da plataforma
check_dependencies() {
    local missing_deps=()
    
    echo "🔍 Verificando dependências..."
    
    # Docker
    if ! command -v "$DOCKER_CMD" >/dev/null 2>&1; then
        missing_deps+=("docker")
    fi
    
    # YQ para manipulação YAML
    if ! command -v "$YQ_CMD" >/dev/null 2>&1; then
        missing_deps+=("yq")
    fi
    
    # curl para downloads
    if ! command -v curl >/dev/null 2>&1; then
        missing_deps+=("curl")
    fi
    
    if [ ${#missing_deps[@]} -gt 0 ]; then
        echo "❌ Dependências faltando: ${missing_deps[*]}"
        echo ""
        echo "📋 Instruções de instalação:"
        
        case "$PLATFORM" in
            "Linux")
                echo "sudo apt update && sudo apt install -y ${missing_deps[*]}"
                echo "# Para yq: wget -O /usr/local/bin/yq https://github.com/mikefarah/yq/releases/latest/download/yq_linux_amd64 && chmod +x /usr/local/bin/yq"
                ;;
            "macOS")
                echo "brew install ${missing_deps[*]}"
                ;;
            "Windows")
                echo "choco install ${missing_deps[*]}"
                echo "# Ou use o Windows Package Manager: winget install ${missing_deps[*]}"
                ;;
        esac
        
        return 1
    fi
    
    echo "✅ Todas as dependências estão instaladas"
    return 0
}

# Função para executar comandos com compatibilidade
run_compat() {
    local cmd="$1"
    shift
    local args=("$@")
    
    case "$cmd" in
        "docker")
            "$DOCKER_CMD" "${args[@]}"
            ;;
        "yq")
            "$YQ_CMD" "${args[@]}"
            ;;
        "sed")
            "$SED_CMD" "${args[@]}"
            ;;
        "grep")
            "$GREP_CMD" "${args[@]}"
            ;;
        "find")
            "$FIND_CMD" "${args[@]}"
            ;;
        *)
            "$cmd" "${args[@]}"
            ;;
    esac
}

# Auto-setup quando script é executado
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    setup_platform
    check_dependencies
    
    echo ""
    echo "🎯 Configuração Cross-Platform Concluída"
    echo "Platform: $PLATFORM"
    echo "Docker: $DOCKER_CMD"
    echo "YQ: $YQ_CMD"
    echo ""
    echo "Para usar em outros scripts:"
    echo "source scripts/helpers/cross-platform-compat.sh"
    echo "run_compat docker service ls"
fi