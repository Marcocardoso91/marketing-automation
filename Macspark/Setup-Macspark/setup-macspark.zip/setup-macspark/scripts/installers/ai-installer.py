#!/usr/bin/env python3
"""
🤖 MACSPARK AI-POWERED INSTALLER 2025
====================================
Instalador inteligente com auto-detection e recomendações IA
"""

import asyncio
import json
import os
import platform
import psutil
import subprocess
import sys
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
from pathlib import Path
import requests
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.panel import Panel
from rich.prompt import Prompt, Confirm
from rich.table import Table
from rich.text import Text
from rich.tree import Tree
import typer
from pydantic import BaseModel

app = typer.Typer(
    name="macspark-ai",
    help="🤖 Macspark AI-Powered Installer 2025",
    add_completion=False,
    rich_markup_mode="rich"
)

console = Console()

# ============================================================================
# MODELOS DE DADOS
# ============================================================================

@dataclass
class SystemInfo:
    """Informações do sistema detectadas automaticamente"""
    os_name: str
    os_version: str
    architecture: str
    cpu_cores: int
    total_ram_gb: int
    available_disk_gb: int
    docker_installed: bool
    kubernetes_installed: bool
    internet_speed_mbps: Optional[float]
    cloud_provider: Optional[str]
    
class InstallationProfile(BaseModel):
    """Perfil de instalação recomendado pela IA"""
    name: str
    description: str
    services: List[str]
    resource_requirements: Dict[str, str]
    estimated_time_minutes: int
    complexity: str  # "beginner", "intermediate", "advanced"
    use_case: str

class AIRecommendation(BaseModel):
    """Recomendação da IA baseada no sistema"""
    confidence: float  # 0.0 - 1.0
    profile: InstallationProfile
    reasoning: str
    optimizations: List[str]
    warnings: List[str]

# ============================================================================
# DETECÇÃO INTELIGENTE DO SISTEMA
# ============================================================================

class SystemDetector:
    """AI-powered system detection"""
    
    def __init__(self):
        self.console = console
        
    async def detect_system(self) -> SystemInfo:
        """Detecta informações do sistema automaticamente"""
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            transient=True,
            console=self.console
        ) as progress:
            task = progress.add_task("🔍 Detectando configuração do sistema...", total=8)
            
            # OS Info
            os_name = platform.system()
            os_version = platform.release()
            architecture = platform.machine()
            progress.advance(task)
            
            # Hardware
            cpu_cores = psutil.cpu_count(logical=True)
            total_ram_gb = round(psutil.virtual_memory().total / (1024**3))
            available_disk_gb = round(psutil.disk_usage('/').free / (1024**3))
            progress.advance(task)
            
            # Docker detection
            docker_installed = await self._check_docker()
            progress.advance(task)
            
            # Kubernetes detection  
            kubernetes_installed = await self._check_kubernetes()
            progress.advance(task)
            
            # Internet speed test
            internet_speed = await self._test_internet_speed()
            progress.advance(task)
            
            # Cloud provider detection
            cloud_provider = await self._detect_cloud_provider()
            progress.advance(task, 2)
            
        return SystemInfo(
            os_name=os_name,
            os_version=os_version,
            architecture=architecture,
            cpu_cores=cpu_cores,
            total_ram_gb=total_ram_gb,
            available_disk_gb=available_disk_gb,
            docker_installed=docker_installed,
            kubernetes_installed=kubernetes_installed,
            internet_speed_mbps=internet_speed,
            cloud_provider=cloud_provider
        )
    
    async def _check_docker(self) -> bool:
        """Verifica se Docker está instalado"""
        try:
            result = subprocess.run(['docker', '--version'], 
                                 capture_output=True, text=True, timeout=5)
            return result.returncode == 0
        except:
            return False
    
    async def _check_kubernetes(self) -> bool:
        """Verifica se Kubernetes está disponível"""
        try:
            result = subprocess.run(['kubectl', 'version', '--client'], 
                                 capture_output=True, text=True, timeout=5)
            return result.returncode == 0
        except:
            return False
    
    async def _test_internet_speed(self) -> Optional[float]:
        """Teste básico de velocidade de internet"""
        try:
            import time
            start_time = time.time()
            response = requests.get('https://httpbin.org/bytes/1024', timeout=10)
            end_time = time.time()
            
            if response.status_code == 200:
                duration = end_time - start_time
                speed_mbps = (1024 * 8) / (duration * 1024 * 1024)  # Convert to Mbps
                return round(speed_mbps, 2)
        except:
            return None
    
    async def _detect_cloud_provider(self) -> Optional[str]:
        """Detecta provedor de nuvem baseado em metadata"""
        cloud_checks = {
            'aws': 'http://169.254.169.254/latest/meta-data/',
            'gcp': 'http://metadata.google.internal/computeMetadata/v1/',
            'azure': 'http://169.254.169.254/metadata/instance?api-version=2021-02-01'
        }
        
        for provider, url in cloud_checks.items():
            try:
                headers = {'Metadata-Flavor': 'Google'} if provider == 'gcp' else {}
                response = requests.get(url, headers=headers, timeout=3)
                if response.status_code == 200:
                    return provider
            except:
                continue
        
        return None

# ============================================================================
# MOTOR DE IA PARA RECOMENDAÇÕES
# ============================================================================

class AIEngine:
    """Motor de IA para recomendações de instalação"""
    
    def __init__(self):
        self.profiles = self._load_installation_profiles()
    
    def _load_installation_profiles(self) -> List[InstallationProfile]:
        """Carrega perfis de instalação predefinidos"""
        return [
            InstallationProfile(
                name="startup-minimal",
                description="Configuração mínima para startups e desenvolvimento",
                services=["traefik", "portainer", "netdata", "postgres"],
                resource_requirements={"cpu": "2 cores", "ram": "4GB", "disk": "20GB"},
                estimated_time_minutes=15,
                complexity="beginner",
                use_case="Desenvolvimento local, pequenos projetos"
            ),
            InstallationProfile(
                name="enterprise-full",
                description="Stack completo para ambiente empresarial",
                services=["traefik", "portainer", "prometheus", "grafana", "vault", 
                         "jaeger", "postgres", "redis", "elasticsearch"],
                resource_requirements={"cpu": "8 cores", "ram": "16GB", "disk": "100GB"},
                estimated_time_minutes=45,
                complexity="advanced",
                use_case="Produção empresarial, alta disponibilidade"
            ),
            InstallationProfile(
                name="ai-focused",
                description="Otimizado para workloads de IA e ML",
                services=["traefik", "ollama", "jupyter", "mlflow", "minio", 
                         "prometheus", "grafana", "gpu-operator"],
                resource_requirements={"cpu": "16 cores", "ram": "32GB", "disk": "200GB", "gpu": "Required"},
                estimated_time_minutes=60,
                complexity="advanced",
                use_case="Machine Learning, AI development"
            ),
            InstallationProfile(
                name="edge-lightweight",
                description="Configuração otimizada para edge computing",
                services=["k3s", "traefik", "portainer-agent", "netdata-parent"],
                resource_requirements={"cpu": "2 cores", "ram": "2GB", "disk": "10GB"},
                estimated_time_minutes=10,
                complexity="intermediate",
                use_case="IoT, edge devices, ARM64"
            ),
            InstallationProfile(
                name="microservices-cloud",
                description="Arquitetura de microserviços para nuvem",
                services=["kubernetes", "istio", "argocd", "prometheus", "jaeger", 
                         "vault", "cert-manager", "external-secrets"],
                resource_requirements={"cpu": "12 cores", "ram": "24GB", "disk": "150GB"},
                estimated_time_minutes=90,
                complexity="advanced",
                use_case="Microserviços, cloud-native, DevOps"
            )
        ]
    
    def analyze_and_recommend(self, system_info: SystemInfo) -> AIRecommendation:
        """Analisa o sistema e retorna recomendação inteligente"""
        
        # Algoritmo de IA simplificado (em produção usaria ML mais avançado)
        scores = []
        
        for profile in self.profiles:
            score = self._calculate_compatibility_score(system_info, profile)
            scores.append((score, profile))
        
        # Ordena por score e pega o melhor
        scores.sort(key=lambda x: x[0], reverse=True)
        best_score, best_profile = scores[0]
        
        # Gera explicação e otimizações
        reasoning = self._generate_reasoning(system_info, best_profile, best_score)
        optimizations = self._generate_optimizations(system_info, best_profile)
        warnings = self._generate_warnings(system_info, best_profile)
        
        return AIRecommendation(
            confidence=best_score,
            profile=best_profile,
            reasoning=reasoning,
            optimizations=optimizations,
            warnings=warnings
        )
    
    def _calculate_compatibility_score(self, system_info: SystemInfo, 
                                     profile: InstallationProfile) -> float:
        """Calcula score de compatibilidade usando heurísticas"""
        score = 0.0
        
        # RAM requirements
        if "32GB" in profile.resource_requirements.get("ram", ""):
            ram_req = 32
        elif "24GB" in profile.resource_requirements.get("ram", ""):
            ram_req = 24
        elif "16GB" in profile.resource_requirements.get("ram", ""):
            ram_req = 16
        elif "4GB" in profile.resource_requirements.get("ram", ""):
            ram_req = 4
        else:
            ram_req = 2
            
        if system_info.total_ram_gb >= ram_req:
            score += 0.3
        elif system_info.total_ram_gb >= ram_req * 0.75:
            score += 0.2
        else:
            score += 0.1
        
        # CPU requirements  
        if "16 cores" in profile.resource_requirements.get("cpu", ""):
            cpu_req = 16
        elif "12 cores" in profile.resource_requirements.get("cpu", ""):
            cpu_req = 12
        elif "8 cores" in profile.resource_requirements.get("cpu", ""):
            cpu_req = 8
        else:
            cpu_req = 2
            
        if system_info.cpu_cores >= cpu_req:
            score += 0.25
        elif system_info.cpu_cores >= cpu_req * 0.75:
            score += 0.15
        else:
            score += 0.05
        
        # Disk space
        disk_req_str = profile.resource_requirements.get("disk", "20GB")
        disk_req = int(''.join(filter(str.isdigit, disk_req_str)))
        
        if system_info.available_disk_gb >= disk_req:
            score += 0.2
        elif system_info.available_disk_gb >= disk_req * 0.75:
            score += 0.1
        
        # Cloud provider bonus
        if system_info.cloud_provider and "cloud" in profile.name:
            score += 0.15
        
        # Architecture specific
        if system_info.architecture in ["aarch64", "arm64"] and "edge" in profile.name:
            score += 0.1
            
        return min(score, 1.0)
    
    def _generate_reasoning(self, system_info: SystemInfo, 
                          profile: InstallationProfile, score: float) -> str:
        """Gera explicação da recomendação"""
        reasoning = f"Baseado na análise do seu sistema ({system_info.cpu_cores} cores, "
        reasoning += f"{system_info.total_ram_gb}GB RAM), recomendo o perfil '{profile.name}' "
        reasoning += f"com {score:.0%} de compatibilidade. "
        
        if system_info.cloud_provider:
            reasoning += f"Detectei que você está usando {system_info.cloud_provider.upper()}, "
            reasoning += "o que permite configurações mais avançadas. "
        
        if system_info.kubernetes_installed:
            reasoning += "Kubernetes já está instalado, facilitando deploy de microserviços. "
        elif not system_info.docker_installed:
            reasoning += "Docker não está instalado, será configurado automaticamente. "
            
        return reasoning
    
    def _generate_optimizations(self, system_info: SystemInfo, 
                              profile: InstallationProfile) -> List[str]:
        """Gera otimizações específicas"""
        optimizations = []
        
        if system_info.total_ram_gb > 16:
            optimizations.append("Configurar cache Redis com 2GB para melhor performance")
        
        if system_info.cpu_cores >= 8:
            optimizations.append("Habilitar paralelização em builds Docker")
            optimizations.append("Configurar auto-scaling baseado em CPU")
        
        if system_info.cloud_provider:
            optimizations.append(f"Usar load balancers nativos do {system_info.cloud_provider.upper()}")
            optimizations.append("Configurar backup automático para cloud storage")
        
        if system_info.internet_speed_mbps and system_info.internet_speed_mbps > 100:
            optimizations.append("Usar imagens não-comprimidas para deploy mais rápido")
        
        return optimizations
    
    def _generate_warnings(self, system_info: SystemInfo, 
                         profile: InstallationProfile) -> List[str]:
        """Gera avisos importantes"""
        warnings = []
        
        ram_req = 16 if "enterprise" in profile.name else 4
        if system_info.total_ram_gb < ram_req:
            warnings.append(f"RAM insuficiente. Recomendado: {ram_req}GB, Atual: {system_info.total_ram_gb}GB")
        
        disk_req = 100 if "enterprise" in profile.name else 20
        if system_info.available_disk_gb < disk_req:
            warnings.append(f"Espaço em disco baixo. Recomendado: {disk_req}GB, Disponível: {system_info.available_disk_gb}GB")
        
        if not system_info.docker_installed and profile.complexity == "advanced":
            warnings.append("Perfil avançado sem Docker instalado pode levar mais tempo")
        
        if system_info.internet_speed_mbps and system_info.internet_speed_mbps < 10:
            warnings.append("Conexão lenta pode afetar download de imagens Docker")
            
        return warnings

# ============================================================================
# INTERFACE DE USUÁRIO MODERNA
# ============================================================================

class ModernUI:
    """Interface moderna com Rich"""
    
    def __init__(self):
        self.console = console
    
    def show_welcome(self):
        """Tela de boas-vindas moderna"""
        welcome_text = """
🤖 [bold cyan]MACSPARK AI-POWERED INSTALLER 2025[/bold cyan]

[dim]Instalador inteligente de nova geração com:[/dim]
• [green]✓[/green] Auto-detecção de sistema
• [green]✓[/green] Recomendações baseadas em IA  
• [green]✓[/green] Configuração zero-touch
• [green]✓[/green] Otimizações automáticas
• [green]✓[/green] Deploy cloud-native

[bold yellow]Preparando análise inteligente do sistema...[/bold yellow]
        """
        
        panel = Panel(
            welcome_text,
            title="🚀 Welcome to the Future",
            border_style="cyan",
            padding=(1, 2)
        )
        
        self.console.print(panel)
        self.console.print()
    
    def show_system_analysis(self, system_info: SystemInfo):
        """Mostra análise do sistema"""
        
        # Criar tabela de informações do sistema
        table = Table(title="🔍 Análise do Sistema", show_header=True, header_style="bold cyan")
        table.add_column("Componente", style="white", width=20)
        table.add_column("Valor", style="green", width=30)
        table.add_column("Status", style="yellow", width=15)
        
        # Adicionar dados
        table.add_row("Sistema Operacional", f"{system_info.os_name} {system_info.os_version}", "✓ Compatível")
        table.add_row("Arquitetura", system_info.architecture, "✓ Suportada")
        table.add_row("CPU Cores", str(system_info.cpu_cores), "✓ Adequado" if system_info.cpu_cores >= 4 else "⚠ Limitado")
        table.add_row("RAM Total", f"{system_info.total_ram_gb}GB", "✓ Suficiente" if system_info.total_ram_gb >= 8 else "⚠ Limitada")
        table.add_row("Disco Disponível", f"{system_info.available_disk_gb}GB", "✓ Adequado" if system_info.available_disk_gb >= 50 else "⚠ Limitado")
        
        docker_status = "✓ Instalado" if system_info.docker_installed else "⚠ Não instalado"
        table.add_row("Docker", docker_status, "OK" if system_info.docker_installed else "Será instalado")
        
        k8s_status = "✓ Disponível" if system_info.kubernetes_installed else "⚠ Não disponível"
        table.add_row("Kubernetes", k8s_status, "Opcional")
        
        if system_info.cloud_provider:
            table.add_row("Cloud Provider", system_info.cloud_provider.upper(), "✓ Detectado")
        
        if system_info.internet_speed_mbps:
            table.add_row("Velocidade Internet", f"{system_info.internet_speed_mbps} Mbps", "✓ Testado")
        
        self.console.print(table)
        self.console.print()
    
    def show_ai_recommendation(self, recommendation: AIRecommendation):
        """Mostra recomendação da IA"""
        
        # Painel principal da recomendação
        rec_text = f"""
[bold green]Perfil Recomendado:[/bold green] {recommendation.profile.name}
[bold blue]Confiança da IA:[/bold blue] {recommendation.confidence:.0%}

[dim]{recommendation.profile.description}[/dim]

[bold yellow]Caso de Uso:[/bold yellow] {recommendation.profile.use_case}
[bold yellow]Complexidade:[/bold yellow] {recommendation.profile.complexity}
[bold yellow]Tempo Estimado:[/bold yellow] {recommendation.profile.estimated_time_minutes} minutos

[bold cyan]Serviços Inclusos:[/bold cyan]
{chr(10).join(f"• {service}" for service in recommendation.profile.services)}
        """
        
        panel = Panel(
            rec_text,
            title=f"🤖 Recomendação IA ({recommendation.confidence:.0%} confiança)",
            border_style="green",
            padding=(1, 2)
        )
        
        self.console.print(panel)
        
        # Mostrar reasoning
        if recommendation.reasoning:
            reasoning_panel = Panel(
                recommendation.reasoning,
                title="🧠 Análise da IA",
                border_style="blue",
                padding=(1, 2)
            )
            self.console.print(reasoning_panel)
        
        # Mostrar otimizações
        if recommendation.optimizations:
            opt_text = "\n".join(f"• {opt}" for opt in recommendation.optimizations)
            opt_panel = Panel(
                opt_text,
                title="⚡ Otimizações Recomendadas",
                border_style="yellow",
                padding=(1, 2)
            )
            self.console.print(opt_panel)
        
        # Mostrar avisos
        if recommendation.warnings:
            warn_text = "\n".join(f"• {warn}" for warn in recommendation.warnings)
            warn_panel = Panel(
                warn_text,
                title="⚠️  Avisos Importantes",
                border_style="red",
                padding=(1, 2)
            )
            self.console.print(warn_panel)
        
        self.console.print()

# ============================================================================
# COMANDOS PRINCIPAIS
# ============================================================================

@app.command()
def analyze(
    interactive: bool = typer.Option(True, "--interactive/--no-interactive", help="Modo interativo")
):
    """🔍 Analisa o sistema e gera recomendações IA"""
    
    ui = ModernUI()
    ui.show_welcome()
    
    # Detectar sistema
    detector = SystemDetector()
    system_info = asyncio.run(detector.detect_system())
    
    ui.show_system_analysis(system_info)
    
    # Gerar recomendação IA
    ai_engine = AIEngine()
    recommendation = ai_engine.analyze_and_recommend(system_info)
    
    ui.show_ai_recommendation(recommendation)
    
    # Salvar análise
    analysis_data = {
        "system_info": system_info.__dict__,
        "recommendation": recommendation.dict(),
        "timestamp": "2025-01-01T00:00:00Z"
    }
    
    with open("/tmp/macspark_analysis.json", "w") as f:
        json.dump(analysis_data, f, indent=2, default=str)
    
    console.print(f"[dim]💾 Análise salva em /tmp/macspark_analysis.json[/dim]")
    
    if interactive:
        if Confirm.ask("\n🚀 Deseja prosseguir com a instalação recomendada?"):
            install_recommended(recommendation)

def install_recommended(recommendation: AIRecommendation):
    """Instala o perfil recomendado pela IA"""
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console
    ) as progress:
        
        task = progress.add_task(
            f"🚀 Instalando perfil {recommendation.profile.name}...", 
            total=len(recommendation.profile.services)
        )
        
        for service in recommendation.profile.services:
            progress.update(task, description=f"📦 Instalando {service}...")
            # Simular instalação
            import time
            time.sleep(2)
            progress.advance(task)
    
    console.print(f"\n[bold green]✅ Instalação do perfil '{recommendation.profile.name}' concluída![/bold green]")

@app.command()
def install(
    profile: str = typer.Option("auto", help="Perfil de instalação"),
    skip_analysis: bool = typer.Option(False, help="Pular análise automática")
):
    """🚀 Instala Macspark com perfil específico ou recomendação IA"""
    
    if profile == "auto" and not skip_analysis:
        analyze(interactive=True)
    else:
        console.print(f"[yellow]Instalação manual do perfil: {profile}[/yellow]")

@app.command()
def profiles():
    """📋 Lista perfis de instalação disponíveis"""
    
    ai_engine = AIEngine()
    
    table = Table(title="📋 Perfis de Instalação Disponíveis", show_header=True, header_style="bold cyan")
    table.add_column("Nome", style="green", width=20)
    table.add_column("Descrição", style="white", width=40)
    table.add_column("Complexidade", style="yellow", width=15)
    table.add_column("Tempo", style="blue", width=10)
    
    for profile in ai_engine.profiles:
        table.add_row(
            profile.name,
            profile.description[:37] + "..." if len(profile.description) > 40 else profile.description,
            profile.complexity,
            f"{profile.estimated_time_minutes}min"
        )
    
    console.print(table)

if __name__ == "__main__":
    app()