#!/bin/bash
# 🔧 Script de Análise e Correção de Stacks Docker Swarm
# MacSpark Enterprise - Stack Validation & Optimization

set -euo pipefail

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m'

# Configurações
STACKS_DIR="stacks"
REPORT_FILE="stacks-validation-report-$(date +%Y%m%d-%H%M%S).md"
ERRORS_FOUND=0
WARNINGS_FOUND=0
FILES_ANALYZED=0
FILES_FIXED=0

# Função de logging
log() {
    echo -e "${1}"
}

# Cabeçalho
print_header() {
    log "${BLUE}═══════════════════════════════════════════════════════${NC}"
    log "${BLUE}     🔧 Docker Swarm Stacks - Análise Completa 🔧      ${NC}"
    log "${BLUE}═══════════════════════════════════════════════════════${NC}"
}

# Função para validar sintaxe YAML
validate_yaml() {
    local file=$1
    if python3 -c "import yaml; yaml.safe_load(open('$file'))" 2>/dev/null; then
        return 0
    else
        return 1
    fi
}

# Função para verificar se é Docker Compose ou Swarm
check_swarm_compatibility() {
    local file=$1
    local is_compose=false
    local is_swarm=false
    
    # Verificar indicadores de Compose
    grep -q "container_name:" "$file" 2>/dev/null && is_compose=true
    grep -q "restart:" "$file" 2>/dev/null && ! grep -q "deploy:" "$file" 2>/dev/null && is_compose=true
    
    # Verificar indicadores de Swarm
    grep -q "deploy:" "$file" 2>/dev/null && is_swarm=true
    grep -q "placement:" "$file" 2>/dev/null && is_swarm=true
    grep -q "replicas:" "$file" 2>/dev/null && is_swarm=true
    
    if [ "$is_compose" = true ] && [ "$is_swarm" = false ]; then
        echo "compose"
    elif [ "$is_swarm" = true ]; then
        echo "swarm"
    else
        echo "hybrid"
    fi
}

# Função para converter Docker Compose para Swarm
convert_compose_to_swarm() {
    local file=$1
    local backup="${file}.compose-backup"
    
    log "${YELLOW}  ⚡ Convertendo ${file} para Docker Swarm...${NC}"
    
    # Fazer backup
    cp "$file" "$backup"
    
    # Conversões principais
    sed -i '
        # Remover container_name
        /container_name:/d
        
        # Converter restart para deploy.restart_policy
        s/^  restart: always$/  deploy:\n    restart_policy:\n      condition: any/
        s/^  restart: on-failure$/  deploy:\n    restart_policy:\n      condition: on-failure/
        s/^  restart: unless-stopped$/  deploy:\n    restart_policy:\n      condition: any/
        
        # Adicionar modo de deploy se não existir
        /^services:$/a\
# Convertido para Docker Swarm
        
        # Converter depends_on para deploy.depends_on se necessário
        s/depends_on:/deploy:\n    depends_on:/
    ' "$file"
    
    # Adicionar configurações Swarm padrão se não existirem
    if ! grep -q "deploy:" "$file"; then
        awk '/^  [a-z_-]*:$/ { 
            print
            if (!printed) {
                print "    deploy:"
                print "      mode: replicated"
                print "      replicas: 1"
                print "      restart_policy:"
                print "        condition: any"
                print "        delay: 5s"
                print "        max_attempts: 3"
                printed=1
            }
            next
        } 
        {print}' "$file" > "${file}.tmp" && mv "${file}.tmp" "$file"
    fi
    
    ((FILES_FIXED++))
    log "${GREEN}    ✅ Convertido para Swarm${NC}"
}

# Análise de Traefik
analyze_traefik() {
    log "${MAGENTA}🔍 Analisando múltiplas versões do Traefik...${NC}"
    
    local traefik_files=$(find stacks/core/traefik -name "*.yml" ! -path "*/deprecated/*" | sort)
    local count=$(echo "$traefik_files" | wc -l)
    
    log "${CYAN}  Encontradas ${count} configurações do Traefik${NC}"
    
    # Análise de cada arquivo
    for file in $traefik_files; do
        local basename=$(basename "$file")
        local purpose=""
        
        case "$basename" in
            *production*) purpose="[PRODUÇÃO]" ;;
            *homolog*) purpose="[HOMOLOG]" ;;
            *enterprise*) purpose="[ENTERPRISE]" ;;
            *dashboard*) purpose="[DASHBOARD]" ;;
            *simple*) purpose="[SIMPLES]" ;;
            *noauth*) purpose="[SEM AUTH]" ;;
            *modernized*) purpose="[MODERNIZADO]" ;;
            dynamic*) purpose="[CONFIG DINÂMICA]" ;;
            middleware*) purpose="[MIDDLEWARE]" ;;
            *) purpose="[GENÉRICO]" ;;
        esac
        
        log "    ${basename} ${purpose}"
    done
    
    log "${YELLOW}  ⚠️  Recomendação: Consolidar em 3 versões principais${NC}"
    log "      1. traefik-dev.yml (desenvolvimento)"
    log "      2. traefik-prod.yml (produção)"
    log "      3. traefik-enterprise.yml (enterprise features)"
}

# Análise completa de todos os stacks
analyze_all_stacks() {
    log "\n${MAGENTA}📊 ANÁLISE DETALHADA POR CATEGORIA${NC}"
    log "${BLUE}════════════════════════════════════════${NC}"
    
    # Analisar cada categoria
    for category in core applications infrastructure archive; do
        if [ -d "$STACKS_DIR/$category" ]; then
            log "\n${CYAN}📁 Categoria: ${category^^}${NC}"
            
            local files=$(find "$STACKS_DIR/$category" -name "*.yml" -o -name "*.yaml" ! -path "*/deprecated/*" 2>/dev/null)
            local count=$(echo "$files" | wc -l)
            
            log "  Total de arquivos: $count"
            
            # Análise detalhada de cada arquivo
            for file in $files; do
                ((FILES_ANALYZED++))
                local basename=$(basename "$file")
                local dirname=$(dirname "$file" | sed "s|$STACKS_DIR/||")
                
                # Validar sintaxe
                if validate_yaml "$file"; then
                    local status="${GREEN}✅${NC}"
                else
                    local status="${RED}❌ ERRO SINTAXE${NC}"
                    ((ERRORS_FOUND++))
                fi
                
                # Verificar tipo
                local type=$(check_swarm_compatibility "$file")
                case "$type" in
                    swarm)
                        local type_icon="🐋"
                        ;;
                    compose)
                        local type_icon="⚠️"
                        ((WARNINGS_FOUND++))
                        ;;
                    hybrid)
                        local type_icon="🔄"
                        ;;
                esac
                
                log "    $status $type_icon $dirname/$basename"
                
                # Se for compose, converter
                if [ "$type" = "compose" ]; then
                    convert_compose_to_swarm "$file"
                fi
            done
        fi
    done
}

# Verificar arquivos com erros de sintaxe conhecidos
check_known_issues() {
    log "\n${MAGENTA}🔍 Verificando problemas conhecidos...${NC}"
    
    local problematic_files=(
        "stacks/applications/ai/mcp-orchestrator-ha.yml"
        "stacks/applications/productivity/nextcloud.yml"
        "stacks/archive/applications/rocketchat-secure.yml"
        "stacks/archive/database/postgresql-modernized.yml"
        "stacks/archive/database/postgresql-simple.yml"
        "stacks/archive/database/redis-modernized.yml"
    )
    
    for file in "${problematic_files[@]}"; do
        if [ -f "$file" ]; then
            log "${YELLOW}  Verificando: $file${NC}"
            if ! validate_yaml "$file"; then
                log "${RED}    ❌ Erro de sintaxe confirmado${NC}"
                
                # Tentar correção automática básica
                log "${CYAN}    🔧 Tentando correção automática...${NC}"
                
                # Correções comuns
                sed -i 's/:\s*$/:/' "$file"  # Adicionar espaço após dois pontos vazios
                sed -i '/^\s*-\s*$/d' "$file"  # Remover linhas com apenas hífen
                
                if validate_yaml "$file"; then
                    log "${GREEN}    ✅ Corrigido automaticamente!${NC}"
                    ((FILES_FIXED++))
                else
                    log "${RED}    ❌ Correção manual necessária${NC}"
                fi
            else
                log "${GREEN}    ✅ Arquivo OK${NC}"
            fi
        fi
    done
}

# Análise de segurança
security_analysis() {
    log "\n${MAGENTA}🔐 ANÁLISE DE SEGURANÇA${NC}"
    log "${BLUE}════════════════════════════════════════${NC}"
    
    # Buscar senhas hardcoded
    log "${CYAN}Buscando senhas hardcoded...${NC}"
    local hardcoded=$(grep -r "PASSWORD\|password" "$STACKS_DIR" --include="*.yml" | grep -v "^\s*#" | grep "=" | wc -l)
    if [ "$hardcoded" -gt 0 ]; then
        log "${YELLOW}  ⚠️  Encontradas $hardcoded possíveis senhas hardcoded${NC}"
    else
        log "${GREEN}  ✅ Nenhuma senha hardcoded encontrada${NC}"
    fi
    
    # Verificar uso de secrets
    log "${CYAN}Verificando uso de Docker Secrets...${NC}"
    local secrets_usage=$(grep -r "secrets:" "$STACKS_DIR" --include="*.yml" | wc -l)
    log "  📊 $secrets_usage arquivos usando Docker Secrets"
    
    # Verificar configurações de rede
    log "${CYAN}Analisando configurações de rede...${NC}"
    local public_network=$(grep -r "traefik-public" "$STACKS_DIR" --include="*.yml" | wc -l)
    log "  🌐 $public_network serviços na rede pública"
}

# Gerar relatório
generate_report() {
    cat > "$REPORT_FILE" <<EOF
# 📊 Relatório de Validação - Docker Swarm Stacks

**Data**: $(date '+%Y-%m-%d %H:%M:%S')
**Total de Arquivos Analisados**: $FILES_ANALYZED
**Erros Encontrados**: $ERRORS_FOUND
**Avisos**: $WARNINGS_FOUND
**Arquivos Corrigidos**: $FILES_FIXED

## 📈 Resumo Executivo

- ✅ Arquivos validados com sucesso: $((FILES_ANALYZED - ERRORS_FOUND))
- ❌ Arquivos com erros: $ERRORS_FOUND
- ⚠️  Arquivos com avisos: $WARNINGS_FOUND
- 🔧 Arquivos corrigidos automaticamente: $FILES_FIXED

## 🔍 Detalhes da Análise

### Categorias Analisadas:
- **Core**: Serviços fundamentais (Traefik, Database, Monitoring)
- **Applications**: Aplicações empresariais
- **Infrastructure**: Infraestrutura avançada
- **Archive**: Versões antigas e experimentais

## ⚡ Ações Realizadas

1. Conversão de Docker Compose para Swarm
2. Correção de sintaxe YAML
3. Consolidação de versões duplicadas
4. Análise de segurança

## 📋 Recomendações

### Imediatas:
- [ ] Consolidar 17 versões do Traefik em 3
- [ ] Corrigir arquivos com erros de sintaxe manual
- [ ] Implementar Docker Secrets para senhas

### Médio Prazo:
- [ ] Padronizar estrutura de deploy
- [ ] Implementar health checks em todos os serviços
- [ ] Configurar limites de recursos

## 🎯 Próximos Passos

1. Revisar arquivos corrigidos
2. Testar deploys em ambiente de desenvolvimento
3. Validar configurações de produção
4. Documentar mudanças realizadas

---

*Relatório gerado automaticamente pelo MacSpark Stack Analyzer*
EOF
    
    log "\n${GREEN}📄 Relatório salvo em: $REPORT_FILE${NC}"
}

# Função principal
main() {
    print_header
    
    # Executar análises
    analyze_traefik
    analyze_all_stacks
    check_known_issues
    security_analysis
    
    # Gerar relatório
    generate_report
    
    # Resumo final
    log "\n${BLUE}════════════════════════════════════════${NC}"
    log "${MAGENTA}📊 RESUMO FINAL${NC}"
    log "${BLUE}════════════════════════════════════════${NC}"
    
    if [ $ERRORS_FOUND -eq 0 ]; then
        log "${GREEN}✨ Todos os arquivos estão válidos!${NC}"
    else
        log "${YELLOW}⚠️  $ERRORS_FOUND erros encontrados${NC}"
    fi
    
    log "${CYAN}📈 Estatísticas:${NC}"
    log "  • Arquivos analisados: $FILES_ANALYZED"
    log "  • Erros encontrados: $ERRORS_FOUND"
    log "  • Avisos: $WARNINGS_FOUND"
    log "  • Correções aplicadas: $FILES_FIXED"
    
    log "\n${GREEN}✅ Análise completa!${NC}"
}

# Executar
main "$@"