#!/bin/bash

# ============================================================================
# MACSPARK INTELLIGENT HEALTH MONITOR 2025
# ============================================================================
# Sistema de monitoramento inteligente com IA, alertas e auto-correção
# Versão: 2025.1.0
# ============================================================================

set -euo pipefail

# ============================================================================
# CONFIGURAÇÕES AVANÇADAS
# ============================================================================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(dirname "$SCRIPT_DIR")"

# Carregar variáveis do .env
if [[ -f "$BASE_DIR/.env" ]]; then
    source "$BASE_DIR/.env"
fi

# Configurações de monitoramento
MONITOR_INTERVAL=${MONITOR_INTERVAL:-30}
ALERT_THRESHOLD_CPU=${ALERT_THRESHOLD_CPU:-80}
ALERT_THRESHOLD_MEMORY=${ALERT_THRESHOLD_MEMORY:-85}
ALERT_THRESHOLD_DISK=${ALERT_THRESHOLD_DISK:-90}
AUTO_HEALING=${AUTO_HEALING:-true}
CONTINUOUS_MODE=${CONTINUOUS_MODE:-false}

# Paths
LOGS_PATH="${LOGS_PATH:-/opt/macspark/logs}"
METRICS_PATH="${LOGS_PATH}/metrics"
HEALTH_LOG="${LOGS_PATH}/health-monitor.log"
ALERTS_LOG="${LOGS_PATH}/alerts.log"

# Webhooks e notificações
WEBHOOK_URL="${WEBHOOK_SLACK_URL:-}"
EMAIL_ALERTS="${EMAIL_ALERTS:-true}"
WEBHOOK_DISCORD="${WEBHOOK_DISCORD_URL:-}"

# ============================================================================
# CORES E LOGGING
# ============================================================================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
GRAY='\033[0;90m'
NC='\033[0m'
BOLD='\033[1m'

# Emojis para status
EMOJI_OK="✅"
EMOJI_WARNING="⚠️"
EMOJI_ERROR="❌"
EMOJI_INFO="ℹ️"
EMOJI_AI="🤖"
EMOJI_HEALING="🔧"
EMOJI_ALERT="🚨"

# Criar diretórios necessários
mkdir -p "$LOGS_PATH" "$METRICS_PATH"

log() {
    local level=$1
    shift
    local message="$*"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    case $level in
        INFO)    echo -e "${BLUE}[INFO]${NC} $message" | tee -a "$HEALTH_LOG" ;;
        SUCCESS) echo -e "${GREEN}[SUCCESS]${NC} $message" | tee -a "$HEALTH_LOG" ;;
        WARNING) echo -e "${YELLOW}[WARNING]${NC} $message" | tee -a "$HEALTH_LOG" ;;
        ERROR)   echo -e "${RED}[ERROR]${NC} $message" | tee -a "$HEALTH_LOG" ;;
        AI)      echo -e "${PURPLE}[AI]${NC} $message" | tee -a "$HEALTH_LOG" ;;
        HEALING) echo -e "${CYAN}[HEALING]${NC} $message" | tee -a "$HEALTH_LOG" ;;
    esac
    
    # Log estruturado para métricas
    echo "{\"timestamp\":\"$timestamp\",\"level\":\"$level\",\"message\":\"$message\",\"component\":\"health-monitor\"}" >> "${METRICS_PATH}/health-structured.log"
}

# ============================================================================
# COLETA DE MÉTRICAS DO SISTEMA
# ============================================================================
collect_system_metrics() {
    local metrics_file="$METRICS_PATH/system_$(date +%Y%m%d_%H%M%S).json"
    
    # CPU
    local cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | awk -F'%' '{print $1}')
    local cpu_load_1min=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | tr -d ',')
    
    # Memória
    local memory_info=$(free -m)
    local memory_total=$(echo "$memory_info" | awk 'NR==2{print $2}')
    local memory_used=$(echo "$memory_info" | awk 'NR==2{print $3}')
    local memory_percent=$((memory_used * 100 / memory_total))
    
    # Disco
    local disk_usage=$(df / | tail -1 | awk '{print $5}' | tr -d '%')
    local disk_available=$(df -h / | tail -1 | awk '{print $4}')
    
    # Rede
    local network_stats=$(cat /proc/net/dev | grep -E '(eth0|ens|enp)' | head -1 | awk '{print $2","$10}')
    local rx_bytes=$(echo "$network_stats" | cut -d',' -f1)
    local tx_bytes=$(echo "$network_stats" | cut -d',' -f2)
    
    # Temperatura (se disponível)
    local temperature="N/A"
    if command -v sensors >/dev/null 2>&1; then
        temperature=$(sensors 2>/dev/null | grep -E '(Core|temp)' | head -1 | awk '{print $3}' | tr -d '+°C' || echo "N/A")
    fi
    
    # Criar JSON com métricas
    cat > "$metrics_file" << EOF
{
    "timestamp": "$(date -Iseconds)",
    "system": {
        "cpu_usage_percent": ${cpu_usage:-0},
        "cpu_load_1min": ${cpu_load_1min:-0},
        "memory_total_mb": $memory_total,
        "memory_used_mb": $memory_used,
        "memory_percent": $memory_percent,
        "disk_usage_percent": $disk_usage,
        "disk_available": "$disk_available",
        "rx_bytes": ${rx_bytes:-0},
        "tx_bytes": ${tx_bytes:-0},
        "temperature": "$temperature",
        "uptime": "$(uptime -p)"
    }
}
EOF
    
    # Exportar variáveis para uso em outras funções
    export CPU_USAGE=$cpu_usage
    export MEMORY_PERCENT=$memory_percent
    export DISK_USAGE=$disk_usage
    export SYSTEM_SCORE=$(calculate_system_health_score)
}

calculate_system_health_score() {
    local score=100
    
    # Penalizar por alto uso de CPU (converter float para int)
    local cpu_int=$(echo "${CPU_USAGE:-0}" | cut -d'.' -f1)
    if [[ ${cpu_int:-0} -gt 80 ]]; then
        score=$((score - 20))
    elif [[ ${cpu_int:-0} -gt 60 ]]; then
        score=$((score - 10))
    fi
    
    # Penalizar por alto uso de memória
    if [[ ${MEMORY_PERCENT:-0} -gt 85 ]]; then
        score=$((score - 25))
    elif [[ ${MEMORY_PERCENT:-0} -gt 70 ]]; then
        score=$((score - 15))
    fi
    
    # Penalizar por alto uso de disco
    if [[ ${DISK_USAGE:-0} -gt 90 ]]; then
        score=$((score - 30))
    elif [[ ${DISK_USAGE:-0} -gt 80 ]]; then
        score=$((score - 15))
    fi
    
    echo $score
}

# ============================================================================
# MONITORAMENTO DE CONTAINERS DOCKER
# ============================================================================
monitor_docker_containers() {
    log INFO "🐳 Verificando containers Docker..."
    
    if ! command -v docker >/dev/null 2>&1; then
        log ERROR "Docker não está instalado ou não está no PATH"
        return 1
    fi
    
    local containers_data="$METRICS_PATH/containers_$(date +%Y%m%d_%H%M%S).json"
    echo "{\"timestamp\":\"$(date -Iseconds)\",\"containers\":[" > "$containers_data"
    
    local container_count=0
    local unhealthy_count=0
    local total_memory_mb=0
    
    # Listar todos os containers
    local containers=$(docker ps -a --format "{{.Names}},{{.State}},{{.Status}}" 2>/dev/null || echo "")
    
    if [[ -z "$containers" ]]; then
        log WARNING "Nenhum container encontrado"
        echo "]}" >> "$containers_data"
        return 0
    fi
    
    while IFS=',' read -r name state status; do
        if [[ -n "$name" ]]; then
            container_count=$((container_count + 1))
            
            # Obter estatísticas do container
            local stats=""
            local memory_mb=0
            local cpu_percent=0
            
            if [[ "$state" == "running" ]]; then
                if stats=$(docker stats "$name" --no-stream --format "{{.MemUsage}},{{.CPUPerc}}" 2>/dev/null); then
                    memory_usage=$(echo "$stats" | cut -d',' -f1 | cut -d'/' -f1 | grep -o '[0-9.]*' | head -1)
                    memory_unit=$(echo "$stats" | cut -d',' -f1 | cut -d'/' -f1 | grep -o '[a-zA-Z]*' | head -1)
                    cpu_percent=$(echo "$stats" | cut -d',' -f2 | tr -d '%')
                    
                    # Converter memória para MB
                    case $memory_unit in
                        GiB|GB) memory_mb=$(echo "$memory_usage * 1024" | bc 2>/dev/null || echo "0") ;;
                        MiB|MB) memory_mb=$memory_usage ;;
                        KiB|KB) memory_mb=$(echo "$memory_usage / 1024" | bc 2>/dev/null || echo "0") ;;
                        *) memory_mb=0 ;;
                    esac
                    
                    total_memory_mb=$((total_memory_mb + ${memory_mb%.*}))
                fi
                
                # Verificar health check
                local health_status="unknown"
                if docker inspect "$name" --format '{{.State.Health.Status}}' 2>/dev/null | grep -q "healthy"; then
                    health_status="healthy"
                elif docker inspect "$name" --format '{{.State.Health.Status}}' 2>/dev/null | grep -q "unhealthy"; then
                    health_status="unhealthy"
                    unhealthy_count=$((unhealthy_count + 1))
                fi
                
                log SUCCESS "$EMOJI_OK Container $name: $state ($health_status)"
            else
                log WARNING "$EMOJI_WARNING Container $name: $state"
                unhealthy_count=$((unhealthy_count + 1))
            fi
            
            # Adicionar ao JSON
            if [[ $container_count -gt 1 ]]; then
                echo "," >> "$containers_data"
            fi
            
            cat >> "$containers_data" << EOF
{
    "name": "$name",
    "state": "$state",
    "status": "$status",
    "health_status": "${health_status:-unknown}",
    "memory_mb": ${memory_mb%.*},
    "cpu_percent": ${cpu_percent:-0}
}
EOF
        fi
    done <<< "$containers"
    
    echo "]," >> "$containers_data"
    echo "\"summary\":{\"total\":$container_count,\"unhealthy\":$unhealthy_count,\"total_memory_mb\":$total_memory_mb}}" >> "$containers_data"
    
    export CONTAINER_COUNT=$container_count
    export UNHEALTHY_CONTAINERS=$unhealthy_count
    export DOCKER_MEMORY_MB=$total_memory_mb
    
    log INFO "📊 Containers: $container_count total, $unhealthy_count com problemas"
}

# ============================================================================
# VERIFICAÇÃO DE SERVIÇOS ESPECÍFICOS
# ============================================================================
check_core_services() {
    log INFO "🔍 Verificando serviços principais..."
    
    local services_status="$METRICS_PATH/services_$(date +%Y%m%d_%H%M%S).json"
    echo "{\"timestamp\":\"$(date -Iseconds)\",\"services\":{" > "$services_status"
    
    local service_count=0
    local failed_services=0
    
    # Definir serviços críticos
    local critical_services=(
        "traefik:8080:/api/version"
        "portainer:9000:/api/status"
        "postgres:5432:tcp"
        "redis:6379:tcp"
    )
    
    for service_def in "${critical_services[@]}"; do
        IFS=':' read -r service_name service_port service_check <<< "$service_def"
        service_count=$((service_count + 1))
        
        local status="unknown"
        local response_time=0
        local details=""
        
        if [[ $service_count -gt 1 ]]; then
            echo "," >> "$services_status"
        fi
        
        # Verificar se porta está aberta
        if timeout 5 bash -c "</dev/tcp/localhost/$service_port" 2>/dev/null; then
            status="running"
            
            # Se for HTTP, verificar endpoint
            if [[ "$service_check" == /* ]]; then
                local start_time=$(date +%s.%N)
                if curl -sf "http://localhost:$service_port$service_check" >/dev/null 2>&1; then
                    local end_time=$(date +%s.%N)
                    response_time=$(echo "$end_time - $start_time" | bc | awk '{printf "%.3f", $0}')
                    status="healthy"
                    details="Endpoint respondendo"
                else
                    status="unhealthy"
                    details="Endpoint não responde"
                    failed_services=$((failed_services + 1))
                fi
            else
                details="Porta acessível"
            fi
            
            log SUCCESS "$EMOJI_OK $service_name: $status (${response_time}s)"
        else
            status="down"
            details="Porta não acessível"
            failed_services=$((failed_services + 1))
            log ERROR "$EMOJI_ERROR $service_name: $status"
        fi
        
        cat >> "$services_status" << EOF
"$service_name": {
    "status": "$status",
    "port": $service_port,
    "response_time": $response_time,
    "details": "$details"
}
EOF
    done
    
    echo "},\"summary\":{\"total\":$service_count,\"failed\":$failed_services}}" >> "$services_status"
    
    export SERVICE_COUNT=$service_count
    export FAILED_SERVICES=$failed_services
    
    log INFO "📊 Serviços: $service_count total, $failed_services com falhas"
}

# ============================================================================
# ANÁLISE INTELIGENTE COM IA
# ============================================================================
ai_health_analysis() {
    log AI "$EMOJI_AI Executando análise de saúde com IA..."
    
    local health_score=100
    local recommendations=()
    local critical_issues=()
    local warnings=()
    
    # Análise de recursos do sistema (converter decimais para inteiros)
    local cpu_int=$(echo "${CPU_USAGE:-0}" | cut -d'.' -f1)
    local threshold_cpu_int=$(echo "${ALERT_THRESHOLD_CPU:-80}" | cut -d'.' -f1)
    if [[ ${cpu_int:-0} -gt ${threshold_cpu_int:-80} ]]; then
        health_score=$((health_score - 25))
        critical_issues+=("CPU usage crítico: ${CPU_USAGE}%")
        recommendations+=("Verificar processos com alto uso de CPU")
    elif [[ ${cpu_int:-0} -gt 60 ]]; then
        health_score=$((health_score - 10))
        warnings+=("CPU usage elevado: ${CPU_USAGE}%")
    fi
    
    if [[ ${MEMORY_PERCENT:-0} -gt $ALERT_THRESHOLD_MEMORY ]]; then
        health_score=$((health_score - 30))
        critical_issues+=("Memória crítica: ${MEMORY_PERCENT}%")
        recommendations+=("Considerar adicionar mais RAM ou otimizar containers")
    elif [[ ${MEMORY_PERCENT:-0} -gt 70 ]]; then
        health_score=$((health_score - 15))
        warnings+=("Uso de memória elevado: ${MEMORY_PERCENT}%")
    fi
    
    if [[ ${DISK_USAGE:-0} -gt $ALERT_THRESHOLD_DISK ]]; then
        health_score=$((health_score - 35))
        critical_issues+=("Disco crítico: ${DISK_USAGE}%")
        recommendations+=("Limpeza de logs e arquivos antigos urgente")
    elif [[ ${DISK_USAGE:-0} -gt 75 ]]; then
        health_score=$((health_score - 20))
        warnings+=("Uso de disco elevado: ${DISK_USAGE}%")
        recommendations+=("Agendar limpeza de arquivos antigos")
    fi
    
    # Análise de containers
    if [[ ${UNHEALTHY_CONTAINERS:-0} -gt 0 ]]; then
        health_score=$((health_score - (UNHEALTHY_CONTAINERS * 15)))
        critical_issues+=("${UNHEALTHY_CONTAINERS} containers com problemas")
        recommendations+=("Verificar logs dos containers com falha")
    fi
    
    # Análise de serviços
    if [[ ${FAILED_SERVICES:-0} -gt 0 ]]; then
        health_score=$((health_score - (FAILED_SERVICES * 20)))
        critical_issues+=("${FAILED_SERVICES} serviços críticos falhando")
        recommendations+=("Reiniciar serviços com falha imediatamente")
    fi
    
    # Análise de padrões temporais (últimas 24h)
    local recent_issues=$(grep -c "ERROR\|CRITICAL" "$HEALTH_LOG" 2>/dev/null || echo "0")
    if [[ $recent_issues -gt 10 ]]; then
        health_score=$((health_score - 10))
        warnings+=("Muitos erros recentes: $recent_issues nas últimas execuções")
        recommendations+=("Investigar padrão de erros recorrentes")
    fi
    
    # Determinar status geral
    local overall_status
    local status_emoji
    if [[ $health_score -gt 90 ]]; then
        overall_status="EXCELLENT"
        status_emoji="🟢"
    elif [[ $health_score -gt 75 ]]; then
        overall_status="GOOD"
        status_emoji="🟡"
    elif [[ $health_score -gt 50 ]]; then
        overall_status="WARNING"
        status_emoji="🟠"
    else
        overall_status="CRITICAL"
        status_emoji="🔴"
    fi
    
    # Salvar análise
    local analysis_file="$METRICS_PATH/ai_analysis_$(date +%Y%m%d_%H%M%S).json"
    cat > "$analysis_file" << EOF
{
    "timestamp": "$(date -Iseconds)",
    "health_score": $health_score,
    "overall_status": "$overall_status",
    "critical_issues": [$(printf '"%s",' "${critical_issues[@]}" | sed 's/,$//')]],
    "warnings": [$(printf '"%s",' "${warnings[@]}" | sed 's/,$//')]],
    "recommendations": [$(printf '"%s",' "${recommendations[@]}" | sed 's/,$//')]],
    "system_metrics": {
        "cpu_usage": ${CPU_USAGE:-0},
        "memory_percent": ${MEMORY_PERCENT:-0},
        "disk_usage": ${DISK_USAGE:-0},
        "containers_total": ${CONTAINER_COUNT:-0},
        "containers_unhealthy": ${UNHEALTHY_CONTAINERS:-0},
        "services_total": ${SERVICE_COUNT:-0},
        "services_failed": ${FAILED_SERVICES:-0}
    }
}
EOF
    
    # Log da análise
    log AI "$status_emoji Status geral: $overall_status (Score: $health_score/100)"
    
    if [[ ${#critical_issues[@]} -gt 0 ]]; then
        log ERROR "$EMOJI_ALERT Issues críticos encontrados:"
        for issue in "${critical_issues[@]}"; do
            log ERROR "  • $issue"
        done
    fi
    
    if [[ ${#warnings[@]} -gt 0 ]]; then
        log WARNING "$EMOJI_WARNING Avisos:"
        for warning in "${warnings[@]}"; do
            log WARNING "  • $warning"
        done
    fi
    
    if [[ ${#recommendations[@]} -gt 0 ]]; then
        log AI "$EMOJI_AI Recomendações da IA:"
        for rec in "${recommendations[@]}"; do
            log AI "  💡 $rec"
        done
    fi
    
    export HEALTH_SCORE=$health_score
    export OVERALL_STATUS="$overall_status"
    export CRITICAL_ISSUES_COUNT=${#critical_issues[@]}
    
    # Trigger auto-healing se necessário
    if [[ "$AUTO_HEALING" == "true" && $health_score -lt 60 ]]; then
        trigger_auto_healing
    fi
    
    # Trigger alertas se necessário
    if [[ ${#critical_issues[@]} -gt 0 || $health_score -lt 70 ]]; then
        send_health_alert "$overall_status" "$health_score"
    fi
}

# ============================================================================
# AUTO-HEALING INTELIGENTE
# ============================================================================
trigger_auto_healing() {
    log HEALING "$EMOJI_HEALING Iniciando processo de auto-correção..."
    
    local healing_actions=0
    
    # Reiniciar containers unhealthy
    if [[ ${UNHEALTHY_CONTAINERS:-0} -gt 0 ]]; then
        log HEALING "🔄 Reiniciando containers com problemas..."
        
        local unhealthy_containers=$(docker ps -a --filter "health=unhealthy" --format "{{.Names}}" 2>/dev/null || echo "")
        while IFS= read -r container; do
            if [[ -n "$container" ]]; then
                log HEALING "🔄 Reiniciando container: $container"
                if docker restart "$container" >/dev/null 2>&1; then
                    log SUCCESS "$EMOJI_OK Container $container reiniciado"
                    healing_actions=$((healing_actions + 1))
                else
                    log ERROR "$EMOJI_ERROR Falha ao reiniciar $container"
                fi
            fi
        done <<< "$unhealthy_containers"
    fi
    
    # Limpeza de disco se necessário
    if [[ ${DISK_USAGE:-0} -gt 85 ]]; then
        log HEALING "🧹 Iniciando limpeza de disco automática..."
        
        # Limpar logs antigos
        find "$LOGS_PATH" -name "*.log" -mtime +7 -delete 2>/dev/null || true
        
        # Limpar containers e imagens não utilizadas
        docker system prune -f >/dev/null 2>&1 || true
        
        # Limpar cache do sistema
        if command -v apt-get >/dev/null 2>&1; then
            apt-get clean >/dev/null 2>&1 || true
        fi
        
        healing_actions=$((healing_actions + 1))
        log SUCCESS "$EMOJI_OK Limpeza de disco executada"
    fi
    
    # Restart de serviços críticos se necessário
    if [[ ${FAILED_SERVICES:-0} -gt 0 ]]; then
        log HEALING "🔄 Tentando corrigir serviços críticos..."
        
        # Tentar reiniciar stack do Docker Swarm se ativo
        if docker info | grep -q "Swarm: active" 2>/dev/null; then
            local stacks=$(docker stack ls --format "{{.Name}}" 2>/dev/null || echo "")
            while IFS= read -r stack; do
                if [[ -n "$stack" ]]; then
                    log HEALING "🔄 Verificando stack: $stack"
                    docker stack ps "$stack" --format "{{.CurrentState}}" | grep -q "Running" || {
                        log HEALING "🔄 Reiniciando stack: $stack"
                        # Note: Stack restart requires manual intervention for safety
                        healing_actions=$((healing_actions + 1))
                    }
                fi
            done <<< "$stacks"
        fi
    fi
    
    log HEALING "$EMOJI_HEALING Auto-healing concluído: $healing_actions ações executadas"
    
    # Log da ação de healing
    echo "{\"timestamp\":\"$(date -Iseconds)\",\"actions\":$healing_actions,\"trigger\":\"auto\"}" >> "$METRICS_PATH/healing_actions.log"
}

# ============================================================================
# SISTEMA DE ALERTAS
# ============================================================================
send_health_alert() {
    local status=$1
    local score=$2
    
    log INFO "$EMOJI_ALERT Enviando alerta de saúde: $status"
    
    local color
    case $status in
        EXCELLENT) return 0 ;;  # Não enviar alerta para status excelente
        GOOD) color="#36a64f" ;;
        WARNING) color="#ff9000" ;;
        CRITICAL) color="#ff0000" ;;
        *) color="#764fa5" ;;
    esac
    
    local message="Sistema Macspark: $status (Score: $score/100)"
    
    # Slack/Discord webhook
    if [[ -n "$WEBHOOK_URL" ]]; then
        local payload=$(cat << EOF
{
    "attachments": [
        {
            "color": "$color",
            "title": "🏥 Health Monitor - $status",
            "text": "$message",
            "fields": [
                {
                    "title": "CPU",
                    "value": "${CPU_USAGE:-0}%",
                    "short": true
                },
                {
                    "title": "Memória",
                    "value": "${MEMORY_PERCENT:-0}%",
                    "short": true
                },
                {
                    "title": "Disco",
                    "value": "${DISK_USAGE:-0}%",
                    "short": true
                },
                {
                    "title": "Containers",
                    "value": "${UNHEALTHY_CONTAINERS:-0} problemas",
                    "short": true
                },
                {
                    "title": "Timestamp",
                    "value": "$(date)",
                    "short": false
                }
            ]
        }
    ]
}
EOF
        )
        
        curl -X POST -H 'Content-type: application/json' --data "$payload" "$WEBHOOK_URL" >/dev/null 2>&1 || true
    fi
    
    # Log do alerta
    echo "$(date -Iseconds): $status - $message" >> "$ALERTS_LOG"
}

# ============================================================================
# DASHBOARD EM TEMPO REAL
# ============================================================================
show_health_dashboard() {
    clear
    
    # Header do dashboard
    echo -e "${PURPLE}${BOLD}"
    cat << 'EOF'
╔══════════════════════════════════════════════════════════════════════════════╗
║                    🏥 MACSPARK HEALTH DASHBOARD 2025                        ║
╚══════════════════════════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"
    
    echo -e "${GRAY}Last Update: $(date)${NC}"
    echo -e "${GRAY}Monitoring Interval: ${MONITOR_INTERVAL}s${NC}"
    echo ""
    
    # Status geral
    local status_color
    case ${OVERALL_STATUS:-UNKNOWN} in
        EXCELLENT) status_color=$GREEN ;;
        GOOD) status_color=$YELLOW ;;
        WARNING) status_color=$YELLOW ;;
        CRITICAL) status_color=$RED ;;
        *) status_color=$GRAY ;;
    esac
    
    echo -e "${WHITE}${BOLD}OVERALL HEALTH: ${status_color}${OVERALL_STATUS:-UNKNOWN} (${HEALTH_SCORE:-0}/100)${NC}"
    echo ""
    
    # Métricas do sistema
    echo -e "${CYAN}${BOLD}📊 SYSTEM METRICS${NC}"
    echo -e "CPU Usage:    $(printf '%3d%%' ${CPU_USAGE:-0}) $(draw_bar ${CPU_USAGE:-0})"
    echo -e "Memory:       $(printf '%3d%%' ${MEMORY_PERCENT:-0}) $(draw_bar ${MEMORY_PERCENT:-0})"
    echo -e "Disk Usage:   $(printf '%3d%%' ${DISK_USAGE:-0}) $(draw_bar ${DISK_USAGE:-0})"
    echo ""
    
    # Containers Docker
    echo -e "${BLUE}${BOLD}🐳 CONTAINERS${NC}"
    echo -e "Total:        ${CONTAINER_COUNT:-0}"
    echo -e "Unhealthy:    ${UNHEALTHY_CONTAINERS:-0}"
    echo -e "Memory Used:  ${DOCKER_MEMORY_MB:-0} MB"
    echo ""
    
    # Serviços
    echo -e "${GREEN}${BOLD}🔧 SERVICES${NC}"
    echo -e "Total:        ${SERVICE_COUNT:-0}"
    echo -e "Failed:       ${FAILED_SERVICES:-0}"
    echo ""
    
    # Issues críticos
    if [[ ${CRITICAL_ISSUES_COUNT:-0} -gt 0 ]]; then
        echo -e "${RED}${BOLD}🚨 CRITICAL ISSUES${NC}"
        echo -e "Count:        ${CRITICAL_ISSUES_COUNT}"
        echo ""
    fi
    
    # Comandos disponíveis
    echo -e "${GRAY}Press 'q' to quit, 'r' to refresh, 'h' for help${NC}"
}

draw_bar() {
    local percentage=$1
    local bar_length=20
    local filled_length=$((percentage * bar_length / 100))
    
    local bar=""
    for ((i=0; i<filled_length; i++)); do
        bar="${bar}█"
    done
    for ((i=filled_length; i<bar_length; i++)); do
        bar="${bar}░"
    done
    
    if [[ $percentage -gt 90 ]]; then
        echo -e "${RED}[$bar]${NC}"
    elif [[ $percentage -gt 70 ]]; then
        echo -e "${YELLOW}[$bar]${NC}"
    else
        echo -e "${GREEN}[$bar]${NC}"
    fi
}

# ============================================================================
# MODO INTERATIVO
# ============================================================================
interactive_mode() {
    log INFO "🎮 Iniciando modo interativo do Health Monitor..."
    
    while true; do
        # Coletar todas as métricas
        collect_system_metrics
        monitor_docker_containers
        check_core_services
        ai_health_analysis
        
        # Mostrar dashboard
        show_health_dashboard
        
        # Aguardar input do usuário
        read -t $MONITOR_INTERVAL -n 1 input || input=""
        
        case $input in
            q|Q) 
                log INFO "👋 Saindo do Health Monitor..."
                break 
                ;;
            r|R) 
                continue 
                ;;
            h|H)
                show_help
                read -p "Press Enter to continue..."
                ;;
        esac
    done
}

show_help() {
    clear
    echo -e "${CYAN}${BOLD}🏥 MACSPARK HEALTH MONITOR - HELP${NC}"
    echo ""
    echo "Comandos disponíveis:"
    echo "  q, Q  - Quit (sair)"
    echo "  r, R  - Refresh (atualizar)"
    echo "  h, H  - Help (esta tela)"
    echo ""
    echo "Configurações:"
    echo "  Intervalo de monitoramento: ${MONITOR_INTERVAL}s"
    echo "  Auto-healing: ${AUTO_HEALING}"
    echo "  Alertas por email: ${EMAIL_ALERTS}"
    echo ""
    echo "Thresholds de alerta:"
    echo "  CPU: ${ALERT_THRESHOLD_CPU}%"
    echo "  Memória: ${ALERT_THRESHOLD_MEMORY}%"
    echo "  Disco: ${ALERT_THRESHOLD_DISK}%"
    echo ""
}

# ============================================================================
# FUNÇÃO PRINCIPAL
# ============================================================================
main() {
    local mode="${1:-single}"
    
    case $mode in
        continuous|daemon)
            CONTINUOUS_MODE=true
            log INFO "🔄 Iniciando modo contínuo..."
            
            while true; do
                collect_system_metrics
                monitor_docker_containers
                check_core_services
                ai_health_analysis
                
                sleep $MONITOR_INTERVAL
            done
            ;;
            
        interactive|dashboard)
            interactive_mode
            ;;
            
        single|check)
            log INFO "📊 Executando verificação única..."
            collect_system_metrics
            monitor_docker_containers
            check_core_services
            ai_health_analysis
            
            echo ""
            log SUCCESS "✅ Verificação de saúde concluída"
            log INFO "💾 Métricas salvas em: $METRICS_PATH"
            ;;
            
        help|--help|-h)
            echo "Uso: $0 [mode]"
            echo ""
            echo "Modos disponíveis:"
            echo "  single      - Verificação única (padrão)"
            echo "  continuous  - Modo contínuo (daemon)"
            echo "  interactive - Modo interativo com dashboard"
            echo "  help        - Mostra esta ajuda"
            echo ""
            echo "Variáveis de ambiente:"
            echo "  MONITOR_INTERVAL - Intervalo entre verificações (padrão: 30s)"
            echo "  AUTO_HEALING     - Ativar auto-correção (padrão: true)"
            echo "  WEBHOOK_URL      - URL para alertas (Slack/Discord)"
            echo ""
            exit 0
            ;;
            
        *)
            log ERROR "Modo inválido: $mode"
            log INFO "Use: $0 help para ver opções disponíveis"
            exit 1
            ;;
    esac
}

# ============================================================================
# EXECUÇÃO
# ============================================================================
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi