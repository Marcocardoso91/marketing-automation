#!/bin/bash

# ============================================================================
# MACSPARK HEALTH MONITOR v13.1
# ============================================================================
# Dashboard de saúde em tempo real dos serviços
# ============================================================================

set -euo pipefail

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
GRAY='\033[0;37m'
NC='\033[0m'
BOLD='\033[1m'

# Símbolos
CHECK="✅"
CROSS="❌"
WARNING="⚠️"
INFO="ℹ️"
LOADING="⏳"
HEART="💓"
FIRE="🔥"
GRAPH="📊"

get_service_health() {
    local service="$1"
    local replicas_running=0
    local replicas_desired=0
    
    if docker service ls --format "{{.Name}}" | grep -q "^${service}$"; then
        local replica_info=$(docker service ls --filter name="$service" --format "{{.Replicas}}")
        replicas_running=$(echo "$replica_info" | cut -d'/' -f1)
        replicas_desired=$(echo "$replica_info" | cut -d'/' -f2)
        
        if [[ "$replicas_running" == "$replicas_desired" ]] && [[ "$replicas_running" -gt 0 ]]; then
            echo "healthy"
        elif [[ "$replicas_running" -gt 0 ]]; then
            echo "degraded"
        else
            echo "down"
        fi
    else
        echo "not_installed"
    fi
}

get_system_resources() {
    local cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | awk -F'%' '{print $1}')
    local memory_usage=$(free | grep Mem | awk '{printf("%.1f", $3/$2 * 100.0)}')
    local disk_usage=$(df / | tail -1 | awk '{print $5}' | sed 's/%//')
    
    echo "$cpu_usage $memory_usage $disk_usage"
}

get_docker_stats() {
    local containers=$(docker ps -q | wc -l)
    local images=$(docker images -q | wc -l)
    local volumes=$(docker volume ls -q | wc -l)
    local networks=$(docker network ls -q | wc -l)
    
    echo "$containers $images $volumes $networks"
}

show_health_status() {
    local service="$1"
    local health="$2"
    local name="$3"
    
    case "$health" in
        "healthy")
            echo -e "  ${CHECK} ${GREEN}${BOLD}${name}${NC} ${GRAY}(Running)${NC}"
            ;;
        "degraded")
            echo -e "  ${WARNING} ${YELLOW}${BOLD}${name}${NC} ${GRAY}(Degraded)${NC}"
            ;;
        "down")
            echo -e "  ${CROSS} ${RED}${BOLD}${name}${NC} ${GRAY}(Down)${NC}"
            ;;
        "not_installed")
            echo -e "  ${GRAY}○ ${name}${NC} ${GRAY}(Not Installed)${NC}"
            ;;
    esac
}

show_resource_bar() {
    local value="$1"
    local max="$2"
    local label="$3"
    local unit="$4"
    
    local percentage=$((value * 100 / max))
    local bar_width=20
    local filled=$((percentage * bar_width / 100))
    local empty=$((bar_width - filled))
    
    local color=""
    if [[ $percentage -lt 70 ]]; then
        color="${GREEN}"
    elif [[ $percentage -lt 90 ]]; then
        color="${YELLOW}"
    else
        color="${RED}"
    fi
    
    echo -ne "${BOLD}${label}:${NC} ${color}"
    for ((i=0; i<filled; i++)); do echo -ne "█"; done
    for ((i=0; i<empty; i++)); do echo -ne "░"; done
    echo -e "${NC} ${percentage}${unit}"
}

show_realtime_dashboard() {
    while true; do
        clear
        echo -e "${PURPLE}${BOLD}"
        echo "╔══════════════════════════════════════════════════════════════════════════════╗"
        echo "║                    ${HEART} MACSPARK HEALTH MONITOR v13.1 ${HEART}                     ║"
        echo "║                          Dashboard em Tempo Real                             ║"
        echo "╚══════════════════════════════════════════════════════════════════════════════╝"
        echo -e "${NC}"
        
        # Timestamp
        echo -e "${CYAN}${BOLD}${INFO} Última atualização: $(date '+%Y-%m-%d %H:%M:%S')${NC}"
        echo
        
        # System Resources
        echo -e "${WHITE}${BOLD}${GRAPH} RECURSOS DO SISTEMA${NC}"
        echo "────────────────────────────────────────"
        
        local resources=($(get_system_resources))
        local cpu=${resources[0]:-0}
        local memory=${resources[1]:-0}
        local disk=${resources[2]:-0}
        
        show_resource_bar ${cpu%.*} 100 "CPU " "%"
        show_resource_bar ${memory%.*} 100 "RAM " "%"
        show_resource_bar $disk 100 "Disk" "%"
        echo
        
        # Docker Stats
        echo -e "${WHITE}${BOLD}🐳 DOCKER STATS${NC}"
        echo "────────────────────────────────────────"
        
        local docker_stats=($(get_docker_stats))
        echo -e "  ${BLUE}${BOLD}Containers:${NC} ${docker_stats[0]}"
        echo -e "  ${BLUE}${BOLD}Images:${NC} ${docker_stats[1]}"
        echo -e "  ${BLUE}${BOLD}Volumes:${NC} ${docker_stats[2]}"
        echo -e "  ${BLUE}${BOLD}Networks:${NC} ${docker_stats[3]}"
        echo
        
        # Service Health
        echo -e "${WHITE}${BOLD}${HEART} SAÚDE DOS SERVIÇOS${NC}"
        echo "────────────────────────────────────────"
        
        # Core Infrastructure
        echo -e "${CYAN}${BOLD}🏗️ Infraestrutura Core:${NC}"
        show_health_status "traefik_traefik" "$(get_service_health "traefik_traefik")" "Traefik"
        show_health_status "portainer_portainer" "$(get_service_health "portainer_portainer")" "Portainer"
        show_health_status "postgres_postgres" "$(get_service_health "postgres_postgres")" "PostgreSQL"
        show_health_status "redis_redis" "$(get_service_health "redis_redis")" "Redis"
        show_health_status "netdata_netdata" "$(get_service_health "netdata_netdata")" "Netdata"
        echo
        
        # AI Services
        echo -e "${CYAN}${BOLD}🤖 Inteligência Artificial:${NC}"
        show_health_status "ollama_ollama" "$(get_service_health "ollama_ollama")" "Ollama"
        show_health_status "openwebui_openwebui" "$(get_service_health "openwebui_openwebui")" "Open WebUI"
        show_health_status "flowise_flowise" "$(get_service_health "flowise_flowise")" "Flowise"
        echo
        
        # Development
        echo -e "${CYAN}${BOLD}🛠️ Desenvolvimento:${NC}"
        show_health_status "gitea_gitea" "$(get_service_health "gitea_gitea")" "Gitea"
        show_health_status "jenkins_jenkins" "$(get_service_health "jenkins_jenkins")" "Jenkins"
        show_health_status "vscode_vscode" "$(get_service_health "vscode_vscode")" "VS Code Server"
        echo
        
        # Monitoring
        echo -e "${CYAN}${BOLD}📊 Monitoramento:${NC}"
        show_health_status "prometheus_prometheus" "$(get_service_health "prometheus_prometheus")" "Prometheus"
        show_health_status "grafana_grafana" "$(get_service_health "grafana_grafana")" "Grafana"
        show_health_status "jaeger_jaeger" "$(get_service_health "jaeger_jaeger")" "Jaeger"
        echo
        
        # Quick Actions
        echo -e "${WHITE}${BOLD}⚡ AÇÕES RÁPIDAS${NC}"
        echo "────────────────────────────────────────"
        echo -e "  ${GREEN}[R]${NC} Reiniciar serviço específico"
        echo -e "  ${BLUE}[L]${NC} Ver logs de serviço"
        echo -e "  ${YELLOW}[S]${NC} Estatísticas detalhadas"
        echo -e "  ${RED}[Q]${NC} Sair do monitor"
        echo
        echo -e "${GRAY}${BOLD}Atualizando em 5 segundos... (Pressione Q para sair)${NC}"
        
        # Wait for input or auto-refresh
        if read -t 5 -n 1 key; then
            case "$key" in
                [Rr])
                    echo
                    echo -ne "${CYAN}Nome do serviço para reiniciar: ${NC}"
                    read -r service_name
                    if [[ -n "$service_name" ]]; then
                        echo -e "${YELLOW}Reiniciando $service_name...${NC}"
                        docker service update --force "$service_name" 2>/dev/null && \
                        echo -e "${GREEN}${CHECK} Serviço reiniciado!${NC}" || \
                        echo -e "${RED}${CROSS} Erro ao reiniciar serviço!${NC}"
                        sleep 3
                    fi
                    ;;
                [Ll])
                    echo
                    echo -ne "${CYAN}Nome do serviço para ver logs: ${NC}"
                    read -r service_name
                    if [[ -n "$service_name" ]]; then
                        echo -e "${BLUE}Logs de $service_name (últimas 20 linhas):${NC}"
                        docker service logs --tail 20 "$service_name" 2>/dev/null || \
                        echo -e "${RED}${CROSS} Serviço não encontrado!${NC}"
                        echo
                        echo -ne "${CYAN}Pressione ENTER para continuar...${NC}"
                        read
                    fi
                    ;;
                [Ss])
                    show_detailed_stats
                    ;;
                [Qq])
                    clear
                    echo -e "${GREEN}${BOLD}${CHECK} Monitor finalizado!${NC}"
                    exit 0
                    ;;
            esac
        fi
    done
}

show_detailed_stats() {
    clear
    echo -e "${WHITE}${BOLD}📊 ESTATÍSTICAS DETALHADAS${NC}"
    echo "════════════════════════════════════════════════════════════════"
    echo
    
    # Docker System Info
    echo -e "${CYAN}${BOLD}🐳 Docker System Info:${NC}"
    docker system df
    echo
    
    # Top processes
    echo -e "${CYAN}${BOLD}🔥 Top Processes (CPU):${NC}"
    docker stats --no-stream --format "table {{.Container}}\t{{.CPUPerc}}\t{{.MemUsage}}" | head -6
    echo
    
    # Service details
    echo -e "${CYAN}${BOLD}📋 Service Details:${NC}"
    docker service ls
    echo
    
    echo -ne "${CYAN}Pressione ENTER para voltar ao monitor...${NC}"
    read
}

# Main execution
main() {
    # Check if Docker is running
    if ! docker info >/dev/null 2>&1; then
        echo -e "${RED}${BOLD}${CROSS} Docker não está rodando!${NC}"
        echo -e "${CYAN}Inicie o Docker e tente novamente.${NC}"
        exit 1
    fi
    
    # Check if running as root
    if [[ $EUID -ne 0 ]]; then
        echo -e "${YELLOW}${BOLD}${WARNING} Executando sem privilégios de root.${NC}"
        echo -e "${CYAN}Algumas informações podem estar limitadas.${NC}"
        sleep 2
    fi
    
    show_realtime_dashboard
}

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi