#!/bin/bash

# =============================================================================
# MACSPARK-SETUP MAINTENANCE SCRIPT
# =============================================================================
# Versão: 1.0
# Data: 2025-07-22
# Descrição: Script automático de manutenção mensal para Macspark-Setup
# =============================================================================

set -euo pipefail

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configurações FHS
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# Usar diretórios FHS se disponíveis, senão usar diretórios locais
if [ -d "/var/log/macspark" ]; then
    LOG_DIR="/var/log/macspark"
    BACKUP_DIR="/var/lib/macspark/backups"
    CONFIG_DIR="/etc/macspark"
    MACSPARK_HOME="/opt/macspark"
else
    # Fallback para estrutura antiga
    LOG_DIR="${SCRIPT_DIR}/logs"
    BACKUP_DIR="${SCRIPT_DIR}/backups"
    CONFIG_DIR="${SCRIPT_DIR}"
    MACSPARK_HOME="${SCRIPT_DIR}"
fi
DATE=$(date +%Y%m%d_%H%M%S)
MAINTENANCE_LOG="${LOG_DIR}/maintenance_${DATE}.log"

# Funções de logging
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1" | tee -a "${MAINTENANCE_LOG}"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1" | tee -a "${MAINTENANCE_LOG}"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1" | tee -a "${MAINTENANCE_LOG}"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1" | tee -a "${MAINTENANCE_LOG}"
}

# Criar diretórios se não existirem
mkdir -p "${LOG_DIR}" "${BACKUP_DIR}"

# Header do log
{
    echo "========================================================================================"
    echo "MACSPARK-SETUP MAINTENANCE LOG - $(date)"
    echo "========================================================================================"
} >> "${MAINTENANCE_LOG}"

log_info "🔧 Iniciando manutenção automática do Macspark-Setup..."

# =============================================================================
# 1. VERIFICAÇÃO DO SISTEMA
# =============================================================================
log_info "📊 Verificando status do sistema..."

# Verificar se Docker está rodando
if ! systemctl is-active --quiet docker; then
    log_error "Docker não está ativo!"
    exit 1
fi

# Verificar Swarm
if ! docker info | grep -q "Swarm: active"; then
    log_error "Docker Swarm não está ativo!"
    exit 1
fi

log_success "Sistema verificado - Docker e Swarm ativos"

# =============================================================================
# 2. LIMPEZA DE IMAGENS ÓRFÃS
# =============================================================================
log_info "🧹 Limpando imagens órfãs..."

# Contar imagens órfãs antes
ORPHAN_COUNT_BEFORE=$(docker images | grep "<none>" | wc -l || echo "0")
log_info "Imagens órfãs encontradas: ${ORPHAN_COUNT_BEFORE}"

if [ "${ORPHAN_COUNT_BEFORE}" -gt 0 ]; then
    # Backup da lista de imagens antes da limpeza
    docker images > "${BACKUP_DIR}/images_before_cleanup_${DATE}.txt"
    
    # Limpeza agressiva de imagens não utilizadas
    CLEANUP_OUTPUT=$(docker image prune -a -f 2>&1 || echo "Erro na limpeza")
    echo "${CLEANUP_OUTPUT}" >> "${MAINTENANCE_LOG}"
    
    # Contar após limpeza
    ORPHAN_COUNT_AFTER=$(docker images | grep "<none>" | wc -l || echo "0")
    CLEANED_COUNT=$((ORPHAN_COUNT_BEFORE - ORPHAN_COUNT_AFTER))
    
    log_success "Limpeza concluída - ${CLEANED_COUNT} imagens removidas"
else
    log_info "Nenhuma imagem órfã encontrada"
fi

# =============================================================================
# 3. ANÁLISE DE LOGS DO TRAEFIK
# =============================================================================
log_info "🌐 Analisando logs do Traefik..."

TRAEFIK_LOG_FILE="${LOG_DIR}/traefik_analysis_${DATE}.log"

# Capturar logs do Traefik
if docker service ls | grep -q "traefik_traefik"; then
    echo "=== LOGS DO TRAEFIK (últimas 50 linhas) ===" > "${TRAEFIK_LOG_FILE}"
    docker service logs traefik_traefik --tail 50 >> "${TRAEFIK_LOG_FILE}" 2>&1
    
    # Análise de erros comuns
    ERROR_COUNT=$(grep -i "error\|fail\|timeout" "${TRAEFIK_LOG_FILE}" | wc -l || echo "0")
    WARNING_COUNT=$(grep -i "warn" "${TRAEFIK_LOG_FILE}" | wc -l || echo "0")
    
    if [ "${ERROR_COUNT}" -gt 0 ]; then
        log_warning "Traefik: ${ERROR_COUNT} erros encontrados nos logs"
        echo "--- ERROS ENCONTRADOS ---" >> "${TRAEFIK_LOG_FILE}"
        grep -i "error\|fail\|timeout" "${TRAEFIK_LOG_FILE}" >> "${TRAEFIK_LOG_FILE}" || true
    fi
    
    if [ "${WARNING_COUNT}" -gt 0 ]; then
        log_warning "Traefik: ${WARNING_COUNT} avisos encontrados nos logs"
    fi
    
    # Verificar se Traefik está respondendo
    if timeout 10 curl -s http://localhost:8080/api/entrypoints > /dev/null 2>&1; then
        log_success "Traefik API respondendo corretamente"
    else
        log_warning "Traefik API não está respondendo na porta 8080"
    fi
    
else
    log_error "Serviço traefik_traefik não encontrado!"
fi

# =============================================================================
# 4. VERIFICAÇÃO E AJUSTE DE CONFIGURAÇÃO IPv4 DO DOCKER
# =============================================================================
log_info "🔧 Verificando configuração IPv4 do Docker..."

DOCKER_DAEMON_JSON="/etc/docker/daemon.json"

# Verificar se existem avisos de IPv4 nos logs do Docker
IPV4_WARNINGS=$(journalctl -u docker --since "1 hour ago" | grep -i "ipv4.vs" | wc -l || echo "0")

if [ "${IPV4_WARNINGS}" -gt 0 ]; then
    log_warning "Encontrados ${IPV4_WARNINGS} avisos de IPv4 nos logs do Docker"
    
    # Criar backup da configuração atual
    if [ -f "${DOCKER_DAEMON_JSON}" ]; then
        cp "${DOCKER_DAEMON_JSON}" "${BACKUP_DIR}/daemon.json.backup.${DATE}"
    fi
    
    # Sugerir configuração otimizada (não aplicar automaticamente)
    cat > "${LOG_DIR}/docker_daemon_suggested_${DATE}.json" << 'EOF'
{
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  },
  "storage-driver": "overlay2",
  "iptables": false,
  "ip-forward": true,
  "ip-masq": true,
  "userland-proxy": false,
  "default-address-pools": [
    {
      "base": "172.20.0.0/16",
      "size": 24
    }
  ]
}
EOF
    
    log_info "Configuração sugerida criada em: ${LOG_DIR}/docker_daemon_suggested_${DATE}.json"
    log_warning "Revisar e aplicar manualmente se necessário. Requer restart do Docker."
else
    log_success "Nenhum aviso crítico de IPv4 encontrado"
fi

# =============================================================================
# 5. INSTALAÇÃO E CONFIGURAÇÃO DO TRIVY
# =============================================================================
log_info "🔒 Verificando instalação do Trivy..."

if ! command -v trivy &> /dev/null; then
    log_info "Trivy não instalado. Instalando..."
    
    # Instalar Trivy
    curl -sfL https://raw.githubusercontent.com/aquasecurity/trivy/main/contrib/install.sh | sh -s -- -b /usr/local/bin
    
    if command -v trivy &> /dev/null; then
        log_success "Trivy instalado com sucesso"
    else
        log_error "Falha na instalação do Trivy"
        exit 1
    fi
else
    log_success "Trivy já está instalado"
fi

# Atualizar base de dados do Trivy
log_info "Atualizando base de dados de vulnerabilidades..."
trivy image --download-db-only

# =============================================================================
# 6. SCAN DE VULNERABILIDADES NAS IMAGENS PRINCIPAIS
# =============================================================================
log_info "🔍 Executando scan de vulnerabilidades..."

VULN_REPORT="${LOG_DIR}/vulnerability_scan_${DATE}.txt"
echo "=== RELATÓRIO DE VULNERABILIDADES - $(date) ===" > "${VULN_REPORT}"

# Lista de imagens críticas para scan
CRITICAL_IMAGES=(
    "traefik:v3.4"
    "portainer/portainer-ce:lts"
    "postgres:15-alpine"
    "redis:7-alpine"
    "grafana/grafana:latest"
    "prom/prometheus:latest"
)

TOTAL_HIGH_VULNS=0
TOTAL_CRITICAL_VULNS=0

for image in "${CRITICAL_IMAGES[@]}"; do
    if docker images | grep -q "${image%:*}"; then
        log_info "Scanning ${image}..."
        
        # Executar scan
        SCAN_OUTPUT=$(trivy image --severity HIGH,CRITICAL --format table "${image}" 2>&1 || echo "Erro no scan")
        
        # Contar vulnerabilidades
        HIGH_COUNT=$(echo "${SCAN_OUTPUT}" | grep -c "HIGH" || echo "0")
        CRITICAL_COUNT=$(echo "${SCAN_OUTPUT}" | grep -c "CRITICAL" || echo "0")
        
        TOTAL_HIGH_VULNS=$((TOTAL_HIGH_VULNS + HIGH_COUNT))
        TOTAL_CRITICAL_VULNS=$((TOTAL_CRITICAL_VULNS + CRITICAL_COUNT))
        
        echo "--- SCAN: ${image} ---" >> "${VULN_REPORT}"
        echo "HIGH: ${HIGH_COUNT} | CRITICAL: ${CRITICAL_COUNT}" >> "${VULN_REPORT}"
        echo "${SCAN_OUTPUT}" >> "${VULN_REPORT}"
        echo "" >> "${VULN_REPORT}"
        
        if [ "${CRITICAL_COUNT}" -gt 0 ]; then
            log_warning "${image}: ${CRITICAL_COUNT} vulnerabilidades CRÍTICAS encontradas"
        elif [ "${HIGH_COUNT}" -gt 0 ]; then
            log_warning "${image}: ${HIGH_COUNT} vulnerabilidades ALTAS encontradas"
        else
            log_success "${image}: Nenhuma vulnerabilidade crítica"
        fi
    fi
done

log_info "Scan concluído. Total: ${TOTAL_CRITICAL_VULNS} críticas, ${TOTAL_HIGH_VULNS} altas"

# =============================================================================
# 7. VERIFICAÇÃO DE BACKUPS
# =============================================================================
log_info "💾 Verificando backups recentes..."

# Verificar backups dos últimos 7 dias
RECENT_BACKUPS=$(find "${BACKUP_DIR}" -name "*.tar.gz" -mtime -7 | wc -l)

if [ "${RECENT_BACKUPS}" -gt 0 ]; then
    log_success "${RECENT_BACKUPS} backup(s) recente(s) encontrado(s)"
    
    # Verificar integridade dos backups
    log_info "Verificando integridade dos backups..."
    for backup in $(find "${BACKUP_DIR}" -name "*.tar.gz" -mtime -7); do
        if tar -tzf "${backup}" > /dev/null 2>&1; then
            log_success "Backup íntegro: $(basename "${backup}")"
        else
            log_error "Backup corrompido: $(basename "${backup}")"
        fi
    done
else
    log_warning "Nenhum backup recente encontrado (últimos 7 dias)"
fi

# =============================================================================
# 8. CONFIGURAÇÃO DE CRON PARA SCANS AUTOMÁTICOS
# =============================================================================
log_info "⏰ Configurando agendamento automático..."

CRON_JOB="0 3 * * 0 cd ${SCRIPT_DIR} && ./maintenance.sh > /dev/null 2>&1"
TRIVY_CRON="0 2 * * 0 trivy image --exit-code 1 --severity CRITICAL $(docker images --format '{{.Repository}}:{{.Tag}}' | grep -v '<none>' | head -10) > ${LOG_DIR}/weekly_vuln_scan.log 2>&1"

# Verificar se já existe no cron
if ! crontab -l 2>/dev/null | grep -q "maintenance.sh"; then
    (crontab -l 2>/dev/null; echo "${CRON_JOB}") | crontab -
    log_success "Agendamento semanal configurado (Domingos às 03:00)"
else
    log_info "Agendamento já configurado"
fi

if ! crontab -l 2>/dev/null | grep -q "trivy image"; then
    (crontab -l 2>/dev/null; echo "${TRIVY_CRON}") | crontab -
    log_success "Scan automático de vulnerabilidades configurado (Domingos às 02:00)"
else
    log_info "Scan automático já configurado"
fi

# =============================================================================
# 9. RELATÓRIO FINAL DE STATUS
# =============================================================================
log_info "📋 Gerando relatório final..."

STATUS_REPORT="${LOG_DIR}/system_status_${DATE}.txt"

{
    echo "========================================================================================"
    echo "RELATÓRIO DE STATUS DO SISTEMA - $(date)"
    echo "========================================================================================"
    echo ""
    echo "=== INFORMAÇÕES DO SISTEMA ==="
    echo "Hostname: $(hostname)"
    echo "Uptime: $(uptime)"
    echo "Kernel: $(uname -r)"
    echo "Docker: $(docker --version)"
    echo ""
    echo "=== RECURSOS ==="
    free -h
    echo ""
    df -h | head -10
    echo ""
    echo "=== SERVIÇOS DOCKER ==="
    docker service ls
    echo ""
    echo "=== CONTAINERS ATIVOS ==="
    docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
    echo ""
    echo "=== RESUMO DA MANUTENÇÃO ==="
    echo "- Imagens limpas: ${CLEANED_COUNT:-0}"
    echo "- Vulnerabilidades críticas: ${TOTAL_CRITICAL_VULNS}"
    echo "- Vulnerabilidades altas: ${TOTAL_HIGH_VULNS}"
    echo "- Backups recentes: ${RECENT_BACKUPS}"
    echo "- Avisos IPv4: ${IPV4_WARNINGS}"
    echo ""
} > "${STATUS_REPORT}"

log_success "Relatório de status salvo em: ${STATUS_REPORT}"

# =============================================================================
# 10. FINALIZAÇÃO
# =============================================================================
echo ""
log_success "🎉 Manutenção concluída com sucesso!"
log_info "📁 Logs salvos em: ${LOG_DIR}"
log_info "📊 Relatório principal: ${STATUS_REPORT}"

if [ "${TOTAL_CRITICAL_VULNS}" -gt 0 ]; then
    log_warning "⚠️  ATENÇÃO: ${TOTAL_CRITICAL_VULNS} vulnerabilidades críticas encontradas!"
    log_info "📄 Detalhes em: ${VULN_REPORT}"
fi

if [ "${IPV4_WARNINGS}" -gt 0 ]; then
    log_warning "⚠️  Considere aplicar a configuração Docker sugerida"
fi

echo ""
echo "========================================================================================"
echo "Para executar manutenção manual:"
echo "  sudo ${SCRIPT_DIR}/maintenance.sh"
echo ""
echo "Para ver logs em tempo real:"
echo "  tail -f ${MAINTENANCE_LOG}"
echo "========================================================================================"