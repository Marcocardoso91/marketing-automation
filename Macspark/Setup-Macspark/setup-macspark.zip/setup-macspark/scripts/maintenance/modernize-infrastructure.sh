#!/bin/bash

# ============================================================================
# SETUP-MACSPARK INFRASTRUCTURE MODERNIZATION SCRIPT
# ============================================================================
# Script enterprise para modernizar e otimizar infraestrutura Docker Swarm
# Versão: 2025.1.0 - Integrado às melhores práticas Setup-Macspark
# ============================================================================

set -euo pipefail

# ============================================================================
# CONFIGURAÇÕES E VARIÁVEIS
# ============================================================================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(dirname "$(dirname "$SCRIPT_DIR")")"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

# Paths padrão Setup-Macspark
STACKS_DIR="$BASE_DIR/stacks"
CONFIGS_DIR="$BASE_DIR/configs"
LOGS_DIR="${LOGS_PATH:-/opt/macspark/logs}"

# Criar diretório de logs se não existir
mkdir -p "$LOGS_DIR"
LOG_FILE="$LOGS_DIR/modernize-infrastructure-$TIMESTAMP.log"

# ============================================================================
# FUNÇÕES DE LOGGING
# ============================================================================
log() {
    local message="$1"
    echo -e "${BLUE}[MODERNIZE]${NC} $message" | tee -a "$LOG_FILE"
}

success() {
    local message="$1"
    echo -e "${GREEN}[SUCCESS]${NC} $message" | tee -a "$LOG_FILE"
}

warning() {
    local message="$1"
    echo -e "${YELLOW}[WARNING]${NC} $message" | tee -a "$LOG_FILE"
}

error() {
    local message="$1"
    echo -e "${RED}[ERROR]${NC} $message" | tee -a "$LOG_FILE"
}

# ============================================================================
# BANNER ENTERPRISE
# ============================================================================
show_banner() {
    echo -e "${PURPLE}"
    echo "╔══════════════════════════════════════════════════════════════════╗"
    echo "║          🚀 SETUP-MACSPARK INFRASTRUCTURE MODERNIZATION         ║"
    echo "║                         Versão 2025.1.0                         ║"
    echo "║               Enterprise Docker Swarm Optimization               ║"
    echo "╚══════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

# ============================================================================
# PRÉ-REQUISITOS E VALIDAÇÕES
# ============================================================================
check_prerequisites() {
    log "🔍 Verificando pré-requisitos..."
    
    # Verificar se é root/sudo
    if [[ $EUID -ne 0 ]]; then
        error "Este script deve ser executado como root ou com sudo"
        exit 1
    fi
    
    # Verificar Docker
    if ! command -v docker >/dev/null 2>&1; then
        error "Docker não está instalado"
        exit 1
    fi
    
    # Verificar Swarm
    if ! docker info | grep -q "Swarm: active"; then
        warning "Docker Swarm não está ativo - será inicializado"
        docker swarm init --advertise-addr $(hostname -I | awk '{print $1}') || {
            error "Falha ao inicializar Docker Swarm"
            exit 1
        }
    fi
    
    success "✅ Pré-requisitos validados"
}

# ============================================================================
# OTIMIZAÇÃO DO DOCKER DAEMON
# ============================================================================
optimize_docker_daemon() {
    log "🐳 Otimizando configuração do Docker Daemon..."
    
    # Backup da configuração atual
    if [[ -f /etc/docker/daemon.json ]]; then
        cp /etc/docker/daemon.json "/etc/docker/daemon.json.backup.$TIMESTAMP"
        log "📁 Backup da configuração atual: daemon.json.backup.$TIMESTAMP"
    fi
    
    # Criar configuração enterprise otimizada
    cat > /etc/docker/daemon.json << 'EOF'
{
    "log-driver": "json-file",
    "log-opts": {
        "max-size": "10m",
        "max-file": "5",
        "compress": "true",
        "labels": "service,environment,version"
    },
    "storage-driver": "overlay2",
    "exec-opts": ["native.cgroupdriver=systemd"],
    "live-restore": true,
    "userland-proxy": false,
    "experimental": false,
    "iptables": false,
    "ip6tables": false,
    "metrics-addr": "127.0.0.1:9323",
    "features": {
        "buildkit": true
    },
    "builder": {
        "gc": {
            "enabled": true,
            "defaultKeepStorage": "20GB"
        }
    },
    "default-address-pools": [
        {
            "base": "172.20.0.0/16",
            "size": 24
        }
    ],
    "insecure-registries": [],
    "registry-mirrors": [],
    "max-concurrent-downloads": 3,
    "max-concurrent-uploads": 5,
    "default-shm-size": "64M",
    "shutdown-timeout": 15
}
EOF
    
    success "✅ Docker Daemon configurado para enterprise"
}

# ============================================================================
# OTIMIZAÇÃO DE REDES DOCKER SWARM
# ============================================================================
optimize_swarm_networks() {
    log "🌐 Otimizando redes Docker Swarm..."
    
    # Criar redes enterprise se não existirem
    local networks=(
        "traefik-public"
        "apps-internal" 
        "database-internal"
        "monitoring-internal"
        "security-internal"
    )
    
    for network in "${networks[@]}"; do
        if ! docker network inspect "$network" >/dev/null 2>&1; then
            log "📡 Criando rede: $network"
            case "$network" in
                "traefik-public")
                    docker network create \
                        --driver overlay \
                        --attachable \
                        --label "network.tier=public" \
                        --label "network.purpose=reverse-proxy" \
                        "$network"
                    ;;
                "*-internal")
                    docker network create \
                        --driver overlay \
                        --internal \
                        --encrypted \
                        --label "network.tier=internal" \
                        --label "network.purpose=${network%-*}" \
                        "$network"
                    ;;
                *)
                    docker network create \
                        --driver overlay \
                        --attachable \
                        --encrypted \
                        --label "network.tier=application" \
                        "$network"
                    ;;
            esac
            success "✅ Rede $network criada"
        else
            log "📡 Rede $network já existe - pulando"
        fi
    done
}

# ============================================================================
# CRIAÇÃO DE VOLUMES ENTERPRISE
# ============================================================================
create_enterprise_volumes() {
    log "💾 Criando estrutura de volumes enterprise..."
    
    # Diretórios base
    local base_volumes_path="${DOCKER_VOLUMES_PATH:-/opt/macspark/volumes}"
    
    # Estrutura de volumes enterprise
    local volume_dirs=(
        "traefik/letsencrypt"
        "traefik/logs"
        "traefik/dynamic"
        "postgres/data"
        "postgres/logs"
        "postgres/backups"
        "redis/data"
        "redis/logs" 
        "monitoring/prometheus"
        "monitoring/grafana"
        "monitoring/loki"
        "backup/data"
        "backup/logs"
        "security/vault"
        "security/secrets"
    )
    
    for dir in "${volume_dirs[@]}"; do
        local full_path="$base_volumes_path/$dir"
        if [[ ! -d "$full_path" ]]; then
            mkdir -p "$full_path"
            chown -R 1001:1001 "$full_path" 2>/dev/null || true
            chmod 755 "$full_path"
            log "📁 Criado: $full_path"
        fi
    done
    
    success "✅ Estrutura de volumes enterprise criada"
}

# ============================================================================
# CONFIGURAÇÕES DE SISTEMA OTIMIZADAS
# ============================================================================
optimize_system_configs() {
    log "⚙️ Aplicando otimizações de sistema..."
    
    # Otimizações do kernel para containers
    cat > /etc/sysctl.d/99-macspark-docker.conf << 'EOF'
# MacSpark Docker Swarm Optimizations
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 5000
net.core.rmem_max = 134217728
net.core.wmem_max = 134217728
net.ipv4.tcp_wmem = 4096 65536 134217728
net.ipv4.tcp_rmem = 4096 87380 134217728
net.ipv4.tcp_congestion_control = bbr
net.ipv4.tcp_slow_start_after_idle = 0
net.ipv4.ip_forward = 1
vm.swappiness = 10
vm.dirty_ratio = 15
vm.dirty_background_ratio = 5
fs.file-max = 2097152
kernel.pid_max = 4194304
EOF
    
    # Aplicar configurações
    sysctl -p /etc/sysctl.d/99-macspark-docker.conf
    
    # Limites de recursos
    cat > /etc/security/limits.d/99-macspark.conf << 'EOF'
# MacSpark resource limits
* soft nofile 1048576
* hard nofile 1048576
* soft nproc 1048576  
* hard nproc 1048576
root soft nofile 1048576
root hard nofile 1048576
root soft nproc 1048576
root hard nproc 1048576
EOF
    
    success "✅ Sistema otimizado para containers enterprise"
}

# ============================================================================
# CONFIGURAÇÕES POSTGRESQL ENTERPRISE
# ============================================================================
create_postgres_enterprise_config() {
    log "🐘 Criando configuração PostgreSQL enterprise..."
    
    local config_dir="$CONFIGS_DIR/database/postgres"
    mkdir -p "$config_dir"
    
    cat > "$config_dir/postgresql.conf" << 'EOF'
# ============================================================================
# POSTGRESQL ENTERPRISE CONFIGURATION - SETUP-MACSPARK
# ============================================================================

# Connection Settings
listen_addresses = '*'
port = 5432
max_connections = 200
superuser_reserved_connections = 3

# Memory Settings (otimizado para 16GB+ RAM)
shared_buffers = 4GB
effective_cache_size = 12GB
maintenance_work_mem = 1GB
work_mem = 64MB
wal_buffers = 32MB
huge_pages = try

# Checkpoint Settings  
checkpoint_completion_target = 0.9
checkpoint_timeout = 10min
max_wal_size = 4GB
min_wal_size = 1GB

# Query Planner
default_statistics_target = 100
random_page_cost = 1.1
effective_io_concurrency = 200
max_worker_processes = 8
max_parallel_workers_per_gather = 4
max_parallel_workers = 8

# WAL Settings
wal_level = replica
archive_mode = on
archive_command = '/usr/local/bin/postgres-archive.sh %f %p'
max_wal_senders = 10
wal_keep_size = 1GB
hot_standby = on

# Autovacuum (otimizado para workload misto)
autovacuum = on
autovacuum_max_workers = 6
autovacuum_naptime = 15s
autovacuum_vacuum_threshold = 50
autovacuum_analyze_threshold = 50
autovacuum_vacuum_scale_factor = 0.05
autovacuum_analyze_scale_factor = 0.02

# Logging Enterprise
log_destination = 'stderr,csvlog'
logging_collector = on
log_directory = '/var/log/postgresql'
log_filename = 'postgresql-%Y-%m-%d_%H%M%S.log'
log_rotation_age = 1d
log_rotation_size = 100MB
log_min_duration_statement = 500ms
log_checkpoints = on
log_connections = on
log_disconnections = on
log_lock_waits = on
log_temp_files = 10MB
log_autovacuum_min_duration = 0
log_error_verbosity = default
log_line_prefix = '%t [%p]: [%l-1] user=%u,db=%d,app=%a,client=%h '
log_statement = 'ddl'

# Security
password_encryption = scram-sha-256
ssl = on
ssl_cert_file = '/etc/ssl/certs/postgres.crt'
ssl_key_file = '/etc/ssl/private/postgres.key'

# Performance Monitoring
shared_preload_libraries = 'pg_stat_statements,pg_buffercache,pg_prewarm'
track_activities = on
track_counts = on
track_io_timing = on
track_functions = all
track_activity_query_size = 4096
pg_stat_statements.max = 10000
pg_stat_statements.track = all

# JSON/JSONB Optimizations  
default_text_search_config = 'pg_catalog.english'
EOF
    
    success "✅ Configuração PostgreSQL enterprise criada"
}

# ============================================================================
# CONFIGURAÇÕES REDIS ENTERPRISE
# ============================================================================
create_redis_enterprise_config() {
    log "🔴 Criando configuração Redis enterprise..."
    
    local config_dir="$CONFIGS_DIR/database/redis"
    mkdir -p "$config_dir"
    
    cat > "$config_dir/redis.conf" << 'EOF'
# ============================================================================
# REDIS ENTERPRISE CONFIGURATION - SETUP-MACSPARK
# ============================================================================

# Network
bind 0.0.0.0
port 6379
timeout 300
tcp-keepalive 300
tcp-backlog 511

# General
daemonize no
loglevel notice
logfile /var/log/redis/redis.log
databases 16
always-show-logo no

# Persistence RDB
save 900 1
save 300 10  
save 60 10000
stop-writes-on-bgsave-error yes
rdbcompression yes
rdbchecksum yes
dbfilename dump.rdb
rdb-del-sync-files no
dir /data

# Persistence AOF
appendonly yes
appendfilename "appendonly.aof"
appendfsync everysec
no-appendfsync-on-rewrite no
auto-aof-rewrite-percentage 100
auto-aof-rewrite-min-size 64mb
aof-load-truncated yes
aof-use-rdb-preamble yes
aof-timestamp-enabled no

# Memory Management Enterprise
maxmemory 2gb
maxmemory-policy allkeys-lru
maxmemory-samples 5
maxmemory-eviction-tenacity 10

# Performance Tuning
hash-max-ziplist-entries 512
hash-max-ziplist-value 64
list-max-ziplist-size -2
list-compress-depth 0
set-max-intset-entries 512
zset-max-ziplist-entries 128
zset-max-ziplist-value 64
hll-sparse-max-bytes 3000
stream-node-max-bytes 4096
stream-node-max-entries 100

# Security
requirepass ${REDIS_PASSWORD:-changeme123}
rename-command FLUSHDB ""
rename-command FLUSHALL ""
rename-command EVAL ""
rename-command DEBUG ""
rename-command CONFIG "CONFIG_09f911029d74e35b"

# Monitoring
latency-monitor-threshold 100
slowlog-log-slower-than 10000
slowlog-max-len 1024

# Clients
client-output-buffer-limit normal 0 0 0
client-output-buffer-limit replica 256mb 64mb 60
client-output-buffer-limit pubsub 32mb 8mb 60
client-query-buffer-limit 1gb
proto-max-bulk-len 512mb

# Advanced
hz 10
dynamic-hz yes
aof-rewrite-incremental-fsync yes
rdb-save-incremental-fsync yes
jemalloc-bg-thread yes
EOF
    
    success "✅ Configuração Redis enterprise criada"
}

# ============================================================================
# SCRIPT DE HEALTHCHECK ENTERPRISE
# ============================================================================
create_healthcheck_script() {
    log "🏥 Criando sistema de healthcheck enterprise..."
    
    local script_path="/usr/local/bin/macspark-healthcheck.sh"
    
    cat > "$script_path" << 'EOF'
#!/bin/bash

# MacSpark Enterprise Health Check
set -euo pipefail

TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
LOG_FILE="/opt/macspark/logs/healthcheck-$(date +%Y%m%d).log"

log() {
    echo "[$TIMESTAMP] $1" | tee -a "$LOG_FILE"
}

# Verificar Docker Swarm
check_swarm() {
    if docker info | grep -q "Swarm: active"; then
        log "✅ Docker Swarm: ATIVO"
        return 0
    else
        log "❌ Docker Swarm: INATIVO"
        return 1
    fi
}

# Verificar serviços críticos
check_services() {
    local critical_services=("traefik" "postgres" "redis")
    local failed_services=()
    
    for service in "${critical_services[@]}"; do
        local replicas=$(docker service ls --filter name="$service" --format "{{.Replicas}}" 2>/dev/null | head -1)
        if [[ "$replicas" =~ ^[1-9]+/[1-9]+$ ]]; then
            log "✅ Serviço $service: $replicas"
        else
            log "❌ Serviço $service: FALHA ($replicas)"
            failed_services+=("$service")
        fi
    done
    
    if [[ ${#failed_services[@]} -eq 0 ]]; then
        return 0
    else
        log "⚠️ Serviços com falha: ${failed_services[*]}"
        return 1
    fi
}

# Verificar recursos do sistema
check_resources() {
    local disk_usage=$(df /opt/macspark | awk 'NR==2 {print $5}' | sed 's/%//')
    local mem_usage=$(free | grep Mem | awk '{printf "%.1f", ($3/$2)*100}')
    
    log "📊 Uso de disco: ${disk_usage}%"
    log "📊 Uso de memória: ${mem_usage}%"
    
    if [[ $disk_usage -gt 90 ]]; then
        log "⚠️ ALERTA: Disco quase cheio (${disk_usage}%)"
        return 1
    fi
    
    if [[ $(echo "$mem_usage > 90" | bc -l) -eq 1 ]]; then
        log "⚠️ ALERTA: Memória quase cheia (${mem_usage}%)"
        return 1
    fi
    
    return 0
}

# Função principal
main() {
    log "🔍 Iniciando healthcheck enterprise..."
    
    local exit_code=0
    
    check_swarm || exit_code=1
    check_services || exit_code=1  
    check_resources || exit_code=1
    
    if [[ $exit_code -eq 0 ]]; then
        log "✅ Sistema saudável"
    else
        log "❌ Problemas detectados no sistema"
    fi
    
    return $exit_code
}

main "$@"
EOF
    
    chmod +x "$script_path"
    success "✅ Sistema de healthcheck enterprise criado"
}

# ============================================================================
# CRONJOBS DE MANUTENÇÃO
# ============================================================================
setup_maintenance_crons() {
    log "⏰ Configurando cronjobs de manutenção..."
    
    # Remover cronjobs antigos do macspark
    crontab -l 2>/dev/null | grep -v "macspark" | crontab -
    
    # Adicionar novos cronjobs
    (crontab -l 2>/dev/null; echo "# MacSpark Enterprise Maintenance") | crontab -
    (crontab -l 2>/dev/null; echo "*/5 * * * * /usr/local/bin/macspark-healthcheck.sh >/dev/null 2>&1") | crontab -
    (crontab -l 2>/dev/null; echo "0 2 * * * docker system prune -f --volumes >/dev/null 2>&1") | crontab -
    (crontab -l 2>/dev/null; echo "0 3 * * 0 docker builder prune -f --all >/dev/null 2>&1") | crontab -
    (crontab -l 2>/dev/null; echo "0 1 * * * find /opt/macspark/logs -name '*.log' -mtime +30 -delete") | crontab -
    
    success "✅ Cronjobs de manutenção configurados"
}

# ============================================================================
# FUNÇÃO PRINCIPAL
# ============================================================================
main() {
    show_banner
    
    log "🎯 Iniciando modernização enterprise da infraestrutura Setup-Macspark..."
    
    # Executar todas as otimizações em sequência
    check_prerequisites
    optimize_docker_daemon
    optimize_swarm_networks  
    create_enterprise_volumes
    optimize_system_configs
    create_postgres_enterprise_config
    create_redis_enterprise_config
    create_healthcheck_script
    setup_maintenance_crons
    
    success "🎉 Modernização enterprise concluída com sucesso!"
    
    # Próximos passos
    echo ""
    echo -e "${GREEN}=== PRÓXIMOS PASSOS ===${NC}"
    echo -e "${CYAN}1. Reiniciar Docker daemon: ${NC}systemctl restart docker"
    echo -e "${CYAN}2. Verificar redes: ${NC}docker network ls"
    echo -e "${CYAN}3. Executar healthcheck: ${NC}/usr/local/bin/macspark-healthcheck.sh"
    echo -e "${CYAN}4. Deploy stacks modernizados: ${NC}./scripts/deployment/deploy-production.sh"
    echo -e "${CYAN}5. Monitorar logs: ${NC}tail -f $LOG_FILE"
    echo ""
    
    warning "⚠️ IMPORTANTE: Reinicie o Docker daemon para aplicar todas as otimizações"
    
    return 0
}

# Executar se chamado diretamente
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi