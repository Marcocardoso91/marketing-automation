#!/usr/bin/env python3
"""
Converter JSON Docker Service Inspect para Docker Compose YML
Criado para migração completa VPS Setup-Macspark
Data: 23/08/2025
"""

import json
import yaml
import os
import re
from pathlib import Path
from typing import Dict, Any, List

class DockerServiceConverter:
    def __init__(self, input_dir: str, output_dir: str):
        self.input_dir = Path(input_dir)
        self.output_dir = Path(output_dir)
        
        # Categorização por nome do serviço
        self.categories = {
            'core': ['traefik', 'postgres', 'redis', 'lgtm', 'netdata', 'prometheus', 'grafana', 'loki'],
            'applications_ai': ['qwen', 'ollama', 'agente', 'n8n', 'sparkone', 'mcp'],
            'applications_communication': ['evolution', 'rocketchat', 'chatwoot', 'jitsi'],
            'applications_productivity': ['bookstack', 'heimdall', 'portainer', 'adminer'],
            'applications_development': ['registry', 'code-server', 'penpot'],
            'infrastructure': ['backup', 'vault', 'minio', 'restic', 'kopia', 'consul'],
            'monitoring': ['cyber-monitor', 'performance', 'agno', 'db-mgmt'],
            'storage': ['nextcloud', 'photoprism', 'mc-setup']
        }
    
    def categorize_service(self, service_name: str) -> str:
        """Categoriza serviço baseado no nome"""
        service_lower = service_name.lower()
        
        for category, keywords in self.categories.items():
            for keyword in keywords:
                if keyword in service_lower:
                    return category
        
        # Default para miscellaneous se não encontrar categoria
        return 'miscellaneous'
    
    def convert_nanoseconds_to_seconds(self, nanoseconds: int) -> str:
        """Converte nanosegundos para formato de segundos do Docker Compose"""
        if nanoseconds is None:
            return "30s"
        
        seconds = nanoseconds // 1_000_000_000
        if seconds == 0:
            return "1s"
        return f"{seconds}s"
    
    def convert_bytes_to_readable(self, bytes_value: int) -> str:
        """Converte bytes para formato legível (MB/GB)"""
        if bytes_value is None:
            return "512M"
            
        if bytes_value >= 1_073_741_824:  # >= 1GB
            return f"{bytes_value // 1_073_741_824}G"
        elif bytes_value >= 1_048_576:  # >= 1MB
            return f"{bytes_value // 1_048_576}M"
        else:
            return f"{bytes_value // 1024}K"
    
    def convert_nanocpus_to_cpus(self, nanocpus: int) -> str:
        """Converte NanoCPUs para formato CPUs"""
        if nanocpus is None:
            return "1"
        
        cpus = nanocpus / 1_000_000_000
        if cpus < 1:
            return f"{cpus:.1f}"
        return str(int(cpus))
    
    def extract_image_name(self, image_full: str) -> str:
        """Extrai nome da imagem removendo SHA digest"""
        if '@sha256:' in image_full:
            return image_full.split('@sha256:')[0]
        return image_full
    
    def convert_mounts(self, mounts: List[Dict]) -> List[str]:
        """Converte mounts Docker Swarm para volumes Docker Compose"""
        volumes = []
        
        for mount in mounts:
            mount_type = mount.get('Type', 'volume')
            source = mount.get('Source', '')
            target = mount.get('Target', '')
            read_only = mount.get('ReadOnly', False)
            
            if mount_type == 'bind':
                volume_str = f"{source}:{target}"
                if read_only:
                    volume_str += ":ro"
                volumes.append(volume_str)
            elif mount_type == 'volume':
                volume_str = f"{source}:{target}"
                if read_only:
                    volume_str += ":ro"
                volumes.append(volume_str)
        
        return volumes
    
    def convert_ports(self, endpoint_spec: Dict) -> List[str]:
        """Converte ports do Docker Swarm para Docker Compose"""
        ports = []
        
        if not endpoint_spec or 'Ports' not in endpoint_spec:
            return ports
        
        for port in endpoint_spec.get('Ports', []):
            published = port.get('PublishedPort')
            target = port.get('TargetPort')
            protocol = port.get('Protocol', 'tcp')
            
            if published and target:
                port_str = f"{published}:{target}"
                if protocol != 'tcp':
                    port_str += f"/{protocol}"
                ports.append(port_str)
        
        return ports
    
    def convert_healthcheck(self, healthcheck: Dict) -> Dict:
        """Converte healthcheck do Docker Swarm para Docker Compose"""
        if not healthcheck:
            return {}
        
        compose_healthcheck = {}
        
        if 'Test' in healthcheck:
            compose_healthcheck['test'] = healthcheck['Test']
        
        if 'Interval' in healthcheck:
            compose_healthcheck['interval'] = self.convert_nanoseconds_to_seconds(healthcheck['Interval'])
        
        if 'Timeout' in healthcheck:
            compose_healthcheck['timeout'] = self.convert_nanoseconds_to_seconds(healthcheck['Timeout'])
        
        if 'Retries' in healthcheck:
            compose_healthcheck['retries'] = healthcheck['Retries']
        
        if 'StartPeriod' in healthcheck:
            compose_healthcheck['start_period'] = self.convert_nanoseconds_to_seconds(healthcheck['StartPeriod'])
        
        return compose_healthcheck
    
    def extract_networks(self, networks: List[Dict]) -> List[str]:
        """Extrai nomes de redes dos aliases"""
        network_names = []
        for network in networks:
            if 'Aliases' in network:
                # Usar primeiro alias como nome da rede
                if network['Aliases']:
                    network_names.append(network['Aliases'][0] + '-network')
        
        # Se não tem aliases, usar nome padrão
        if not network_names:
            network_names = ['default']
        
        return network_names
    
    def convert_service_to_compose(self, service_data: Dict) -> Dict:
        """Converte um serviço Docker Swarm para formato Docker Compose"""
        spec = service_data.get('Spec', {})
        task_template = spec.get('TaskTemplate', {})
        container_spec = task_template.get('ContainerSpec', {})
        
        # Nome do serviço (remove prefix do stack)
        full_name = spec.get('Name', 'unknown')
        service_name = full_name.split('_')[-1] if '_' in full_name else full_name
        
        # Configuração base do serviço
        service_config = {}
        
        # Imagem
        if 'Image' in container_spec:
            service_config['image'] = self.extract_image_name(container_spec['Image'])
        
        # Environment variables
        if 'Env' in container_spec:
            service_config['environment'] = container_spec['Env']
        
        # Command/Args
        if 'Args' in container_spec:
            service_config['command'] = container_spec['Args']
        
        # Volumes
        if 'Mounts' in container_spec:
            volumes = self.convert_mounts(container_spec['Mounts'])
            if volumes:
                service_config['volumes'] = volumes
        
        # Ports
        ports = self.convert_ports(spec.get('EndpointSpec', {}))
        if ports:
            service_config['ports'] = ports
        
        # Healthcheck
        if 'Healthcheck' in container_spec:
            healthcheck = self.convert_healthcheck(container_spec['Healthcheck'])
            if healthcheck:
                service_config['healthcheck'] = healthcheck
        
        # Deploy configuration
        deploy_config = {}
        
        # Replicas
        mode = spec.get('Mode', {})
        if 'Replicated' in mode:
            deploy_config['replicas'] = mode['Replicated'].get('Replicas', 1)
        
        # Resources
        resources = task_template.get('Resources', {})
        if resources:
            resource_config = {}
            
            if 'Limits' in resources:
                limits = {}
                limits_data = resources['Limits']
                
                if 'NanoCPUs' in limits_data:
                    limits['cpus'] = self.convert_nanocpus_to_cpus(limits_data['NanoCPUs'])
                
                if 'MemoryBytes' in limits_data:
                    limits['memory'] = self.convert_bytes_to_readable(limits_data['MemoryBytes'])
                
                if limits:
                    resource_config['limits'] = limits
            
            if 'Reservations' in resources:
                reservations = {}
                reservations_data = resources['Reservations']
                
                if 'NanoCPUs' in reservations_data:
                    reservations['cpus'] = self.convert_nanocpus_to_cpus(reservations_data['NanoCPUs'])
                
                if 'MemoryBytes' in reservations_data:
                    reservations['memory'] = self.convert_bytes_to_readable(reservations_data['MemoryBytes'])
                
                if reservations:
                    resource_config['reservations'] = reservations
            
            if resource_config:
                deploy_config['resources'] = resource_config
        
        # Placement constraints
        placement = task_template.get('Placement', {})
        if 'Constraints' in placement and placement['Constraints']:
            deploy_config['placement'] = {
                'constraints': placement['Constraints']
            }
        
        # Restart policy
        restart_policy = task_template.get('RestartPolicy', {})
        if restart_policy:
            policy_config = {}
            condition = restart_policy.get('Condition', 'any')
            
            if condition == 'on-failure':
                policy_config['condition'] = 'on-failure'
                if 'MaxAttempts' in restart_policy:
                    policy_config['max_attempts'] = restart_policy['MaxAttempts']
            
            if policy_config:
                deploy_config['restart_policy'] = policy_config
        
        if deploy_config:
            service_config['deploy'] = deploy_config
        
        # Networks
        if 'Networks' in task_template:
            networks = self.extract_networks(task_template['Networks'])
            service_config['networks'] = networks
        
        return {service_name: service_config}
    
    def process_json_file(self, json_file: Path) -> Dict:
        """Processa um arquivo JSON e converte para formato Compose"""
        try:
            with open(json_file, 'r') as f:
                data = json.load(f)
            
            # Docker service inspect retorna uma lista com um item
            if isinstance(data, list) and len(data) > 0:
                service_data = data[0]
            else:
                service_data = data
            
            return self.convert_service_to_compose(service_data)
        
        except Exception as e:
            print(f"❌ Erro processando {json_file}: {e}")
            return {}
    
    def create_compose_file(self, category: str, services: Dict):
        """Cria arquivo Docker Compose para uma categoria"""
        compose_data = {
            'version': '3.8',
            'services': services
        }
        
        # Adicionar networks padrão
        networks = set()
        for service_config in services.values():
            if 'networks' in service_config:
                networks.update(service_config['networks'])
        
        if networks:
            compose_data['networks'] = {}
            for network in networks:
                if network != 'default':
                    compose_data['networks'][network] = {'external': True}
        
        # Extrair volumes usados
        volumes = set()
        for service_config in services.values():
            if 'volumes' in service_config:
                for volume in service_config['volumes']:
                    if ':' in volume:
                        volume_name = volume.split(':')[0]
                        # Apenas volumes nomeados (não bind mounts)
                        if not volume_name.startswith('/'):
                            volumes.add(volume_name)
        
        if volumes:
            compose_data['volumes'] = {}
            for volume in volumes:
                compose_data['volumes'][volume] = {}
        
        # Salvar arquivo
        category_dir = self.output_dir / category.replace('_', '/')
        category_dir.mkdir(parents=True, exist_ok=True)
        
        output_file = category_dir / f"{category.split('_')[-1]}.yml"
        
        with open(output_file, 'w') as f:
            yaml.dump(compose_data, f, default_flow_style=False, sort_keys=False, indent=2)
        
        print(f"✅ Criado: {output_file} ({len(services)} serviços)")
    
    def convert_all(self):
        """Converte todos os arquivos JSON encontrados"""
        print("🔄 INICIANDO CONVERSÃO JSON → YML")
        print("="*50)
        
        # Criar diretório de saída
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Buscar arquivos JSON
        json_files = list(self.input_dir.glob("*_config.json"))
        
        if not json_files:
            print("❌ Nenhum arquivo *_config.json encontrado!")
            return
        
        print(f"📁 Encontrados {len(json_files)} arquivos JSON")
        
        # Categorizar serviços
        categorized_services = {}
        
        for json_file in json_files:
            print(f"🔍 Processando: {json_file.name}")
            
            service_compose = self.process_json_file(json_file)
            if not service_compose:
                continue
            
            # Determinar categoria
            service_name = list(service_compose.keys())[0]
            category = self.categorize_service(service_name)
            
            if category not in categorized_services:
                categorized_services[category] = {}
            
            categorized_services[category].update(service_compose)
        
        # Criar arquivos por categoria
        print(f"\n📊 ORGANIZANDO EM {len(categorized_services)} CATEGORIAS:")
        
        for category, services in categorized_services.items():
            self.create_compose_file(category, services)
        
        print(f"\n✅ CONVERSÃO COMPLETA!")
        print(f"📂 Arquivos salvos em: {self.output_dir}")


if __name__ == "__main__":
    # Configuração dos diretórios
    input_directory = "/home/marcocardoso/Setup-Macspark/backup-vps-atual/stacks"
    output_directory = "/home/marcocardoso/Setup-Macspark/stacks-converted"
    
    # Executar conversão
    converter = DockerServiceConverter(input_directory, output_directory)
    converter.convert_all()
    
    print("\n🎯 PRÓXIMOS PASSOS:")
    print("1. Revisar arquivos YML gerados")
    print("2. Ajustar redes e volumes conforme necessário")
    print("3. Testar deployment em ambiente de desenvolvimento")
    print("4. Migrar para estrutura final Setup-Macspark/stacks/")