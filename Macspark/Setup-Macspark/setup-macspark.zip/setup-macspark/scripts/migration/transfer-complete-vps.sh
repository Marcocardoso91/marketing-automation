#!/bin/bash
# TRANSFERÊNCIA COMPLETA VPS - Macspark-Setup para Setup-Macspark
# Data: 23/08/2025
# Objetivo: Copiar TODOS os arquivos e configurações

set -euo pipefail

echo "🚀 INICIANDO TRANSFERÊNCIA COMPLETA VPS"
echo "======================================"

MACSPARK_SETUP="/home/marcocardoso/Macspark-Setup"
TARGET_DIR="/home/marcocardoso/Setup-Macspark"
BACKUP_DIR="$TARGET_DIR/backup-vps-atual"

# Verificar se diretórios existem
if [[ ! -d "$MACSPARK_SETUP" ]]; then
    echo "❌ Diretório Macspark-Setup não encontrado!"
    exit 1
fi

echo "📂 1. COPIANDO STACKS YML (68 arquivos)..."
mkdir -p "$TARGET_DIR/stacks-macspark-setup"
cp -rv "$MACSPARK_SETUP/stacks"/* "$TARGET_DIR/stacks-macspark-setup/" || true

echo "📜 2. COPIANDO SCRIPTS DE AUTOMAÇÃO..."
mkdir -p "$TARGET_DIR/scripts-macspark-setup"
cp -rv "$MACSPARK_SETUP/scripts"/* "$TARGET_DIR/scripts-macspark-setup/" || true
cp -v "$MACSPARK_SETUP"/*.sh "$TARGET_DIR/scripts-macspark-setup/" || true

echo "⚙️ 3. COPIANDO CONFIGURAÇÕES..."
mkdir -p "$TARGET_DIR/configs-macspark-setup"
cp -rv "$MACSPARK_SETUP/configs"/* "$TARGET_DIR/configs-macspark-setup/" || true

echo "📊 4. COPIANDO MONITORAMENTO..."
mkdir -p "$TARGET_DIR/monitoring-macspark-setup"
cp -rv "$MACSPARK_SETUP/monitoring"/* "$TARGET_DIR/monitoring-macspark-setup/" || true

echo "📚 5. COPIANDO DOCUMENTAÇÃO..."
mkdir -p "$TARGET_DIR/docs-macspark-setup"
cp -rv "$MACSPARK_SETUP/docs"/* "$TARGET_DIR/docs-macspark-setup/" || true

echo "🔧 6. COPIANDO ARQUIVOS RAIZ..."
cp -v "$MACSPARK_SETUP"/.env.example "$TARGET_DIR/" || true
cp -v "$MACSPARK_SETUP"/install-2025.sh "$TARGET_DIR/" || true
cp -v "$MACSPARK_SETUP"/ai-installer.py "$TARGET_DIR/" || true

echo "🔍 7. ANALISANDO STACKS ENCONTRADOS..."
find "$TARGET_DIR/stacks-macspark-setup" -name "*.yml" -o -name "*.yaml" | wc -l | xargs echo "   Arquivos YML encontrados:"

echo "📋 8. LISTANDO STACKS POR CATEGORIA..."

echo "   === CORE/INFRA ==="
find "$TARGET_DIR/stacks-macspark-setup" -path "*/traefik/*" -name "*.yml" | head -3
find "$TARGET_DIR/stacks-macspark-setup" -path "*/infra/*" -name "*.yml" | head -3

echo "   === APPLICATIONS ==="
find "$TARGET_DIR/stacks-macspark-setup" -path "*/apps/*" -name "*.yml" | head -3
find "$TARGET_DIR/stacks-macspark-setup" -path "*/ai/*" -name "*.yml" | head -3

echo "   === MONITORING ==="
find "$TARGET_DIR/stacks-macspark-setup" -path "*/monitoring/*" -name "*.yml" | head -3

echo "   === BACKUP/SECURITY ==="
find "$TARGET_DIR/stacks-macspark-setup" -path "*/backup/*" -name "*.yml" | head -3
find "$TARGET_DIR/stacks-macspark-setup" -path "*/security/*" -name "*.yml" | head -3

echo "🔄 9. CONVERTENDO PARA ESTRUTURA SETUP-MACSPARK..."

# Core services
mkdir -p "$TARGET_DIR/stacks/core"/{traefik,database,monitoring,networking}
find "$TARGET_DIR/stacks-macspark-setup" -path "*/traefik/*" -name "*.yml" -exec cp {} "$TARGET_DIR/stacks/core/traefik/" \;
find "$TARGET_DIR/stacks-macspark-setup" -path "*/infra/*" -name "*postgres*.yml" -exec cp {} "$TARGET_DIR/stacks/core/database/" \;
find "$TARGET_DIR/stacks-macspark-setup" -path "*/infra/*" -name "*redis*.yml" -exec cp {} "$TARGET_DIR/stacks/core/database/" \;
find "$TARGET_DIR/stacks-macspark-setup" -path "*/monitoring/*" -name "*.yml" -exec cp {} "$TARGET_DIR/stacks/core/monitoring/" \;

# Applications
mkdir -p "$TARGET_DIR/stacks/applications"/{ai,productivity,communication,development,media}
find "$TARGET_DIR/stacks-macspark-setup" -path "*/ai/*" -name "*.yml" -exec cp {} "$TARGET_DIR/stacks/applications/ai/" \;
find "$TARGET_DIR/stacks-macspark-setup" -path "*/apps/*" -name "*n8n*.yml" -exec cp {} "$TARGET_DIR/stacks/applications/productivity/" \;
find "$TARGET_DIR/stacks-macspark-setup" -path "*/chat/*" -name "*.yml" -exec cp {} "$TARGET_DIR/stacks/applications/communication/" \;
find "$TARGET_DIR/stacks-macspark-setup" -path "*/development/*" -name "*.yml" -exec cp {} "$TARGET_DIR/stacks/applications/development/" \;
find "$TARGET_DIR/stacks-macspark-setup" -path "*/portainer/*" -name "*.yml" -exec cp {} "$TARGET_DIR/stacks/applications/development/" \;

# Infrastructure
mkdir -p "$TARGET_DIR/stacks/infrastructure"/{backup,security,registry,logging,automation}
find "$TARGET_DIR/stacks-macspark-setup" -path "*/backup/*" -name "*.yml" -exec cp {} "$TARGET_DIR/stacks/infrastructure/backup/" \;
find "$TARGET_DIR/stacks-macspark-setup" -path "*/security/*" -name "*.yml" -exec cp {} "$TARGET_DIR/stacks/infrastructure/security/" \;
find "$TARGET_DIR/stacks-macspark-setup" -path "*/registry/*" -name "*.yml" -exec cp {} "$TARGET_DIR/stacks/infrastructure/registry/" \;
find "$TARGET_DIR/stacks-macspark-setup" -path "*/storage/*" -name "*.yml" -exec cp {} "$TARGET_DIR/stacks/infrastructure/" \;

echo "📊 10. GERANDO RELATÓRIO DE TRANSFERÊNCIA..."

cat > "$TARGET_DIR/RELATORIO_TRANSFERENCIA_COMPLETA.md" << 'EOF'
# 📊 RELATÓRIO DE TRANSFERÊNCIA COMPLETA

## ✅ ARQUIVOS TRANSFERIDOS:

### 📂 Macspark-Setup → Setup-Macspark
EOF

echo "**Stacks YML:** $(find "$TARGET_DIR/stacks-macspark-setup" -name "*.yml" | wc -l) arquivos" >> "$TARGET_DIR/RELATORIO_TRANSFERENCIA_COMPLETA.md"
echo "**Scripts:** $(find "$TARGET_DIR/scripts-macspark-setup" -name "*.sh" | wc -l) scripts" >> "$TARGET_DIR/RELATORIO_TRANSFERENCIA_COMPLETA.md"
echo "**Configs:** $(find "$TARGET_DIR/configs-macspark-setup" -type f | wc -l) arquivos" >> "$TARGET_DIR/RELATORIO_TRANSFERENCIA_COMPLETA.md"

cat >> "$TARGET_DIR/RELATORIO_TRANSFERENCIA_COMPLETA.md" << 'EOF'

### 📦 Estrutura Organizada:
```
Setup-Macspark/
├── stacks/                    # ✅ Reorganizado
│   ├── core/                  # Traefik, DB, Monitoring
│   ├── applications/          # AI, Productivity, Communication
│   └── infrastructure/        # Backup, Security, Registry
├── stacks-macspark-setup/     # ✅ Backup original
├── scripts-macspark-setup/    # ✅ Scripts originais
├── configs-macspark-setup/    # ✅ Configs originais
└── backup-vps-atual/          # ✅ Configurações VPS
```

## 🎯 PRÓXIMO PASSO:
Converter configurações JSON em arquivos YML funcionais
EOF

echo ""
echo "✅ TRANSFERÊNCIA COMPLETA FINALIZADA!"
echo "📊 Relatório: $TARGET_DIR/RELATORIO_TRANSFERENCIA_COMPLETA.md"
echo ""
echo "📈 ESTATÍSTICAS:"
echo "   Stacks YML: $(find "$TARGET_DIR/stacks-macspark-setup" -name "*.yml" | wc -l) arquivos"
echo "   Scripts: $(find "$TARGET_DIR/scripts-macspark-setup" -name "*.sh" | wc -l) arquivos"  
echo "   Configs: $(find "$TARGET_DIR/configs-macspark-setup" -type f | wc -l) arquivos"
echo ""
echo "🚀 VPS PRONTA PARA FORMATAÇÃO!"