#!/bin/bash

# ============================================================================
# ADVANCED HEALTH CHECKS - MACSPARK SETUP
# ============================================================================
# Sistema avançado de health checks com alertas automáticos
# Monitoramento proativo de serviços e infraestrutura
# ============================================================================

set -euo pipefail

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configurações
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
HEALTH_DIR="$PROJECT_ROOT/monitoring/health-checks"
ALERTS_DIR="$PROJECT_ROOT/monitoring/alerts"
RESULTS_DIR="$HEALTH_DIR/results"
TIMESTAMP=$(date '+%Y%m%d-%H%M%S')

# Configurações de alertas
WEBHOOK_URL=${WEBHOOK_URL:-""}
EMAIL_RECIPIENT=${EMAIL_RECIPIENT:-"admin@macspark.dev"}
ALERT_COOLDOWN=${ALERT_COOLDOWN:-300}  # 5 minutos

# Métricas
TOTAL_CHECKS=0
PASSED_CHECKS=0
FAILED_CHECKS=0
WARNING_CHECKS=0

# Logging
log() {
    local level=$1; shift
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    case $level in
        "INFO") echo -e "${BLUE}[INFO]${NC} [$timestamp] $*" ;;
        "SUCCESS") echo -e "${GREEN}[PASS]${NC} [$timestamp] $*"; ((PASSED_CHECKS++)) ;;
        "ERROR") echo -e "${RED}[FAIL]${NC} [$timestamp] $*"; ((FAILED_CHECKS++)) ;;
        "WARN") echo -e "${YELLOW}[WARN]${NC} [$timestamp] $*"; ((WARNING_CHECKS++)) ;;
    esac
    ((TOTAL_CHECKS++))
}

# Inicializar estrutura de monitoramento
init_monitoring_structure() {
    log "INFO" "🛠️  Inicializando estrutura de monitoramento..."
    
    mkdir -p "$HEALTH_DIR"/{config,templates,history}
    mkdir -p "$ALERTS_DIR"/{templates,history}
    mkdir -p "$RESULTS_DIR"
    
    # Criar configuração de health checks
    create_health_config
    
    # Criar templates de alertas
    create_alert_templates
    
    log "SUCCESS" "Estrutura de monitoramento inicializada"
}

# Criar configuração de health checks
create_health_config() {
    local config_file="$HEALTH_DIR/config/health-checks.yml"
    
    if [[ ! -f "$config_file" ]]; then
        cat > "$config_file" << 'EOF'
# ============================================================================
# CONFIGURAÇÃO DE HEALTH CHECKS - MACSPARK SETUP
# ============================================================================

version: "1.0"
update_interval: 300  # 5 minutos

# Checks de infraestrutura
infrastructure:
  docker_swarm:
    enabled: true
    command: "docker info | grep -q 'Swarm: active'"
    timeout: 10
    critical: true
    description: "Docker Swarm ativo"
    
  overlay_networks:
    enabled: true
    command: "docker network ls | grep overlay | wc -l"
    expected_min: 3
    timeout: 15
    critical: true
    description: "Redes overlay funcionais"
    
  docker_secrets:
    enabled: true
    command: "docker secret ls | wc -l"
    expected_min: 1
    timeout: 10
    critical: false
    description: "Docker secrets disponíveis"

# Checks de serviços core
core_services:
  traefik:
    enabled: true
    service_pattern: "traefik"
    port_check: 80
    url_check: "http://localhost/dashboard/"
    timeout: 30
    critical: true
    description: "Traefik proxy funcionando"
    
  prometheus:
    enabled: true
    service_pattern: "prometheus"
    url_check: "http://localhost/prometheus/api/v1/query?query=up"
    timeout: 20
    critical: false
    description: "Prometheus coletando métricas"
    
  grafana:
    enabled: true
    service_pattern: "grafana"
    url_check: "http://localhost/grafana/api/health"
    timeout: 20
    critical: false
    description: "Grafana dashboard ativo"

# Checks de recursos do sistema
system_resources:
  memory_usage:
    enabled: true
    command: "free | awk '/^Mem:/ {printf \"%.0f\", ($3/$2)*100}'"
    threshold_warning: 80
    threshold_critical: 90
    description: "Uso de memória RAM"
    
  disk_usage:
    enabled: true
    command: "df / | awk 'NR==2 {print $(NF-1)}' | sed 's/%//'"
    threshold_warning: 80
    threshold_critical: 95
    description: "Uso do disco raiz"
    
  load_average:
    enabled: true
    command: "uptime | grep -oE 'load average: [0-9.]+' | cut -d' ' -f3 | cut -d',' -f1"
    threshold_warning: 4.0
    threshold_critical: 8.0
    description: "Load average do sistema"

# Checks de conectividade
connectivity:
  internal_dns:
    enabled: true
    command: "docker run --rm --network core-network alpine:latest nslookup traefik"
    timeout: 15
    critical: true
    description: "DNS interno funcionando"
    
  external_connectivity:
    enabled: true
    command: "curl -s --connect-timeout 5 https://google.com"
    timeout: 10
    critical: false
    description: "Conectividade externa"
    
  ssl_certificates:
    enabled: true
    command: "curl -s -I https://traefik.homolog.macspark.dev | grep -q 'HTTP/2 200'"
    timeout: 15
    critical: true
    description: "Certificados SSL válidos"
EOF
        log "SUCCESS" "Configuração de health checks criada"
    fi
}

# Criar templates de alertas
create_alert_templates() {
    # Template Slack/Discord
    cat > "$ALERTS_DIR/templates/webhook-alert.json" << 'EOF'
{
  "text": "🚨 ALERTA MACSPARK - {{SEVERITY}}",
  "attachments": [
    {
      "color": "{{COLOR}}",
      "fields": [
        {
          "title": "Serviço",
          "value": "{{SERVICE}}",
          "short": true
        },
        {
          "title": "Status",
          "value": "{{STATUS}}",
          "short": true
        },
        {
          "title": "Descrição",
          "value": "{{DESCRIPTION}}",
          "short": false
        },
        {
          "title": "Timestamp",
          "value": "{{TIMESTAMP}}",
          "short": true
        },
        {
          "title": "Ambiente",
          "value": "{{ENVIRONMENT}}",
          "short": true
        }
      ]
    }
  ]
}
EOF

    # Template Email
    cat > "$ALERTS_DIR/templates/email-alert.html" << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <title>Alerta Macspark - {{SEVERITY}}</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .alert-critical { background: #f8d7da; border: 1px solid #dc3545; }
        .alert-warning { background: #fff3cd; border: 1px solid #ffc107; }
        .alert-info { background: #d1ecf1; border: 1px solid #17a2b8; }
        .header { padding: 15px; border-radius: 5px; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="header alert-{{SEVERITY_LOWER}}">
        <h2>🚨 Alerta Macspark - {{SEVERITY}}</h2>
    </div>
    
    <table border="1" cellpadding="10" cellspacing="0">
        <tr><td><strong>Serviço:</strong></td><td>{{SERVICE}}</td></tr>
        <tr><td><strong>Status:</strong></td><td>{{STATUS}}</td></tr>
        <tr><td><strong>Descrição:</strong></td><td>{{DESCRIPTION}}</td></tr>
        <tr><td><strong>Ambiente:</strong></td><td>{{ENVIRONMENT}}</td></tr>
        <tr><td><strong>Timestamp:</strong></td><td>{{TIMESTAMP}}</td></tr>
    </table>
    
    <p><strong>Ação recomendada:</strong> Verificar logs e status do serviço.</p>
    <p><em>Este é um alerta automático do sistema Macspark.</em></p>
</body>
</html>
EOF
}

# Executar health check de infraestrutura
check_infrastructure() {
    log "INFO" "🔧 Verificando infraestrutura..."
    
    # Docker Swarm
    if docker info 2>/dev/null | grep -q "Swarm: active"; then
        log "SUCCESS" "Docker Swarm ativo"
    else
        log "ERROR" "Docker Swarm não está ativo"
        send_alert "CRITICAL" "docker_swarm" "FAILED" "Docker Swarm não está ativo"
    fi
    
    # Redes overlay
    local networks_count=$(docker network ls | grep overlay | wc -l)
    if [[ $networks_count -ge 3 ]]; then
        log "SUCCESS" "Redes overlay: $networks_count"
    else
        log "WARN" "Poucas redes overlay: $networks_count"
        send_alert "WARNING" "overlay_networks" "LOW_COUNT" "Apenas $networks_count redes overlay encontradas"
    fi
    
    # Docker secrets
    local secrets_count=$(docker secret ls 2>/dev/null | wc -l || echo "0")
    if [[ $secrets_count -gt 0 ]]; then
        log "SUCCESS" "Docker secrets: $secrets_count"
    else
        log "WARN" "Nenhum Docker secret encontrado"
    fi
}

# Executar health check de serviços core
check_core_services() {
    log "INFO" "⚙️  Verificando serviços core..."
    
    # Lista de serviços essenciais
    local core_services=("traefik" "prometheus" "grafana")
    
    for service in "${core_services[@]}"; do
        local service_count=$(docker service ls --filter name="$service" --format "{{.Name}}" 2>/dev/null | wc -l)
        
        if [[ $service_count -gt 0 ]]; then
            local replicas=$(docker service ls --filter name="$service" --format "{{.Replicas}}" | head -1)
            if [[ "$replicas" =~ ^[1-9]/[1-9] ]]; then
                log "SUCCESS" "Serviço $service: $replicas"
                
                # Health check específico por URL
                case $service in
                    "traefik")
                        check_service_url "http://localhost/dashboard/" "Traefik Dashboard"
                        ;;
                    "prometheus")
                        check_service_url "http://localhost/prometheus/api/v1/query?query=up" "Prometheus API"
                        ;;
                    "grafana")
                        check_service_url "http://localhost/grafana/api/health" "Grafana API"
                        ;;
                esac
            else
                log "ERROR" "Serviço $service não saudável: $replicas"
                send_alert "CRITICAL" "$service" "UNHEALTHY" "Serviço $service com réplicas: $replicas"
            fi
        else
            log "ERROR" "Serviço $service não encontrado"
            send_alert "CRITICAL" "$service" "NOT_FOUND" "Serviço $service não encontrado"
        fi
    done
}

# Verificar URL de serviço
check_service_url() {
    local url=$1
    local service_name=$2
    local timeout=${3:-10}
    
    if curl -s --connect-timeout "$timeout" --max-time "$timeout" "$url" >/dev/null 2>&1; then
        log "SUCCESS" "$service_name acessível"
    else
        log "ERROR" "$service_name não acessível: $url"
        send_alert "WARNING" "$service_name" "URL_UNAVAILABLE" "$service_name não acessível via $url"
    fi
}

# Verificar recursos do sistema
check_system_resources() {
    log "INFO" "📊 Verificando recursos do sistema..."
    
    # Memória RAM
    local memory_percent=$(free | awk '/^Mem:/ {printf "%.0f", ($3/$2)*100}')
    if [[ $memory_percent -lt 80 ]]; then
        log "SUCCESS" "Uso de RAM: ${memory_percent}%"
    elif [[ $memory_percent -lt 90 ]]; then
        log "WARN" "Uso alto de RAM: ${memory_percent}%"
        send_alert "WARNING" "system_memory" "HIGH_USAGE" "Uso de RAM: ${memory_percent}%"
    else
        log "ERROR" "Uso crítico de RAM: ${memory_percent}%"
        send_alert "CRITICAL" "system_memory" "CRITICAL_USAGE" "Uso de RAM: ${memory_percent}%"
    fi
    
    # Disco
    local disk_percent=$(df / | awk 'NR==2 {print $(NF-1)}' | sed 's/%//')
    if [[ $disk_percent -lt 80 ]]; then
        log "SUCCESS" "Uso de disco: ${disk_percent}%"
    elif [[ $disk_percent -lt 95 ]]; then
        log "WARN" "Uso alto de disco: ${disk_percent}%"
        send_alert "WARNING" "system_disk" "HIGH_USAGE" "Uso de disco: ${disk_percent}%"
    else
        log "ERROR" "Uso crítico de disco: ${disk_percent}%"
        send_alert "CRITICAL" "system_disk" "CRITICAL_USAGE" "Uso de disco: ${disk_percent}%"
    fi
    
    # Load average
    local load_avg=$(uptime | grep -oE 'load average: [0-9.]+' | cut -d' ' -f3 | cut -d',' -f1)
    local load_int=$(echo "$load_avg" | cut -d'.' -f1)
    local cpu_cores=$(nproc)
    
    if [[ $load_int -lt $cpu_cores ]]; then
        log "SUCCESS" "Load average: $load_avg (${cpu_cores} cores)"
    elif [[ $load_int -lt $((cpu_cores * 2)) ]]; then
        log "WARN" "Load alto: $load_avg (${cpu_cores} cores)"
        send_alert "WARNING" "system_load" "HIGH_LOAD" "Load average: $load_avg em ${cpu_cores} cores"
    else
        log "ERROR" "Load crítico: $load_avg (${cpu_cores} cores)"
        send_alert "CRITICAL" "system_load" "CRITICAL_LOAD" "Load average: $load_avg em ${cpu_cores} cores"
    fi
}

# Verificar conectividade
check_connectivity() {
    log "INFO" "🌐 Verificando conectividade..."
    
    # DNS interno
    if docker run --rm --network core-network alpine:latest nslookup traefik >/dev/null 2>&1; then
        log "SUCCESS" "DNS interno funcionando"
    else
        log "ERROR" "Problema no DNS interno"
        send_alert "CRITICAL" "internal_dns" "FAILED" "DNS interno não está funcionando"
    fi
    
    # Conectividade externa
    if curl -s --connect-timeout 5 https://google.com >/dev/null 2>&1; then
        log "SUCCESS" "Conectividade externa OK"
    else
        log "WARN" "Problema na conectividade externa"
        send_alert "WARNING" "external_connectivity" "FAILED" "Conectividade externa com problemas"
    fi
    
    # SSL certificates
    if curl -s -I https://traefik.homolog.macspark.dev 2>/dev/null | grep -q "HTTP/2 200\|HTTP/1.1 200"; then
        log "SUCCESS" "Certificados SSL válidos"
    else
        log "WARN" "Problema com certificados SSL"
        send_alert "WARNING" "ssl_certificates" "INVALID" "Certificados SSL podem estar inválidos"
    fi
}

# Enviar alerta
send_alert() {
    local severity=$1
    local service=$2
    local status=$3
    local description=$4
    local timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
    local environment=${ENVIRONMENT:-"homolog"}
    
    # Verificar cooldown
    local alert_file="$ALERTS_DIR/history/${service}-${status}-alert.lock"
    if [[ -f "$alert_file" ]]; then
        local last_alert=$(stat -f %m "$alert_file" 2>/dev/null || stat -c %Y "$alert_file" 2>/dev/null)
        local current_time=$(date +%s)
        local time_diff=$((current_time - last_alert))
        
        if [[ $time_diff -lt $ALERT_COOLDOWN ]]; then
            log "INFO" "Alerta em cooldown para $service: ${time_diff}s < ${ALERT_COOLDOWN}s"
            return 0
        fi
    fi
    
    # Criar arquivo de lock para cooldown
    touch "$alert_file"
    
    # Webhook (Slack/Discord)
    if [[ -n "$WEBHOOK_URL" ]]; then
        send_webhook_alert "$severity" "$service" "$status" "$description" "$timestamp" "$environment"
    fi
    
    # Email (se configurado)
    if command -v mail >/dev/null 2>&1; then
        send_email_alert "$severity" "$service" "$status" "$description" "$timestamp" "$environment"
    fi
    
    # Log local
    echo "[$timestamp] ALERT: $severity - $service - $status - $description" >> "$ALERTS_DIR/history/alerts.log"
}

# Enviar alerta via webhook
send_webhook_alert() {
    local severity=$1
    local service=$2
    local status=$3
    local description=$4
    local timestamp=$5
    local environment=$6
    
    # Cor baseada na severidade
    local color="good"
    case $severity in
        "CRITICAL") color="danger" ;;
        "WARNING") color="warning" ;;
        "INFO") color="good" ;;
    esac
    
    # Processar template
    local payload=$(cat "$ALERTS_DIR/templates/webhook-alert.json" | \
        sed "s/{{SEVERITY}}/$severity/g" | \
        sed "s/{{COLOR}}/$color/g" | \
        sed "s/{{SERVICE}}/$service/g" | \
        sed "s/{{STATUS}}/$status/g" | \
        sed "s/{{DESCRIPTION}}/$description/g" | \
        sed "s/{{TIMESTAMP}}/$timestamp/g" | \
        sed "s/{{ENVIRONMENT}}/$environment/g")
    
    # Enviar webhook
    if curl -s -H "Content-Type: application/json" -d "$payload" "$WEBHOOK_URL" >/dev/null; then
        log "INFO" "Webhook enviado para $service"
    else
        log "WARN" "Falha ao enviar webhook para $service"
    fi
}

# Enviar alerta via email
send_email_alert() {
    local severity=$1
    local service=$2
    local status=$3
    local description=$4
    local timestamp=$5
    local environment=$6
    
    local subject="[MACSPARK] Alerta $severity - $service"
    local severity_lower=$(echo "$severity" | tr '[:upper:]' '[:lower:]')
    
    # Processar template HTML
    local body=$(cat "$ALERTS_DIR/templates/email-alert.html" | \
        sed "s/{{SEVERITY}}/$severity/g" | \
        sed "s/{{SEVERITY_LOWER}}/$severity_lower/g" | \
        sed "s/{{SERVICE}}/$service/g" | \
        sed "s/{{STATUS}}/$status/g" | \
        sed "s/{{DESCRIPTION}}/$description/g" | \
        sed "s/{{TIMESTAMP}}/$timestamp/g" | \
        sed "s/{{ENVIRONMENT}}/$environment/g")
    
    # Enviar email
    echo "$body" | mail -s "$subject" -a "Content-Type: text/html" "$EMAIL_RECIPIENT" 2>/dev/null || \
        log "WARN" "Falha ao enviar email para $EMAIL_RECIPIENT"
}

# Gerar relatório de saúde
generate_health_report() {
    local report_file="$RESULTS_DIR/health-report-${TIMESTAMP}.json"
    local success_rate=$(( PASSED_CHECKS * 100 / TOTAL_CHECKS ))
    
    cat > "$report_file" << EOF
{
  "timestamp": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
  "environment": "${ENVIRONMENT:-homolog}",
  "summary": {
    "total_checks": $TOTAL_CHECKS,
    "passed": $PASSED_CHECKS,
    "failed": $FAILED_CHECKS,
    "warnings": $WARNING_CHECKS,
    "success_rate": $success_rate
  },
  "status": "$(if [[ $success_rate -ge 95 ]]; then echo "HEALTHY"; elif [[ $success_rate -ge 80 ]]; then echo "DEGRADED"; else echo "UNHEALTHY"; fi)",
  "checks_executed": [
    "infrastructure",
    "core_services", 
    "system_resources",
    "connectivity"
  ]
}
EOF
    
    log "SUCCESS" "Relatório gerado: $report_file"
    return $success_rate
}

# Main
main() {
    echo -e "${BLUE}"
    echo "=========================================="
    echo "     ADVANCED HEALTH CHECKS"
    echo "=========================================="
    echo "🏥 Verificação completa de saúde do sistema"
    echo "=========================================="
    echo -e "${NC}"
    
    # Inicializar estrutura se necessário
    if [[ ! -d "$HEALTH_DIR" ]]; then
        init_monitoring_structure
    fi
    
    # Executar checks
    check_infrastructure
    check_core_services
    check_system_resources
    check_connectivity
    
    # Gerar relatório
    local success_rate
    success_rate=$(generate_health_report)
    
    # Resumo final
    echo ""
    echo -e "${BLUE}==========================================="
    echo "        RESUMO HEALTH CHECKS"
    echo "==========================================${NC}"
    echo "📊 Total: $TOTAL_CHECKS | ✅ Passou: $PASSED_CHECKS | ❌ Falhou: $FAILED_CHECKS | ⚠️  Aviso: $WARNING_CHECKS"
    echo "🎯 Taxa de sucesso: ${success_rate}%"
    
    if [[ $success_rate -ge 95 ]]; then
        echo -e "${GREEN}🎉 Sistema SAUDÁVEL${NC}"
        exit 0
    elif [[ $success_rate -ge 80 ]]; then
        echo -e "${YELLOW}⚠️  Sistema DEGRADADO${NC}"
        exit 1
    else
        echo -e "${RED}🚨 Sistema CRÍTICO${NC}"
        exit 2
    fi
}

# Executar
main "$@"