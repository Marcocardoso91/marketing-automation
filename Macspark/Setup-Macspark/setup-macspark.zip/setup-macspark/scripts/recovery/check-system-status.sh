#!/bin/bash
# Status Completo do Sistema - MacSpark Setup
# Gerado automaticamente em 2025-08-23

echo "🚀 MACSPARK SETUP - STATUS COMPLETO"
echo "=================================="
echo ""

# Informações básicas
echo "📅 Data/Hora: $(date)"
echo "🖥️  Hostname: $(hostname)"
echo "👤 Usuário: $(whoami)"
echo ""

# Docker Swarm Status
echo "🐳 DOCKER SWARM STATUS"
echo "----------------------"
if docker node ls > /dev/null 2>&1; then
    echo "✅ Docker Swarm ATIVO"
    echo "📊 Nodes:"
    docker node ls
    echo ""
    
    echo "📦 Stacks Ativas:"
    docker stack ls
    echo ""
    
    echo "⚠️  Serviços com Problemas (0 replicas):"
    docker service ls | grep "0/" | wc -l | xargs echo "   Total de serviços com problemas:"
    echo ""
    
    echo "✅ Serviços Funcionando:"
    docker service ls | grep -v "0/" | wc -l | xargs echo "   Total de serviços ok:"
    echo ""
else
    echo "❌ Docker Swarm INATIVO"
fi

# Sistema
echo "💻 SISTEMA"
echo "----------"
echo "🔋 Uptime: $(uptime | cut -d',' -f1 | cut -d' ' -f4-)"
echo "💾 Memória: $(free -h | grep Mem | awk '{print $3"/"$2}')"
echo "💿 Disco: $(df -h / | tail -1 | awk '{print $3"/"$2" ("$5" usado)"}')"
echo ""

# Portas principais
echo "🌐 PORTAS PRINCIPAIS"
echo "-------------------"
echo "🌍 Traefik Dashboard: :8080 $(netstat -tuln | grep :8080 > /dev/null && echo '✅' || echo '❌')"
echo "📊 Grafana: :3000 $(netstat -tuln | grep :3000 > /dev/null && echo '✅' || echo '❌')"
echo "🔴 Redis Commander: :9100 $(netstat -tuln | grep :9100 > /dev/null && echo '✅' || echo '❌')"
echo "🔒 Vault: :8200 $(netstat -tuln | grep :8200 > /dev/null && echo '✅' || echo '❌')"
echo "🐘 PostgreSQL: :5432 $(netstat -tuln | grep :5432 > /dev/null && echo '✅' || echo '❌')"
echo ""

# Últimas atividades
echo "📋 ÚLTIMAS ATIVIDADES"
echo "---------------------"
echo "🔄 Últimos 5 eventos Docker:"
docker events --since="1h" --until="now" | tail -5 || echo "Nenhum evento recente"
echo ""

echo "✅ Análise completa finalizada!"
echo "💡 Para restaurar serviços: ./scripts/recovery/restore-critical-services.sh"
echo "🚀 Para deploy homolog: sudo ./scripts/deployment/deploy-homolog-complete.sh"