#!/bin/bash
# 🔍 Script de Auditoria de Segurança - Secrets
# Setup MacSpark - Enterprise Security Audit

set -euo pipefail

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Configurações
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
AUDIT_LOG="/var/log/macspark-security-audit-$(date +%Y%m%d-%H%M%S).log"
REPORT_FILE="${PROJECT_ROOT}/secrets/SECURITY_AUDIT_$(date +%Y%m%d).md"

# Contadores
VULNERABILITIES_CRITICAL=0
VULNERABILITIES_HIGH=0
VULNERABILITIES_MEDIUM=0
VULNERABILITIES_LOW=0
FILES_SCANNED=0
SECRETS_FOUND=0

# Função de logging
log() {
    echo -e "${1}" | tee -a "${AUDIT_LOG}"
}

# Função para buscar passwords hardcoded
check_hardcoded_passwords() {
    log "${BLUE}🔍 Verificando passwords hardcoded...${NC}"
    
    local patterns=(
        "password="
        "PASSWORD="
        "passwd="
        "PASSWD="
        "secret="
        "SECRET="
        "token="
        "TOKEN="
        "api_key="
        "API_KEY="
        "apikey="
        "APIKEY="
    )
    
    local exclude_dirs=(
        ".git"
        "node_modules"
        "vendor"
        "__pycache__"
        ".venv"
        "dist"
        "build"
    )
    
    local exclude_pattern=""
    for dir in "${exclude_dirs[@]}"; do
        exclude_pattern="${exclude_pattern} -not -path '*/${dir}/*'"
    done
    
    for pattern in "${patterns[@]}"; do
        log "${CYAN}  Buscando: ${pattern}${NC}"
        
        # Buscar em arquivos de código
        while IFS= read -r file; do
            if grep -q "${pattern}" "$file" 2>/dev/null; then
                local lines=$(grep -n "${pattern}" "$file" 2>/dev/null | head -3)
                if [ -n "$lines" ]; then
                    log "${RED}    ⚠️  Encontrado em: ${file}${NC}"
                    echo "$lines" | while IFS= read -r line; do
                        log "${YELLOW}      ${line}${NC}"
                    done
                    ((SECRETS_FOUND++))
                    ((VULNERABILITIES_HIGH++))
                fi
            fi
            ((FILES_SCANNED++))
        done < <(find "${PROJECT_ROOT}" -type f \( -name "*.sh" -o -name "*.yml" -o -name "*.yaml" -o -name "*.py" -o -name "*.js" -o -name "*.ts" \) ! -path "*/deprecated/*" ${exclude_pattern})
    done
}

# Função para verificar arquivos .env
check_env_files() {
    log "${BLUE}🔍 Verificando arquivos .env...${NC}"
    
    # Buscar arquivos .env
    while IFS= read -r env_file; do
        log "${CYAN}  Analisando: ${env_file}${NC}"
        
        # Verificar se tem valores reais (não placeholders)
        if grep -E "=.*(secret|password|token|key)" "$env_file" | grep -v "change_me\|placeholder\|example\|your_" > /dev/null 2>&1; then
            log "${RED}    ⚠️  Possível secret real em ${env_file}${NC}"
            ((VULNERABILITIES_CRITICAL++))
        fi
        
        # Verificar se está no .gitignore
        if ! git check-ignore "$env_file" > /dev/null 2>&1; then
            log "${YELLOW}    ⚠️  ${env_file} NÃO está no .gitignore${NC}"
            ((VULNERABILITIES_HIGH++))
        fi
        
        ((FILES_SCANNED++))
    done < <(find "${PROJECT_ROOT}" -type f -name ".env*" -not -path "*/.git/*")
}

# Função para verificar Docker secrets
check_docker_secrets() {
    log "${BLUE}🔍 Verificando Docker secrets...${NC}"
    
    if docker info > /dev/null 2>&1; then
        local secret_count=$(docker secret ls --format "{{.Name}}" 2>/dev/null | wc -l)
        log "${CYAN}  Docker secrets configurados: ${secret_count}${NC}"
        
        # Verificar secrets órfãos (não usados por nenhum serviço)
        docker secret ls --format "{{.Name}}" 2>/dev/null | while read -r secret; do
            local usage=$(docker service ls --format "{{.Name}}" | xargs -I {} docker service inspect {} 2>/dev/null | grep -c "$secret" || true)
            if [ "$usage" -eq 0 ]; then
                log "${YELLOW}    ⚠️  Secret órfão: ${secret}${NC}"
                ((VULNERABILITIES_LOW++))
            fi
        done
    else
        log "${YELLOW}  ⚠️  Docker não está acessível${NC}"
    fi
}

# Função para verificar permissões de arquivos
check_file_permissions() {
    log "${BLUE}🔍 Verificando permissões de arquivos sensíveis...${NC}"
    
    # Verificar arquivos com permissões muito abertas
    while IFS= read -r file; do
        local perms=$(stat -c "%a" "$file" 2>/dev/null)
        if [ "$perms" -gt 644 ]; then
            log "${YELLOW}  ⚠️  Permissões muito abertas (${perms}) em: ${file}${NC}"
            ((VULNERABILITIES_MEDIUM++))
        fi
        ((FILES_SCANNED++))
    done < <(find "${PROJECT_ROOT}/secrets" -type f 2>/dev/null || true)
}

# Função para verificar certificados SSL
check_ssl_certificates() {
    log "${BLUE}🔍 Verificando certificados SSL...${NC}"
    
    # Buscar arquivos de certificado
    while IFS= read -r cert_file; do
        log "${CYAN}  Verificando: ${cert_file}${NC}"
        
        # Verificar validade se for certificado real
        if openssl x509 -in "$cert_file" -noout -checkend 0 > /dev/null 2>&1; then
            local expiry=$(openssl x509 -in "$cert_file" -noout -enddate | cut -d= -f2)
            log "${GREEN}    ✅ Certificado válido até: ${expiry}${NC}"
        elif openssl x509 -in "$cert_file" -noout > /dev/null 2>&1; then
            log "${RED}    ⚠️  Certificado expirado: ${cert_file}${NC}"
            ((VULNERABILITIES_HIGH++))
        fi
        
        ((FILES_SCANNED++))
    done < <(find "${PROJECT_ROOT}" -type f \( -name "*.crt" -o -name "*.pem" -o -name "*.cert" \) -not -path "*/.git/*" 2>/dev/null || true)
}

# Função para verificar chaves privadas
check_private_keys() {
    log "${BLUE}🔍 Verificando chaves privadas expostas...${NC}"
    
    # Buscar chaves privadas
    while IFS= read -r key_file; do
        log "${CYAN}  Encontrada chave: ${key_file}${NC}"
        
        # Verificar se está no .gitignore
        if ! git check-ignore "$key_file" > /dev/null 2>&1; then
            log "${RED}    ⚠️  Chave privada NÃO está no .gitignore: ${key_file}${NC}"
            ((VULNERABILITIES_CRITICAL++))
        fi
        
        # Verificar permissões
        local perms=$(stat -c "%a" "$key_file" 2>/dev/null)
        if [ "$perms" -gt 600 ]; then
            log "${YELLOW}    ⚠️  Permissões muito abertas (${perms}) na chave: ${key_file}${NC}"
            ((VULNERABILITIES_HIGH++))
        fi
        
        ((FILES_SCANNED++))
    done < <(find "${PROJECT_ROOT}" -type f \( -name "*.key" -o -name "id_rsa" -o -name "id_ed25519" \) -not -path "*/.git/*" 2>/dev/null || true)
}

# Função para verificar Vault
check_vault_configuration() {
    log "${BLUE}🔍 Verificando configuração do Vault...${NC}"
    
    # Verificar se Vault está configurado
    if [ -d "${PROJECT_ROOT}/secrets/vault" ]; then
        log "${GREEN}  ✅ Diretório Vault encontrado${NC}"
        
        # Verificar políticas
        if [ -d "${PROJECT_ROOT}/secrets/vault/policies" ]; then
            local policy_count=$(find "${PROJECT_ROOT}/secrets/vault/policies" -name "*.hcl" 2>/dev/null | wc -l)
            log "${CYAN}    Políticas configuradas: ${policy_count}${NC}"
        else
            log "${YELLOW}    ⚠️  Sem políticas de Vault configuradas${NC}"
            ((VULNERABILITIES_MEDIUM++))
        fi
    else
        log "${YELLOW}  ⚠️  Vault não configurado${NC}"
        ((VULNERABILITIES_MEDIUM++))
    fi
}

# Função para gerar relatório
generate_report() {
    log "${BLUE}📊 Gerando relatório de auditoria...${NC}"
    
    local total_vulnerabilities=$((VULNERABILITIES_CRITICAL + VULNERABILITIES_HIGH + VULNERABILITIES_MEDIUM + VULNERABILITIES_LOW))
    local security_score=100
    
    # Calcular score
    security_score=$((security_score - VULNERABILITIES_CRITICAL * 20))
    security_score=$((security_score - VULNERABILITIES_HIGH * 10))
    security_score=$((security_score - VULNERABILITIES_MEDIUM * 5))
    security_score=$((security_score - VULNERABILITIES_LOW * 2))
    
    if [ $security_score -lt 0 ]; then
        security_score=0
    fi
    
    # Gerar relatório Markdown
    cat > "${REPORT_FILE}" <<EOF
# 🔍 Relatório de Auditoria de Segurança - Secrets

**Data**: $(date '+%Y-%m-%d %H:%M:%S')  
**Score de Segurança**: ${security_score}/100  
**Status**: $([ $security_score -ge 80 ] && echo "✅ BOM" || echo "⚠️ ATENÇÃO NECESSÁRIA")

## 📊 Resumo Executivo

| Métrica | Valor |
|---------|-------|
| Arquivos Escaneados | ${FILES_SCANNED} |
| Secrets Encontrados | ${SECRETS_FOUND} |
| Vulnerabilidades Críticas | ${VULNERABILITIES_CRITICAL} |
| Vulnerabilidades Altas | ${VULNERABILITIES_HIGH} |
| Vulnerabilidades Médias | ${VULNERABILITIES_MEDIUM} |
| Vulnerabilidades Baixas | ${VULNERABILITIES_LOW} |
| **Total de Vulnerabilidades** | **${total_vulnerabilities}** |

## 🚨 Vulnerabilidades por Severidade

### Críticas (${VULNERABILITIES_CRITICAL})
$([ $VULNERABILITIES_CRITICAL -gt 0 ] && echo "- Secrets reais encontrados em arquivos" || echo "- Nenhuma vulnerabilidade crítica")
$([ $VULNERABILITIES_CRITICAL -gt 0 ] && echo "- Chaves privadas expostas" || echo "")

### Altas (${VULNERABILITIES_HIGH})
$([ $VULNERABILITIES_HIGH -gt 0 ] && echo "- Passwords hardcoded em scripts" || echo "- Nenhuma vulnerabilidade alta")
$([ $VULNERABILITIES_HIGH -gt 0 ] && echo "- Arquivos sensíveis fora do .gitignore" || echo "")

### Médias (${VULNERABILITIES_MEDIUM})
$([ $VULNERABILITIES_MEDIUM -gt 0 ] && echo "- Permissões incorretas em arquivos" || echo "- Nenhuma vulnerabilidade média")
$([ $VULNERABILITIES_MEDIUM -gt 0 ] && echo "- Vault não configurado" || echo "")

### Baixas (${VULNERABILITIES_LOW})
$([ $VULNERABILITIES_LOW -gt 0 ] && echo "- Secrets órfãos no Docker" || echo "- Nenhuma vulnerabilidade baixa")

## ✅ Recomendações

1. **Imediato**
   - Rotacionar todos os secrets expostos
   - Adicionar arquivos sensíveis ao .gitignore
   - Corrigir permissões de arquivos

2. **Curto Prazo**
   - Implementar Docker Secrets para todos os serviços
   - Configurar Vault para gestão centralizada
   - Automatizar rotação de secrets

3. **Médio Prazo**
   - Implementar monitoramento contínuo
   - Realizar auditorias regulares
   - Treinar equipe em práticas seguras

## 📈 Histórico

| Data | Score | Vulnerabilidades |
|------|-------|-----------------|
| $(date '+%Y-%m-%d') | ${security_score} | ${total_vulnerabilities} |

---

**Gerado automaticamente pelo MacSpark Security Audit**
EOF
    
    log "${GREEN}✅ Relatório salvo em: ${REPORT_FILE}${NC}"
}

# Função principal
main() {
    log "${BLUE}═══════════════════════════════════════════════════════${NC}"
    log "${BLUE}       🔍 MacSpark - Auditoria de Segurança 🔍         ${NC}"
    log "${BLUE}═══════════════════════════════════════════════════════${NC}"
    
    # Verificar diretório
    if [ ! -d "${PROJECT_ROOT}" ]; then
        log "${RED}❌ Diretório do projeto não encontrado${NC}"
        exit 1
    fi
    
    # Executar verificações
    check_hardcoded_passwords
    check_env_files
    check_docker_secrets
    check_file_permissions
    check_ssl_certificates
    check_private_keys
    check_vault_configuration
    
    # Gerar relatório
    generate_report
    
    # Resumo final
    log "${BLUE}═══════════════════════════════════════════════════════${NC}"
    log "${BLUE}📊 Resumo da Auditoria:${NC}"
    log "${CYAN}  Arquivos escaneados: ${FILES_SCANNED}${NC}"
    log "${CYAN}  Secrets encontrados: ${SECRETS_FOUND}${NC}"
    
    if [ $VULNERABILITIES_CRITICAL -gt 0 ]; then
        log "${RED}  ❌ Vulnerabilidades CRÍTICAS: ${VULNERABILITIES_CRITICAL}${NC}"
    fi
    if [ $VULNERABILITIES_HIGH -gt 0 ]; then
        log "${RED}  ⚠️  Vulnerabilidades ALTAS: ${VULNERABILITIES_HIGH}${NC}"
    fi
    if [ $VULNERABILITIES_MEDIUM -gt 0 ]; then
        log "${YELLOW}  ⚠️  Vulnerabilidades MÉDIAS: ${VULNERABILITIES_MEDIUM}${NC}"
    fi
    if [ $VULNERABILITIES_LOW -gt 0 ]; then
        log "${BLUE}  ℹ️  Vulnerabilidades BAIXAS: ${VULNERABILITIES_LOW}${NC}"
    fi
    
    local total=$((VULNERABILITIES_CRITICAL + VULNERABILITIES_HIGH + VULNERABILITIES_MEDIUM + VULNERABILITIES_LOW))
    
    if [ $total -eq 0 ]; then
        log "${GREEN}✨ Nenhuma vulnerabilidade encontrada! Excelente!${NC}"
        exit 0
    elif [ $VULNERABILITIES_CRITICAL -gt 0 ]; then
        log "${RED}🚨 ATENÇÃO: Vulnerabilidades críticas encontradas! Ação imediata necessária!${NC}"
        exit 2
    elif [ $VULNERABILITIES_HIGH -gt 0 ]; then
        log "${YELLOW}⚠️  Vulnerabilidades altas encontradas. Correção urgente recomendada.${NC}"
        exit 1
    else
        log "${GREEN}✅ Auditoria concluída. Algumas melhorias recomendadas.${NC}"
        exit 0
    fi
}

# Executar
main "$@"