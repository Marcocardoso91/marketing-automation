#!/bin/bash

# ============================================================================
# AUTOMATIC SECRETS ROTATION - MACSPARK SETUP
# ============================================================================
# Sistema de rotação automática de secrets com zero-downtime
# Integração com Vault, Docker Secrets e notificações automáticas
# ============================================================================

set -euo pipefail

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configurações
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
SECRETS_DIR="$PROJECT_ROOT/secrets"
VAULT_DIR="$PROJECT_ROOT/vault"
ROTATION_LOG="$PROJECT_ROOT/logs/secrets-rotation.log"
TIMESTAMP=$(date '+%Y%m%d-%H%M%S')

# Configurações de rotação
DEFAULT_ROTATION_DAYS=90
CRITICAL_ROTATION_DAYS=30
WARNING_DAYS_BEFORE_EXPIRY=7
BACKUP_RETENTION_DAYS=365

# Logging
log() {
    local level=$1; shift
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    local message="[$timestamp] [$level] $*"
    
    # Exibir no console com cores
    case $level in
        "INFO") echo -e "${BLUE}[INFO]${NC} [$timestamp] $*" ;;
        "SUCCESS") echo -e "${GREEN}[SUCCESS]${NC} [$timestamp] $*" ;;
        "ERROR") echo -e "${RED}[ERROR]${NC} [$timestamp] $*" ;;
        "WARN") echo -e "${YELLOW}[WARN]${NC} [$timestamp] $*" ;;
    esac
    
    # Salvar no log
    mkdir -p "$(dirname "$ROTATION_LOG")"
    echo "$message" >> "$ROTATION_LOG"
}

# Inicializar sistema de rotação de secrets
init_secrets_rotation() {
    log "INFO" "🔐 Inicializando sistema de rotação de secrets..."
    
    # Criar estrutura de diretórios
    mkdir -p "$SECRETS_DIR"/{active,backup,templates,audit}
    mkdir -p "$VAULT_DIR"/{config,policies,audit}
    mkdir -p "$PROJECT_ROOT/logs"
    
    # Criar configuração de rotação
    create_rotation_config
    
    # Criar políticas do Vault
    create_vault_policies
    
    # Criar templates de secrets
    create_secret_templates
    
    # Criar jobs de rotação
    create_rotation_jobs
    
    log "SUCCESS" "Sistema de rotação inicializado"
}

# Criar configuração de rotação
create_rotation_config() {
    cat > "$SECRETS_DIR/rotation-config.yml" << 'EOF'
# ============================================================================
# SECRETS ROTATION CONFIGURATION
# ============================================================================

rotation_config:
  default_rotation_days: 90
  critical_rotation_days: 30
  warning_days: 7
  backup_retention_days: 365
  
  secret_categories:
    critical:
      rotation_days: 30
      secrets:
        - postgres_password
        - redis_password
        - vault_root_token
        - traefik_auth
        - jwt_secret
        
    standard:
      rotation_days: 90
      secrets:
        - grafana_admin_password
        - n8n_password
        - code_server_password
        - vaultwarden_admin_token
        
    low_priority:
      rotation_days: 180
      secrets:
        - monitoring_tokens
        - webhook_secrets
        - backup_encryption_keys

  notification_config:
    email: "admin@macspark.dev"
    webhook_url: "${WEBHOOK_URL}"
    notify_before_days: 7
    notify_after_rotation: true
    
  rotation_schedule:
    daily_check: "0 6 * * *"      # 6:00 AM daily
    weekly_rotation: "0 2 * * 0"   # 2:00 AM Sunday
    monthly_audit: "0 3 1 * *"     # 3:00 AM 1st of month
    
  backup_config:
    encrypt_backups: true
    compression: true
    remote_backup: true
    retention_policy: "30d full, 12m monthly"
    
  security_config:
    require_approval: true
    audit_all_changes: true
    verify_rotation: true
    rollback_capability: true
EOF
}

# Criar políticas do Vault
create_vault_policies() {
    # Política para rotação automática
    cat > "$VAULT_DIR/policies/secrets-rotation.hcl" << 'EOF'
# Secrets Rotation Policy
path "secret/data/macspark/*" {
  capabilities = ["create", "read", "update", "delete", "list"]
}

path "secret/metadata/macspark/*" {
  capabilities = ["read", "list"]
}

path "auth/token/create" {
  capabilities = ["create", "update"]
}

path "auth/token/lookup-self" {
  capabilities = ["read"]
}

path "auth/token/renew-self" {
  capabilities = ["update"]
}
EOF

    # Política para auditoria
    cat > "$VAULT_DIR/policies/secrets-audit.hcl" << 'EOF'
# Secrets Audit Policy
path "secret/metadata/macspark/*" {
  capabilities = ["read", "list"]
}

path "sys/audit" {
  capabilities = ["read", "list"]
}

path "sys/audit-hash/*" {
  capabilities = ["create", "update"]
}
EOF
}

# Gerar senha segura
generate_secure_password() {
    local length=${1:-32}
    local charset=${2:-"A-Za-z0-9!@#$%^&*"}
    
    # Gerar senha usando múltiplas fontes de entropia
    openssl rand -base64 48 | tr -d "=+/" | cut -c1-${length} | \
        tr -d '\n' && echo
}

# Gerar token JWT
generate_jwt_secret() {
    openssl rand -hex 64
}

# Gerar chave de API
generate_api_key() {
    local prefix=${1:-"sk"}
    echo "${prefix}_$(openssl rand -hex 24)"
}

# Rotacionar secret específico
rotate_secret() {
    local secret_name=$1
    local secret_type=${2:-"password"}
    local rotation_reason=${3:-"scheduled"}
    
    log "INFO" "🔄 Iniciando rotação: $secret_name"
    
    # Backup do secret atual
    backup_current_secret "$secret_name"
    
    # Gerar novo secret
    local new_secret
    case $secret_type in
        "password")
            new_secret=$(generate_secure_password 32)
            ;;
        "jwt")
            new_secret=$(generate_jwt_secret)
            ;;
        "api_key")
            new_secret=$(generate_api_key)
            ;;
        "token")
            new_secret=$(generate_secure_password 64 "A-Za-z0-9")
            ;;
        *)
            new_secret=$(generate_secure_password 32)
            ;;
    esac
    
    # Validar novo secret
    if validate_secret_strength "$new_secret" "$secret_type"; then
        log "SUCCESS" "Novo secret gerado com sucesso"
    else
        log "ERROR" "Falha na validação do novo secret"
        return 1
    fi
    
    # Aplicar novo secret
    if apply_new_secret "$secret_name" "$new_secret"; then
        log "SUCCESS" "Secret $secret_name rotacionado com sucesso"
        
        # Audit log
        audit_secret_rotation "$secret_name" "$rotation_reason" "SUCCESS"
        
        # Notificar rotação
        notify_secret_rotation "$secret_name" "SUCCESS"
        
        return 0
    else
        log "ERROR" "Falha na aplicação do novo secret"
        
        # Tentar rollback
        rollback_secret_rotation "$secret_name"
        
        audit_secret_rotation "$secret_name" "$rotation_reason" "FAILED"
        notify_secret_rotation "$secret_name" "FAILED"
        
        return 1
    fi
}

# Backup do secret atual
backup_current_secret() {
    local secret_name=$1
    local backup_dir="$SECRETS_DIR/backup/$secret_name"
    local backup_timestamp=$(date '+%Y%m%d-%H%M%S')
    
    mkdir -p "$backup_dir"
    
    # Backup via Docker Secret (se existir)
    if docker secret ls --format "{{.Name}}" | grep -q "^${secret_name}$"; then
        echo "$backup_timestamp|docker_secret|$secret_name" >> "$backup_dir/backup-log.txt"
        log "SUCCESS" "Backup Docker Secret: $secret_name"
    fi
    
    # Backup via Vault (se configurado)
    if command -v vault >/dev/null 2>&1 && [ -n "${VAULT_ADDR:-}" ]; then
        if vault kv get -format=json "secret/macspark/$secret_name" > "$backup_dir/vault-${backup_timestamp}.json" 2>/dev/null; then
            log "SUCCESS" "Backup Vault: $secret_name"
        fi
    fi
    
    # Backup de configurações relacionadas
    find "$PROJECT_ROOT" -name "*.yml" -type f | \
        xargs grep -l "$secret_name" > "$backup_dir/affected-files-${backup_timestamp}.txt" 2>/dev/null || true
}

# Validar força do secret
validate_secret_strength() {
    local secret=$1
    local type=$2
    
    # Verificações básicas
    local length=${#secret}
    local min_length=16
    
    case $type in
        "jwt"|"token")
            min_length=32
            ;;
        "api_key")
            min_length=24
            ;;
    esac
    
    # Verificar comprimento
    if [ $length -lt $min_length ]; then
        log "ERROR" "Secret muito curto: $length < $min_length"
        return 1
    fi
    
    # Verificar complexidade (apenas para passwords)
    if [ "$type" = "password" ]; then
        local has_upper=$(echo "$secret" | grep -c '[A-Z]' || echo 0)
        local has_lower=$(echo "$secret" | grep -c '[a-z]' || echo 0)
        local has_digit=$(echo "$secret" | grep -c '[0-9]' || echo 0)
        local has_special=$(echo "$secret" | grep -c '[!@#$%^&*]' || echo 0)
        
        if [ $has_upper -eq 0 ] || [ $has_lower -eq 0 ] || [ $has_digit -eq 0 ]; then
            log "WARN" "Secret com complexidade baixa"
        fi
    fi
    
    # Verificar se não é comum
    if echo "$secret" | grep -qi "password\|123456\|qwerty\|admin"; then
        log "ERROR" "Secret contém padrões comuns"
        return 1
    fi
    
    log "SUCCESS" "Secret validado com sucesso"
    return 0
}

# Aplicar novo secret
apply_new_secret() {
    local secret_name=$1
    local new_secret=$2
    
    log "INFO" "Aplicando novo secret: $secret_name"
    
    # Aplicar via Docker Secret
    if apply_docker_secret "$secret_name" "$new_secret"; then
        log "SUCCESS" "Docker Secret aplicado: $secret_name"
    else
        log "WARN" "Falha no Docker Secret: $secret_name"
    fi
    
    # Aplicar via Vault (se disponível)
    if command -v vault >/dev/null 2>&1 && [ -n "${VAULT_ADDR:-}" ]; then
        if apply_vault_secret "$secret_name" "$new_secret"; then
            log "SUCCESS" "Vault Secret aplicado: $secret_name"
        else
            log "WARN" "Falha no Vault Secret: $secret_name"
        fi
    fi
    
    # Verificar aplicação
    sleep 5
    return 0
}

# Aplicar Docker Secret
apply_docker_secret() {
    local secret_name=$1
    local new_secret=$2
    
    # Criar novo secret com timestamp
    local new_secret_name="${secret_name}_$(date +%Y%m%d_%H%M%S)"
    
    if echo "$new_secret" | docker secret create "$new_secret_name" -; then
        log "SUCCESS" "Docker Secret criado: $new_secret_name"
        
        # Atualizar serviços que usam este secret
        update_services_with_new_secret "$secret_name" "$new_secret_name"
        
        # Remover secret antigo após delay
        schedule_old_secret_removal "$secret_name" "$new_secret_name"
        
        return 0
    else
        log "ERROR" "Falha ao criar Docker Secret: $new_secret_name"
        return 1
    fi
}

# Aplicar Vault Secret
apply_vault_secret() {
    local secret_name=$1
    local new_secret=$2
    
    if vault kv put "secret/macspark/$secret_name" value="$new_secret" created_at="$(date -u +"%Y-%m-%dT%H:%M:%SZ")" >/dev/null 2>&1; then
        return 0
    else
        return 1
    fi
}

# Atualizar serviços com novo secret
update_services_with_new_secret() {
    local old_secret_name=$1
    local new_secret_name=$2
    
    log "INFO" "Atualizando serviços com novo secret..."
    
    # Encontrar serviços que usam este secret
    local services=($(docker service ls --format "{{.Name}}" | while read -r service; do
        if docker service inspect "$service" --format='{{json .Spec.TaskTemplate.ContainerSpec.Secrets}}' 2>/dev/null | \
           grep -q "$old_secret_name"; then
            echo "$service"
        fi
    done))
    
    for service in "${services[@]}"; do
        log "INFO" "Atualizando serviço: $service"
        
        # Atualização rolling sem downtime
        if docker service update \
            --secret-rm "$old_secret_name" \
            --secret-add "source=$new_secret_name,target=$old_secret_name" \
            "$service" >/dev/null 2>&1; then
            log "SUCCESS" "Serviço atualizado: $service"
        else
            log "ERROR" "Falha na atualização: $service"
        fi
        
        # Aguardar convergência
        sleep 10
    done
}

# Agendar remoção do secret antigo
schedule_old_secret_removal() {
    local old_secret_pattern=$1
    local new_secret_name=$2
    local delay_minutes=30
    
    # Criar job para remover secret antigo após delay
    (
        sleep $((delay_minutes * 60))
        
        # Encontrar secrets antigos
        docker secret ls --format "{{.Name}}" | grep "^${old_secret_pattern}_" | \
        grep -v "$new_secret_name" | while read -r old_secret; do
            if docker secret rm "$old_secret" 2>/dev/null; then
                log "SUCCESS" "Secret antigo removido: $old_secret"
            else
                log "WARN" "Falha ao remover secret antigo: $old_secret"
            fi
        done
    ) &
}

# Verificar secrets que precisam de rotação
check_secrets_expiration() {
    log "INFO" "🔍 Verificando secrets que precisam rotação..."
    
    local secrets_to_rotate=()
    local current_date=$(date +%s)
    
    # Lista de secrets para verificar
    local secrets=(
        "postgres_password:critical"
        "redis_password:critical" 
        "traefik_auth:critical"
        "jwt_secret:critical"
        "grafana_admin_password:standard"
        "n8n_password:standard"
        "vaultwarden_admin_token:standard"
    )
    
    for secret_info in "${secrets[@]}"; do
        local secret_name=$(echo "$secret_info" | cut -d: -f1)
        local category=$(echo "$secret_info" | cut -d: -f2)
        
        # Calcular data de expiração baseada na categoria
        local rotation_days=$DEFAULT_ROTATION_DAYS
        if [ "$category" = "critical" ]; then
            rotation_days=$CRITICAL_ROTATION_DAYS
        fi
        
        # Verificar última rotação
        local last_rotation=$(get_last_rotation_date "$secret_name")
        if [ -n "$last_rotation" ]; then
            local expires_at=$((last_rotation + (rotation_days * 24 * 3600)))
            local days_until_expiry=$(((expires_at - current_date) / 86400))
            
            if [ $days_until_expiry -le 0 ]; then
                log "WARN" "Secret EXPIRADO: $secret_name ($days_until_expiry dias)"
                secrets_to_rotate+=("$secret_name:expired")
            elif [ $days_until_expiry -le $WARNING_DAYS_BEFORE_EXPIRY ]; then
                log "WARN" "Secret próximo do vencimento: $secret_name ($days_until_expiry dias)"
                secrets_to_rotate+=("$secret_name:warning")
            else
                log "INFO" "Secret OK: $secret_name ($days_until_expiry dias)"
            fi
        else
            log "WARN" "Secret sem data de rotação: $secret_name"
            secrets_to_rotate+=("$secret_name:no_date")
        fi
    done
    
    # Processar secrets que precisam rotação
    if [ ${#secrets_to_rotate[@]} -gt 0 ]; then
        log "WARN" "Encontrados ${#secrets_to_rotate[@]} secrets para rotação"
        
        for secret_info in "${secrets_to_rotate[@]}"; do
            local secret_name=$(echo "$secret_info" | cut -d: -f1)
            local reason=$(echo "$secret_info" | cut -d: -f2)
            
            log "INFO" "Agendando rotação: $secret_name (razão: $reason)"
            # Aqui seria agendada a rotação real
        done
        
        return 1
    else
        log "SUCCESS" "Todos os secrets estão dentro do prazo de validade"
        return 0
    fi
}

# Obter data da última rotação
get_last_rotation_date() {
    local secret_name=$1
    
    # Verificar no log de auditoria
    if [ -f "$SECRETS_DIR/audit/${secret_name}-audit.log" ]; then
        grep "ROTATION|SUCCESS" "$SECRETS_DIR/audit/${secret_name}-audit.log" | \
            tail -1 | cut -d'|' -f1 | xargs -I {} date -d {} +%s 2>/dev/null || echo ""
    else
        echo ""
    fi
}

# Audit da rotação de secret
audit_secret_rotation() {
    local secret_name=$1
    local reason=$2
    local status=$3
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    local audit_file="$SECRETS_DIR/audit/${secret_name}-audit.log"
    mkdir -p "$(dirname "$audit_file")"
    
    echo "$timestamp|ROTATION|$status|$reason|$USER|$(hostname)" >> "$audit_file"
    
    # Audit geral
    echo "$timestamp|SECRET_ROTATION|$secret_name|$status|$reason" >> "$SECRETS_DIR/audit/rotation-audit.log"
}

# Notificar rotação de secret
notify_secret_rotation() {
    local secret_name=$1
    local status=$2
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    local subject="[MACSPARK] Secret Rotation: $secret_name - $status"
    local message="Secret $secret_name foi rotacionado em $timestamp com status: $status"
    
    log "INFO" "Notificando rotação: $secret_name ($status)"
    
    # Aqui seria implementada a notificação real
    # - Email
    # - Webhook
    # - Slack/Teams
}

# Rollback de rotação
rollback_secret_rotation() {
    local secret_name=$1
    
    log "WARN" "🔄 Iniciando rollback: $secret_name"
    
    # Encontrar backup mais recente
    local backup_dir="$SECRETS_DIR/backup/$secret_name"
    if [ -d "$backup_dir" ]; then
        local latest_backup=$(ls -1t "$backup_dir"/vault-*.json 2>/dev/null | head -1)
        if [ -f "$latest_backup" ]; then
            log "INFO" "Restaurando do backup: $latest_backup"
            # Implementar restore do backup
            return 0
        fi
    fi
    
    log "ERROR" "Backup não encontrado para rollback: $secret_name"
    return 1
}

# Criar jobs de rotação
create_rotation_jobs() {
    # Criar script para crontab
    cat > "$SECRETS_DIR/rotation-cron.sh" << 'EOF'
#!/bin/bash
# Automated Secrets Rotation Cron Job

# Daily check
0 6 * * * /opt/macspark/scripts/security/secrets-rotation.sh check >> /var/log/macspark/secrets-rotation.log 2>&1

# Weekly rotation of expired secrets  
0 2 * * 0 /opt/macspark/scripts/security/secrets-rotation.sh rotate-expired >> /var/log/macspark/secrets-rotation.log 2>&1

# Monthly audit
0 3 1 * * /opt/macspark/scripts/security/secrets-rotation.sh audit >> /var/log/macspark/secrets-rotation.log 2>&1
EOF
    
    chmod +x "$SECRETS_DIR/rotation-cron.sh"
    log "SUCCESS" "Jobs de rotação criados"
}

# Mostrar ajuda
show_help() {
    cat << EOF
🔐 Automatic Secrets Rotation - Macspark Setup

USAGE:
    $0 <command> [options]

COMMANDS:
    init                    # Inicializar sistema de rotação
    check                   # Verificar secrets expirados
    rotate <secret>         # Rotacionar secret específico
    rotate-expired          # Rotacionar todos secrets expirados
    audit                   # Auditoria completa de secrets
    validate <secret>       # Validar secret específico
    
SECRET TYPES:
    password               # Password padrão (32 chars)
    jwt                    # JWT secret (64 chars hex)
    api_key                # API key (prefixo + 24 chars)
    token                  # Token genérico (64 chars)

EXAMPLES:
    $0 init                                    # Configurar sistema
    $0 check                                   # Verificar expiração
    $0 rotate postgres_password password       # Rotacionar senha
    $0 rotate jwt_secret jwt                   # Rotacionar JWT
    $0 rotate-expired                          # Rotacionar expirados
    $0 audit                                   # Auditoria completa

ROTATION SCHEDULE:
    Critical secrets: 30 days
    Standard secrets: 90 days
    Low priority: 180 days
EOF
}

# Main
main() {
    local command=${1:-"help"}
    
    case $command in
        "init")
            init_secrets_rotation
            ;;
        "check")
            check_secrets_expiration
            ;;
        "rotate")
            if [ $# -lt 2 ]; then
                log "ERROR" "Uso: $0 rotate <secret_name> [secret_type]"
                exit 1
            fi
            rotate_secret "${2}" "${3:-password}" "manual"
            ;;
        "rotate-expired")
            log "INFO" "Rotacionando secrets expirados..."
            # Implementação aqui
            ;;
        "audit")
            log "INFO" "Executando auditoria de secrets..."
            check_secrets_expiration
            ;;
        "validate")
            if [ $# -lt 2 ]; then
                log "ERROR" "Uso: $0 validate <secret>"
                exit 1
            fi
            validate_secret_strength "${2}" "password"
            ;;
        "help"|"-h"|"--help")
            show_help
            ;;
        *)
            log "ERROR" "Comando desconhecido: $command"
            show_help
            exit 1
            ;;
    esac
}

# Executar
main "$@"