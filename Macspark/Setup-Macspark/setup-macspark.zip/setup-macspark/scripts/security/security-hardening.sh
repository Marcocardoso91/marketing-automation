#!/bin/bash

# ============================================================================
# MACSPARK SECURITY HARDENING SCRIPT
# ============================================================================
# Script para aplicar configurações de segurança no sistema
# ============================================================================

set -euo pipefail

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'
BOLD='\033[1m'

# Funções de log
log_info() { echo -e "${BLUE}${BOLD}[SECURITY]${NC} $1"; }
log_success() { echo -e "${GREEN}${BOLD}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}${BOLD}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}${BOLD}[ERROR]${NC} $1"; }

# Verificar se é root
if [[ $EUID -ne 0 ]]; then
    log_error "Este script deve ser executado como root"
    exit 1
fi

log_info "🔒 Iniciando hardening de segurança do sistema..."

# ============================================================================
# CONFIGURAÇÕES SSH
# ============================================================================
harden_ssh() {
    log_info "🔐 Configurando SSH..."
    
    # Backup da configuração original
    cp /etc/ssh/sshd_config /etc/ssh/sshd_config.backup.$(date +%Y%m%d)
    
    # Aplicar configurações seguras
    cat >> /etc/ssh/sshd_config << EOF

# MACSPARK SECURITY HARDENING
PermitRootLogin no
PasswordAuthentication no
PubkeyAuthentication yes
AuthorizedKeysFile .ssh/authorized_keys
PermitEmptyPasswords no
ChallengeResponseAuthentication no
UsePAM yes
X11Forwarding no
PrintMotd no
Banner /etc/issue.net
ClientAliveInterval 300
ClientAliveCountMax 2
MaxAuthTries 3
MaxSessions 2
Protocol 2
EOF

    # Criar banner de segurança
    cat > /etc/issue.net << EOF
***************************************************************************
                            SISTEMA RESTRITO
                         ACESSO APENAS AUTORIZADO
***************************************************************************
EOF

    # Reiniciar SSH
    systemctl restart ssh
    log_success "✅ SSH configurado com segurança"
}

# ============================================================================
# CONFIGURAÇÕES DE FIREWALL
# ============================================================================
configure_firewall() {
    log_info "🛡️ Configurando firewall..."
    
    # Resetar UFW
    ufw --force reset
    
    # Configurações padrão
    ufw default deny incoming
    ufw default allow outgoing
    
    # Portas essenciais
    ufw allow 22/tcp comment 'SSH'
    ufw allow 80/tcp comment 'HTTP'
    ufw allow 443/tcp comment 'HTTPS'
    ufw allow 8080/tcp comment 'Traefik Dashboard'
    ufw allow 9000/tcp comment 'Portainer'
    ufw allow 19999/tcp comment 'Netdata'
    
    # Docker Swarm (apenas se necessário)
    ufw allow 2377/tcp comment 'Docker Swarm'
    ufw allow 7946/tcp comment 'Docker Swarm'
    ufw allow 7946/udp comment 'Docker Swarm'
    ufw allow 4789/udp comment 'Docker Overlay'
    
    # Habilitar firewall
    ufw --force enable
    
    log_success "✅ Firewall configurado"
}

# ============================================================================
# FAIL2BAN
# ============================================================================
configure_fail2ban() {
    log_info "🚫 Configurando Fail2ban..."
    
    # Instalar se não estiver instalado
    if ! command -v fail2ban-server &> /dev/null; then
        apt-get update -y
        apt-get install -y fail2ban
    fi
    
    # Configuração customizada
    cat > /etc/fail2ban/jail.local << EOF
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 3
backend = systemd

[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log
maxretry = 3

[traefik-auth]
enabled = true
port = 8080
filter = traefik-auth
logpath = /var/log/traefik/access.log
maxretry = 3

[docker-registry]
enabled = true
port = 5000
filter = docker-registry
logpath = /var/log/docker-registry.log
maxretry = 3
EOF

    # Filtro para Traefik
    mkdir -p /etc/fail2ban/filter.d
    cat > /etc/fail2ban/filter.d/traefik-auth.conf << EOF
[Definition]
failregex = ^<HOST> - \S+ \[\S+\] "\S+ \S+ \S+" 401 \d+ "\S*" "\S*" \d+ "\S+" "\S+" \d+ms$
ignoreregex =
EOF

    # Reiniciar fail2ban
    systemctl enable fail2ban
    systemctl restart fail2ban
    
    log_success "✅ Fail2ban configurado"
}

# ============================================================================
# CONFIGURAÇÕES DO SISTEMA
# ============================================================================
system_hardening() {
    log_info "⚙️ Aplicando hardening do sistema..."
    
    # Configurações do kernel
    cat >> /etc/sysctl.conf << EOF

# MACSPARK SECURITY HARDENING
# Disable IP forwarding (se não usar Docker, descomente)
# net.ipv4.ip_forward = 0

# Disable ICMP redirects
net.ipv4.conf.all.accept_redirects = 0
net.ipv6.conf.all.accept_redirects = 0
net.ipv4.conf.default.accept_redirects = 0
net.ipv6.conf.default.accept_redirects = 0

# Disable source packet routing
net.ipv4.conf.all.accept_source_route = 0
net.ipv6.conf.all.accept_source_route = 0
net.ipv4.conf.default.accept_source_route = 0
net.ipv6.conf.default.accept_source_route = 0

# Log Martians
net.ipv4.conf.all.log_martians = 1

# Ignore ICMP ping requests
net.ipv4.icmp_echo_ignore_all = 1

# SYN flood protection
net.ipv4.tcp_syncookies = 1
net.ipv4.tcp_max_syn_backlog = 2048
net.ipv4.tcp_synack_retries = 2
net.ipv4.tcp_syn_retries = 5

# Kernel hardening
kernel.dmesg_restrict = 1
kernel.kptr_restrict = 2
kernel.yama.ptrace_scope = 1
EOF

    # Aplicar configurações
    sysctl -p
    
    # Configurações de limites
    cat >> /etc/security/limits.conf << EOF

# MACSPARK SECURITY LIMITS
* hard core 0
* soft nproc 1024
* hard nproc 2048
* soft nofile 1024
* hard nofile 65536
EOF

    log_success "✅ System hardening aplicado"
}

# ============================================================================
# AUDITORIA E LOGS
# ============================================================================
configure_audit() {
    log_info "📋 Configurando auditoria..."
    
    # Instalar auditd se não estiver instalado
    if ! command -v auditd &> /dev/null; then
        apt-get install -y auditd audispd-plugins
    fi
    
    # Configurações de auditoria
    cat >> /etc/audit/rules.d/macspark.rules << EOF
# MACSPARK AUDIT RULES

# Monitor authentication
-w /etc/passwd -p wa -k identity
-w /etc/group -p wa -k identity
-w /etc/shadow -p wa -k identity
-w /etc/sudoers -p wa -k identity

# Monitor network configuration
-w /etc/hosts -p wa -k network
-w /etc/network/ -p wa -k network

# Monitor Docker
-w /var/lib/docker/ -p wa -k docker
-w /etc/docker/ -p wa -k docker

# Monitor SSH
-w /etc/ssh/sshd_config -p wa -k ssh

# Monitor system calls
-a always,exit -F arch=b64 -S adjtimex -S settimeofday -k time-change
-a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-change
EOF

    # Reiniciar auditd
    systemctl enable auditd
    systemctl restart auditd
    
    log_success "✅ Auditoria configurada"
}

# ============================================================================
# LIMPEZA E OTIMIZAÇÃO
# ============================================================================
cleanup_system() {
    log_info "🧹 Limpando sistema..."
    
    # Remover pacotes desnecessários
    apt-get autoremove -y
    apt-get autoclean -y
    
    # Limpar logs antigos
    journalctl --vacuum-time=7d
    
    # Limpar cache
    apt-get clean
    
    log_success "✅ Sistema limpo"
}

# ============================================================================
# VERIFICAÇÕES FINAIS
# ============================================================================
security_check() {
    log_info "🔍 Verificando configurações de segurança..."
    
    echo
    log_info "📊 RELATÓRIO DE SEGURANÇA"
    echo "========================================"
    
    # SSH
    if grep -q "PermitRootLogin no" /etc/ssh/sshd_config; then
        log_success "✅ SSH: Root login desabilitado"
    else
        log_warning "⚠️ SSH: Root login ainda habilitado"
    fi
    
    # Firewall
    if ufw status | grep -q "Status: active"; then
        log_success "✅ Firewall: Ativo"
    else
        log_warning "⚠️ Firewall: Inativo"
    fi
    
    # Fail2ban
    if systemctl is-active --quiet fail2ban; then
        log_success "✅ Fail2ban: Ativo"
    else
        log_warning "⚠️ Fail2ban: Inativo"
    fi
    
    # Updates
    local updates=$(apt list --upgradable 2>/dev/null | wc -l)
    if [ "$updates" -gt 1 ]; then
        log_warning "⚠️ Sistema: $((updates-1)) atualizações disponíveis"
    else
        log_success "✅ Sistema: Atualizado"
    fi
    
    echo
    log_success "🎉 Hardening de segurança concluído!"
    log_info "📋 Logs disponíveis em /var/log/auth.log e /var/log/audit/audit.log"
}

# ============================================================================
# EXECUÇÃO PRINCIPAL
# ============================================================================
main() {
    log_info "🚀 Iniciando processo de hardening..."
    
    # Perguntar confirmação
    echo -ne "${YELLOW}${BOLD}Aplicar hardening de segurança? (s/N): ${NC}"
    read -r confirm
    if [[ ! "$confirm" =~ ^[Ss]$ ]]; then
        log_info "Hardening cancelado pelo usuário"
        exit 0
    fi
    
    # Executar hardening
    harden_ssh
    configure_firewall
    configure_fail2ban
    system_hardening
    configure_audit
    cleanup_system
    security_check
    
    echo
    log_success "🔒 Sistema hardening completo!"
    log_info "🔄 Recomenda-se reiniciar o sistema: reboot"
}

# Executar script
main "$@"