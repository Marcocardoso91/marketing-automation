#!/bin/bash
# ============================================================================
# CREATE DOCKER SWARM NETWORKS - ENTERPRISE SETUP
# ============================================================================
# Script para criar todas as networks necessárias para o ambiente Macspark
# ============================================================================

set -euo pipefail

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}================================================${NC}"
echo -e "${BLUE}   CRIANDO NETWORKS DOCKER SWARM${NC}"
echo -e "${BLUE}================================================${NC}"

# Função para criar network
create_network() {
    local name=$1
    local internal=${2:-false}
    local attachable=${3:-true}
    local subnet=${4:-""}
    
    echo -e "${YELLOW}Criando network: ${name}${NC}"
    
    # Verificar se já existe
    if docker network ls | grep -q "$name"; then
        echo -e "${GREEN}✓ Network ${name} já existe${NC}"
        return 0
    fi
    
    # Construir comando
    local cmd="docker network create --driver overlay"
    
    if [ "$attachable" = true ]; then
        cmd="$cmd --attachable"
    fi
    
    if [ "$internal" = true ]; then
        cmd="$cmd --internal"
    fi
    
    if [ -n "$subnet" ]; then
        cmd="$cmd --subnet=$subnet"
    fi
    
    # Adicionar opções de segurança
    cmd="$cmd --opt encrypted=true"
    cmd="$cmd --opt com.docker.network.driver.mtu=1450"
    
    # Criar network
    if $cmd "$name" 2>/dev/null; then
        echo -e "${GREEN}✓ Network ${name} criada com sucesso${NC}"
    else
        echo -e "${RED}✗ Erro ao criar network ${name}${NC}"
        return 1
    fi
}

# Verificar se está em modo Swarm
if ! docker info 2>/dev/null | grep -q "Swarm: active"; then
    echo -e "${RED}Erro: Docker não está em modo Swarm${NC}"
    echo -e "${YELLOW}Inicialize o Swarm com: docker swarm init${NC}"
    exit 1
fi

echo ""
echo -e "${BLUE}[1/7] Networks Públicas${NC}"
echo "================================"

# Network principal para Traefik (exposição externa)
create_network "traefik-public" false true "10.0.1.0/24"

echo ""
echo -e "${BLUE}[2/7] Networks de Aplicações${NC}"
echo "================================"

# Network interna para aplicações
create_network "apps-internal" true true "10.0.2.0/24"

echo ""
echo -e "${BLUE}[3/7] Networks de IA${NC}"
echo "================================"

# Network para serviços de IA
create_network "ai-internal" true true "10.0.3.0/24"

echo ""
echo -e "${BLUE}[4/7] Networks de Dados${NC}"
echo "================================"

# Network para bancos de dados
create_network "data-internal" true false "10.0.4.0/24"

# Network para cache
create_network "cache-internal" true false "10.0.5.0/24"

echo ""
echo -e "${BLUE}[5/7] Networks de Monitoramento${NC}"
echo "================================"

# Network para stack de monitoramento
create_network "monitoring" false true "10.0.6.0/24"

echo ""
echo -e "${BLUE}[6/7] Networks de Backup${NC}"
echo "================================"

# Network para operações de backup
create_network "backup-internal" true false "10.0.7.0/24"

echo ""
echo -e "${BLUE}[7/7] Networks de Segurança${NC}"
echo "================================"

# Network para ferramentas de segurança
create_network "security-internal" true true "10.0.8.0/24"

echo ""
echo -e "${GREEN}================================================${NC}"
echo -e "${GREEN}   NETWORKS CRIADAS COM SUCESSO!${NC}"
echo -e "${GREEN}================================================${NC}"

echo ""
echo -e "${BLUE}Networks disponíveis:${NC}"
docker network ls --filter driver=overlay --format "table {{.Name}}\t{{.Driver}}\t{{.Scope}}"

echo ""
echo -e "${YELLOW}Próximos passos:${NC}"
echo "1. Deploy dos stacks usando estas networks"
echo "2. Configurar firewall rules se necessário"
echo "3. Monitorar tráfego entre networks"

echo ""
echo -e "${BLUE}Documentação:${NC}"
echo "- README: /opt/macspark/networks/README.md"
echo "- Troubleshooting: /opt/macspark/docs/network-troubleshooting.md"