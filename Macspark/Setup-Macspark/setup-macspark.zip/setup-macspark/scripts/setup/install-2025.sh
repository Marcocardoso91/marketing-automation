#!/bin/bash

# ============================================================================
# MACSPARK INSTALLER 2025/2026 - NEXT GENERATION
# ============================================================================
# Sistema de instalação de nova geração com IA, cloud-native e zero-touch
# ============================================================================

set -euo pipefail

# ============================================================================
# PROTEÇÃO DO DIRETÓRIO DO CÓDIGO FONTE
# ============================================================================
# Executar verificação de proteção ANTES de qualquer operação
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -f "$SCRIPT_DIR/scripts/protect-source-directory.sh" ]]; then
    if ! bash "$SCRIPT_DIR/scripts/protect-source-directory.sh" --check; then
        echo "❌ Instalação bloqueada por violação de estrutura!"
        echo "📋 Use 'bash scripts/protect-source-directory.sh --help' para mais informações"
        exit 1
    fi
fi

# ============================================================================
# CONFIGURAÇÕES GLOBAIS 2025
# ============================================================================
SCRIPT_VERSION="2025.1.0"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DATE=$(date +"%Y%m%d_%H%M%S")

# URLs e versões das tecnologias 2025/2026
PYTHON_MIN_VERSION="3.11"
NODE_MIN_VERSION="20"
DOCKER_VERSION="latest"
K3S_VERSION="v1.30.0+k3s1"
HELM_VERSION="v3.15.4"

# Cores futurísticas
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
GRAY='\033[0;90m'
NC='\033[0m'
BOLD='\033[1m'
DIM='\033[2m'

# Emojis 2025
ROCKET="🚀"
AI="🤖"
CLOUD="☁️"
GEAR="⚙️"
SHIELD="🛡️"
SPARKLES="✨"
PACKAGE="📦"
GLOBE="🌐"
LIGHTNING="⚡"
STAR="⭐"
CHECK="✅"
CROSS="❌"
WARNING="⚠️"
INFO="ℹ️"

# ============================================================================
# SISTEMA DE LOGGING PADRONIZADO MACSPARK
# ============================================================================
LOG_FILE="/var/log/macspark-install-2025.log"
ERROR_LOG="/var/log/macspark-install-2025-errors.log"

# Criar arquivos de log com fallback
mkdir -p /var/log
touch "$LOG_FILE" "$ERROR_LOG" 2>/dev/null || {
    LOG_FILE="/tmp/macspark-install-2025.log"
    ERROR_LOG="/tmp/macspark-install-2025-errors.log"
    touch "$LOG_FILE" "$ERROR_LOG"
}

# Função central de logging
log_to_file() {
    local level="$1"
    local message="$2"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    # Log para arquivo principal ou erro baseado no nível
    if [[ "$level" == "ERROR" ]]; then
        echo "$timestamp - $level: $message" >> "$ERROR_LOG"
    else
        echo "$timestamp - $level: $message" >> "$LOG_FILE"
    fi
}

log_banner() {
    echo -e "\n${PURPLE}${BOLD}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${PURPLE}${BOLD}║ $1 ${NC}${PURPLE}${BOLD}║${NC}"
    echo -e "${PURPLE}${BOLD}╚══════════════════════════════════════════════════════════════════════════════╝${NC}\n"
    log_to_file "BANNER" "$1"
}

log_section() {
    echo -e "\n${CYAN}${BOLD}▶ $1${NC}"
    echo -e "${GRAY}$(printf '─%.0s' {1..80})${NC}"
    log_to_file "SECTION" "$1"
}

log_ai() {
    echo -e "${BLUE}${BOLD}[AI]${NC} ${AI} $1"
    log_to_file "AI" "$1"
}

log_info() {
    echo -e "${BLUE}${BOLD}[INFO]${NC} ${INFO} $1"
    log_to_file "INFO" "$1"
}

log_success() {
    echo -e "${GREEN}${BOLD}[SUCCESS]${NC} ${CHECK} $1"
    log_to_file "SUCCESS" "$1"
}

log_warning() {
    echo -e "${YELLOW}${BOLD}[WARNING]${NC} ${WARNING} $1"
    log_to_file "WARNING" "$1"
}

log_error() {
    echo -e "${RED}${BOLD}[ERROR]${NC} ${CROSS} $1" >&2
    log_to_file "ERROR" "$1"
}

log_step() {
    echo -e "${WHITE}${BOLD}[STEP]${NC} ${GEAR} $1"
    log_to_file "STEP" "$1"
}

log_debug() {
    if [[ "${DEBUG:-false}" == "true" ]]; then
        echo -e "${GRAY}[DEBUG]${NC} $1"
        log_to_file "DEBUG" "$1"
    fi
}

log_header() {
    echo -e "${PURPLE}${BOLD}[MACSPARK]${NC} $1"
    log_to_file "HEADER" "$1"
}

# ============================================================================
# DEPENDENCY CHECKS PADRONIZADOS MACSPARK
# ============================================================================
check_system_requirements() {
    log_info "🔍 Verificando pré-requisitos do sistema..."
    
    # Verificar se é root
    if [[ $EUID -eq 0 ]]; then
        log_error "Não execute como root! Use um usuário com sudo."
        exit 1
    fi
    
    # Verificar sudo
    if ! sudo -n true 2>/dev/null; then
        log_warning "Este script precisa de privilégios sudo"
        read -p "Pressione ENTER para continuar ou Ctrl+C para cancelar..."
    fi
    
    # Verificar sistema operacional
    if ! grep -qi "ubuntu\|debian\|centos\|rhel\|fedora\|arch" /etc/os-release 2>/dev/null; then
        log_warning "Sistema operacional não testado. Recomendado: Ubuntu, Debian, CentOS, RHEL, Fedora, Arch"
    fi
    
    # Verificar recursos mínimos
    local ram_gb=$(free -g | awk '/^Mem:/{print $2}')
    if [ "$ram_gb" -lt 2 ]; then
        log_warning "⚠️ RAM: ${ram_gb}GB (Recomendado: 4GB+)"
    else
        log_success "✅ RAM: ${ram_gb}GB"
    fi
    
    local disk_gb=$(df / | awk 'NR==2 {print int($4/1024/1024)}')
    if [ "$disk_gb" -lt 10 ]; then
        log_error "❌ Espaço insuficiente: ${disk_gb}GB (Necessário: 20GB+)"
        exit 1
    else
        log_success "✅ Espaço em disco: ${disk_gb}GB"
    fi
    
    # Verificar conectividade
    if ! ping -c 1 8.8.8.8 >/dev/null 2>&1; then
        log_error "❌ Sem conexão com internet"
        exit 1
    else
        log_success "✅ Conectividade OK"
    fi
    
    log_success "✅ Pré-requisitos verificados"
}

check_required_tools() {
    log_info "🔧 Verificando ferramentas essenciais..."
    
    local missing_tools=()
    local required_tools=("curl" "wget" "git" "unzip" "jq" "bc")
    
    for tool in "${required_tools[@]}"; do
        if ! command -v "$tool" &> /dev/null; then
            missing_tools+=("$tool")
        fi
    done
    
    if [ ${#missing_tools[@]} -gt 0 ]; then
        log_warning "Ferramentas ausentes: ${missing_tools[*]}"
        log_info "Instalando ferramentas necessárias..."
        
        case $DISTRO in
            ubuntu|debian)
                sudo apt-get update -y >/dev/null 2>&1
                sudo apt-get install -y "${missing_tools[@]}" >/dev/null 2>&1
                ;;
            centos|rhel|fedora)
                if command -v dnf >/dev/null 2>&1; then
                    sudo dnf install -y "${missing_tools[@]}" >/dev/null 2>&1
                else
                    sudo yum install -y "${missing_tools[@]}" >/dev/null 2>&1
                fi
                ;;
            arch)
                sudo pacman -S --noconfirm "${missing_tools[@]}" >/dev/null 2>&1
                ;;
        esac
        
        # Verificar novamente após instalação
        local still_missing=()
        for tool in "${missing_tools[@]}"; do
            if ! command -v "$tool" &> /dev/null; then
                still_missing+=("$tool")
            fi
        done
        
        if [ ${#still_missing[@]} -gt 0 ]; then
            log_error "Falha ao instalar: ${still_missing[*]}"
            exit 1
        fi
    fi
    
    log_success "✅ Todas as ferramentas essenciais disponíveis"
}

check_docker_requirements() {
    log_info "🐳 Verificando Docker..."
    
    # Verificar se Docker está instalado
    if ! command -v docker &> /dev/null; then
        log_error "Docker não está instalado"
        log_info "Execute: curl -fsSL https://get.docker.com | sh"
        exit 1
    fi
    
    # Verificar versão do Docker
    local docker_version=$(docker --version | grep -oP '\d+\.\d+' | head -1 2>/dev/null || echo "0.0")
    if [[ $(echo "$docker_version < 20.0" | bc 2>/dev/null || echo "1") -eq 1 ]]; then
        log_warning "Docker versão $docker_version pode ser antiga. Recomendado: 20.0+"
    else
        log_success "✅ Docker versão: $docker_version"
    fi
    
    # Verificar se Docker está rodando
    if ! docker info >/dev/null 2>&1; then
        log_error "Docker não está rodando"
        log_info "Execute: sudo systemctl start docker"
        exit 1
    fi
    
    # Verificar se usuário está no grupo docker
    if ! groups | grep -q docker; then
        log_warning "Usuário não está no grupo docker"
        log_info "Execute: sudo usermod -aG docker $USER && newgrp docker"
    fi
    
    log_success "✅ Docker configurado corretamente"
}

check_kubernetes_requirements() {
    log_info "☸️ Verificando Kubernetes (opcional)..."
    
    if command -v kubectl >/dev/null 2>&1; then
        local kubectl_version=$(kubectl version --client --short 2>/dev/null | cut -d' ' -f3 || echo "unknown")
        log_success "✅ kubectl versão: $kubectl_version"
    else
        log_info "kubectl não instalado (será instalado se necessário)"
    fi
    
    if command -v helm >/dev/null 2>&1; then
        local helm_version=$(helm version --short 2>/dev/null | cut -d' ' -f1 || echo "unknown")
        log_success "✅ Helm versão: $helm_version"
    else
        log_info "Helm não instalado (será instalado se necessário)"
    fi
}

# ============================================================================
# INCLUIR FUNÇÕES FHS (FILESYSTEM HIERARCHY STANDARD)
# ============================================================================
# Carregar funções de instalação FHS
if [[ -f "$SCRIPT_DIR/scripts/fhs-installation.sh" ]]; then
    source "$SCRIPT_DIR/scripts/fhs-installation.sh"
    log_info "Funções FHS carregadas com sucesso"
else
    log_warning "Arquivo fhs-installation.sh não encontrado - usando instalação tradicional"
fi

# ============================================================================
# DETECÇÃO INTELIGENTE DE AMBIENTE
# ============================================================================
detect_environment_ai() {
    log_banner "${AI} DETECÇÃO INTELIGENTE DE AMBIENTE 2025"
    
    log_ai "Analisando ambiente com algoritmos de machine learning..."
    
    # Sistema operacional
    OS_NAME=$(uname -s)
    OS_VERSION=$(uname -r)
    DISTRO="unknown"
    
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        DISTRO=$ID
        DISTRO_VERSION=$VERSION_ID
    fi
    
    # Hardware
    CPU_CORES=$(nproc)
    TOTAL_RAM_GB=$(free -g | awk '/^Mem:/{print $2}')
    AVAILABLE_DISK_GB=$(df / | tail -1 | awk '{print int($4/1024/1024)}')
    ARCH=$(uname -m)
    
    # GPU Detection (2025 Standard)
    GPU_AVAILABLE=false
    GPU_COUNT=0
    GPU_MEMORY_MB=0
    GPU_DRIVER_VERSION=""
    
    if command -v nvidia-smi >/dev/null 2>&1; then
        log_info "Detectando GPUs NVIDIA..."
        GPU_COUNT=$(nvidia-smi -L 2>/dev/null | wc -l || echo "0")
        if [ "$GPU_COUNT" -gt 0 ]; then
            GPU_AVAILABLE=true
            GPU_MEMORY_MB=$(nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits | head -1 | tr -d ' ' || echo "0")
            GPU_DRIVER_VERSION=$(nvidia-smi --query-gpu=driver_version --format=csv,noheader,nounits | head -1 | tr -d ' ' || echo "unknown")
            log_success "GPU NVIDIA detectada: $GPU_COUNT x ${GPU_MEMORY_MB}MB (Driver: $GPU_DRIVER_VERSION)"
        fi
    elif lspci | grep -i "vga\|3d\|display" | grep -i "amd\|radeon" >/dev/null 2>&1; then
        log_info "GPU AMD/Radeon detectada (suporte limitado)"
        GPU_AVAILABLE=true
        GPU_COUNT=1
    elif lspci | grep -i "vga\|3d\|display" | grep -i "intel" >/dev/null 2>&1; then
        log_info "GPU Intel integrada detectada"
        GPU_AVAILABLE=true
        GPU_COUNT=1
    fi
    
    # Conversão de arquitetura
    case $ARCH in
        x86_64) ARCH_NORMALIZED="amd64" ;;
        aarch64) ARCH_NORMALIZED="arm64" ;;
        armv7l) ARCH_NORMALIZED="armv7" ;;
        *) ARCH_NORMALIZED=$ARCH ;;
    esac
    
    # Detecção de cloud provider
    CLOUD_PROVIDER="onprem"
    if curl -s --max-time 3 http://169.254.169.254/latest/meta-data/ >/dev/null 2>&1; then
        CLOUD_PROVIDER="aws"
        CLOUD_INSTANCE_TYPE=$(curl -s http://169.254.169.254/latest/meta-data/instance-type 2>/dev/null || echo "unknown")
    elif curl -s --max-time 3 -H "Metadata-Flavor: Google" http://metadata.google.internal/ >/dev/null 2>&1; then
        CLOUD_PROVIDER="gcp"
        CLOUD_INSTANCE_TYPE=$(curl -s -H "Metadata-Flavor: Google" http://metadata.google.internal/computeMetadata/v1/instance/machine-type 2>/dev/null | cut -d'/' -f4 || echo "unknown")
    elif curl -s --max-time 3 -H "Metadata: true" http://169.254.169.254/metadata/instance >/dev/null 2>&1; then
        CLOUD_PROVIDER="azure"
        CLOUD_INSTANCE_TYPE=$(curl -s -H "Metadata: true" "http://169.254.169.254/metadata/instance/compute/vmSize?api-version=2021-02-01&format=text" 2>/dev/null || echo "unknown")
    fi
    
    # Detecção de container runtime
    CONTAINER_RUNTIME="none"
    if command -v docker >/dev/null 2>&1; then
        CONTAINER_RUNTIME="docker"
        DOCKER_VERSION_INSTALLED=$(docker --version | cut -d' ' -f3 | tr -d ',')
    fi
    
    if command -v kubectl >/dev/null 2>&1; then
        KUBERNETES_AVAILABLE=true
        KUBECTL_VERSION=$(kubectl version --client --short 2>/dev/null | cut -d' ' -f3 || echo "unknown")
    else
        KUBERNETES_AVAILABLE=false
        KUBECTL_VERSION="not installed"
    fi
    
    # Verificação de conectividade
    INTERNET_SPEED=""
    if command -v curl >/dev/null 2>&1; then
        log_info "Testando velocidade de conexão..."
        start_time=$(date +%s.%N)
        if curl -s --max-time 10 -o /dev/null https://httpbin.org/bytes/1048576; then
            end_time=$(date +%s.%N)
            duration=$(echo "$end_time - $start_time" | bc)
            speed_mbps=$(echo "scale=2; 8 / $duration" | bc)
            INTERNET_SPEED="${speed_mbps} Mbps"
        fi
    fi
    
    # Gerar score de adequação do sistema
    SYSTEM_SCORE=0
    
    # Score baseado em RAM
    if [[ $TOTAL_RAM_GB -ge 32 ]]; then
        SYSTEM_SCORE=$((SYSTEM_SCORE + 40))
        RAM_ADEQUACY="excellent"
    elif [[ $TOTAL_RAM_GB -ge 16 ]]; then
        SYSTEM_SCORE=$((SYSTEM_SCORE + 30))
        RAM_ADEQUACY="good"
    elif [[ $TOTAL_RAM_GB -ge 8 ]]; then
        SYSTEM_SCORE=$((SYSTEM_SCORE + 20))
        RAM_ADEQUACY="adequate"
    else
        SYSTEM_SCORE=$((SYSTEM_SCORE + 10))
        RAM_ADEQUACY="limited"
    fi
    
    # Score baseado em CPU
    if [[ $CPU_CORES -ge 16 ]]; then
        SYSTEM_SCORE=$((SYSTEM_SCORE + 30))
        CPU_ADEQUACY="excellent"
    elif [[ $CPU_CORES -ge 8 ]]; then
        SYSTEM_SCORE=$((SYSTEM_SCORE + 25))
        CPU_ADEQUACY="good"
    elif [[ $CPU_CORES -ge 4 ]]; then
        SYSTEM_SCORE=$((SYSTEM_SCORE + 20))
        CPU_ADEQUACY="adequate"
    else
        SYSTEM_SCORE=$((SYSTEM_SCORE + 10))
        CPU_ADEQUACY="limited"
    fi
    
    # Score baseado em disco
    if [[ $AVAILABLE_DISK_GB -ge 200 ]]; then
        SYSTEM_SCORE=$((SYSTEM_SCORE + 20))
        DISK_ADEQUACY="excellent"
    elif [[ $AVAILABLE_DISK_GB -ge 100 ]]; then
        SYSTEM_SCORE=$((SYSTEM_SCORE + 15))
        DISK_ADEQUACY="good"
    elif [[ $AVAILABLE_DISK_GB -ge 50 ]]; then
        SYSTEM_SCORE=$((SYSTEM_SCORE + 10))
        DISK_ADEQUACY="adequate"
    else
        SYSTEM_SCORE=$((SYSTEM_SCORE + 5))
        DISK_ADEQUACY="limited"
    fi
    
    # Score baseado em cloud
    if [[ "$CLOUD_PROVIDER" != "onprem" ]]; then
        SYSTEM_SCORE=$((SYSTEM_SCORE + 10))
    fi
    
    # Recomendação de perfil baseada no score
    if [[ $SYSTEM_SCORE -ge 90 ]]; then
        RECOMMENDED_PROFILE="enterprise"
        PROFILE_CONFIDENCE="95%"
    elif [[ $SYSTEM_SCORE -ge 70 ]]; then
        RECOMMENDED_PROFILE="production"
        PROFILE_CONFIDENCE="85%"
    elif [[ $SYSTEM_SCORE -ge 50 ]]; then
        RECOMMENDED_PROFILE="development"
        PROFILE_CONFIDENCE="75%"
    else
        RECOMMENDED_PROFILE="minimal"
        PROFILE_CONFIDENCE="65%"
    fi
    
    # Mostrar relatório da análise
    log_success "Análise do ambiente concluída"
    echo ""
    
    # Tabela de informações do sistema
    printf "${CYAN}${BOLD}%-25s${NC} ${WHITE}%-30s${NC} ${GREEN}%-15s${NC}\n" "COMPONENTE" "VALOR" "ADEQUAÇÃO"
    printf "${GRAY}%s${NC}\n" "$(printf '─%.0s' {1..70})"
    printf "%-25s %-30s ${GREEN}%-15s${NC}\n" "Sistema Operacional" "$DISTRO $DISTRO_VERSION" "✓ Compatível"
    printf "%-25s %-30s ${GREEN}%-15s${NC}\n" "Arquitetura" "$ARCH_NORMALIZED" "✓ Suportada"
    printf "%-25s %-30s %-15s\n" "CPU Cores" "$CPU_CORES cores" "$CPU_ADEQUACY"
    printf "%-25s %-30s %-15s\n" "RAM Total" "${TOTAL_RAM_GB}GB" "$RAM_ADEQUACY"
    printf "%-25s %-30s %-15s\n" "Disco Disponível" "${AVAILABLE_DISK_GB}GB" "$DISK_ADEQUACY"
    printf "%-25s %-30s ${GREEN}%-15s${NC}\n" "Container Runtime" "$CONTAINER_RUNTIME" "${CONTAINER_RUNTIME/none/❌ Ausente}"
    printf "%-25s %-30s %-15s\n" "Kubernetes" "$KUBECTL_VERSION" "${KUBERNETES_AVAILABLE/true/✓ Disponível}"
    printf "%-25s %-30s ${GREEN}%-15s${NC}\n" "Cloud Provider" "$CLOUD_PROVIDER" "${CLOUD_PROVIDER/onprem/On-Premises}"
    
    if [[ -n "$INTERNET_SPEED" ]]; then
        printf "%-25s %-30s ${GREEN}%-15s${NC}\n" "Velocidade Internet" "$INTERNET_SPEED" "✓ Testado"
    fi
    
    echo ""
    
    # Recomendação da IA
    log_ai "Recomendação do perfil de instalação:"
    echo -e "${GREEN}${BOLD}  ${STAR} Perfil: ${RECOMMENDED_PROFILE^^}${NC}"
    echo -e "${BLUE}${BOLD}  ${AI} Confiança: $PROFILE_CONFIDENCE${NC}"
    echo -e "${GRAY}  Score do sistema: $SYSTEM_SCORE/100${NC}"
    
    # Exportar variáveis para uso posterior
    export OS_NAME DISTRO DISTRO_VERSION
    export CPU_CORES TOTAL_RAM_GB AVAILABLE_DISK_GB ARCH_NORMALIZED
    export CLOUD_PROVIDER CLOUD_INSTANCE_TYPE
    export CONTAINER_RUNTIME KUBERNETES_AVAILABLE
    export RECOMMENDED_PROFILE SYSTEM_SCORE
}

# ============================================================================
# INSTALAÇÃO DE DEPENDÊNCIAS MODERNAS
# ============================================================================
install_modern_dependencies() {
    log_banner "${PACKAGE} INSTALAÇÃO DE DEPENDÊNCIAS 2025"
    
    log_step "Atualizando sistema base..."
    
    case $DISTRO in
        ubuntu|debian)
            sudo apt update && sudo apt upgrade -y
            sudo apt install -y curl wget git unzip jq bc software-properties-common apt-transport-https ca-certificates gnupg lsb-release
            ;;
        centos|rhel|fedora)
            if command -v dnf >/dev/null 2>&1; then
                sudo dnf update -y
                sudo dnf install -y curl wget git unzip jq bc
            else
                sudo yum update -y
                sudo yum install -y curl wget git unzip jq bc
            fi
            ;;
        arch)
            sudo pacman -Syu --noconfirm
            sudo pacman -S --noconfirm curl wget git unzip jq bc
            ;;
        *)
            log_warning "Distribuição não reconhecida, tentando comandos genéricos..."
            ;;
    esac
    
    # Instalar Python 3.11+ se necessário
    log_step "Verificando Python $PYTHON_MIN_VERSION+..."
    if ! command -v python3 >/dev/null 2>&1; then
        log_info "Instalando Python 3..."
        case $DISTRO in
            ubuntu|debian)
                sudo apt install -y python3 python3-pip python3-venv
                ;;
            centos|rhel|fedora)
                sudo dnf install -y python3 python3-pip
                ;;
        esac
    fi
    
    # Instalar Node.js 20+ LTS
    log_step "Verificando Node.js $NODE_MIN_VERSION LTS..."
    if ! command -v node >/dev/null 2>&1; then
        log_info "Instalando Node.js LTS..."
        curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
        sudo apt-get install -y nodejs
    fi
    
    # Instalar ferramentas cloud-native
    log_step "Instalando ferramentas cloud-native..."
    
    # kubectl
    if ! command -v kubectl >/dev/null 2>&1; then
        log_info "Instalando kubectl..."
        curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/${ARCH_NORMALIZED}/kubectl"
        sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl
        rm kubectl
    fi
    
    # helm
    if ! command -v helm >/dev/null 2>&1; then
        log_info "Instalando Helm 3..."
        curl -fsSL -o get_helm.sh https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3
        chmod 700 get_helm.sh
        DESIRED_VERSION="$HELM_VERSION" ./get_helm.sh
        rm get_helm.sh
    fi
    
    log_success "Dependências modernas instaladas"
}

# ============================================================================
# SELEÇÃO INTELIGENTE DE RUNTIME
# ============================================================================
choose_container_runtime() {
    log_banner "${GEAR} SELEÇÃO INTELIGENTE DE RUNTIME"
    
    # Lógica de decisão baseada no perfil e recursos
    if [[ "$RECOMMENDED_PROFILE" == "enterprise" ]] || [[ "$RECOMMENDED_PROFILE" == "production" ]]; then
        if [[ $TOTAL_RAM_GB -ge 16 ]] && [[ $CPU_CORES -ge 8 ]]; then
            CHOSEN_RUNTIME="kubernetes"
            log_ai "Recomendação: Kubernetes (K3s) para perfil $RECOMMENDED_PROFILE"
        else
            CHOSEN_RUNTIME="docker-swarm"
            log_ai "Recomendação: Docker Swarm (recursos limitados para K8s)"
        fi
    else
        CHOSEN_RUNTIME="docker-swarm"
        log_ai "Recomendação: Docker Swarm para perfil $RECOMMENDED_PROFILE"
    fi
    
    echo -e "${CYAN}Runtime escolhido: ${WHITE}${BOLD}$CHOSEN_RUNTIME${NC}"
    
    # Oferecer escolha manual se desejado
    if [[ "${INTERACTIVE:-true}" == "true" ]]; then
        echo ""
        echo "Opções disponíveis:"
        echo "1) Kubernetes (K3s) - Cloud-native, microserviços"
        echo "2) Docker Swarm - Simples, eficiente"
        echo "3) Usar recomendação IA ($CHOSEN_RUNTIME)"
        echo ""
        read -p "Escolha (1-3) [3]: " runtime_choice
        
        case ${runtime_choice:-3} in
            1) CHOSEN_RUNTIME="kubernetes" ;;
            2) CHOSEN_RUNTIME="docker-swarm" ;;
            3) ;; # Manter recomendação
            *) log_warning "Opção inválida, usando recomendação IA" ;;
        esac
    fi
    
    export CHOSEN_RUNTIME
    log_success "Runtime selecionado: $CHOSEN_RUNTIME"
}

# ============================================================================
# INSTALAÇÃO DO RUNTIME ESCOLHIDO
# ============================================================================
install_chosen_runtime() {
    log_banner "${ROCKET} INSTALAÇÃO $CHOSEN_RUNTIME"
    
    case $CHOSEN_RUNTIME in
        kubernetes)
            log_info "Iniciando instalação Kubernetes (K3s)..."
            bash "$SCRIPT_DIR/k3s-installer.sh"
            ;;
        docker-swarm)
            log_info "Iniciando instalação Docker Swarm..."
            bash "$SCRIPT_DIR/install.sh"
            ;;
        *)
            log_error "Runtime não reconhecido: $CHOSEN_RUNTIME"
            exit 1
            ;;
    esac
}

# ============================================================================
# PÓS-INSTALAÇÃO E OTIMIZAÇÕES
# ============================================================================
post_installation_optimization() {
    log_banner "${LIGHTNING} OTIMIZAÇÕES PÓS-INSTALAÇÃO"
    
    # Aplicar otimizações baseadas no perfil
    case $RECOMMENDED_PROFILE in
        enterprise)
            log_step "Aplicando otimizações enterprise..."
            # Configurar resource limits altos
            # Habilitar features avançadas
            ;;
        production)
            log_step "Aplicando otimizações de produção..."
            # Configurar monitoring avançado
            # Configurar backup automático
            ;;
        development)
            log_step "Aplicando otimizações de desenvolvimento..."
            # Configurar hot-reload
            # Configurar debugging
            ;;
        minimal)
            log_step "Aplicando otimizações mínimas..."
            # Reduzir resource usage
            # Desabilitar features desnecessárias
            ;;
    esac
    
    # Configurar monitoramento inteligente
    if [[ -f "$SCRIPT_DIR/scripts/modernize-complete.sh" ]]; then
        log_step "Aplicando modernizações adicionais..."
        bash "$SCRIPT_DIR/scripts/modernize-complete.sh"
    fi
    
    log_success "Otimizações aplicadas"
}

# ============================================================================
# INTERFACE DE ESCOLHA DE INSTALAÇÃO
# ============================================================================
show_installation_menu() {
    log_banner "${GLOBE} MÉTODOS DE INSTALAÇÃO DISPONÍVEIS"
    
    echo -e "${CYAN}Escolha o método de instalação:${NC}\n"
    
    echo -e "${WHITE}1)${NC} ${AI} ${BOLD}AI-Powered CLI${NC} - Instalação inteligente via linha de comando"
    echo -e "   ${GRAY}• Auto-detecção e recomendações IA${NC}"
    echo -e "   ${GRAY}• Interface terminal moderna${NC}"
    echo -e "   ${GRAY}• Ideal para servidores${NC}\n"
    
    echo -e "${WHITE}2)${NC} ${GLOBE} ${BOLD}Web Installer${NC} - Interface web moderna"
    echo -e "   ${GRAY}• Dashboard visual interativo${NC}"
    echo -e "   ${GRAY}• Progress em tempo real${NC}"
    echo -e "   ${GRAY}• Ideal para desktop${NC}\n"
    
    echo -e "${WHITE}3)${NC} ${CLOUD} ${BOLD}Cloud-Native K3s${NC} - Instalação Kubernetes moderna"
    echo -e "   ${GRAY}• Kubernetes K3s + ArgoCD${NC}"
    echo -e "   ${GRAY}• Service mesh + GitOps${NC}"
    echo -e "   ${GRAY}• Ideal para produção${NC}\n"
    
    echo -e "${WHITE}4)${NC} ${PACKAGE} ${BOLD}Legacy Docker Swarm${NC} - Instalação compatível"
    echo -e "   ${GRAY}• Docker Swarm tradicional${NC}"
    echo -e "   ${GRAY}• Compatibilidade máxima${NC}"
    echo -e "   ${GRAY}• Ideal para migração${NC}\n"
    
    echo -e "${WHITE}5)${NC} ${GEAR} ${BOLD}Análise Apenas${NC} - Só analisar o sistema"
    echo -e "   ${GRAY}• Detectar configurações${NC}"
    echo -e "   ${GRAY}• Gerar recomendações${NC}"
    echo -e "   ${GRAY}• Não instalar nada${NC}\n"
    
    read -p "Escolha uma opção (1-5): " installation_choice
    
    case $installation_choice in
        1)
            log_info "Iniciando AI-Powered CLI Installer..."
            python3 "$SCRIPT_DIR/ai-installer.py" analyze
            ;;
        2)
            log_info "Iniciando Web Installer..."
            start_web_installer
            ;;
        3)
            log_info "Iniciando Cloud-Native K3s Installer..."
            bash "$SCRIPT_DIR/k3s-installer.sh"
            ;;
        4)
            log_info "Iniciando Legacy Docker Swarm Installer..."
            bash "$SCRIPT_DIR/install.sh"
            ;;
        5)
            log_info "Executando apenas análise do sistema..."
            # Análise já foi feita, mostrar resumo
            show_analysis_summary
            ;;
        *)
            log_error "Opção inválida"
            exit 1
            ;;
    esac
}

start_web_installer() {
    log_step "Configurando Web Installer..."
    
    # Verificar se Python e pip estão disponíveis
    if ! command -v python3 >/dev/null 2>&1; then
        log_error "Python 3 é necessário para o Web Installer"
        exit 1
    fi
    
    # Instalar dependências do web installer
    if [[ ! -d "$SCRIPT_DIR/web-installer/venv" ]]; then
        log_info "Criando ambiente virtual Python..."
        python3 -m venv "$SCRIPT_DIR/web-installer/venv"
    fi
    
    source "$SCRIPT_DIR/web-installer/venv/bin/activate"
    pip install -r "$SCRIPT_DIR/web-installer/requirements.txt" >/dev/null 2>&1
    
    log_success "Web Installer configurado"
    log_info "Iniciando servidor web em http://localhost:8000"
    
    cd "$SCRIPT_DIR/web-installer"
    python3 app.py
}

show_analysis_summary() {
    log_banner "${AI} RESUMO DA ANÁLISE INTELIGENTE"
    
    echo -e "${CYAN}${BOLD}Sistema analisado com sucesso!${NC}\n"
    
    echo -e "${WHITE}Perfil recomendado:${NC} ${GREEN}${BOLD}$RECOMMENDED_PROFILE${NC}"
    echo -e "${WHITE}Score do sistema:${NC} ${BLUE}$SYSTEM_SCORE/100${NC}"
    echo -e "${WHITE}Runtime recomendado:${NC} ${YELLOW}$CHOSEN_RUNTIME${NC}"
    
    echo -e "\n${GRAY}Para prosseguir com a instalação, execute novamente este script${NC}"
    echo -e "${GRAY}e escolha um dos métodos de instalação disponíveis.${NC}"
}

# ============================================================================
# RELATÓRIO FINAL MODERNO
# ============================================================================
show_final_report() {
    log_banner "${SPARKLES} INSTALAÇÃO 2025 CONCLUÍDA"
    
    echo -e "${GREEN}${BOLD}"
    cat <<'EOF'
╔══════════════════════════════════════════════════════════════════════════════╗
║                         🚀 MACSPARK PLATFORM 2025 🚀                        ║
║                      Instalação Next-Gen Concluída!                         ║
╚══════════════════════════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"
    
    echo -e "${CYAN}${BOLD}🎯 RESUMO DA INSTALAÇÃO:${NC}"
    echo -e "${WHITE}• Perfil instalado: ${GREEN}$RECOMMENDED_PROFILE${NC}"
    echo -e "${WHITE}• Runtime: ${BLUE}$CHOSEN_RUNTIME${NC}"
    echo -e "${WHITE}• Score do sistema: ${YELLOW}$SYSTEM_SCORE/100${NC}"
    echo -e "${WHITE}• Arquitetura: ${PURPLE}$ARCH_NORMALIZED${NC}"
    echo -e "${WHITE}• Cloud provider: ${CYAN}$CLOUD_PROVIDER${NC}"
    
    echo ""
    echo -e "${CYAN}${BOLD}🛠️ FERRAMENTAS DISPONÍVEIS:${NC}"
    echo -e "${WHITE}• AI Installer: ${GRAY}python3 ai-installer.py${NC}"
    echo -e "${WHITE}• Web Interface: ${GRAY}cd web-installer && python3 app.py${NC}"
    echo -e "${WHITE}• Status Monitor: ${GRAY}./scripts/health-monitor.sh${NC}"
    echo -e "${WHITE}• Security Scan: ${GRAY}./scripts/security-automation.sh${NC}"
    echo -e "${WHITE}• Backup System: ${GRAY}./scripts/backup-automated.sh${NC}"
    
    echo ""
    echo -e "${CYAN}${BOLD}🔮 PRÓXIMOS PASSOS:${NC}"
    echo -e "${WHITE}1. Configure DNS para seu domínio${NC}"
    echo -e "${WHITE}2. Execute security scan inicial${NC}"
    echo -e "${WHITE}3. Configure backup automático${NC}"
    echo -e "${WHITE}4. Deploy suas aplicações${NC}"
    echo -e "${WHITE}5. Configure monitoramento e alertas${NC}"
    
    echo ""
    echo -e "${GREEN}${BOLD}✨ Welcome to the Cloud-Native Future! ✨${NC}"
}

# =========================================================================
# PARSE DE FLAGS MODERNAS (SWARM, K3S, WEB, AI, MODULARIDADE)
# =========================================================================
SWARM=false
K3S=false
WEB=false
AI=false
MODULAR_STACKS=""
INTERACTIVE=true

while [[ $# -gt 0 ]]; do
  case $1 in
    --swarm)
      SWARM=true
      ;;
    --k3s)
      K3S=true
      ;;
    --web)
      WEB=true
      ;;
    --ai)
      AI=true
      ;;
    --stacks)
      MODULAR_STACKS="$2"
      shift
      ;;
    --non-interactive)
      INTERACTIVE=false
      ;;
    *)
      echo "Unknown option: $1"; exit 1
      ;;
  esac
  shift
done

# Após a detecção de ambiente e escolha de runtime, permitir seleção modular de stacks
select_stacks_modular() {
  log_banner "${PACKAGE} SELEÇÃO MODULAR DE STACKS"
  echo "Selecione os stacks que deseja instalar (separados por vírgula):"
  echo "1) Infraestrutura (Traefik, PostgreSQL, Redis, Portainer)"
  echo "2) IA (Ollama, SparkOne, Claude Interface)"
  echo "3) Monitoramento (Prometheus, Grafana, Jaeger, Netdata)"
  echo "4) Segurança (Vault, CrowdSec, Backup)"
  echo "5) Produtividade (N8N, BookStack, NextCloud, OnlyOffice)"
  echo "6) Comunicação (RocketChat, Jitsi, Mattermost)"
  echo "7) Desenvolvimento (Jenkins, Code-Server, Gitea)"
  echo "8) E-commerce/CMS (WooCommerce, WordPress, Strapi)"
  echo "9) Todos"
  if [[ -z "$MODULAR_STACKS" && "$INTERACTIVE" == "true" ]]; then
    read -p "Digite os números desejados (ex: 1,2,3): " MODULAR_STACKS
  fi
  if [[ "$MODULAR_STACKS" == "9" ]]; then
    MODULAR_STACKS="1,2,3,4,5,6,7,8"
  fi
  export MODULAR_STACKS
  log_success "Stacks selecionados: $MODULAR_STACKS"
}

# Geração automática de .env seguro
if [[ -f "$SCRIPT_DIR/scripts/create-smart-env.sh" ]]; then
  bash "$SCRIPT_DIR/scripts/create-smart-env.sh"
fi

# Instalação dos stacks selecionados
install_selected_stacks() {
  IFS=',' read -ra STACKS <<< "$MODULAR_STACKS"
  for stack in "${STACKS[@]}"; do
    case $stack in
      1) bash "$SCRIPT_DIR/scripts/install-core-only.sh" ;;
      2) bash "$SCRIPT_DIR/scripts/install-ai.sh" ;;
      3) bash "$SCRIPT_DIR/scripts/install-monitoring.sh" ;;
      4) bash "$SCRIPT_DIR/scripts/install-security.sh" ;;
      5) bash "$SCRIPT_DIR/scripts/install-productivity.sh" ;;
      6) bash "$SCRIPT_DIR/scripts/install-communication.sh" ;;
      7) bash "$SCRIPT_DIR/scripts/install-development.sh" ;;
      8) bash "$SCRIPT_DIR/scripts/install-ecommerce.sh" ;;
    esac
  done
}

# Health check pós-deploy
if [[ -f "$SCRIPT_DIR/scripts/health-monitor-ai.sh" ]]; then
  bash "$SCRIPT_DIR/scripts/health-monitor-ai.sh"
fi

# Integração com backup, segurança e automação
if [[ -f "$SCRIPT_DIR/scripts/backup-automated.sh" ]]; then
  bash "$SCRIPT_DIR/scripts/backup-automated.sh" --schedule
fi
if [[ -f "$SCRIPT_DIR/scripts/security-hardening.sh" ]]; then
  bash "$SCRIPT_DIR/scripts/security-hardening.sh"
fi
if [[ -f "$SCRIPT_DIR/scripts/security-automation.sh" ]]; then
  bash "$SCRIPT_DIR/scripts/security-automation.sh"
fi

# Execução principal
main() {
  detect_environment_ai
  
  # ============================================================================
  # INSTALAÇÃO FHS (FILESYSTEM HIERARCHY STANDARD)
  # ============================================================================
  log_banner "${PACKAGE} INSTALAÇÃO FHS - ESTRUTURA PROFISSIONAL"
  
  # Verificar se funções FHS estão disponíveis
  if command -v install_macspark_fhs >/dev/null 2>&1; then
    log_step "Executando instalação FHS..."
    install_macspark_fhs "$SCRIPT_DIR"
    
    log_step "Verificando instalação FHS..."
    if verify_fhs_installation; then
      log_success "Instalação FHS concluída com sucesso!"
      show_fhs_status
    else
      log_error "Falha na verificação da instalação FHS"
      exit 1
    fi
  else
    log_warning "Funções FHS não disponíveis - continuando com instalação tradicional"
    install_modern_dependencies
    choose_container_runtime
    select_stacks_modular
    install_selected_stacks
  fi
  
  log_success "Instalação e configuração concluídas!"
}

main "$@"

# ============================================================================
# TRATAMENTO DE ARGUMENTOS
# ============================================================================
case "${1:-}" in
    --help|-h)
        echo "Macspark Installer 2025/2026"
        echo ""
        echo "Uso: $0 [opção]"
        echo ""
        echo "Opções:"
        echo "  --help, -h          Mostra esta ajuda"
        echo "  --version, -v       Mostra versão"
        echo "  --ai                Executa instalação AI diretamente"
        echo "  --web               Inicia web installer"
        echo "  --k3s               Instalação Kubernetes K3s"
        echo "  --docker            Instalação Docker Swarm"
        echo "  --analyze           Apenas analisa o sistema"
        echo "  --non-interactive   Modo não-interativo"
        echo ""
        exit 0
        ;;
    --version|-v)
        echo "Macspark Installer $SCRIPT_VERSION"
        exit 0
        ;;
    --ai)
        detect_environment_ai
        python3 "$SCRIPT_DIR/ai-installer.py" analyze
        exit 0
        ;;
    --web)
        detect_environment_ai
        start_web_installer
        exit 0
        ;;
    --k3s)
        detect_environment_ai
        bash "$SCRIPT_DIR/k3s-installer.sh"
        exit 0
        ;;
    --docker)
        detect_environment_ai
        bash "$SCRIPT_DIR/install.sh"
        exit 0
        ;;
    --analyze)
        detect_environment_ai
        show_analysis_summary
        exit 0
        ;;
    --non-interactive)
        export INTERACTIVE=false
        ;;
esac

# Função de tratamento de erros
handle_error() {
    local exit_code=$1
    local line_number=$2
    local command="$3"
    echo -e "\n❌ ERRO CRÍTICO INSTALL-2025 na linha $line_number (código: $exit_code)" >&2
    log_to_file "ERROR" "Install-2025 failed at line $line_number with exit code $exit_code - Command: $command"
    echo "📋 Consulte os logs Install-2025: $ERROR_LOG" >&2
    exit $exit_code
}

# Configurar trap para capturar erros
trap 'handle_error $? $LINENO "$BASH_COMMAND"' ERR

# Executar verificações antes da função main
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    # Executar dependency checks antes de main
    check_system_requirements
    check_required_tools
    check_docker_requirements
    check_kubernetes_requirements
    
    # Executar instalação
    main "$@"
fi