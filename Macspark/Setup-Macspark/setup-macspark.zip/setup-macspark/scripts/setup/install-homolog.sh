#!/bin/bash
# MACSPARK HOMOLOG VPS INSTALLER ENTERPRISE 2025
# Deploy otimizado para VPS de homologação
set -euo pipefail

# Cores
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}🏗️ MACSPARK HOMOLOG VPS INSTALLER 2025${NC}"
echo -e "${YELLOW}Ambiente: Homologação (-homolog.macspark.dev)${NC}"
echo

# Carregar configurações de homolog
set -a  # Enable auto-export of variables
source configs/environments/homolog-optimized.env
set +a  # Disable auto-export

# Validar pré-requisitos
check_prerequisites() {
    echo -e "${YELLOW}🔍 Verificando pré-requisitos...${NC}"

    # Docker Engine
    if ! command -v docker &> /dev/null; then
        echo -e "${RED}❌ Docker não encontrado${NC}"
        exit 1
    fi

    # Docker Swarm
    if ! docker info --format '{{.Swarm.LocalNodeState}}' | grep -q active; then
        echo -e "${YELLOW}⚠️ Docker Swarm não ativo, inicializando...${NC}"
        docker swarm init --advertise-addr $(hostname -I | awk '{print $1}')
    fi

    # Recursos mínimos
    MEMORY_GB=$(free -g | awk 'NR==2{printf "%.1f", $2}')
    if (( $(echo "$MEMORY_GB < 2" | bc -l) )); then
        echo -e "${RED}❌ Memória insuficiente: ${MEMORY_GB}GB (mínimo: 2GB)${NC}"
        exit 1
    fi

    echo -e "${GREEN}✅ Pré-requisitos OK${NC}"
}

# Criar redes Docker
create_networks() {
    echo -e "${YELLOW}🌐 Criando redes Docker...${NC}"

    docker network create --driver overlay --attachable traefik-public || true
    docker network create --driver overlay --attachable --opt encrypted apps-network || true
    docker network create --driver overlay --internal --opt encrypted data-network || true
    docker network create --driver overlay --attachable --opt encrypted monitoring-network || true
    docker network create --driver overlay --attachable --opt encrypted security-network || true

    echo -e "${GREEN}✅ Redes criadas${NC}"
}

# Deploy core services
deploy_core() {
    echo -e "${YELLOW}🔧 Deploying core services...${NC}"

    # PostgreSQL otimizado para homolog
    docker stack deploy -c stacks/infra/postgresql-homolog.yml postgres

    # Redis otimizado para homolog
    docker stack deploy -c stacks/infra/redis.yml redis

    # Traefik enterprise
    docker stack deploy -c stacks/traefik/traefik-enterprise-2025.yml traefik

    echo -e "${GREEN}✅ Core services deployed${NC}"
}

# Deploy monitoring stack
deploy_monitoring() {
    echo -e "${YELLOW}📊 Deploying monitoring stack...${NC}"

    docker stack deploy -c stacks/monitoring/monitoring-homolog.yml monitoring

    echo -e "${GREEN}✅ Monitoring deployed${NC}"
}

# Deploy applications
deploy_apps() {
    echo -e "${YELLOW}📱 Deploying applications...${NC}"

    # N8N para automação
    docker stack deploy -c stacks/apps/n8n-homolog.yml n8n

    # Chatwoot para suporte
    docker stack deploy -c stacks/chat/chatwoot-homolog.yml chatwoot

    echo -e "${GREEN}✅ Applications deployed${NC}"
}

# Health check
health_check() {
    echo -e "${YELLOW}🏥 Verificando saúde dos serviços...${NC}"

    sleep 30  # Aguardar inicialização

    # Verificar serviços
    FAILED_SERVICES=$(docker service ls --format "table {{.Name}}\t{{.Replicas}}" | grep "0/")

    if [ -n "$FAILED_SERVICES" ]; then
        echo -e "${RED}❌ Serviços com problemas:${NC}"
        echo "$FAILED_SERVICES"
        echo -e "${YELLOW}Use: docker service logs <service-name> para debug${NC}"
    else
        echo -e "${GREEN}✅ Todos os serviços healthy${NC}"
    fi
}

# Executar instalação
main() {
    check_prerequisites
    create_networks
    deploy_core
    sleep 60  # Aguardar DB
    deploy_monitoring
    deploy_apps
    health_check

    echo
    echo -e "${GREEN}🎉 HOMOLOG VPS INSTALADO COM SUCESSO!${NC}"
    echo -e "${BLUE}📍 Acesso: https://traefik-homolog.macspark.dev${NC}"
    echo -e "${BLUE}📍 N8N: https://n8n-homolog.macspark.dev${NC}"
    echo -e "${BLUE}📍 Chat: https://chat-homolog.macspark.dev${NC}"
    echo
}

main "$@"
