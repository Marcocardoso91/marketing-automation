#!/bin/bash
# MACSPARK PRODUCTION VPS INSTALLER ENTERPRISE 2025
# Deploy enterprise para VPS de produção
set -euo pipefail

# Cores
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
PURPLE='\033[0;35m'
NC='\033[0m'

echo -e "${PURPLE}🚀 MACSPARK PRODUCTION VPS INSTALLER 2025${NC}"
echo -e "${YELLOW}Ambiente: Produção Enterprise (*.macspark.dev)${NC}"
echo

# Carregar configurações de produção
export $(cat configs/environments/production-optimized.env | grep -v '^#' | xargs)

# Validações enterprise
check_production_requirements() {
    echo -e "${YELLOW}🔍 Verificando requisitos enterprise...${NC}"

    # Recursos mínimos para produção
    MEMORY_GB=$(free -g | awk 'NR==2{printf "%.1f", $2}')
    CPU_CORES=$(nproc)

    if (( $(echo "$MEMORY_GB < 8" | bc -l) )); then
        echo -e "${RED}❌ Memória insuficiente: ${MEMORY_GB}GB (mínimo: 8GB)${NC}"
        exit 1
    fi

    if (( CPU_CORES < 4 )); then
        echo -e "${RED}❌ CPU insuficiente: ${CPU_CORES} cores (mínimo: 4)${NC}"
        exit 1
    fi

    # Docker Swarm com múltiplos nós
    NODE_COUNT=$(docker node ls --format "{{.ID}}" | wc -l)
    if (( NODE_COUNT < 3 )); then
        echo -e "${YELLOW}⚠️ Recomendado 3+ nós para HA (atual: ${NODE_COUNT})${NC}"
    fi

    # Volumes para dados persistentes
    if [ ! -d "/opt/macspark" ]; then
        echo -e "${YELLOW}📁 Criando estrutura FHS 2025...${NC}"
        mkdir -p /opt/macspark/{data,logs,configs,backup}
        chown -R 1001:1001 /opt/macspark
    fi

    echo -e "${GREEN}✅ Requisitos enterprise OK${NC}"
}

# Configurações de segurança enterprise
setup_security() {
    echo -e "${YELLOW}🔐 Configurando segurança enterprise...${NC}"

    # Secrets management
    echo "generating_secure_passwords..." | docker secret create db_root_password - || true
    openssl rand -base64 32 | docker secret create jwt_secret - || true
    openssl rand -base64 64 | docker secret create session_secret - || true

    # Configurações de sistema
    echo 'vm.max_map_count=262144' >> /etc/sysctl.conf || true
    echo 'fs.file-max=65536' >> /etc/sysctl.conf || true
    sysctl -p || true

    # Firewall básico
    ufw --force enable || true
    ufw allow 22/tcp || true
    ufw allow 80/tcp || true
    ufw allow 443/tcp || true
    ufw allow 2377/tcp || true  # Docker Swarm
    ufw allow 7946/tcp || true  # Docker Swarm
    ufw allow 7946/udp || true  # Docker Swarm
    ufw allow 4789/udp || true  # Docker Overlay

    echo -e "${GREEN}✅ Segurança configurada${NC}"
}

# Deploy infraestrutura HA
deploy_infrastructure() {
    echo -e "${YELLOW}🏗️ Deploy infraestrutura HA...${NC}"

    # PostgreSQL cluster HA
    docker stack deploy -c stacks/infra/postgresql-production.yml postgres

    # Redis cluster HA
    docker stack deploy -c stacks/infra/redis-production.yml redis

    # Traefik HA com certificados
    docker stack deploy -c stacks/traefik/traefik-enterprise-2025.yml traefik

    # Vault para secrets
    docker stack deploy -c stacks/security/vault-production.yml vault

    echo -e "${GREEN}✅ Infraestrutura HA deployed${NC}"
}

# Deploy observabilidade
deploy_observability() {
    echo -e "${YELLOW}📊 Deploy observabilidade enterprise...${NC}"

    # Stack completa LGTM + Jaeger
    docker stack deploy -c stacks/monitoring/monitoring-production.yml monitoring

    # Falco para runtime security
    docker stack deploy -c configs/security/audit-compliance-2025.yml security

    echo -e "${GREEN}✅ Observabilidade deployed${NC}"
}

# Deploy aplicações de produção
deploy_production_apps() {
    echo -e "${YELLOW}🚀 Deploy aplicações enterprise...${NC}"

    # N8N enterprise
    docker stack deploy -c stacks/apps/n8n-production.yml n8n

    # Chatwoot enterprise
    docker stack deploy -c stacks/chat/chatwoot-production.yml chatwoot

    # Evolution API
    docker stack deploy -c stacks/apps/evolution-api-production.yml evolution

    # Nextcloud enterprise
    docker stack deploy -c stacks/storage/nextcloud-production.yml storage

    echo -e "${GREEN}✅ Aplicações enterprise deployed${NC}"
}

# Configurar backup automático
setup_backup() {
    echo -e "${YELLOW}💾 Configurando backup enterprise...${NC}"

    # Backup schedule
    cat > /etc/cron.d/macspark-backup << 'CRON'
0 2 * * * root /home/marcocardoso/Macspark-Setup/scripts/backup-intelligent.sh
0 6 * * 0 root /home/marcocardoso/Macspark-Setup/scripts/disaster-recovery.sh
CRON

    echo -e "${GREEN}✅ Backup configurado${NC}"
}

# Validação final enterprise
final_validation() {
    echo -e "${YELLOW}✅ Validação final enterprise...${NC}"

    sleep 120  # Aguardar inicialização completa

    # Verificar todos os serviços
    TOTAL_SERVICES=$(docker service ls --format "{{.Name}}" | wc -l)
    RUNNING_SERVICES=$(docker service ls --format "{{.Replicas}}" | grep -c "/")

    echo -e "${BLUE}📊 Status: ${RUNNING_SERVICES}/${TOTAL_SERVICES} serviços${NC}"

    # Health checks específicos
    echo -e "${YELLOW}🏥 Health checks...${NC}"

    # Verificar Traefik
    curl -f https://traefik.macspark.dev/api/version &>/dev/null && \
        echo -e "${GREEN}✅ Traefik OK${NC}" || \
        echo -e "${RED}❌ Traefik FAIL${NC}"

    # Verificar PostgreSQL
    docker exec $(docker ps -q -f name=postgres) pg_isready &>/dev/null && \
        echo -e "${GREEN}✅ PostgreSQL OK${NC}" || \
        echo -e "${RED}❌ PostgreSQL FAIL${NC}"

    # Verificar Redis
    docker exec $(docker ps -q -f name=redis) redis-cli ping &>/dev/null && \
        echo -e "${GREEN}✅ Redis OK${NC}" || \
        echo -e "${RED}❌ Redis FAIL${NC}"
}

# Executar instalação enterprise
main() {
    check_production_requirements
    setup_security
    create_networks
    deploy_infrastructure
    sleep 180  # Aguardar infraestrutura
    deploy_observability
    deploy_production_apps
    setup_backup
    final_validation

    echo
    echo -e "${PURPLE}🎉 PRODUCTION VPS ENTERPRISE INSTALADO!${NC}"
    echo -e "${GREEN}═══════════════════════════════════════${NC}"
    echo -e "${BLUE}🌐 Dashboard: https://traefik.macspark.dev${NC}"
    echo -e "${BLUE}🤖 N8N: https://n8n.macspark.dev${NC}"
    echo -e "${BLUE}💬 Chat: https://chat.macspark.dev${NC}"
    echo -e "${BLUE}☁️ Storage: https://cloud.macspark.dev${NC}"
    echo -e "${BLUE}📊 Monitoring: https://grafana.macspark.dev${NC}"
    echo -e "${BLUE}🔐 Vault: https://vault.macspark.dev${NC}"
    echo
    echo -e "${YELLOW}📋 Próximos passos:${NC}"
    echo "1. Configurar domínios no Cloudflare"
    echo "2. Configurar backup externo"
    echo "3. Executar testes de penetração"
    echo "4. Configurar monitoramento 24/7"
    echo
}

main "$@"
