#!/bin/bash

# ============================================================================
# MACSPARK SETUP - INSTALAÇÃO EM VPS v11.2
# ============================================================================
# Instalação otimizada para VPS usando stacks Docker Swarm existentes
# ============================================================================

set -euo pipefail

# ============================================================================
# PROTEÇÃO DO DIRETÓRIO DO CÓDIGO FONTE
# ============================================================================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -f "$SCRIPT_DIR/scripts/protect-source-directory.sh" ]]; then
    bash "$SCRIPT_DIR/scripts/protect-source-directory.sh" --check || exit 1
fi

# ============================================================================
# TRATAMENTO DE ERROS E LOGS
# ============================================================================
INSTALL_LOG="/var/log/macspark-install.log"
ERROR_LOG="/var/log/macspark-errors.log"

# Compatibilidade com funções antigas (deprecated)
log_to_file() {
    log_to_file_unified "LEGACY" "$1"
}

log_error_to_file() {
    log_to_file_unified "ERROR" "$1"
}

# Interceptar erros
trap 'handle_error $? $LINENO' ERR

handle_error() {
    local exit_code=$1
    local line_number=$2
    log_error "❌ Erro na linha $line_number (código: $exit_code)"
    log_error_to_file "Script failed at line $line_number with exit code $exit_code"
    log_error "📋 Consulte os logs para mais detalhes:"
    log_error "   Install: $INSTALL_LOG"
    log_error "   Errors: $ERROR_LOG"
    exit $exit_code
}

# Criar arquivos de log
mkdir -p /var/log
touch "$INSTALL_LOG" "$ERROR_LOG"
chmod 640 "$INSTALL_LOG" "$ERROR_LOG"

# ============================================================================
# CONFIGURAÇÕES E CORES
# ============================================================================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m'
BOLD='\033[1m'

# ============================================================================
# SISTEMA DE LOGGING PADRONIZADO MACSPARK
# ============================================================================
# Função central de logging
log_to_file_unified() {
    local level="$1"
    local message="$2"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    # Log para arquivo principal ou erro baseado no nível
    if [[ "$level" == "ERROR" ]]; then
        echo "$timestamp - $level: $message" >> "$ERROR_LOG"
    else
        echo "$timestamp - $level: $message" >> "$INSTALL_LOG"
    fi
}

log_info() { 
    echo -e "${BLUE}${BOLD}[INFO]${NC} $1"
    log_to_file_unified "INFO" "$1"
}

log_success() { 
    echo -e "${GREEN}${BOLD}[SUCCESS]${NC} $1"
    log_to_file_unified "SUCCESS" "$1"
}

log_warning() { 
    echo -e "${YELLOW}${BOLD}[WARNING]${NC} $1"
    log_to_file_unified "WARNING" "$1"
}

log_error() { 
    echo -e "${RED}${BOLD}[ERROR]${NC} $1" >&2
    log_to_file_unified "ERROR" "$1"
}

log_header() { 
    echo -e "${PURPLE}${BOLD}[MACSPARK]${NC} $1"
    log_to_file_unified "HEADER" "$1"
}

log_step() {
    echo -e "${CYAN}${BOLD}[STEP]${NC} $1"
    log_to_file_unified "STEP" "$1"
}

log_debug() {
    if [[ "${DEBUG:-false}" == "true" ]]; then
        echo -e "${GRAY}[DEBUG]${NC} $1"
        log_to_file_unified "DEBUG" "$1"
    fi
}

# ============================================================================
# DEPENDENCY CHECKS PADRONIZADOS MACSPARK
# ============================================================================
check_system_requirements_vps() {
    log_info "🔍 Verificando pré-requisitos VPS..."
    
    # Verificar se é root
    if [[ $EUID -ne 0 ]]; then
        log_error "Este script deve ser executado como root"
        exit 1
    fi
    
    # Verificar sistema operacional
    if ! grep -qi "ubuntu\|debian" /etc/os-release; then
        log_warning "Sistema não testado. Recomendado: Ubuntu/Debian"
    fi
    
    # Verificar recursos do sistema
    local ram_gb=$(free -g | awk '/^Mem:/{print $2}')
    if [ "$ram_gb" -lt 2 ]; then
        log_warning "⚠️ RAM: ${ram_gb}GB (Recomendado: 4GB+)"
    else
        log_success "✅ RAM: ${ram_gb}GB"
    fi
    
    local disk_gb=$(df / | awk 'NR==2 {print int($4/1024/1024)}')
    if [ "$disk_gb" -lt 10 ]; then
        log_error "❌ Espaço insuficiente: ${disk_gb}GB (Necessário: 20GB+)"
        exit 1
    else
        log_success "✅ Espaço em disco: ${disk_gb}GB"
    fi
    
    # Verificar conexão com internet
    if ! ping -c 1 8.8.8.8 >/dev/null 2>&1; then
        log_error "❌ Sem conexão com internet"
        exit 1
    else
        log_success "✅ Conectividade OK"
    fi
    
    log_success "✅ Pré-requisitos VPS verificados"
}

check_docker_requirements_vps() {
    log_info "🐳 Verificando Docker..."
    
    # Verificar se Docker está instalado
    if ! command -v docker &> /dev/null; then
        log_error "Docker não está instalado"
        log_info "Execute: curl -fsSL https://get.docker.com | sh"
        exit 1
    fi
    
    # Verificar versão do Docker
    local docker_version=$(docker --version | grep -oP '\d+\.\d+' | head -1)
    if [[ $(echo "$docker_version < 20.0" | bc 2>/dev/null || echo "1") -eq 1 ]]; then
        log_warning "Docker versão $docker_version pode ser antiga. Recomendado: 20.0+"
    fi
    
    # Verificar se Docker está rodando
    if ! docker info >/dev/null 2>&1; then
        log_error "Docker não está rodando"
        log_info "Execute: systemctl start docker"
        exit 1
    fi
    
    # Verificar Docker Swarm
    if ! docker info --format '{{.Swarm.LocalNodeState}}' | grep -q active; then
        log_info "Inicializando Docker Swarm..."
        docker swarm init --advertise-addr $(hostname -I | awk '{print $1}')
    fi
    
    log_success "✅ Docker e Swarm configurados"
}

check_required_tools_vps() {
    log_info "🔧 Verificando ferramentas essenciais..."
    
    local missing_tools=()
    for tool in openssl htpasswd curl bc; do
        if ! command -v "$tool" &> /dev/null; then
            missing_tools+=("$tool")
        fi
    done
    
    if [ ${#missing_tools[@]} -gt 0 ]; then
        log_warning "Ferramentas ausentes: ${missing_tools[*]}"
        log_info "Instalando ferramentas necessárias..."
        apt-get update -y >/dev/null 2>&1
        apt-get install -y apache2-utils curl openssl bc >/dev/null 2>&1
        
        # Verificar novamente
        local still_missing=()
        for tool in "${missing_tools[@]}"; do
            if ! command -v "$tool" &> /dev/null; then
                still_missing+=("$tool")
            fi
        done
        
        if [ ${#still_missing[@]} -gt 0 ]; then
            log_error "Falha ao instalar: ${still_missing[*]}"
            exit 1
        fi
    fi
    
    log_success "✅ Todas as ferramentas essenciais disponíveis"
}

# ============================================================================
# FUNÇÕES DE VALIDAÇÃO
# ============================================================================
validate_domain() {
    local domain=$1
    # Validar formato básico de domínio
    if [[ ! "$domain" =~ ^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$ ]]; then
        return 1
    fi
    # Verificar se não contém caracteres perigosos
    if [[ "$domain" == *";"* ]] || [[ "$domain" == *"&"* ]] || [[ "$domain" == *"|"* ]] || [[ "$domain" == *"<"* ]] || [[ "$domain" == *">"* ]]; then
        return 1
    fi
    return 0
}

validate_email() {
    local email=$1
    # Validar formato básico de email
    if [[ ! "$email" =~ ^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$ ]]; then
        return 1
    fi
    # Verificar se não contém caracteres perigosos
    if [[ "$email" == *";"* ]] || [[ "$email" == *"&"* ]] || [[ "$email" == *"|"* ]] || [[ "$email" == *"<"* ]] || [[ "$email" == *">"* ]]; then
        return 1
    fi
    return 0
}

sanitize_input() {
    local input=$1
    # Remove caracteres potencialmente perigosos
    echo "$input" | sed 's/[;&|<>]//g'
}

# ============================================================================
# BANNER
# ============================================================================
show_banner() {
    clear
    echo -e "${PURPLE}${BOLD}"
    cat << 'EOF'
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║    🚀 MACSPARK SETUP - INSTALAÇÃO EM VPS v11.2                             ║
║                                                                              ║
║    ✅ Instalação 100% funcional                                             ║
║    🔒 Senhas seguras automáticas                                            ║
║    🌐 SSL automático com Let's Encrypt                                      ║
║    📊 Monitoramento integrado                                               ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"
    echo
}

# ============================================================================
# ANÁLISE E LIMPEZA DA VPS
# ============================================================================
analyze_vps() {
    log_info "🔍 Analisando estado atual da VPS..."
    
    # Verificar processos Docker
    if docker ps -q &>/dev/null; then
        local containers=$(docker ps -q | wc -l)
        log_info "📦 Containers em execução: $containers"
        
        if [ "$containers" -gt 0 ]; then
            log_warning "⚠️ Existem containers em execução"
            docker ps --format "table {{.Names}}\t{{.Image}}\t{{.Status}}"
        fi
    fi
    
    # Verificar Docker Swarm
    if docker info --format '{{.Swarm.LocalNodeState}}' 2>/dev/null | grep -q active; then
        log_info "🐳 Docker Swarm ativo"
        local services=$(docker service ls -q 2>/dev/null | wc -l)
        log_info "🔧 Serviços em execução: $services"
        
        if [ "$services" -gt 0 ]; then
            log_warning "⚠️ Existem serviços Docker Swarm em execução"
            docker service ls
        fi
    fi
    
    # Verificar volumes
    local volumes=$(docker volume ls -q 2>/dev/null | wc -l)
    log_info "💾 Volumes Docker: $volumes"
    
    # Verificar redes
    local networks=$(docker network ls --filter driver=overlay -q 2>/dev/null | wc -l)
    log_info "🌐 Redes overlay: $networks"
    
    # Verificar diretório /opt/macspark
    if [ -d "/opt/macspark" ]; then
        log_warning "⚠️ Diretório /opt/macspark já existe"
        du -sh /opt/macspark 2>/dev/null || true
    fi
    
    echo
}

clean_vps() {
    log_warning "🧹 Iniciando limpeza da VPS..."
    
    read -p "Deseja remover todos os containers, serviços e volumes existentes? (s/N): " confirm
    if [[ ! "$confirm" =~ ^[Ss]$ ]]; then
        log_info "Limpeza cancelada pelo usuário"
        return 0
    fi
    
    # Parar todos os containers
    if docker ps -q &>/dev/null; then
        log_info "🛑 Parando containers..."
        docker ps -q | xargs -r docker stop
        docker ps -aq | xargs -r docker rm
    fi
    
    # Remover serviços do Swarm
    if docker service ls -q &>/dev/null; then
        log_info "🔧 Removendo serviços do Swarm..."
        docker service ls -q | xargs -r docker service rm
    fi
    
    # Remover stacks
    if docker stack ls --format "{{.Name}}" 2>/dev/null | grep -q .; then
        log_info "📚 Removendo stacks..."
        docker stack ls --format "{{.Name}}" | xargs -r -I {} docker stack rm {}
        sleep 10  # Aguardar remoção completa
    fi
    
    # Limpar volumes (cuidado!)
    read -p "Deseja remover TODOS os volumes Docker? (DADOS SERÃO PERDIDOS) (s/N): " confirm_volumes
    if [[ "$confirm_volumes" =~ ^[Ss]$ ]]; then
        log_warning "💥 Removendo volumes..."
        docker volume ls -q | xargs -r docker volume rm 2>/dev/null || true
    fi
    
    # Limpar redes
    log_info "🌐 Limpando redes..."
    docker network ls --filter driver=overlay --format "{{.Name}}" | grep -v ingress | xargs -r docker network rm 2>/dev/null || true
    
    # Remover secrets
    log_info "🔐 Removendo secrets..."
    docker secret ls -q | xargs -r docker secret rm 2>/dev/null || true
    
    # Limpar diretório /opt/macspark
    if [ -d "/opt/macspark" ]; then
        read -p "Deseja remover o diretório /opt/macspark? (s/N): " confirm_dir
        if [[ "$confirm_dir" =~ ^[Ss]$ ]]; then
            rm -rf /opt/macspark
            log_success "✅ Diretório /opt/macspark removido"
        fi
    fi
    
    # Prune do sistema
    log_info "🧽 Limpeza final do sistema Docker..."
    docker system prune -af --volumes
    
    log_success "✅ Limpeza da VPS concluída"
    echo
}

# ============================================================================
# VERIFICAÇÕES PRÉ-INSTALAÇÃO
# ============================================================================
check_requirements() {
    log_info "🔍 Verificando pré-requisitos..."
    
    # Verificar se é root
    if [[ $EUID -ne 0 ]]; then
        log_error "Este script deve ser executado como root"
        exit 1
    fi
    
    # Verificar sistema operacional
    if ! grep -qi "ubuntu\|debian" /etc/os-release; then
        log_warning "Sistema não testado. Recomendado: Ubuntu/Debian"
    fi
    
    # Verificar Docker
    if ! command -v docker &> /dev/null; then
        log_error "Docker não está instalado"
        log_info "Execute: curl -fsSL https://get.docker.com | sh"
        exit 1
    fi
    
    # Verificar versão do Docker
    local docker_version=$(docker --version | grep -oP '\d+\.\d+' | head -1)
    if [[ $(echo "$docker_version < 20.0" | bc 2>/dev/null || echo "1") -eq 1 ]]; then
        log_warning "Docker versão $docker_version pode ser antiga. Recomendado: 20.0+"
    fi
    
    # Verificar se Docker está rodando
    if ! docker info >/dev/null 2>&1; then
        log_error "Docker não está rodando"
        log_info "Execute: systemctl start docker"
        exit 1
    fi
    
    # Verificar Docker Swarm
    if ! docker info --format '{{.Swarm.LocalNodeState}}' | grep -q active; then
        log_info "Inicializando Docker Swarm..."
        docker swarm init --advertise-addr $(hostname -I | awk '{print $1}')
    fi
    
    # Verificar recursos do sistema
    local ram_gb=$(free -g | awk '/^Mem:/{print $2}')
    if [ "$ram_gb" -lt 2 ]; then
        log_warning "⚠️ RAM: ${ram_gb}GB (Recomendado: 4GB+)"
    else
        log_success "✅ RAM: ${ram_gb}GB"
    fi
    
    local disk_gb=$(df / | awk 'NR==2 {print int($4/1024/1024)}')
    if [ "$disk_gb" -lt 10 ]; then
        log_error "❌ Espaço insuficiente: ${disk_gb}GB (Necessário: 20GB+)"
        exit 1
    else
        log_success "✅ Espaço em disco: ${disk_gb}GB"
    fi
    
    # Verificar conexão com internet
    if ! ping -c 1 8.8.8.8 >/dev/null 2>&1; then
        log_error "❌ Sem conexão com internet"
        exit 1
    else
        log_success "✅ Conectividade OK"
    fi
    
    # Verificar ferramentas essenciais
    local missing_tools=()
    for tool in openssl htpasswd curl; do
        if ! command -v "$tool" &> /dev/null; then
            missing_tools+=("$tool")
        fi
    done
    
    if [ ${#missing_tools[@]} -gt 0 ]; then
        log_warning "Ferramentas ausentes: ${missing_tools[*]}"
        log_info "Instalando ferramentas necessárias..."
        apt-get update -y >/dev/null 2>&1
        apt-get install -y apache2-utils curl openssl >/dev/null 2>&1
    fi
    
    log_success "✅ Todos os pré-requisitos verificados"
}

# ============================================================================
# CONFIGURAÇÃO DE DOMÍNIO E SENHAS
# ============================================================================
setup_configuration() {
    log_info "⚙️ Configurando instalação..."
    
    # Capturar e validar domínio
    while true; do
        echo -ne "${CYAN}${BOLD}Digite seu domínio (ex: macspark.com): ${NC}"
        read -r DOMAIN
        
        if [[ -z "$DOMAIN" ]]; then
            log_error "Domínio é obrigatório"
            continue
        fi
        
        # Sanitizar entrada
        DOMAIN=$(sanitize_input "$DOMAIN")
        
        # Validar domínio
        if validate_domain "$DOMAIN"; then
            log_success "Domínio válido: $DOMAIN"
            break
        else
            log_error "Domínio inválido. Use apenas letras, números, pontos e hífens"
            continue
        fi
    done
    
    # Capturar e validar email
    while true; do
        echo -ne "${CYAN}${BOLD}Digite seu email para SSL (ex: admin@$DOMAIN): ${NC}"
        read -r EMAIL
        
        if [[ -z "$EMAIL" ]]; then
            EMAIL="admin@$DOMAIN"
        fi
        
        # Sanitizar entrada
        EMAIL=$(sanitize_input "$EMAIL")
        
        # Validar email
        if validate_email "$EMAIL"; then
            log_success "Email válido: $EMAIL"
            break
        else
            log_error "Email inválido. Use formato válido (ex: admin@dominio.com)"
            continue
        fi
    done
    
    # Gerar senhas seguras com critérios rígidos
    TRAEFIK_PASSWORD=$(openssl rand -base64 24 | tr -d "=+/" | cut -c1-20)
    REDIS_PASSWORD=$(openssl rand -base64 48 | tr -d "=+/" | cut -c1-35)
    
    # Validar se senhas foram geradas corretamente
    if [[ ${#TRAEFIK_PASSWORD} -lt 16 ]] || [[ ${#REDIS_PASSWORD} -lt 32 ]]; then
        log_error "Falha na geração de senhas seguras"
        exit 1
    fi
    
    # Gerar hash da senha do Traefik
    if command -v htpasswd &> /dev/null; then
        TRAEFIK_PASSWORD_HASH=$(htpasswd -nb admin "$TRAEFIK_PASSWORD")
    else
        TRAEFIK_PASSWORD_HASH="admin:$(openssl passwd -apr1 "$TRAEFIK_PASSWORD")"
    fi
    
    log_success "✅ Configuração definida"
    log_info "🌐 Domínio: $DOMAIN"
    log_info "📧 Email: $EMAIL"
}

# ============================================================================
# CRIAÇÃO DE ESTRUTURA DE DIRETÓRIOS
# ============================================================================
create_directory_structure() {
    log_info "📁 Criando estrutura de diretórios..."
    
    # Diretórios principais
    mkdir -p /opt/macspark/{data,logs,config,secrets,backups}
    
    # Configurar permissões seguras
    chown -R root:root /opt/macspark
    chmod 755 /opt/macspark
    chmod 750 /opt/macspark/config /opt/macspark/secrets
    chmod 755 /opt/macspark/data /opt/macspark/logs /opt/macspark/backups
    chown -R 1000:1000 /opt/macspark/data
    
    log_success "✅ Estrutura de diretórios criada"
}

# ============================================================================
# CONFIGURAÇÃO DE REDES E VOLUMES
# ============================================================================
setup_docker_infrastructure() {
    log_info "🐳 Configurando infraestrutura Docker..."
    
    # Criar redes necessárias
    docker network create --driver overlay --attachable traefik-public 2>/dev/null || true
    docker network create --driver overlay --attachable database-internal 2>/dev/null || true
    docker network create --driver overlay --attachable management-internal 2>/dev/null || true
    
    # Criar volumes externos
    docker volume create --name certificados 2>/dev/null || true
    docker volume create --name portainer_data 2>/dev/null || true
    docker volume create --name redis_data 2>/dev/null || true
    
    log_success "✅ Infraestrutura Docker configurada"
}

# ============================================================================
# CRIAÇÃO DE SECRETS
# ============================================================================
create_secrets() {
    log_info "🔐 Criando secrets seguros..."
    
    # Remover secrets existentes (se houver)
    docker secret rm redis_password traefik_users 2>/dev/null || true
    
    # Criar arquivo temporário para usuários do Traefik
    local temp_users_file=$(mktemp)
    echo "$TRAEFIK_PASSWORD_HASH" > "$temp_users_file"
    
    # Criar secrets Docker
    echo "$REDIS_PASSWORD" | docker secret create redis_password -
    docker secret create traefik_users "$temp_users_file"
    
    # Remover arquivo temporário com segurança
    shred -u "$temp_users_file" 2>/dev/null || rm -f "$temp_users_file"
    
    # Verificar se secrets foram criados
    if ! docker secret ls | grep -q redis_password; then
        log_error "Falha ao criar secret redis_password"
        exit 1
    fi
    
    if ! docker secret ls | grep -q traefik_users; then
        log_error "Falha ao criar secret traefik_users"
        exit 1
    fi
    
    log_success "✅ Secrets Docker criados com segurança"
    log_info "🔑 Redis password secret: redis_password"
    log_info "👤 Traefik users secret: traefik_users"
}

# ============================================================================
# DEPLOY DOS STACKS
# ============================================================================
deploy_traefik() {
    log_info "🚀 Instalando Traefik..."
    
    # Definir variáveis de ambiente para o stack
    export TRAEFIK_EMAIL="$EMAIL"
    export TRAEFIK_PASSWORD_HASH="$TRAEFIK_PASSWORD_HASH"
    export DOMAIN_SUFFIX="$DOMAIN"
    
    # Deploy usando o stack existente
    cd stacks/traefik && docker stack deploy -c traefik.yml traefik && cd ../..
    
    log_success "✅ Traefik instalado"
    log_info "🌐 Dashboard: http://$(hostname -I | awk '{print $1}'):8080"
    log_info "🌐 Dashboard SSL: https://traefik.$DOMAIN (quando DNS configurado)"
    log_info "👤 Usuário: admin | Senha: $TRAEFIK_PASSWORD"
}

deploy_portainer() {
    log_info "🐳 Instalando Portainer..."
    
    # Definir variáveis de ambiente
    export DOMAIN_SUFFIX="$DOMAIN"
    
    # Deploy usando o stack existente
    cd stacks/portainer && docker stack deploy -c portainer.yml portainer && cd ../..
    
    log_success "✅ Portainer instalado"
    log_info "🌐 Interface: http://$(hostname -I | awk '{print $1}'):9000"
    log_info "🌐 Interface SSL: https://portainer.$DOMAIN (quando DNS configurado)"
}

deploy_redis() {
    log_info "⚡ Instalando Redis..."
    
    # Deploy usando o stack existente
    cd stacks/infra && docker stack deploy -c redis.yml redis && cd ../..
    
    log_success "✅ Redis instalado"
}

deploy_netdata() {
    log_info "📊 Instalando Netdata..."
    
    # Configurar variáveis de ambiente
    export DOMAIN_SUFFIX="$DOMAIN"
    export TIMEZONE="America/Sao_Paulo"
    
    # Deploy usando o stack existente
    cd stacks/monitoring && docker stack deploy -c netdata.yml netdata && cd ../..
    
    log_success "✅ Netdata instalado"
    log_info "🌐 Monitoramento: http://$(hostname -I | awk '{print $1}'):19999"
}

# ============================================================================
# SALVAR CONFIGURAÇÕES
# ============================================================================
save_configuration() {
    log_info "💾 Salvando configurações..."
    
    # Criar arquivo de configuração principal (sem senhas)
    cat > /opt/macspark/config/macspark.conf << EOF
# MACSPARK CONFIGURATION v11.2
DOMAIN=$DOMAIN
EMAIL=$EMAIL
INSTALL_DATE=$(date)
VERSION=11.2
SERVER_IP=$(hostname -I | awk '{print $1}')
EOF

    # Criar arquivo separado para credenciais
    cat > /opt/macspark/secrets/credentials.conf << EOF
# MACSPARK CREDENTIALS - MANTENHA SEGURO
TRAEFIK_PASSWORD=$TRAEFIK_PASSWORD
REDIS_PASSWORD=$REDIS_PASSWORD
EOF

    # Configurar permissões rigorosas
    chmod 644 /opt/macspark/config/macspark.conf
    chmod 600 /opt/macspark/secrets/credentials.conf
    chown root:root /opt/macspark/config/macspark.conf
    chown root:root /opt/macspark/secrets/credentials.conf
    
    # Criar script de leitura segura
    cat > /opt/macspark/scripts/read-credentials.sh << 'EOF'
#!/bin/bash
# Script para ler credenciais de forma segura
if [[ $EUID -ne 0 ]]; then
    echo "Este script deve ser executado como root"
    exit 1
fi
source /opt/macspark/secrets/credentials.conf
echo "Traefik Password: $TRAEFIK_PASSWORD"
echo "Redis Password: $REDIS_PASSWORD"
EOF
    
    mkdir -p /opt/macspark/scripts
    chmod 700 /opt/macspark/scripts/read-credentials.sh
    chown root:root /opt/macspark/scripts/read-credentials.sh
    
    log_success "✅ Configurações salvas de forma segura"
    log_info "📄 Config: /opt/macspark/config/macspark.conf"
    log_info "🔐 Credentials: /opt/macspark/secrets/credentials.conf (somente root)"
}

# ============================================================================
# VERIFICAÇÃO FINAL
# ============================================================================
final_check() {
    log_info "🔍 Verificando instalação..."
    
    sleep 30  # Aguardar serviços iniciarem
    
    local server_ip=$(hostname -I | awk '{print $1}')
    
    echo
    log_header "VERIFICAÇÃO DE SERVIÇOS"
    docker service ls
    
    echo
    log_header "URLS DE ACESSO"
    log_success "🌐 Traefik Dashboard: http://$server_ip:8080"
    log_success "🐳 Portainer: http://$server_ip:9000"
    log_success "📊 Netdata: http://$server_ip:19999"
    
    echo
    log_header "CREDENCIAIS"
    log_info "👤 Traefik - Usuário: admin | Senha: $TRAEFIK_PASSWORD"
    log_info "⚡ Redis - Senha: $REDIS_PASSWORD"
    
    echo
    log_header "PRÓXIMOS PASSOS"
    log_info "1. Configure DNS apontando para: $server_ip"
    log_info "2. Acesse Portainer para configurar aplicações"
    log_info "3. Configure SSL/HTTPS nos domínios"
    log_info "4. Execute hardening de segurança: bash scripts/security-hardening.sh"
    
    echo
    log_header "SEGURANÇA"
    echo -ne "${YELLOW}${BOLD}Deseja aplicar hardening de segurança agora? (s/N): ${NC}"
    read -r security_confirm
    if [[ "$security_confirm" =~ ^[Ss]$ ]]; then
        log_info "🔒 Executando hardening de segurança..."
        bash scripts/security-hardening.sh
    else
        log_warning "⚠️ Lembre-se de executar o hardening: bash scripts/security-hardening.sh"
    fi
    
    echo
    log_success "🎉 INSTALAÇÃO CONCLUÍDA COM SUCESSO!"
    log_info "📝 Configurações: /opt/macspark/config/macspark.conf"
    log_info "🔐 Credenciais: /opt/macspark/secrets/credentials.conf"
}

# ============================================================================
# FUNÇÃO PRINCIPAL
# ============================================================================
main() {
    show_banner
    
    # Análise da VPS
    analyze_vps
    
    # Perguntar se deseja limpar
    echo -ne "${YELLOW}${BOLD}Deseja limpar a VPS antes da instalação? (s/N): ${NC}"
    read -r clean_confirm
    if [[ "$clean_confirm" =~ ^[Ss]$ ]]; then
        clean_vps
    fi
    
    # Prosseguir com instalação
    check_requirements
    setup_configuration
    create_directory_structure
    setup_docker_infrastructure
    create_secrets
    deploy_traefik
    deploy_portainer
    deploy_redis
    deploy_netdata
    save_configuration
    final_check
}

# Executar dependency checks antes da instalação
check_system_requirements_vps
check_docker_requirements_vps 
check_required_tools_vps

# Executar instalação
main "$@"