#!/bin/bash

# ============================================================================
# PREPARAÇÃO AUTOMÁTICA DE VPS - MACSPARK ENTERPRISE
# ============================================================================
# Prepara completamente uma VPS limpa para receber o Macspark Setup
# Instalação zero-touch com validação completa
# ============================================================================

set -euo pipefail

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Configurações
VPS_REQUIREMENTS_CPU="2"      # vCPUs mínimas
VPS_REQUIREMENTS_RAM="4"      # GB RAM mínima
VPS_REQUIREMENTS_DISK="20"    # GB disk mínimo
DOCKER_VERSION="24.0"
DOCKER_COMPOSE_VERSION="2.21"

# Funções de logging
log() {
    local level=$1; shift
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    case $level in
        "INFO") echo -e "${BLUE}[INFO]${NC} [$timestamp] $*" ;;
        "SUCCESS") echo -e "${GREEN}[✓]${NC} [$timestamp] $*" ;;
        "WARN") echo -e "${YELLOW}[⚠]${NC} [$timestamp] $*" ;;
        "ERROR") echo -e "${RED}[✗]${NC} [$timestamp] $*" ;;
    esac
}

# Banner
show_banner() {
    echo -e "${CYAN}"
    echo "============================================================"
    echo "       MACSPARK VPS PREPARATION SCRIPT v1.0"
    echo "============================================================"
    echo "🚀 Preparação automática de VPS para ambiente enterprise"
    echo "📋 Instalação: Docker, Swarm, dependências e otimizações"
    echo "============================================================"
    echo -e "${NC}"
}

# Verificar requisitos de sistema
check_system_requirements() {
    log "INFO" "🔍 Verificando requisitos do sistema..."
    
    # CPU
    local cpu_cores=$(nproc)
    if [ "$cpu_cores" -lt "$VPS_REQUIREMENTS_CPU" ]; then
        log "ERROR" "Insuficientes CPU cores: $cpu_cores (mínimo: $VPS_REQUIREMENTS_CPU)"
        return 1
    fi
    log "SUCCESS" "CPU: $cpu_cores cores (✓)"
    
    # RAM
    local ram_gb=$(free -g | awk '/^Mem:/{print $2}')
    if [ "$ram_gb" -lt "$VPS_REQUIREMENTS_RAM" ]; then
        log "ERROR" "Insuficiente RAM: ${ram_gb}GB (mínimo: ${VPS_REQUIREMENTS_RAM}GB)"
        return 1
    fi
    log "SUCCESS" "RAM: ${ram_gb}GB (✓)"
    
    # Disk
    local disk_gb=$(df / | awk 'NR==2{print int($4/1024/1024)}')
    if [ "$disk_gb" -lt "$VPS_REQUIREMENTS_DISK" ]; then
        log "ERROR" "Insuficiente espaço em disco: ${disk_gb}GB (mínimo: ${VPS_REQUIREMENTS_DISK}GB)"
        return 1
    fi
    log "SUCCESS" "Disk: ${disk_gb}GB disponível (✓)"
    
    # OS
    if ! command -v systemctl >/dev/null 2>&1; then
        log "ERROR" "Sistema não suporta systemd"
        return 1
    fi
    log "SUCCESS" "Sistema: $(lsb_release -ds 2>/dev/null || cat /etc/os-release | grep PRETTY_NAME | cut -d= -f2 | tr -d '\"') (✓)"
}

# Atualizar sistema
update_system() {
    log "INFO" "📦 Atualizando sistema operacional..."
    
    # Detectar distribuição
    if command -v apt-get >/dev/null 2>&1; then
        export DEBIAN_FRONTEND=noninteractive
        sudo apt-get update -qq
        sudo apt-get upgrade -y -qq
        sudo apt-get install -y -qq \
            curl wget git unzip \
            software-properties-common \
            apt-transport-https ca-certificates \
            gnupg lsb-release \
            htop vim nano \
            fail2ban ufw
    elif command -v yum >/dev/null 2>&1; then
        sudo yum update -y -q
        sudo yum install -y -q \
            curl wget git unzip \
            htop vim nano \
            fail2ban firewalld
    else
        log "ERROR" "Distribuição não suportada"
        return 1
    fi
    
    log "SUCCESS" "Sistema atualizado"
}

# Configurar firewall
configure_firewall() {
    log "INFO" "🔒 Configurando firewall..."
    
    if command -v ufw >/dev/null 2>&1; then
        # Ubuntu/Debian
        sudo ufw --force reset
        sudo ufw default deny incoming
        sudo ufw default allow outgoing
        
        # Portas essenciais
        sudo ufw allow ssh
        sudo ufw allow 80/tcp    # HTTP
        sudo ufw allow 443/tcp   # HTTPS
        sudo ufw allow 2377/tcp  # Docker Swarm management
        sudo ufw allow 7946      # Docker Swarm node communication
        sudo ufw allow 4789/udp  # Docker Swarm overlay network
        
        sudo ufw --force enable
        
    elif command -v firewall-cmd >/dev/null 2>&1; then
        # CentOS/RHEL
        sudo systemctl enable --now firewalld
        sudo firewall-cmd --permanent --add-service=ssh
        sudo firewall-cmd --permanent --add-service=http
        sudo firewall-cmd --permanent --add-service=https
        sudo firewall-cmd --permanent --add-port=2377/tcp
        sudo firewall-cmd --permanent --add-port=7946/tcp
        sudo firewall-cmd --permanent --add-port=7946/udp
        sudo firewall-cmd --permanent --add-port=4789/udp
        sudo firewall-cmd --reload
    fi
    
    log "SUCCESS" "Firewall configurado"
}

# Instalar Docker
install_docker() {
    log "INFO" "🐋 Instalando Docker..."
    
    if command -v docker >/dev/null 2>&1; then
        local current_version=$(docker --version | grep -oE '[0-9]+\.[0-9]+')
        log "WARN" "Docker já instalado (versão: $current_version)"
        return 0
    fi
    
    # Remover versões antigas
    sudo apt-get remove -y -qq docker docker-engine docker.io containerd runc 2>/dev/null || true
    
    # Adicionar repositório oficial Docker
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
    
    # Instalar Docker
    sudo apt-get update -qq
    sudo apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-compose-plugin
    
    # Configurar usuário
    sudo usermod -aG docker $USER
    
    # Inicializar serviço
    sudo systemctl enable --now docker
    
    # Testar instalação
    if sudo docker run --rm hello-world >/dev/null 2>&1; then
        log "SUCCESS" "Docker instalado: $(docker --version)"
    else
        log "ERROR" "Falha na instalação do Docker"
        return 1
    fi
}

# Instalar dependências extras
install_dependencies() {
    log "INFO" "📚 Instalando dependências extras..."
    
    # YQ (YAML processor)
    local yq_version="v4.35.2"
    sudo wget -qO /usr/local/bin/yq "https://github.com/mikefarah/yq/releases/download/${yq_version}/yq_linux_amd64"
    sudo chmod +x /usr/local/bin/yq
    log "SUCCESS" "YQ instalado: $(yq --version)"
    
    # JQ (JSON processor)
    if ! command -v jq >/dev/null 2>&1; then
        sudo apt-get install -y -qq jq
    fi
    log "SUCCESS" "JQ: $(jq --version)"
    
    # Docker Compose standalone (backup)
    local compose_version="v2.21.0"
    sudo curl -SL "https://github.com/docker/compose/releases/download/${compose_version}/docker-compose-linux-x86_64" -o /usr/local/bin/docker-compose
    sudo chmod +x /usr/local/bin/docker-compose
    log "SUCCESS" "Docker Compose: $(docker-compose --version)"
}

# Otimizar sistema
optimize_system() {
    log "INFO" "⚡ Otimizando sistema para containers..."
    
    # Configurar swap (se necessário)
    if [ $(free | grep Swap | awk '{print $2}') -eq 0 ]; then
        log "INFO" "Criando arquivo de swap (2GB)..."
        sudo fallocate -l 2G /swapfile
        sudo chmod 600 /swapfile
        sudo mkswap /swapfile
        sudo swapon /swapfile
        echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
        log "SUCCESS" "Swap configurado"
    fi
    
    # Otimizações de kernel para containers
    cat <<EOF | sudo tee /etc/sysctl.d/99-docker-swarm.conf
# Otimizações para Docker Swarm
vm.swappiness=10
net.ipv4.ip_forward=1
net.bridge.bridge-nf-call-iptables=1
net.bridge.bridge-nf-call-ip6tables=1
fs.may_detach_mounts=1

# Limites de conexão
net.core.somaxconn=65535
net.core.netdev_max_backlog=5000
net.ipv4.tcp_max_syn_backlog=65535

# Otimizações TCP
net.ipv4.tcp_keepalive_time=600
net.ipv4.tcp_keepalive_intvl=60
net.ipv4.tcp_keepalive_probes=10
EOF
    
    sudo sysctl --system >/dev/null
    
    # Limits para containers
    cat <<EOF | sudo tee /etc/security/limits.d/99-docker.conf
root soft nofile 65536
root hard nofile 65536
* soft nofile 65536
* hard nofile 65536
EOF
    
    log "SUCCESS" "Sistema otimizado"
}

# Inicializar Docker Swarm
init_docker_swarm() {
    log "INFO" "🔧 Inicializando Docker Swarm..."
    
    if docker info 2>/dev/null | grep -q "Swarm: active"; then
        log "WARN" "Docker Swarm já inicializado"
        return 0
    fi
    
    # Obter IP principal
    local main_ip=$(hostname -I | awk '{print $1}')
    
    # Inicializar swarm
    if docker swarm init --advertise-addr "$main_ip" >/dev/null 2>&1; then
        log "SUCCESS" "Docker Swarm inicializado (IP: $main_ip)"
    else
        log "ERROR" "Falha ao inicializar Docker Swarm"
        return 1
    fi
}

# Validação final
final_validation() {
    log "INFO" "✅ Executando validação final..."
    
    local errors=0
    
    # Docker
    if docker --version >/dev/null 2>&1; then
        log "SUCCESS" "Docker: $(docker --version | cut -d, -f1)"
    else
        log "ERROR" "Docker não funcional"
        ((errors++))
    fi
    
    # Docker Swarm
    if docker info 2>/dev/null | grep -q "Swarm: active"; then
        log "SUCCESS" "Docker Swarm: Ativo"
    else
        log "ERROR" "Docker Swarm não ativo"
        ((errors++))
    fi
    
    # Dependências
    for cmd in yq jq docker-compose; do
        if command -v $cmd >/dev/null 2>&1; then
            log "SUCCESS" "$cmd: Disponível"
        else
            log "ERROR" "$cmd: Não encontrado"
            ((errors++))
        fi
    done
    
    # Resumo
    if [ $errors -eq 0 ]; then
        log "SUCCESS" "🎉 VPS preparada com sucesso! Pronta para Macspark Setup"
        return 0
    else
        log "ERROR" "❌ $errors erro(s) encontrado(s). Revisar instalação"
        return 1
    fi
}

# Menu principal
main() {
    show_banner
    
    log "INFO" "🚀 Iniciando preparação automática da VPS..."
    
    # Verificar se é root ou sudo
    if [ "$EUID" -eq 0 ]; then
        log "ERROR" "Não execute como root. Use um usuário com sudo"
        exit 1
    fi
    
    # Sequência de instalação
    local steps=(
        "check_system_requirements"
        "update_system" 
        "configure_firewall"
        "install_docker"
        "install_dependencies"
        "optimize_system"
        "init_docker_swarm"
        "final_validation"
    )
    
    local total_steps=${#steps[@]}
    local current_step=0
    
    for step in "${steps[@]}"; do
        ((current_step++))
        log "INFO" "📋 Etapa $current_step/$total_steps: $step"
        
        if $step; then
            log "SUCCESS" "✅ Etapa concluída: $step"
        else
            log "ERROR" "❌ Falha na etapa: $step"
            exit 1
        fi
        echo
    done
    
    # Sucesso final
    echo -e "${GREEN}"
    echo "============================================================"
    echo "           🎉 VPS PREPARADA COM SUCESSO!"
    echo "============================================================"
    echo "✅ Docker Swarm ativo e configurado"
    echo "✅ Firewall configurado com portas necessárias" 
    echo "✅ Todas as dependências instaladas"
    echo "✅ Sistema otimizado para containers"
    echo ""
    echo "🚀 PRÓXIMOS PASSOS:"
    echo "   1. Clonar projeto: git clone <repo-url>"
    echo "   2. Executar: ./scripts/setup/install.sh"
    echo "   3. Validar: ./scripts/validation/preflight.sh"
    echo "============================================================"
    echo -e "${NC}"
    
    log "SUCCESS" "Preparação da VPS concluída!"
}

# Executar
main "$@"