#!/bin/bash
# MACSPARK ENTERPRISE BACKUP - SUITE DE TESTES AUTOMATIZADOS 
# Version: 2.0 - Comprehensive testing suite for enterprise backup system
# Created: 2025-08-24 - Validates complete migration and functionality
# Author: MacSpark Infrastructure Team

set -euo pipefail
IFS=$'\n\t'

# ==============================================================================
# TEST SUITE CONFIGURATION
# ==============================================================================

# Base Configuration
readonly SCRIPT_NAME="$(basename "$0" .sh)"
readonly SCRIPT_VERSION="2.0.0"
readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly SETUP_MACSPARK_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
readonly ENVIRONMENT="${ENVIRONMENT:-production}"

# Test Configuration
readonly STACK_NAME="backup-enterprise"
readonly BACKUP_ROOT="/opt/macspark/backup"
readonly TEST_DATA_DIR="/tmp/backup-test-data"
readonly TEST_RESULTS_DIR="$SETUP_MACSPARK_ROOT/test-results"
readonly SESSION_ID="$(uuidgen 2>/dev/null || openssl rand -hex 8)"
readonly START_TIME="$(date +%s)"
readonly TIMESTAMP="$(date '+%Y%m%d_%H%M%S')"

# Test Timeouts (seconds)
readonly DEFAULT_TIMEOUT=300
readonly BACKUP_TIMEOUT=1800
readonly HEALTH_CHECK_TIMEOUT=60
readonly SERVICE_START_TIMEOUT=180

# Colors for Test Output
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly PURPLE='\033[0;35m'
readonly CYAN='\033[0;36m'
readonly WHITE='\033[1;37m'
readonly NC='\033[0m'

# Test Icons
readonly ICON_PASS="✅"
readonly ICON_FAIL="❌"
readonly ICON_SKIP="⏭️"
readonly ICON_RUNNING="🔄"
readonly ICON_TEST="🧪"
readonly ICON_WARNING="⚠️"

# Test Results Tracking
declare -A TEST_RESULTS=()
declare -a FAILED_TESTS=()
declare -a SKIPPED_TESTS=()
TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS_COUNT=0
SKIPPED_TESTS_COUNT=0

# Create test directories
mkdir -p "$TEST_DATA_DIR" "$TEST_RESULTS_DIR"

# ==============================================================================
# TEST UTILITIES AND FRAMEWORK
# ==============================================================================

# Enhanced logging for test framework
log_test() {
    local level="$1"
    local message="$2"
    local test_name="${3:-general}"
    
    local timestamp="$(date -Iseconds)"
    local color="" icon=""
    
    case "$level" in
        "PASS") color="$GREEN"; icon="$ICON_PASS" ;;
        "FAIL") color="$RED"; icon="$ICON_FAIL" ;;
        "SKIP") color="$YELLOW"; icon="$ICON_SKIP" ;;
        "RUNNING") color="$CYAN"; icon="$ICON_RUNNING" ;;
        "WARNING") color="$YELLOW"; icon="$ICON_WARNING" ;;
        "INFO") color="$BLUE"; icon="$ICON_TEST" ;;
        *) color="$WHITE"; icon="$ICON_TEST" ;;
    esac
    
    echo -e "${color}${icon} [$(date '+%H:%M:%S')] [$level] $message${NC}"
    echo "[$timestamp] [$level] [$test_name] $message" >> "$TEST_RESULTS_DIR/test-execution.log"
}

# Test runner with timeout and error handling
run_test() {
    local test_name="$1"
    local test_function="$2"
    local timeout="${3:-$DEFAULT_TIMEOUT}"
    local description="${4:-$test_name}"
    
    ((TOTAL_TESTS++))
    
    log_test "RUNNING" "Test: $description" "$test_name"
    
    local start_time="$(date +%s%N)"
    local result="FAIL"
    local error_message=""
    
    # Run test with timeout
    if timeout "$timeout" bash -c "
        set -euo pipefail
        $test_function
    " 2>&1; then
        result="PASS"
        ((PASSED_TESTS++))
    else
        local exit_code=$?
        if [[ $exit_code -eq 124 ]]; then
            error_message="Test timed out after ${timeout}s"
        else
            error_message="Test failed with exit code $exit_code"
        fi
        FAILED_TESTS+=("$test_name: $error_message")
        ((FAILED_TESTS_COUNT++))
    fi
    
    local end_time="$(date +%s%N)"
    local duration="$(echo "scale=3; ($end_time - $start_time) / 1000000000" | bc -l 2>/dev/null || echo "0")"
    
    TEST_RESULTS["$test_name"]="$result:$duration:$error_message"
    
    log_test "$result" "$description (${duration}s)" "$test_name"
    
    [[ "$result" == "PASS" ]]
}

# Skip test with reason
skip_test() {
    local test_name="$1"
    local reason="$2"
    
    ((TOTAL_TESTS++))
    ((SKIPPED_TESTS_COUNT++))
    
    SKIPPED_TESTS+=("$test_name: $reason")
    TEST_RESULTS["$test_name"]="SKIP:0:$reason"
    
    log_test "SKIP" "$test_name - $reason" "$test_name"
}

# Assert functions for test validation
assert_equals() {
    local expected="$1"
    local actual="$2"
    local message="${3:-Values should be equal}"
    
    if [[ "$expected" == "$actual" ]]; then
        return 0
    else
        echo "ASSERTION FAILED: $message (expected: '$expected', actual: '$actual')" >&2
        return 1
    fi
}

assert_not_empty() {
    local value="$1"
    local message="${2:-Value should not be empty}"
    
    if [[ -n "$value" ]]; then
        return 0
    else
        echo "ASSERTION FAILED: $message (value is empty)" >&2
        return 1
    fi
}

assert_file_exists() {
    local file_path="$1"
    local message="${2:-File should exist}"
    
    if [[ -f "$file_path" ]]; then
        return 0
    else
        echo "ASSERTION FAILED: $message (file: '$file_path')" >&2
        return 1
    fi
}

assert_service_running() {
    local service_name="$1"
    local message="${2:-Service should be running}"
    
    if docker service ls --format '{{.Name}}' | grep -q "^${service_name}$"; then
        local replicas="$(docker service ls --filter name="$service_name" --format '{{.Replicas}}')"
        if [[ "$replicas" =~ ^[1-9][0-9]*\/[1-9][0-9]*$ ]] && [[ "${replicas%/*}" == "${replicas#*/}" ]]; then
            return 0
        fi
    fi
    
    echo "ASSERTION FAILED: $message (service: '$service_name')" >&2
    return 1
}

# ==============================================================================
# INFRASTRUCTURE TESTS
# ==============================================================================

# Test Docker Swarm prerequisites
test_docker_swarm_status() {
    # Check swarm mode
    local swarm_state="$(docker info --format '{{.Swarm.LocalNodeState}}')"
    assert_equals "active" "$swarm_state" "Docker Swarm should be active"
    
    # Check manager role
    local is_manager="$(docker info --format '{{.Swarm.ControlAvailable}}')"
    assert_equals "true" "$is_manager" "Node should be a swarm manager"
    
    # Check node count
    local node_count="$(docker node ls --format '{{.Hostname}}' | wc -l)"
    [[ "$node_count" -ge 1 ]] || { echo "At least 1 node required" >&2; return 1; }
}

# Test required networks
test_required_networks() {
    local networks=("traefik-public" "monitoring")
    
    for network in "${networks[@]}"; do
        if docker network ls --format '{{.Name}}' | grep -q "^${network}$"; then
            log_test "INFO" "Network $network exists" "networks"
        else
            echo "Required network $network does not exist" >&2
            return 1
        fi
    done
}

# Test node labels
test_node_labels() {
    local node_id="$(docker info --format '{{.Swarm.NodeID}}')"
    local required_labels=(
        "macspark.backup.kopia=true"
        "macspark.backup.restic=true"  
        "macspark.backup.orchestrator=true"
        "macspark.backup.monitoring=true"
    )
    
    for label in "${required_labels[@]}"; do
        local key="${label%=*}"
        local expected_value="${label#*=}"
        local actual_value="$(docker node inspect "$node_id" --format "{{index .Spec.Labels \"$key\"}}")"
        
        assert_equals "$expected_value" "$actual_value" "Node label $key should be $expected_value"
    done
}

# Test storage directories
test_storage_directories() {
    local required_dirs=(
        "$BACKUP_ROOT"
        "$BACKUP_ROOT/kopia"
        "$BACKUP_ROOT/restic"
        "$BACKUP_ROOT/config"
        "$BACKUP_ROOT/logs"
        "$BACKUP_ROOT/repositories"
        "$BACKUP_ROOT/local-backups"
    )
    
    for dir in "${required_dirs[@]}"; do
        [[ -d "$dir" ]] || { echo "Required directory $dir does not exist" >&2; return 1; }
        [[ -w "$dir" ]] || { echo "Directory $dir is not writable" >&2; return 1; }
    done
}

# ==============================================================================
# SERVICE DEPLOYMENT TESTS
# ==============================================================================

# Test stack deployment
test_stack_deployment() {
    # Check if stack exists
    if ! docker stack ls --format '{{.Name}}' | grep -q "^${STACK_NAME}$"; then
        echo "Stack $STACK_NAME is not deployed" >&2
        return 1
    fi
    
    # Check service count
    local service_count="$(docker stack services "$STACK_NAME" --format '{{.Name}}' | wc -l)"
    [[ "$service_count" -ge 5 ]] || { echo "Expected at least 5 services, found $service_count" >&2; return 1; }
}

# Test individual services
test_kopia_service() {
    assert_service_running "${STACK_NAME}_kopia-server" "Kopia server should be running"
    
    # Test health endpoint
    sleep 10  # Allow service to stabilize
    local health_check_result=""
    if health_check_result="$(docker exec $(docker ps -q -f name="${STACK_NAME}_kopia-server") kopia server status 2>/dev/null)"; then
        log_test "INFO" "Kopia health check passed" "kopia-service"
    else
        echo "Kopia health check failed: $health_check_result" >&2
        return 1
    fi
}

test_restic_service() {
    assert_service_running "${STACK_NAME}_restic-server" "Restic server should be running"
    
    # Test HTTP endpoint
    sleep 10  # Allow service to stabilize
    local container_id="$(docker ps -q -f name="${STACK_NAME}_restic-server")"
    if [[ -n "$container_id" ]]; then
        if docker exec "$container_id" curl -f http://localhost:8000/ >/dev/null 2>&1; then
            log_test "INFO" "Restic HTTP endpoint accessible" "restic-service"
        else
            echo "Restic HTTP endpoint not accessible" >&2
            return 1
        fi
    else
        echo "Restic container not found" >&2
        return 1
    fi
}

test_orchestrator_service() {
    assert_service_running "${STACK_NAME}_backup-orchestrator" "Backup orchestrator should be running"
    
    # Test script accessibility
    local container_id="$(docker ps -q -f name="${STACK_NAME}_backup-orchestrator")"
    if [[ -n "$container_id" ]]; then
        if docker exec "$container_id" test -x /scripts/core/backup-critical-complete.sh; then
            log_test "INFO" "Orchestrator scripts accessible" "orchestrator-service"
        else
            echo "Orchestrator scripts not accessible" >&2
            return 1
        fi
    else
        echo "Orchestrator container not found" >&2
        return 1
    fi
}

test_monitor_service() {
    assert_service_running "${STACK_NAME}_backup-monitor" "Backup monitor should be running"
    
    # Test web interface
    sleep 10
    local container_id="$(docker ps -q -f name="${STACK_NAME}_backup-monitor")"
    if [[ -n "$container_id" ]]; then
        if docker exec "$container_id" curl -f http://localhost:80/health >/dev/null 2>&1; then
            log_test "INFO" "Monitor web interface accessible" "monitor-service"
        else
            echo "Monitor web interface not accessible" >&2
            return 1
        fi
    else
        echo "Monitor container not found" >&2
        return 1
    fi
}

test_exporter_service() {
    assert_service_running "${STACK_NAME}_backup-exporter" "Backup exporter should be running"
    
    # Test metrics endpoint
    sleep 10
    local container_id="$(docker ps -q -f name="${STACK_NAME}_backup-exporter")"
    if [[ -n "$container_id" ]]; then
        if docker exec "$container_id" wget -q --spider http://localhost:9100/metrics; then
            log_test "INFO" "Exporter metrics endpoint accessible" "exporter-service"
        else
            echo "Exporter metrics endpoint not accessible" >&2
            return 1
        fi
    else
        echo "Exporter container not found" >&2
        return 1
    fi
}

# ==============================================================================
# SECRETS AND CONFIGURATION TESTS
# ==============================================================================

# Test Docker secrets
test_docker_secrets() {
    local required_secrets=(
        "kopia-password"
        "restic-password"
        "backup-encryption-key"
        "cloud-credentials"
    )
    
    for secret in "${required_secrets[@]}"; do
        if docker secret ls --format '{{.Name}}' | grep -q "^${secret}$"; then
            log_test "INFO" "Secret $secret exists" "secrets"
        else
            echo "Required secret $secret does not exist" >&2
            return 1
        fi
    done
}

# Test configuration files
test_configuration_files() {
    local config_files=(
        "$BACKUP_ROOT/config/kopia.json"
        "$BACKUP_ROOT/config/backup-policies.json"
        "$BACKUP_ROOT/config/monitoring.yml"
    )
    
    for config_file in "${config_files[@]}"; do
        assert_file_exists "$config_file" "Configuration file should exist"
        
        # Validate JSON files
        if [[ "$config_file" == *.json ]]; then
            if jq empty "$config_file" >/dev/null 2>&1; then
                log_test "INFO" "JSON configuration valid: $(basename "$config_file")" "config-validation"
            else
                echo "Invalid JSON in configuration file: $config_file" >&2
                return 1
            fi
        fi
    done
}

# Test TLS certificates
test_tls_certificates() {
    local cert_file="$BACKUP_ROOT/config/tls/cert.pem"
    local key_file="$BACKUP_ROOT/config/tls/key.pem"
    
    assert_file_exists "$cert_file" "TLS certificate should exist"
    assert_file_exists "$key_file" "TLS private key should exist"
    
    # Validate certificate
    if openssl x509 -in "$cert_file" -noout -checkend 86400 >/dev/null 2>&1; then
        log_test "INFO" "TLS certificate is valid" "tls-validation"
    else
        echo "TLS certificate is invalid or expires within 24 hours" >&2
        return 1
    fi
}

# ==============================================================================
# FUNCTIONALITY TESTS
# ==============================================================================

# Create test data
create_test_data() {
    log_test "INFO" "Creating test data for backup validation" "test-data"
    
    # Create test database dump
    mkdir -p "$TEST_DATA_DIR/databases"
    echo "-- Test PostgreSQL dump $(date)" > "$TEST_DATA_DIR/databases/test-postgres.sql"
    echo "CREATE TABLE test_table (id INT, data TEXT);" >> "$TEST_DATA_DIR/databases/test-postgres.sql"
    echo "INSERT INTO test_table VALUES (1, 'test data $(date)');" >> "$TEST_DATA_DIR/databases/test-postgres.sql"
    
    # Create test N8N workflow
    mkdir -p "$TEST_DATA_DIR/n8n-workflows"
    cat > "$TEST_DATA_DIR/n8n-workflows/test-workflow.json" << 'EOF'
{
  "name": "Test Workflow",
  "nodes": [
    {
      "id": "start",
      "name": "Start",
      "type": "n8n-nodes-base.start",
      "position": [0, 0]
    }
  ],
  "connections": {},
  "createdAt": "2025-08-24T12:00:00.000Z",
  "updatedAt": "2025-08-24T12:00:00.000Z"
}
EOF
    
    # Create test configuration files
    mkdir -p "$TEST_DATA_DIR/configs"
    echo "# Test configuration $(date)" > "$TEST_DATA_DIR/configs/test.conf"
    echo "test_setting=value" >> "$TEST_DATA_DIR/configs/test.conf"
    
    # Create test files with different sizes
    dd if=/dev/zero of="$TEST_DATA_DIR/small-file.dat" bs=1K count=1 2>/dev/null
    dd if=/dev/zero of="$TEST_DATA_DIR/medium-file.dat" bs=1M count=10 2>/dev/null
    
    log_test "INFO" "Test data created successfully" "test-data"
}

# Test backup script execution
test_backup_script_execution() {
    local container_id="$(docker ps -q -f name="${STACK_NAME}_backup-orchestrator")"
    assert_not_empty "$container_id" "Backup orchestrator container should exist"
    
    # Test backup script exists and is executable
    if ! docker exec "$container_id" test -x /scripts/core/backup-critical-complete.sh; then
        echo "Backup script is not executable" >&2
        return 1
    fi
    
    # Run a test backup (dry run mode)
    log_test "INFO" "Executing test backup..." "backup-script"
    if docker exec "$container_id" /scripts/core/backup-critical-complete.sh --test 2>&1 | tee "$TEST_RESULTS_DIR/backup-test-output.log"; then
        log_test "INFO" "Test backup completed successfully" "backup-script"
    else
        echo "Test backup failed" >&2
        return 1
    fi
}

# Test notification system
test_notification_system() {
    local container_id="$(docker ps -q -f name="${STACK_NAME}_backup-orchestrator")"
    assert_not_empty "$container_id" "Backup orchestrator container should exist"
    
    # Test notification script exists
    if ! docker exec "$container_id" test -x /scripts/core/notification-system.sh; then
        echo "Notification script is not executable" >&2
        return 1
    fi
    
    # Test notification system
    log_test "INFO" "Testing notification system..." "notifications"
    if docker exec "$container_id" /scripts/core/notification-system.sh --test-enterprise 2>&1 | tee "$TEST_RESULTS_DIR/notification-test-output.log"; then
        log_test "INFO" "Notification system test completed" "notifications"
    else
        echo "Notification system test failed" >&2
        return 1
    fi
}

# Test health check system
test_health_check_system() {
    local container_id="$(docker ps -q -f name="${STACK_NAME}_backup-orchestrator")"
    assert_not_empty "$container_id" "Backup orchestrator container should exist"
    
    # Test health check script exists
    if ! docker exec "$container_id" test -x /scripts/core/health-check-enterprise.sh; then
        echo "Health check script is not executable" >&2
        return 1
    fi
    
    # Run health check
    log_test "INFO" "Running enterprise health check..." "health-check"
    local health_exit_code=0
    docker exec "$container_id" /scripts/core/health-check-enterprise.sh 2>&1 | tee "$TEST_RESULTS_DIR/health-check-output.log" || health_exit_code=$?
    
    # Health check may return 1 for warnings, which is acceptable
    if [[ $health_exit_code -le 1 ]]; then
        log_test "INFO" "Health check completed (exit code: $health_exit_code)" "health-check"
    else
        echo "Health check failed with exit code $health_exit_code" >&2
        return 1
    fi
}

# ==============================================================================
# INTEGRATION TESTS
# ==============================================================================

# Test Traefik integration
test_traefik_integration() {
    # Check if services have Traefik labels
    local kopia_labels="$(docker service inspect "${STACK_NAME}_kopia-server" --format '{{range $key, $value := .Spec.Labels}}{{$key}}={{$value}} {{end}}')"
    
    if echo "$kopia_labels" | grep -q "traefik.enable=true"; then
        log_test "INFO" "Kopia service has Traefik labels" "traefik-integration"
    else
        echo "Kopia service missing Traefik labels" >&2
        return 1
    fi
    
    # Similar check for other services
    local restic_labels="$(docker service inspect "${STACK_NAME}_restic-server" --format '{{range $key, $value := .Spec.Labels}}{{$key}}={{$value}} {{end}}')"
    
    if echo "$restic_labels" | grep -q "traefik.enable=true"; then
        log_test "INFO" "Restic service has Traefik labels" "traefik-integration"
    else
        echo "Restic service missing Traefik labels" >&2
        return 1
    fi
}

# Test monitoring integration
test_monitoring_integration() {
    # Check for monitoring network
    if docker network ls --format '{{.Name}}' | grep -q "^monitoring$"; then
        log_test "INFO" "Monitoring network exists" "monitoring-integration"
    else
        echo "Monitoring network does not exist" >&2
        return 1
    fi
    
    # Check if services are connected to monitoring network
    local kopia_networks="$(docker service inspect "${STACK_NAME}_kopia-server" --format '{{range .Spec.TaskTemplate.Networks}}{{.Target}} {{end}}')"
    
    if echo "$kopia_networks" | grep -q "monitoring"; then
        log_test "INFO" "Kopia service connected to monitoring network" "monitoring-integration"
    else
        echo "Kopia service not connected to monitoring network" >&2
        return 1
    fi
}

# Test cron job integration
test_cron_integration() {
    # Check if cron jobs are installed
    if crontab -l 2>/dev/null | grep -q "macspark\|backup"; then
        local job_count="$(crontab -l 2>/dev/null | grep -c "macspark\|backup" || echo "0")"
        log_test "INFO" "Found $job_count backup-related cron jobs" "cron-integration"
    else
        echo "No backup cron jobs found" >&2
        return 1
    fi
}

# ==============================================================================
# PERFORMANCE TESTS
# ==============================================================================

# Test system performance
test_system_performance() {
    # Check available memory
    local available_memory="$(free -m | awk '/^Mem:/ {print $7}')"
    if [[ "$available_memory" -lt 512 ]]; then
        echo "WARNING: Low available memory: ${available_memory}MB" >&2
    fi
    
    # Check disk space
    local available_space="$(df "$BACKUP_ROOT" | tail -1 | awk '{print $4}')"
    local available_gb="$((available_space / 1024 / 1024))"
    if [[ "$available_gb" -lt 2 ]]; then
        echo "Insufficient disk space: ${available_gb}GB available" >&2
        return 1
    fi
    
    # Check CPU load
    local load_avg="$(uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | sed 's/,//')"
    local cpu_count="$(nproc)"
    local load_threshold="$(echo "$cpu_count * 2" | bc)"
    
    if [[ $(echo "$load_avg > $load_threshold" | bc -l) -eq 1 ]]; then
        echo "WARNING: High CPU load: $load_avg (threshold: $load_threshold)" >&2
    fi
    
    log_test "INFO" "Performance check: ${available_memory}MB memory, ${available_gb}GB disk, load ${load_avg}" "performance"
}

# ==============================================================================
# MAIN TEST EXECUTION
# ==============================================================================

# Generate comprehensive test report
generate_test_report() {
    local test_duration="$(($(date +%s) - START_TIME))"
    local success_rate="$(echo "scale=2; $PASSED_TESTS * 100 / $TOTAL_TESTS" | bc -l 2>/dev/null || echo "0")"
    
    # JSON Report
    cat > "$TEST_RESULTS_DIR/test-report-$TIMESTAMP.json" << EOF
{
  "test_execution": {
    "session_id": "$SESSION_ID",
    "timestamp": "$(date -Iseconds)",
    "duration_seconds": $test_duration,
    "environment": "$ENVIRONMENT",
    "stack_name": "$STACK_NAME"
  },
  "summary": {
    "total_tests": $TOTAL_TESTS,
    "passed_tests": $PASSED_TESTS,
    "failed_tests": $FAILED_TESTS_COUNT,
    "skipped_tests": $SKIPPED_TESTS_COUNT,
    "success_rate_percent": $success_rate
  },
  "test_results": {
$(for test_name in "${!TEST_RESULTS[@]}"; do
    IFS=':' read -r status duration error_msg <<< "${TEST_RESULTS[$test_name]}"
    echo "    \"$test_name\": {\"status\": \"$status\", \"duration\": $duration, \"error\": \"$error_msg\"},"
done | sed '$ s/,$//')
  },
  "failed_tests": [
$(printf '    "%s",\n' "${FAILED_TESTS[@]}" | sed '$ s/,$//')
  ],
  "skipped_tests": [
$(printf '    "%s",\n' "${SKIPPED_TESTS[@]}" | sed '$ s/,$//')
  ]
}
EOF
    
    # Human-readable report
    cat > "$TEST_RESULTS_DIR/test-summary-$TIMESTAMP.txt" << EOF
MacSpark Enterprise Backup System - Test Report
===============================================

Test Execution Summary:
- Session ID: $SESSION_ID
- Environment: $ENVIRONMENT
- Start Time: $(date -d "@$START_TIME" '+%Y-%m-%d %H:%M:%S')
- Duration: ${test_duration}s
- Total Tests: $TOTAL_TESTS
- Passed: $PASSED_TESTS ($success_rate%)
- Failed: $FAILED_TESTS_COUNT
- Skipped: $SKIPPED_TESTS_COUNT

$(if [[ $FAILED_TESTS_COUNT -gt 0 ]]; then
    echo "Failed Tests:"
    printf "- %s\n" "${FAILED_TESTS[@]}"
    echo
fi)

$(if [[ $SKIPPED_TESTS_COUNT -gt 0 ]]; then
    echo "Skipped Tests:"
    printf "- %s\n" "${SKIPPED_TESTS[@]}"
    echo
fi)

Overall Status: $([ $FAILED_TESTS_COUNT -eq 0 ] && echo "✅ ALL TESTS PASSED" || echo "❌ SOME TESTS FAILED")
EOF
    
    # Display summary
    echo
    echo -e "${WHITE}===============================================${NC}"
    echo -e "${WHITE}  MacSpark Enterprise Backup Test Results${NC}"
    echo -e "${WHITE}===============================================${NC}"
    echo -e "${BLUE}Total Tests: ${WHITE}$TOTAL_TESTS${NC}"
    echo -e "${GREEN}Passed: ${WHITE}$PASSED_TESTS ($success_rate%)${NC}"
    [[ $FAILED_TESTS_COUNT -gt 0 ]] && echo -e "${RED}Failed: ${WHITE}$FAILED_TESTS_COUNT${NC}"
    [[ $SKIPPED_TESTS_COUNT -gt 0 ]] && echo -e "${YELLOW}Skipped: ${WHITE}$SKIPPED_TESTS_COUNT${NC}"
    echo -e "${CYAN}Duration: ${WHITE}${test_duration}s${NC}"
    echo
    
    if [[ $FAILED_TESTS_COUNT -eq 0 ]]; then
        echo -e "${GREEN}${ICON_PASS} ALL TESTS PASSED - System is ready for production!${NC}"
    else
        echo -e "${RED}${ICON_FAIL} SOME TESTS FAILED - Review failed tests before deployment${NC}"
        echo
        echo -e "${RED}Failed Tests:${NC}"
        for failed_test in "${FAILED_TESTS[@]}"; do
            echo -e "${RED}  • $failed_test${NC}"
        done
    fi
    echo
    
    echo -e "${CYAN}Test Reports:${NC}"
    echo -e "  • JSON Report: ${WHITE}$TEST_RESULTS_DIR/test-report-$TIMESTAMP.json${NC}"
    echo -e "  • Summary: ${WHITE}$TEST_RESULTS_DIR/test-summary-$TIMESTAMP.txt${NC}"
    echo -e "  • Execution Log: ${WHITE}$TEST_RESULTS_DIR/test-execution.log${NC}"
    echo -e "${WHITE}===============================================${NC}"
}

# Main test execution function
run_all_tests() {
    log_test "INFO" "Starting MacSpark Enterprise Backup Test Suite v$SCRIPT_VERSION" "main"
    log_test "INFO" "Session ID: $SESSION_ID" "main"
    log_test "INFO" "Environment: $ENVIRONMENT" "main"
    
    echo -e "${BLUE}🧪 MacSpark Enterprise Backup Test Suite v$SCRIPT_VERSION${NC}"
    echo -e "${CYAN}Session: $SESSION_ID${NC}"
    echo
    
    # Infrastructure Tests
    echo -e "${WHITE}📋 Infrastructure Tests${NC}"
    run_test "docker_swarm_status" "test_docker_swarm_status" 30 "Docker Swarm Status"
    run_test "required_networks" "test_required_networks" 30 "Required Networks"
    run_test "node_labels" "test_node_labels" 30 "Node Labels"
    run_test "storage_directories" "test_storage_directories" 30 "Storage Directories"
    
    # Service Deployment Tests
    echo -e "${WHITE}🚀 Service Deployment Tests${NC}"
    run_test "stack_deployment" "test_stack_deployment" 60 "Stack Deployment"
    run_test "kopia_service" "test_kopia_service" 120 "Kopia Service"
    run_test "restic_service" "test_restic_service" 120 "Restic Service"
    run_test "orchestrator_service" "test_orchestrator_service" 60 "Orchestrator Service"
    run_test "monitor_service" "test_monitor_service" 60 "Monitor Service"
    run_test "exporter_service" "test_exporter_service" 60 "Exporter Service"
    
    # Configuration Tests
    echo -e "${WHITE}⚙️ Configuration Tests${NC}"
    run_test "docker_secrets" "test_docker_secrets" 30 "Docker Secrets"
    run_test "configuration_files" "test_configuration_files" 30 "Configuration Files"
    run_test "tls_certificates" "test_tls_certificates" 30 "TLS Certificates"
    
    # Functionality Tests
    echo -e "${WHITE}🔧 Functionality Tests${NC}"
    run_test "create_test_data" "create_test_data" 60 "Create Test Data"
    run_test "backup_script_execution" "test_backup_script_execution" "$BACKUP_TIMEOUT" "Backup Script Execution"
    run_test "notification_system" "test_notification_system" 120 "Notification System"
    run_test "health_check_system" "test_health_check_system" "$HEALTH_CHECK_TIMEOUT" "Health Check System"
    
    # Integration Tests
    echo -e "${WHITE}🔗 Integration Tests${NC}"
    run_test "traefik_integration" "test_traefik_integration" 30 "Traefik Integration"
    run_test "monitoring_integration" "test_monitoring_integration" 30 "Monitoring Integration"
    run_test "cron_integration" "test_cron_integration" 30 "Cron Integration"
    
    # Performance Tests
    echo -e "${WHITE}⚡ Performance Tests${NC}"
    run_test "system_performance" "test_system_performance" 30 "System Performance"
    
    # Generate final report
    generate_test_report
    
    # Return appropriate exit code
    [[ $FAILED_TESTS_COUNT -eq 0 ]]
}

# Cleanup function
cleanup() {
    log_test "INFO" "Cleaning up test environment..." "cleanup"
    rm -rf "$TEST_DATA_DIR" 2>/dev/null || true
}

# Signal handlers
trap cleanup EXIT
trap 'echo "Test interrupted"; exit 1' INT TERM

# Parse command line arguments
case "${1:-}" in
    --help|-h)
        cat << 'EOF'
MacSpark Enterprise Backup Test Suite v2.0

USAGE:
    test-backup-enterprise.sh [OPTIONS]

OPTIONS:
    --help, -h          Show this help message
    --quick             Run only essential tests (faster)
    --infrastructure    Run only infrastructure tests  
    --services          Run only service tests
    --functionality     Run only functionality tests
    --integration       Run only integration tests
    --performance       Run only performance tests

EXAMPLES:
    # Run full test suite
    ./test-backup-enterprise.sh

    # Run quick essential tests
    ./test-backup-enterprise.sh --quick

    # Test only services
    ./test-backup-enterprise.sh --services

EOF
        exit 0
        ;;
    --quick)
        log_test "INFO" "Running quick test suite..." "main"
        # Run essential tests only
        run_test "docker_swarm_status" "test_docker_swarm_status" 30 "Docker Swarm Status"
        run_test "stack_deployment" "test_stack_deployment" 60 "Stack Deployment"
        run_test "docker_secrets" "test_docker_secrets" 30 "Docker Secrets"
        run_test "backup_script_execution" "test_backup_script_execution" 600 "Backup Script Execution"
        generate_test_report
        [[ $FAILED_TESTS_COUNT -eq 0 ]]
        ;;
    --infrastructure)
        echo -e "${WHITE}📋 Infrastructure Tests Only${NC}"
        run_test "docker_swarm_status" "test_docker_swarm_status" 30 "Docker Swarm Status"
        run_test "required_networks" "test_required_networks" 30 "Required Networks"
        run_test "node_labels" "test_node_labels" 30 "Node Labels"  
        run_test "storage_directories" "test_storage_directories" 30 "Storage Directories"
        generate_test_report
        [[ $FAILED_TESTS_COUNT -eq 0 ]]
        ;;
    --services)
        echo -e "${WHITE}🚀 Service Tests Only${NC}"
        run_test "stack_deployment" "test_stack_deployment" 60 "Stack Deployment"
        run_test "kopia_service" "test_kopia_service" 120 "Kopia Service"
        run_test "restic_service" "test_restic_service" 120 "Restic Service"
        run_test "orchestrator_service" "test_orchestrator_service" 60 "Orchestrator Service"
        run_test "monitor_service" "test_monitor_service" 60 "Monitor Service"
        run_test "exporter_service" "test_exporter_service" 60 "Exporter Service"
        generate_test_report
        [[ $FAILED_TESTS_COUNT -eq 0 ]]
        ;;
    --functionality)
        echo -e "${WHITE}🔧 Functionality Tests Only${NC}"
        run_test "create_test_data" "create_test_data" 60 "Create Test Data"
        run_test "backup_script_execution" "test_backup_script_execution" "$BACKUP_TIMEOUT" "Backup Script Execution"
        run_test "notification_system" "test_notification_system" 120 "Notification System"
        run_test "health_check_system" "test_health_check_system" "$HEALTH_CHECK_TIMEOUT" "Health Check System"
        generate_test_report
        [[ $FAILED_TESTS_COUNT -eq 0 ]]
        ;;
    --integration)
        echo -e "${WHITE}🔗 Integration Tests Only${NC}"
        run_test "traefik_integration" "test_traefik_integration" 30 "Traefik Integration"
        run_test "monitoring_integration" "test_monitoring_integration" 30 "Monitoring Integration"
        run_test "cron_integration" "test_cron_integration" 30 "Cron Integration"
        generate_test_report
        [[ $FAILED_TESTS_COUNT -eq 0 ]]
        ;;
    --performance)
        echo -e "${WHITE}⚡ Performance Tests Only${NC}"
        run_test "system_performance" "test_system_performance" 30 "System Performance"
        generate_test_report
        [[ $FAILED_TESTS_COUNT -eq 0 ]]
        ;;
    "")
        run_all_tests
        ;;
    *)
        log_test "ERROR" "Unknown option: $1" "main"
        echo "Use --help for usage information"
        exit 1
        ;;
esac