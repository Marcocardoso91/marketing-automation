#!/bin/bash

# ============================================================================
# SCRIPT DE VALIDAÇÃO PREFLIGHT - MACSPARK ENTERPRISE
# ============================================================================
# Validação completa antes do deploy em produção
# Verifica redes, secrets, stacks, dependências e configurações
# ============================================================================

set -e

# Importar compatibilidade cross-platform
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../helpers/cross-platform-compat.sh"
setup_platform

ROOT_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"
STACKS_DIR="${ROOT_DIR}/stacks"
CONFIGS_DIR="${ROOT_DIR}/configs"

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Contadores
TOTAL_CHECKS=0
PASSED_CHECKS=0
FAILED_CHECKS=0
WARNING_CHECKS=0

# Função para logging
log() {
    local level=$1
    shift
    local message="$*"
    
    case $level in
        "INFO")
            echo -e "${BLUE}[INFO]${NC} $message"
            ;;
        "PASS")
            echo -e "${GREEN}[✓]${NC} $message"
            ((PASSED_CHECKS++))
            ;;
        "FAIL")
            echo -e "${RED}[✗]${NC} $message"
            ((FAILED_CHECKS++))
            ;;
        "WARN")
            echo -e "${YELLOW}[⚠]${NC} $message"
            ((WARNING_CHECKS++))
            ;;
    esac
    ((TOTAL_CHECKS++))
}

# Verificar dependências do sistema
check_system_dependencies() {
    log "INFO" "🔍 Verificando dependências do sistema..."
    
    local deps=("docker" "yq" "curl" "git")
    local missing=()
    
    for dep in "${deps[@]}"; do
        if command -v "$dep" >/dev/null 2>&1; then
            log "PASS" "$dep está instalado"
        else
            log "FAIL" "$dep não encontrado"
            missing+=("$dep")
        fi
    done
    
    # Verificar versões mínimas
    if command -v docker >/dev/null 2>&1; then
        local docker_version
        docker_version=$(docker --version | grep -oE '[0-9]+\.[0-9]+' | head -1)
        if [[ $(echo "$docker_version >= 20.10" | bc -l 2>/dev/null || echo 0) -eq 1 ]]; then
            log "PASS" "Docker versão $docker_version (>= 20.10)"
        else
            log "WARN" "Docker versão $docker_version pode ser antiga (recomendado >= 20.10)"
        fi
    fi
    
    if [ ${#missing[@]} -gt 0 ]; then
        log "FAIL" "Dependências faltando: ${missing[*]}"
        return 1
    fi
}

# Verificar Docker Swarm
check_docker_swarm() {
    log "INFO" "🐳 Verificando Docker Swarm..."
    
    if run_compat docker info --format '{{.Swarm.LocalNodeState}}' 2>/dev/null | grep -q "active"; then
        log "PASS" "Docker Swarm está ativo"
        
        local node_role
        node_role=$(run_compat docker info --format '{{.Swarm.ControlAvailable}}')
        if [ "$node_role" = "true" ]; then
            log "PASS" "Nó é manager do Swarm"
        else
            log "WARN" "Nó é worker - algumas operações podem falhar"
        fi
        
        # Verificar número de nós
        local nodes_count
        nodes_count=$(run_compat docker node ls --format "{{.ID}}" 2>/dev/null | wc -l)
        log "INFO" "Nós no Swarm: $nodes_count"
        
    else
        log "FAIL" "Docker Swarm não está inicializado"
        log "INFO" "Execute: docker swarm init"
        return 1
    fi
}

# Verificar networks overlay
check_networks() {
    log "INFO" "🌐 Verificando redes overlay..."
    
    local required_networks=(
        "traefik-public"
        "apps-internal" 
        "ai-internal"
        "data-internal"
        "monitoring"
    )
    
    local existing_networks
    existing_networks=$(run_compat docker network ls --format "{{.Name}}" 2>/dev/null || echo "")
    
    for network in "${required_networks[@]}"; do
        if echo "$existing_networks" | grep -q "^${network}$"; then
            log "PASS" "Rede $network existe"
        else
            log "FAIL" "Rede $network não encontrada"
        fi
    done
}

# Verificar sintaxe YAML dos stacks
check_yaml_syntax() {
    log "INFO" "📄 Verificando sintaxe YAML..."
    
    local yaml_errors=0
    
    while IFS= read -r -d '' file; do
        if run_compat yq eval '. | length' "$file" >/dev/null 2>&1; then
            log "PASS" "$(basename "$file") - YAML válido"
        else
            log "FAIL" "$(basename "$file") - YAML inválido"
            ((yaml_errors++))
        fi
    done < <(find "$STACKS_DIR" -name "*.yml" -type f ! -path "*/deprecated/*" -print0 2>/dev/null || true)
    
    if [ $yaml_errors -gt 0 ]; then
        log "FAIL" "$yaml_errors arquivos YAML com erros"
        return 1
    fi
}

# Verificar Docker Compose syntax
check_compose_syntax() {
    log "INFO" "🐋 Verificando sintaxe Docker Compose..."
    
    local compose_errors=0
    
    while IFS= read -r -d '' file; do
        if run_compat docker compose -f "$file" config >/dev/null 2>&1; then
            log "PASS" "$(basename "$file") - Compose válido"
        else
            log "FAIL" "$(basename "$file") - Compose inválido"
            ((compose_errors++))
        fi
    done < <(find "$STACKS_DIR" -name "*.yml" -type f ! -path "*/deprecated/*" -print0 2>/dev/null || true)
    
    if [ $compose_errors -gt 0 ]; then
        log "FAIL" "$compose_errors stacks com sintaxe inválida"
        return 1
    fi
}

# Verificar secrets necessários
check_secrets() {
    log "INFO" "🔐 Verificando secrets..."
    
    # Lista de secrets críticos
    local required_secrets=(
        "postgres_password"
        "redis_password"
        "traefik_auth"
        "jwt_secret"
    )
    
    local existing_secrets
    existing_secrets=$(run_compat docker secret ls --format "{{.Name}}" 2>/dev/null || echo "")
    
    for secret in "${required_secrets[@]}"; do
        if echo "$existing_secrets" | grep -q "^${secret}$"; then
            log "PASS" "Secret $secret existe"
        else
            log "WARN" "Secret $secret não encontrado (pode ser criado no deploy)"
        fi
    done
}

# Verificar volumes necessários
check_volumes() {
    log "INFO" "💾 Verificando volumes..."
    
    local critical_volumes=(
        "postgres_data"
        "redis_data"
        "traefik_acme"
        "prometheus_data"
        "grafana_data"
    )
    
    local existing_volumes
    existing_volumes=$(run_compat docker volume ls --format "{{.Name}}" 2>/dev/null || echo "")
    
    for volume in "${critical_volumes[@]}"; do
        if echo "$existing_volumes" | grep -q "$volume"; then
            log "PASS" "Volume $volume existe"
        else
            log "WARN" "Volume $volume será criado no deploy"
        fi
    done
}

# Verificar portas disponíveis
check_ports() {
    log "INFO" "🔌 Verificando portas críticas..."
    
    local critical_ports=(80 443 2377 7946 4789)
    
    for port in "${critical_ports[@]}"; do
        if command -v netstat >/dev/null 2>&1; then
            if netstat -tuln 2>/dev/null | grep -q ":${port} "; then
                log "WARN" "Porta $port já está em uso"
            else
                log "PASS" "Porta $port disponível"
            fi
        elif command -v ss >/dev/null 2>&1; then
            if ss -tuln 2>/dev/null | grep -q ":${port} "; then
                log "WARN" "Porta $port já está em uso"
            else
                log "PASS" "Porta $port disponível"
            fi
        else
            log "WARN" "Não foi possível verificar porta $port (netstat/ss não disponível)"
        fi
    done
}

# Verificar recursos do sistema
check_system_resources() {
    log "INFO" "⚡ Verificando recursos do sistema..."
    
    # Memória
    if command -v free >/dev/null 2>&1; then
        local mem_gb
        mem_gb=$(free -g | awk 'NR==2{printf "%.1f", $2}')
        if (( $(echo "$mem_gb >= 8.0" | bc -l 2>/dev/null || echo 0) )); then
            log "PASS" "Memória: ${mem_gb}GB (recomendado >= 8GB)"
        else
            log "WARN" "Memória: ${mem_gb}GB (recomendado >= 8GB para produção)"
        fi
    fi
    
    # Espaço em disco
    local disk_gb
    disk_gb=$(df -BG / | awk 'NR==2{print $4}' | sed 's/G//')
    if [ "$disk_gb" -ge 50 ]; then
        log "PASS" "Espaço disponível: ${disk_gb}GB (recomendado >= 50GB)"
    else
        log "WARN" "Espaço disponível: ${disk_gb}GB (recomendado >= 50GB)"
    fi
    
    # CPU cores
    local cpu_cores
    cpu_cores=$(nproc 2>/dev/null || echo "unknown")
    if [ "$cpu_cores" != "unknown" ] && [ "$cpu_cores" -ge 4 ]; then
        log "PASS" "CPU cores: $cpu_cores (recomendado >= 4)"
    else
        log "WARN" "CPU cores: $cpu_cores (recomendado >= 4 para produção)"
    fi
}

# Verificar configurações de segurança
check_security_config() {
    log "INFO" "🔒 Verificando configurações de segurança..."
    
    # Verificar se há imagens com tag latest
    local latest_count
    latest_count=$(find "$STACKS_DIR" -name "*.yml" ! -path "*/deprecated/*" -exec grep -l ":latest" {} \; 2>/dev/null | wc -l)
    
    if [ "$latest_count" -eq 0 ]; then
        log "PASS" "Nenhuma imagem com tag :latest encontrada"
    else
        log "FAIL" "$latest_count stacks usando tag :latest (não recomendado para produção)"
    fi
    
    # Verificar resource limits
    local no_limits_count
    no_limits_count=$(find "$STACKS_DIR" -name "*.yml" ! -path "*/deprecated/*" -exec grep -L "resources:" {} \; 2>/dev/null | wc -l)
    
    if [ "$no_limits_count" -eq 0 ]; then
        log "PASS" "Todos os stacks têm resource limits"
    else
        log "WARN" "$no_limits_count stacks sem resource limits"
    fi
}

# Relatório final
generate_report() {
    echo ""
    echo "═══════════════════════════════════════════════════════════════"
    echo "🎯 RELATÓRIO PREFLIGHT - MACSPARK ENTERPRISE"
    echo "═══════════════════════════════════════════════════════════════"
    echo "Platform: $PLATFORM"
    echo "Data: $(date)"
    echo ""
    echo "📊 Resumo dos Checks:"
    echo "  Total: $TOTAL_CHECKS"
    echo -e "  ${GREEN}✓ Passou: $PASSED_CHECKS${NC}"
    echo -e "  ${RED}✗ Falhou: $FAILED_CHECKS${NC}"
    echo -e "  ${YELLOW}⚠ Avisos: $WARNING_CHECKS${NC}"
    echo ""
    
    local success_rate
    success_rate=$(( (PASSED_CHECKS * 100) / TOTAL_CHECKS ))
    
    if [ $FAILED_CHECKS -eq 0 ]; then
        echo -e "${GREEN}🎉 PREFLIGHT APROVADO${NC}"
        echo "✅ Sistema pronto para deploy em produção"
        if [ $WARNING_CHECKS -gt 0 ]; then
            echo -e "${YELLOW}⚠️ $WARNING_CHECKS avisos encontrados - revisar recomendado${NC}"
        fi
        return 0
    else
        echo -e "${RED}❌ PREFLIGHT FALHOU${NC}"
        echo "🔧 Corrija os erros antes do deploy"
        return 1
    fi
}

# Função principal
main() {
    echo "🚀 PREFLIGHT CHECK - MACSPARK ENTERPRISE"
    echo "========================================="
    echo ""
    
    # Executar todas as verificações
    check_system_dependencies || true
    check_docker_swarm || true
    check_networks || true
    check_yaml_syntax || true
    check_compose_syntax || true
    check_secrets || true
    check_volumes || true
    check_ports || true
    check_system_resources || true
    check_security_config || true
    
    # Gerar relatório
    generate_report
}

# Executar se script foi chamado diretamente
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi