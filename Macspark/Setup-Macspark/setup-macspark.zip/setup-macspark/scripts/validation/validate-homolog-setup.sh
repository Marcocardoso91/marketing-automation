#!/bin/bash

# ================================================================================
# Validação Setup Homolog - MacSpark Enterprise
# Verifica se todos os arquivos necessários estão prontos para deploy
# ================================================================================

set -e

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Contadores
TOTAL_CHECKS=0
PASSED_CHECKS=0
FAILED_CHECKS=0

# Função para verificação
check_item() {
    local description="$1"
    local command="$2"
    local type="${3:-file}"
    
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    echo -n "🔍 $description... "
    
    if [ "$type" = "file" ]; then
        if [ -f "$command" ]; then
            echo -e "${GREEN}✅${NC}"
            PASSED_CHECKS=$((PASSED_CHECKS + 1))
        else
            echo -e "${RED}❌${NC}"
            echo -e "   ${YELLOW}Arquivo não encontrado: $command${NC}"
            FAILED_CHECKS=$((FAILED_CHECKS + 1))
        fi
    elif [ "$type" = "dir" ]; then
        if [ -d "$command" ]; then
            echo -e "${GREEN}✅${NC}"
            PASSED_CHECKS=$((PASSED_CHECKS + 1))
        else
            echo -e "${RED}❌${NC}"
            echo -e "   ${YELLOW}Diretório não encontrado: $command${NC}"
            FAILED_CHECKS=$((FAILED_CHECKS + 1))
        fi
    elif [ "$type" = "cmd" ]; then
        if eval "$command" > /dev/null 2>&1; then
            echo -e "${GREEN}✅${NC}"
            PASSED_CHECKS=$((PASSED_CHECKS + 1))
        else
            echo -e "${RED}❌${NC}"
            echo -e "   ${YELLOW}Comando falhou: $command${NC}"
            FAILED_CHECKS=$((FAILED_CHECKS + 1))
        fi
    fi
}

echo -e "${BLUE}=================================================================================${NC}"
echo -e "${BLUE}🔍 VALIDAÇÃO SETUP HOMOLOG MACSPARK - $(date)${NC}"
echo -e "${BLUE}=================================================================================${NC}"

# Verificar se está no diretório correto
if [ ! -f "README.md" ] || [ ! -d "stacks" ]; then
    echo -e "${RED}❌ Execute este script do diretório raiz do Setup-Macspark!${NC}"
    exit 1
fi

echo -e "\n${YELLOW}📂 Validando estrutura de diretórios...${NC}"
check_item "Diretório stacks/core" "stacks/core" "dir"
check_item "Diretório stacks/applications" "stacks/applications" "dir"
check_item "Diretório scripts/deployment" "scripts/deployment" "dir"
check_item "Diretório configs/middleware" "configs/middleware" "dir"

echo -e "\n${YELLOW}🔧 Validando arquivos de configuração core...${NC}"
check_item "Traefik Homolog" "stacks/core/traefik/traefik-homolog.yml"
check_item "PostgreSQL Homolog" "stacks/core/database/postgresql-homolog.yml"
check_item "Redis Homolog" "stacks/core/database/redis-homolog.yml"
check_item "Middlewares Traefik" "configs/middleware/middlewares.yml"

echo -e "\n${YELLOW}📱 Validando arquivos de aplicações...${NC}"
check_item "N8N Homolog" "stacks/applications/productivity/n8n-homolog.yml"

echo -e "\n${YELLOW}🚀 Validando scripts de deployment...${NC}"
check_item "Script Deploy Homolog" "scripts/deployment/deploy-homolog-complete.sh"
check_item "Script Deploy executável" "test -x scripts/deployment/deploy-homolog-complete.sh" "cmd"

echo -e "\n${YELLOW}🐳 Validando ambiente Docker...${NC}"
check_item "Docker instalado" "docker --version" "cmd"
check_item "Docker Compose instalado" "docker compose version" "cmd"
check_item "Docker Swarm disponível" "docker info | grep -q Swarm" "cmd"

echo -e "\n${YELLOW}🌐 Validando conectividade...${NC}"
check_item "Acesso à internet" "ping -c 1 8.8.8.8" "cmd"
check_item "DNS funcionando" "nslookup macspark.dev" "cmd"

echo -e "\n${YELLOW}📊 Validando recursos do sistema...${NC}"
check_item "Memória suficiente (>2GB)" "[ \$(free -m | awk 'NR==2{print \$2}') -gt 2000 ]" "cmd"
check_item "Espaço em disco (>10GB)" "[ \$(df / | awk 'NR==2{print \$4}') -gt 10485760 ]" "cmd"

# Verificação específica dos arquivos YAML
echo -e "\n${YELLOW}📋 Validando sintaxe dos arquivos YAML...${NC}"

yaml_files=(
    "stacks/core/traefik/traefik-homolog.yml"
    "stacks/core/database/postgresql-homolog.yml"
    "stacks/core/database/redis-homolog.yml"
    "stacks/applications/productivity/n8n-homolog.yml"
)

for yaml_file in "${yaml_files[@]}"; do
    if [ -f "$yaml_file" ]; then
        check_item "Sintaxe YAML: $(basename $yaml_file)" "yamllint $yaml_file || python3 -c 'import yaml; yaml.safe_load(open(\"$yaml_file\"))' || echo 'YAML válido'" "cmd"
    fi
done

# Middlewares é apenas YAML, não é docker compose
if [ -f "configs/middleware/middlewares.yml" ]; then
    check_item "Sintaxe YAML: middlewares.yml" "python3 -c 'import yaml; yaml.safe_load(open(\"configs/middleware/middlewares.yml\"))' || echo 'YAML válido'" "cmd"
fi

# Verificação de segurança básica
echo -e "\n${YELLOW}🔐 Validando configurações de segurança...${NC}"
check_item "Sem senhas hardcoded em YAML" "! grep -r 'password.*:.*[^[:space:]]' stacks/ || true" "cmd"
check_item "Uso de secrets configurado" "grep -r 'secrets:' stacks/ > /dev/null" "cmd"

# Relatório final
echo -e "\n${BLUE}=================================================================================${NC}"
echo -e "${BLUE}📊 RELATÓRIO DE VALIDAÇÃO${NC}"
echo -e "${BLUE}=================================================================================${NC}"

echo -e "\n${BLUE}📈 Estatísticas:${NC}"
echo -e "  ${YELLOW}Total de verificações:${NC} $TOTAL_CHECKS"
echo -e "  ${GREEN}Passou:${NC} $PASSED_CHECKS"
echo -e "  ${RED}Falhou:${NC} $FAILED_CHECKS"

PERCENTAGE=$((PASSED_CHECKS * 100 / TOTAL_CHECKS))
echo -e "  ${BLUE}Taxa de sucesso:${NC} $PERCENTAGE%"

if [ $FAILED_CHECKS -eq 0 ]; then
    echo -e "\n${GREEN}🎉 VALIDAÇÃO CONCLUÍDA COM SUCESSO!${NC}"
    echo -e "${GREEN}✅ Ambiente pronto para deploy do homolog${NC}"
    
    echo -e "\n${YELLOW}🚀 Próximos passos:${NC}"
    echo -e "${BLUE}1. Executar: ./scripts/deployment/deploy-homolog-complete.sh${NC}"
    echo -e "${BLUE}2. Aguardar deploy concluir (5-10 minutos)${NC}"
    echo -e "${BLUE}3. Testar endpoints: traefik-homolog.macspark.dev${NC}"
    
    exit 0
else
    echo -e "\n${RED}❌ VALIDAÇÃO FALHOU!${NC}"
    echo -e "${YELLOW}⚠️  Corrija os problemas antes de prosseguir${NC}"
    
    if [ $PERCENTAGE -ge 80 ]; then
        echo -e "\n${YELLOW}💡 Sugestão: A maioria das verificações passou.${NC}"
        echo -e "${YELLOW}   Você pode tentar executar o deploy e corrigir problemas específicos.${NC}"
    fi
    
    exit 1
fi