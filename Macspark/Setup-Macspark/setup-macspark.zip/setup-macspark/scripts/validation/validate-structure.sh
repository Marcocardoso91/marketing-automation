#!/bin/bash
# VALIDAÇÃO COMPLETA DA ESTRUTURA ENTERPRISE
set -euo pipefail

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}🔍 VALIDAÇÃO ESTRUTURA ENTERPRISE 2025${NC}"

# Validar arquivos essenciais
validate_files() {
    echo -e "${YELLOW}📋 Validando arquivos essenciais...${NC}"

    REQUIRED_FILES=(
        "scripts/install-homolog.sh"
        "scripts/install-production.sh"
        "configs/environments/homolog-optimized.env"
        "configs/environments/production-optimized.env"
        "stacks/traefik/traefik-enterprise-2025.yml"
        "configs/security/security-headers-enterprise-2025.yml"
    )

    for file in "${REQUIRED_FILES[@]}"; do
        if [ -f "$file" ]; then
            echo -e "${GREEN}✅ $file${NC}"
        else
            echo -e "${RED}❌ $file${NC}"
        fi
    done
}

# Validar sintaxe YAML
validate_yaml() {
    echo -e "${YELLOW}🔧 Validando sintaxe YAML...${NC}"

    find stacks/ -name "*.yml" ! -path "*/deprecated/*" -exec docker-compose -f {} config -q \; 2>/dev/null || \
        echo -e "${YELLOW}⚠️ Alguns YAMLs precisam de variáveis de ambiente${NC}"
}

# Validar scripts Bash
validate_bash() {
    echo -e "${YELLOW}🔧 Validando scripts Bash...${NC}"

    find scripts/ -name "*.sh" -exec bash -n {} \; && \
        echo -e "${GREEN}✅ Todos os scripts são válidos${NC}"
}

# Relatório final
generate_report() {
    echo
    echo -e "${BLUE}📊 RELATÓRIO FINAL DA ESTRUTURA${NC}"
    echo -e "${BLUE}═════════════════════════════════════${NC}"

    TOTAL_FILES=$(find . -type f | wc -l)
    YAML_FILES=$(find . -name "*.yml" ! -path "*/deprecated/*" | wc -l)
    SCRIPT_FILES=$(find . -name "*.sh" | wc -l)
    CONFIG_FILES=$(find configs/ -type f 2>/dev/null | wc -l || echo 0)

    echo -e "${GREEN}📁 Total de arquivos: $TOTAL_FILES${NC}"
    echo -e "${GREEN}📄 YAMLs: $YAML_FILES${NC}"
    echo -e "${GREEN}🔧 Scripts: $SCRIPT_FILES${NC}"
    echo -e "${GREEN}⚙️ Configs: $CONFIG_FILES${NC}"

    echo
    echo -e "${GREEN}🎯 ESTRUTURA VALIDADA COM SUCESSO!${NC}"
}

validate_files
validate_yaml
validate_bash
generate_report
