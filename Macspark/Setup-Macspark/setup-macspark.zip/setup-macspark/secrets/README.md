# 🔐 Gerenciamento de Secrets - Setup MacSpark

## 🏗️ Estrutura Organizada

```
secrets/
├── README.md                    # 📖 Esta documentação
├── SECURITY_AUDIT.md           # 🔍 Relatório de auditoria
│
├── docker-secrets/             # 🐳 Docker Secrets
│   ├── create-secrets.sh       # Script para criar secrets
│   ├── rotate-secrets.sh       # Rotação automática
│   └── templates/              # Templates de secrets
│       ├── db_password.txt
│       ├── redis_password.txt
│       └── traefik_password.txt
│
├── vault/                      # 🔒 HashiCorp Vault
│   ├── policies/              # Políticas de acesso
│   ├── scripts/               # Scripts de gestão
│   └── configs/               # Configurações
│
├── certificates/              # 📜 Certificados SSL
│   ├── letsencrypt/          # Let's Encrypt
│   ├── internal/             # Certificados internos
│   └── README.md             # Gestão de certificados
│
├── api-keys/                  # 🔑 Chaves de API
│   ├── .gitkeep
│   └── README.md             # NUNCA commitar chaves reais
│
├── encryption/                # 🔐 Chaves de criptografia
│   ├── backup-keys/          # Chaves de backup
│   ├── age/                  # Age encryption
│   └── gpg/                  # GPG keys
│
├── templates/                 # 📝 Templates existentes
│   └── (templates para secrets)
│
└── examples/                  # 📚 Exemplos existentes
    └── (exemplos de uso)
```

## 🚨 Regras de Segurança

### NUNCA Fazer
- ❌ **NUNCA** commitar secrets reais no Git
- ❌ **NUNCA** hardcode passwords em scripts
- ❌ **NUNCA** usar secrets em plain text
- ❌ **NUNCA** compartilhar secrets por email/chat
- ❌ **NUNCA** reutilizar secrets entre ambientes

### SEMPRE Fazer
- ✅ **SEMPRE** usar Docker Secrets ou Vault
- ✅ **SEMPRE** rotacionar secrets periodicamente
- ✅ **SEMPRE** criptografar secrets em repouso
- ✅ **SEMPRE** auditar acesso a secrets
- ✅ **SEMPRE** usar secrets únicos por serviço

## 🔧 Gestão de Secrets

### 1. Docker Secrets (Recomendado para Swarm)

```bash
# Criar secret
echo "senha_super_segura" | docker secret create db_password -

# Usar em stack
services:
  app:
    secrets:
      - db_password
secrets:
  db_password:
    external: true
```

### 2. Variáveis de Ambiente (Desenvolvimento apenas)

```bash
# .env.example (template)
DB_PASSWORD=change_me_in_production
REDIS_PASSWORD=change_me_in_production

# .env (real - NUNCA commitar)
DB_PASSWORD=senha_real_super_segura
REDIS_PASSWORD=outra_senha_segura
```

### 3. HashiCorp Vault (Enterprise)

```bash
# Armazenar secret
vault kv put secret/macspark/db password="senha_segura"

# Recuperar secret
vault kv get -field=password secret/macspark/db
```

## 📊 Secrets por Serviço

| Serviço | Secret Type | Método | Rotação |
|---------|------------|---------|----------|
| PostgreSQL | Database Password | Docker Secret | 90 dias |
| Redis | Cache Password | Docker Secret | 90 dias |
| Traefik | Dashboard Auth | Docker Secret | 30 dias |
| N8N | Encryption Key | Vault | 180 dias |
| Vault | Unseal Keys | Offline | Manual |
| Backup | Encryption Key | Age/GPG | Anual |
| API Keys | Various | Vault | Variável |
| JWT | Signing Key | Vault | 90 dias |

## 🔄 Rotação de Secrets

### Automática (Recomendada)
```bash
# Executar rotação programada
./docker-secrets/rotate-secrets.sh --all

# Rotação específica
./docker-secrets/rotate-secrets.sh --service postgresql
```

### Manual
```bash
# 1. Gerar novo secret
openssl rand -base64 32 > new_password.txt

# 2. Criar novo secret no Docker
docker secret create db_password_v2 new_password.txt

# 3. Atualizar stack
docker service update --secret-rm db_password --secret-add db_password_v2 app

# 4. Remover secret antigo
docker secret rm db_password
```

## 🔍 Auditoria de Segurança

### Verificação Rápida
```bash
# Buscar secrets expostos
./scripts/security/audit-secrets.sh

# Verificar permissões
find secrets/ -type f -exec ls -la {} \;

# Buscar hardcoded passwords
grep -r "password=" --include="*.sh" scripts/
```

### Checklist de Segurança
- [ ] Nenhum secret real no repositório
- [ ] .gitignore configurado corretamente
- [ ] Secrets criptografados em repouso
- [ ] Rotação automática configurada
- [ ] Audit logs habilitados
- [ ] Backup de secrets seguro
- [ ] Recovery procedure documentado

## 🚀 Quick Start

### 1. Inicializar Secrets
```bash
# Criar todos os secrets necessários
./docker-secrets/create-secrets.sh --init
```

### 2. Verificar Configuração
```bash
# Listar secrets criados
docker secret ls

# Verificar integridade
./scripts/security/verify-secrets.sh
```

### 3. Deploy com Secrets
```bash
# Deploy stack com secrets
docker stack deploy -c stack.yml app
```

## 🆘 Troubleshooting

### Secret não encontrado
```bash
# Verificar se secret existe
docker secret ls | grep secret_name

# Recriar se necessário
echo "novo_valor" | docker secret create secret_name -
```

### Permissão negada
```bash
# Verificar permissões
ls -la /run/secrets/

# Ajustar no compose
secrets:
  my_secret:
    uid: '1000'
    gid: '1000'
    mode: 0400
```

### Rotação falhou
```bash
# Verificar logs
docker service logs app

# Rollback manual
docker service update --rollback app
```

## 📚 Melhores Práticas

### 1. Princípio do Menor Privilégio
- Cada serviço acessa apenas seus próprios secrets
- Permissões mínimas necessárias (400 para arquivos)
- Segregação por ambiente

### 2. Defense in Depth
- Múltiplas camadas de proteção
- Criptografia em repouso e trânsito
- Monitoramento de acesso

### 3. Zero Trust
- Verificar sempre a origem
- Autenticar todas as requisições
- Nunca assumir segurança

### 4. Compliance
- GDPR: Proteção de dados pessoais
- PCI-DSS: Segurança de cartões
- SOC 2: Controles de segurança
- ISO 27001: Gestão de segurança

## 🔐 Vault Integration

### Setup Inicial
```bash
# Inicializar Vault
vault operator init -key-shares=5 -key-threshold=3

# Unseal Vault
vault operator unseal $KEY1
vault operator unseal $KEY2
vault operator unseal $KEY3

# Login
vault login $ROOT_TOKEN
```

### Políticas de Acesso
```hcl
# policy.hcl
path "secret/data/macspark/*" {
  capabilities = ["read", "list"]
}

path "secret/metadata/macspark/*" {
  capabilities = ["list"]
}
```

## 📊 Monitoramento

### Métricas
- Tempo desde última rotação
- Número de acessos por secret
- Falhas de autenticação
- Secrets expirados

### Alertas
- Secret próximo da expiração
- Múltiplas falhas de acesso
- Secret não rotacionado
- Acesso não autorizado

## 🔄 Backup de Secrets

### Estratégia
1. **Vault**: Backup automático do storage backend
2. **Docker Secrets**: Export criptografado
3. **Certificates**: Backup antes da renovação
4. **Recovery Keys**: Armazenamento offline seguro

### Comando de Backup
```bash
# Backup completo de secrets
./scripts/backup/backup-secrets.sh --encrypt --offsite
```

## 📝 Documentação Adicional

- [Docker Secrets Documentation](https://docs.docker.com/engine/swarm/secrets/)
- [HashiCorp Vault Best Practices](https://learn.hashicorp.com/tutorials/vault/pattern-centralized-secrets)
- [OWASP Secret Management](https://cheatsheetseries.owasp.org/cheatsheets/Secrets_Management_Cheat_Sheet.html)
- [12 Factor App - Config](https://12factor.net/config)

---

**⚠️ ATENÇÃO**: Este diretório contém informações sensíveis. Mantenha seguro e NUNCA commitar secrets reais!