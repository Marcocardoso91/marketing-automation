#!/bin/bash
# 🔐 Script para criação segura de Docker Secrets
# Setup MacSpark - Enterprise Security

set -euo pipefail

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configurações
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TEMPLATES_DIR="${SCRIPT_DIR}/templates"
SECRETS_LIST="${SCRIPT_DIR}/secrets.list"
LOG_FILE="/var/log/macspark-secrets-$(date +%Y%m%d-%H%M%S).log"

# Função de logging
log() {
    echo -e "${1}" | tee -a "${LOG_FILE}"
}

# Função para gerar senha segura
generate_password() {
    local length="${1:-32}"
    openssl rand -base64 "$length" | tr -d '\n'
}

# Função para criar secret
create_secret() {
    local name="$1"
    local value="$2"
    local force="${3:-false}"
    
    # Verificar se secret já existe
    if docker secret ls --format "{{.Name}}" | grep -q "^${name}$"; then
        if [ "$force" = "true" ]; then
            log "${YELLOW}⚠️  Secret ${name} já existe. Pulando...${NC}"
            return 0
        else
            log "${RED}❌ Secret ${name} já existe. Use --force para sobrescrever${NC}"
            return 1
        fi
    fi
    
    # Criar secret
    echo -n "$value" | docker secret create "${name}" - > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        log "${GREEN}✅ Secret ${name} criado com sucesso${NC}"
        return 0
    else
        log "${RED}❌ Falha ao criar secret ${name}${NC}"
        return 1
    fi
}

# Função para criar secrets do banco de dados
create_database_secrets() {
    log "${BLUE}📊 Criando secrets do banco de dados...${NC}"
    
    # PostgreSQL
    create_secret "postgres_password" "$(generate_password 32)"
    create_secret "postgres_user" "postgres"
    create_secret "postgres_db" "macspark"
    
    # PostgreSQL Replicação
    create_secret "postgres_replication_password" "$(generate_password 32)"
    create_secret "postgres_replication_user" "replicator"
    
    # Redis
    create_secret "redis_password" "$(generate_password 32)"
    create_secret "redis_maxmemory" "2gb"
}

# Função para criar secrets de aplicações
create_application_secrets() {
    log "${BLUE}🚀 Criando secrets de aplicações...${NC}"
    
    # N8N
    create_secret "n8n_encryption_key" "$(generate_password 32)"
    create_secret "n8n_db_password" "$(generate_password 32)"
    create_secret "n8n_jwt_secret" "$(generate_password 64)"
    
    # Chatwoot
    create_secret "chatwoot_secret_key" "$(generate_password 64)"
    create_secret "chatwoot_db_password" "$(generate_password 32)"
    
    # BookStack
    create_secret "bookstack_app_key" "base64:$(generate_password 32)"
    create_secret "bookstack_db_password" "$(generate_password 32)"
    
    # RocketChat
    create_secret "rocketchat_mongo_password" "$(generate_password 32)"
    create_secret "rocketchat_admin_password" "$(generate_password 32)"
    
    # Nextcloud
    create_secret "nextcloud_admin_password" "$(generate_password 32)"
    create_secret "nextcloud_db_password" "$(generate_password 32)"
    
    # Code Server
    create_secret "code_server_password" "$(generate_password 16)"
}

# Função para criar secrets do Traefik
create_traefik_secrets() {
    log "${BLUE}🌐 Criando secrets do Traefik...${NC}"
    
    # Dashboard auth
    local traefik_password="$(generate_password 16)"
    local traefik_hash=$(htpasswd -nb admin "$traefik_password" | sed -e 's/\$/\$\$/g')
    
    create_secret "traefik_dashboard_auth" "$traefik_hash"
    
    # Salvar senha em local seguro (temporário)
    echo "Traefik Dashboard Password: $traefik_password" > /tmp/traefik_password.txt
    chmod 600 /tmp/traefik_password.txt
    log "${YELLOW}⚠️  Senha do Traefik salva em /tmp/traefik_password.txt${NC}"
    
    # Certificados (placeholder)
    create_secret "traefik_cert" "placeholder_cert"
    create_secret "traefik_key" "placeholder_key"
}

# Função para criar secrets de monitoramento
create_monitoring_secrets() {
    log "${BLUE}📊 Criando secrets de monitoramento...${NC}"
    
    # Grafana
    create_secret "grafana_admin_password" "$(generate_password 16)"
    create_secret "grafana_secret_key" "$(generate_password 32)"
    
    # Prometheus
    create_secret "prometheus_admin_password" "$(generate_password 16)"
    
    # Loki
    create_secret "loki_s3_secret_key" "$(generate_password 32)"
}

# Função para criar secrets de backup
create_backup_secrets() {
    log "${BLUE}💾 Criando secrets de backup...${NC}"
    
    # Kopia
    create_secret "kopia_repository_password" "$(generate_password 32)"
    create_secret "kopia_server_password" "$(generate_password 32)"
    
    # Restic
    create_secret "restic_repository_password" "$(generate_password 32)"
    
    # S3 (se usar)
    create_secret "backup_s3_access_key" "placeholder_access_key"
    create_secret "backup_s3_secret_key" "placeholder_secret_key"
    
    # Encryption
    create_secret "backup_encryption_key" "$(generate_password 64)"
}

# Função para criar secrets do Vault
create_vault_secrets() {
    log "${BLUE}🔒 Criando secrets do Vault...${NC}"
    
    # Vault root token (GUARDAR COM SEGURANÇA!)
    local vault_root_token="$(generate_password 32)"
    create_secret "vault_root_token" "$vault_root_token"
    
    # Salvar em local seguro
    echo "Vault Root Token: $vault_root_token" > /tmp/vault_root_token.txt
    chmod 600 /tmp/vault_root_token.txt
    log "${YELLOW}⚠️  Vault root token salvo em /tmp/vault_root_token.txt${NC}"
    
    # Vault unseal keys (serão geradas na inicialização)
    create_secret "vault_unseal_key_1" "placeholder"
    create_secret "vault_unseal_key_2" "placeholder"
    create_secret "vault_unseal_key_3" "placeholder"
}

# Função para verificar secrets criados
verify_secrets() {
    log "${BLUE}🔍 Verificando secrets criados...${NC}"
    
    local total=$(docker secret ls --format "{{.Name}}" | wc -l)
    log "${GREEN}✅ Total de secrets criados: $total${NC}"
    
    # Listar todos os secrets
    docker secret ls --format "table {{.Name}}\t{{.CreatedAt}}"
}

# Função para exportar lista de secrets
export_secrets_list() {
    log "${BLUE}📄 Exportando lista de secrets...${NC}"
    
    docker secret ls --format "{{.Name}}" > "${SECRETS_LIST}"
    log "${GREEN}✅ Lista exportada para ${SECRETS_LIST}${NC}"
}

# Função principal
main() {
    log "${BLUE}═══════════════════════════════════════════════════════${NC}"
    log "${BLUE}       🔐 MacSpark - Criação de Docker Secrets 🔐       ${NC}"
    log "${BLUE}═══════════════════════════════════════════════════════${NC}"
    
    # Verificar se está rodando como root
    if [ "$EUID" -ne 0 ]; then
        log "${RED}❌ Este script precisa ser executado como root${NC}"
        exit 1
    fi
    
    # Verificar se Docker está rodando
    if ! docker info > /dev/null 2>&1; then
        log "${RED}❌ Docker não está rodando ou não está acessível${NC}"
        exit 1
    fi
    
    # Verificar se é Swarm manager
    if ! docker node ls > /dev/null 2>&1; then
        log "${RED}❌ Este node não é um Swarm manager${NC}"
        exit 1
    fi
    
    # Parse argumentos
    FORCE=false
    INIT=false
    
    while [[ $# -gt 0 ]]; do
        case $1 in
            --force)
                FORCE=true
                shift
                ;;
            --init)
                INIT=true
                shift
                ;;
            --help)
                echo "Uso: $0 [--init] [--force]"
                echo "  --init   Criar todos os secrets necessários"
                echo "  --force  Sobrescrever secrets existentes"
                exit 0
                ;;
            *)
                log "${RED}❌ Argumento desconhecido: $1${NC}"
                exit 1
                ;;
        esac
    done
    
    if [ "$INIT" = true ]; then
        log "${YELLOW}⚠️  Modo de inicialização - Criando todos os secrets${NC}"
        
        # Criar todos os secrets
        create_database_secrets
        create_application_secrets
        create_traefik_secrets
        create_monitoring_secrets
        create_backup_secrets
        create_vault_secrets
        
        # Verificar e exportar
        verify_secrets
        export_secrets_list
        
        log "${GREEN}✨ Inicialização completa!${NC}"
        log "${YELLOW}⚠️  IMPORTANTE: Salve as senhas de /tmp/ em local seguro e delete os arquivos${NC}"
    else
        log "${BLUE}Use --init para criar todos os secrets necessários${NC}"
        verify_secrets
    fi
    
    log "${BLUE}═══════════════════════════════════════════════════════${NC}"
    log "${GREEN}✅ Processo finalizado. Logs salvos em: ${LOG_FILE}${NC}"
}

# Executar
main "$@"