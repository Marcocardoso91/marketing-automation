#!/bin/bash
# 🔄 Script de Rotação Automática de Docker Secrets
# Setup MacSpark - Enterprise Security

set -euo pipefail

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configurações
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROTATION_LOG="/var/log/macspark-rotation-$(date +%Y%m%d-%H%M%S).log"
ROTATION_CONFIG="${SCRIPT_DIR}/rotation-config.yml"

# Função de logging
log() {
    echo -e "${1}" | tee -a "${ROTATION_LOG}"
}

# Função para gerar senha segura
generate_password() {
    local length="${1:-32}"
    openssl rand -base64 "$length" | tr -d '\n'
}

# Função para fazer backup do secret atual
backup_secret() {
    local secret_name="$1"
    local backup_name="${secret_name}_backup_$(date +%Y%m%d_%H%M%S)"
    
    # Criar backup (apenas metadata, não o valor)
    docker secret ls --filter "name=${secret_name}" --format "{{.Name}},{{.CreatedAt}}" > "/tmp/${backup_name}.meta"
    
    log "${BLUE}📦 Backup metadata do secret ${secret_name} criado${NC}"
}

# Função para rotacionar secret
rotate_secret() {
    local secret_name="$1"
    local service_name="$2"
    local new_value="${3:-$(generate_password 32)}"
    
    log "${BLUE}🔄 Rotacionando secret: ${secret_name}${NC}"
    
    # Fazer backup
    backup_secret "$secret_name"
    
    # Criar novo secret com versão
    local new_secret_name="${secret_name}_v$(date +%Y%m%d_%H%M%S)"
    echo -n "$new_value" | docker secret create "$new_secret_name" - > /dev/null 2>&1
    
    if [ $? -eq 0 ]; then
        log "${GREEN}✅ Novo secret ${new_secret_name} criado${NC}"
        
        # Atualizar serviço
        if [ -n "$service_name" ]; then
            docker service update \
                --secret-rm "$secret_name" \
                --secret-add "source=${new_secret_name},target=${secret_name}" \
                "$service_name" > /dev/null 2>&1
            
            if [ $? -eq 0 ]; then
                log "${GREEN}✅ Serviço ${service_name} atualizado com novo secret${NC}"
                
                # Aguardar rollout
                log "${BLUE}⏳ Aguardando rollout do serviço...${NC}"
                docker service update --detach=false "$service_name" > /dev/null 2>&1
                
                # Remover secret antigo (após sucesso)
                docker secret rm "$secret_name" > /dev/null 2>&1
                log "${GREEN}✅ Secret antigo removido${NC}"
            else
                log "${RED}❌ Falha ao atualizar serviço ${service_name}${NC}"
                # Rollback - remover novo secret
                docker secret rm "$new_secret_name" > /dev/null 2>&1
                return 1
            fi
        fi
    else
        log "${RED}❌ Falha ao criar novo secret${NC}"
        return 1
    fi
}

# Função para rotacionar secrets de database
rotate_database_secrets() {
    log "${BLUE}📊 Rotacionando secrets de database...${NC}"
    
    # PostgreSQL
    rotate_secret "postgres_password" "postgres_master" "$(generate_password 32)"
    rotate_secret "postgres_replication_password" "postgres_replica" "$(generate_password 32)"
    
    # Redis
    rotate_secret "redis_password" "redis_master" "$(generate_password 32)"
}

# Função para rotacionar secrets de aplicações
rotate_application_secrets() {
    log "${BLUE}🚀 Rotacionando secrets de aplicações...${NC}"
    
    # N8N
    rotate_secret "n8n_jwt_secret" "n8n_app" "$(generate_password 64)"
    
    # Chatwoot
    rotate_secret "chatwoot_secret_key" "chatwoot_web" "$(generate_password 64)"
    
    # Grafana
    rotate_secret "grafana_secret_key" "grafana" "$(generate_password 32)"
}

# Função para validar rotação
validate_rotation() {
    local service_name="$1"
    
    log "${BLUE}🔍 Validando rotação do serviço ${service_name}...${NC}"
    
    # Verificar se serviço está healthy
    local replicas=$(docker service ls --filter "name=${service_name}" --format "{{.Replicas}}")
    
    if [[ "$replicas" == *"/"* ]]; then
        local current=$(echo "$replicas" | cut -d'/' -f1)
        local desired=$(echo "$replicas" | cut -d'/' -f2)
        
        if [ "$current" -eq "$desired" ]; then
            log "${GREEN}✅ Serviço ${service_name} está healthy (${replicas})${NC}"
            return 0
        else
            log "${YELLOW}⚠️  Serviço ${service_name} ainda convergindo (${replicas})${NC}"
            return 1
        fi
    else
        log "${RED}❌ Não foi possível verificar status do serviço${NC}"
        return 1
    fi
}

# Função para rotação agendada
scheduled_rotation() {
    local rotation_policy="$1"
    
    case "$rotation_policy" in
        "daily")
            rotate_application_secrets
            ;;
        "weekly")
            rotate_database_secrets
            rotate_application_secrets
            ;;
        "monthly")
            rotate_database_secrets
            rotate_application_secrets
            rotate_monitoring_secrets
            ;;
        *)
            log "${RED}❌ Política de rotação desconhecida: ${rotation_policy}${NC}"
            return 1
            ;;
    esac
}

# Função para notificar sobre rotação
notify_rotation() {
    local status="$1"
    local details="$2"
    
    # Enviar notificação (implementar integração com Slack/Email/etc)
    cat <<EOF >> "${ROTATION_LOG}"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Notificação de Rotação de Secrets
Status: ${status}
Data: $(date)
Detalhes: ${details}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EOF
}

# Função para rotação de emergência
emergency_rotation() {
    log "${RED}🚨 ROTAÇÃO DE EMERGÊNCIA INICIADA 🚨${NC}"
    
    # Rotacionar TODOS os secrets críticos
    rotate_database_secrets
    rotate_application_secrets
    
    # Notificar equipe
    notify_rotation "EMERGÊNCIA" "Rotação de emergência executada"
    
    log "${YELLOW}⚠️  Rotação de emergência completa. Verifique todos os serviços!${NC}"
}

# Função principal
main() {
    log "${BLUE}═══════════════════════════════════════════════════════${NC}"
    log "${BLUE}       🔄 MacSpark - Rotação de Docker Secrets 🔄       ${NC}"
    log "${BLUE}═══════════════════════════════════════════════════════${NC}"
    
    # Verificar se está rodando como root
    if [ "$EUID" -ne 0 ]; then
        log "${RED}❌ Este script precisa ser executado como root${NC}"
        exit 1
    fi
    
    # Parse argumentos
    ACTION="manual"
    SERVICE=""
    
    while [[ $# -gt 0 ]]; do
        case $1 in
            --all)
                ACTION="all"
                shift
                ;;
            --service)
                ACTION="service"
                SERVICE="$2"
                shift 2
                ;;
            --scheduled)
                ACTION="scheduled"
                POLICY="$2"
                shift 2
                ;;
            --emergency)
                ACTION="emergency"
                shift
                ;;
            --help)
                cat <<EOF
Uso: $0 [opções]

Opções:
  --all                Rotacionar todos os secrets
  --service <nome>     Rotacionar secrets de um serviço específico
  --scheduled <policy> Rotação agendada (daily/weekly/monthly)
  --emergency          Rotação de emergência de todos os secrets
  --help              Mostrar esta ajuda

Exemplos:
  $0 --all                      # Rotacionar todos os secrets
  $0 --service postgresql       # Rotacionar secrets do PostgreSQL
  $0 --scheduled weekly         # Rotação semanal agendada
  $0 --emergency               # Rotação de emergência
EOF
                exit 0
                ;;
            *)
                log "${RED}❌ Argumento desconhecido: $1${NC}"
                exit 1
                ;;
        esac
    done
    
    # Executar ação
    case "$ACTION" in
        "all")
            log "${BLUE}📋 Rotacionando todos os secrets...${NC}"
            rotate_database_secrets
            rotate_application_secrets
            notify_rotation "SUCESSO" "Todos os secrets rotacionados"
            ;;
        "service")
            if [ -z "$SERVICE" ]; then
                log "${RED}❌ Nome do serviço não especificado${NC}"
                exit 1
            fi
            log "${BLUE}📋 Rotacionando secrets do serviço ${SERVICE}...${NC}"
            # Implementar lógica específica por serviço
            case "$SERVICE" in
                "postgresql"|"postgres")
                    rotate_secret "postgres_password" "postgres_master"
                    ;;
                "redis")
                    rotate_secret "redis_password" "redis_master"
                    ;;
                "n8n")
                    rotate_secret "n8n_jwt_secret" "n8n_app"
                    ;;
                *)
                    log "${RED}❌ Serviço desconhecido: ${SERVICE}${NC}"
                    exit 1
                    ;;
            esac
            notify_rotation "SUCESSO" "Secrets do ${SERVICE} rotacionados"
            ;;
        "scheduled")
            log "${BLUE}📅 Executando rotação agendada (${POLICY})...${NC}"
            scheduled_rotation "$POLICY"
            notify_rotation "AGENDADO" "Rotação ${POLICY} executada"
            ;;
        "emergency")
            emergency_rotation
            ;;
        "manual")
            log "${BLUE}ℹ️  Modo manual. Use --help para ver opções disponíveis${NC}"
            ;;
    esac
    
    log "${BLUE}═══════════════════════════════════════════════════════${NC}"
    log "${GREEN}✅ Rotação finalizada. Logs em: ${ROTATION_LOG}${NC}"
}

# Executar
main "$@"