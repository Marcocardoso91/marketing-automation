#!/bin/bash
# 🛡️ Docker Security Hardening Script
# MacSpark Enterprise - Container Security

set -euo pipefail

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configurações
SCRIPT_NAME="Docker Security Hardening"
LOG_FILE="/var/log/docker-hardening-$(date +%Y%m%d-%H%M%S).log"
DOCKER_DIR="/etc/docker"
AUDIT_RULES="/etc/audit/rules.d/docker.rules"

# Função de logging
log() {
    echo -e "${1}" | tee -a "${LOG_FILE}"
}

# Verificar se está rodando como root
check_root() {
    if [ "$EUID" -ne 0 ]; then
        log "${RED}❌ Este script precisa ser executado como root${NC}"
        exit 1
    fi
}

# 1. Configurar Docker Daemon Security
configure_daemon_security() {
    log "${BLUE}🔧 Configurando Docker Daemon Security...${NC}"
    
    # Criar daemon.json seguro
    cat > ${DOCKER_DIR}/daemon.json <<EOF
{
  "icc": false,
  "log-level": "info",
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3",
    "labels": "production"
  },
  "storage-driver": "overlay2",
  "userland-proxy": false,
  "default-ulimits": {
    "nofile": {
      "Hard": 64000,
      "Soft": 64000
    }
  },
  "live-restore": true,
  "no-new-privileges": true,
  "seccomp-profile": "/etc/docker/seccomp.json",
  "userns-remap": "default",
  "experimental": false,
  "features": {
    "buildkit": true
  },
  "metrics-addr": "127.0.0.1:9323",
  "experimental-metrics": true,
  "authorization-plugins": ["authz-plugin"],
  "selinux-enabled": true,
  "default-runtime": "runc",
  "runtimes": {
    "runsc": {
      "path": "/usr/bin/runsc"
    }
  }
}
EOF
    
    log "${GREEN}✅ daemon.json configurado${NC}"
}

# 2. Configurar AppArmor/SELinux
configure_mandatory_access_control() {
    log "${BLUE}🔧 Configurando Mandatory Access Control...${NC}"
    
    # Verificar se AppArmor está disponível
    if command -v aa-status &> /dev/null; then
        log "${CYAN}  Configurando AppArmor...${NC}"
        
        # Criar perfil AppArmor para Docker
        cat > /etc/apparmor.d/docker-default <<EOF
#include <tunables/global>

profile docker-default flags=(attach_disconnected,mediate_deleted) {
  #include <abstractions/base>
  
  network inet tcp,
  network inet udp,
  network inet icmp,
  
  deny network raw,
  deny network packet,
  
  file,
  
  deny /proc/sys/** wklx,
  deny /proc/fs/** wklx,
  deny /sys/firmware/** rwklx,
  deny /sys/kernel/** rwklx,
  
  deny /proc/* w,
  deny /sys/* w,
  
  deny mount,
  deny umount,
  deny pivot_root,
}
EOF
        
        # Carregar perfil
        apparmor_parser -r /etc/apparmor.d/docker-default
        log "${GREEN}✅ AppArmor configurado${NC}"
        
    # Verificar se SELinux está disponível
    elif command -v getenforce &> /dev/null; then
        log "${CYAN}  Configurando SELinux...${NC}"
        
        # Habilitar SELinux para Docker
        semanage boolean -m --on docker_connect_any
        semanage boolean -m --on docker_transition_unconfined
        
        log "${GREEN}✅ SELinux configurado${NC}"
    else
        log "${YELLOW}⚠️  Nenhum MAC disponível (AppArmor/SELinux)${NC}"
    fi
}

# 3. Configurar Seccomp Profile
configure_seccomp() {
    log "${BLUE}🔧 Configurando Seccomp Profile...${NC}"
    
    # Criar seccomp profile restritivo
    cat > ${DOCKER_DIR}/seccomp.json <<'EOF'
{
  "defaultAction": "SCMP_ACT_ERRNO",
  "defaultErrnoRet": 1,
  "archMap": [
    {
      "architecture": "SCMP_ARCH_X86_64",
      "subArchitectures": [
        "SCMP_ARCH_X86",
        "SCMP_ARCH_X32"
      ]
    }
  ],
  "syscalls": [
    {
      "names": [
        "accept",
        "accept4",
        "access",
        "arch_prctl",
        "bind",
        "brk",
        "capget",
        "capset",
        "chdir",
        "chmod",
        "chown",
        "clock_gettime",
        "clone",
        "close",
        "connect",
        "dup",
        "dup2",
        "epoll_create",
        "epoll_ctl",
        "epoll_wait",
        "execve",
        "exit",
        "exit_group",
        "fcntl",
        "fstat",
        "fstatfs",
        "futex",
        "getcwd",
        "getdents64",
        "getegid",
        "geteuid",
        "getgid",
        "getpid",
        "getppid",
        "getrlimit",
        "getsockname",
        "getsockopt",
        "gettid",
        "getuid",
        "ioctl",
        "kill",
        "listen",
        "lseek",
        "madvise",
        "memfd_create",
        "mkdir",
        "mmap",
        "mount",
        "mprotect",
        "munmap",
        "nanosleep",
        "open",
        "openat",
        "pipe",
        "poll",
        "prctl",
        "pread64",
        "prlimit64",
        "pwrite64",
        "read",
        "readlink",
        "recvfrom",
        "recvmsg",
        "rename",
        "restart_syscall",
        "rmdir",
        "rt_sigaction",
        "rt_sigprocmask",
        "rt_sigreturn",
        "sched_getaffinity",
        "sched_yield",
        "select",
        "sendmsg",
        "sendto",
        "set_robust_list",
        "setgid",
        "setgroups",
        "setrlimit",
        "setsockopt",
        "setuid",
        "shutdown",
        "sigaltstack",
        "socket",
        "stat",
        "statfs",
        "tgkill",
        "umask",
        "uname",
        "unlink",
        "wait4",
        "write"
      ],
      "action": "SCMP_ACT_ALLOW"
    }
  ]
}
EOF
    
    log "${GREEN}✅ Seccomp profile configurado${NC}"
}

# 4. Configurar User Namespace Remapping
configure_user_namespace() {
    log "${BLUE}🔧 Configurando User Namespace Remapping...${NC}"
    
    # Criar usuário para remapping
    if ! id -u dockremap &>/dev/null; then
        useradd -r -s /bin/false dockremap
    fi
    
    # Configurar subuid e subgid
    echo "dockremap:100000:65536" > /etc/subuid
    echo "dockremap:100000:65536" > /etc/subgid
    
    log "${GREEN}✅ User namespace configurado${NC}"
}

# 5. Configurar Audit Rules
configure_audit() {
    log "${BLUE}🔧 Configurando Audit Rules...${NC}"
    
    # Instalar auditd se necessário
    if ! command -v auditd &> /dev/null; then
        apt-get update && apt-get install -y auditd
    fi
    
    # Criar regras de audit para Docker
    cat > ${AUDIT_RULES} <<EOF
# Docker audit rules
-w /usr/bin/docker -p wa -k docker
-w /var/lib/docker -p wa -k docker
-w /etc/docker -p wa -k docker
-w /usr/lib/systemd/system/docker.service -p wa -k docker
-w /usr/lib/systemd/system/docker.socket -p wa -k docker
-w /etc/docker/daemon.json -p wa -k docker
-w /usr/bin/docker-containerd -p wa -k docker
-w /usr/bin/docker-runc -p wa -k docker
-w /usr/bin/dockerd -p wa -k docker
-w /etc/sysconfig/docker -p wa -k docker
-w /etc/sysconfig/docker-network -p wa -k docker
-w /etc/sysconfig/docker-registry -p wa -k docker
-w /etc/sysconfig/docker-storage -p wa -k docker
-w /etc/sysconfig/docker-storage-setup -p wa -k docker
EOF
    
    # Recarregar regras
    augenrules --load
    systemctl restart auditd
    
    log "${GREEN}✅ Audit rules configuradas${NC}"
}

# 6. Configurar Content Trust
configure_content_trust() {
    log "${BLUE}🔧 Configurando Docker Content Trust...${NC}"
    
    # Habilitar Content Trust globalmente
    echo "export DOCKER_CONTENT_TRUST=1" >> /etc/profile.d/docker-trust.sh
    echo "export DOCKER_CONTENT_TRUST_SERVER=https://notary.docker.io" >> /etc/profile.d/docker-trust.sh
    
    chmod +x /etc/profile.d/docker-trust.sh
    
    log "${GREEN}✅ Content Trust configurado${NC}"
}

# 7. Limitar recursos do container
configure_resource_limits() {
    log "${BLUE}🔧 Configurando Resource Limits...${NC}"
    
    # Criar arquivo de configuração de limites
    cat > ${DOCKER_DIR}/container-limits.conf <<EOF
# Limites padrão para containers
--memory="512m"
--memory-swap="1g"
--cpu-shares="512"
--cpus="0.5"
--pids-limit="100"
--ulimit nofile=1024:2048
--ulimit nproc=32:64
EOF
    
    log "${GREEN}✅ Resource limits configurados${NC}"
}

# 8. Configurar Network Security
configure_network_security() {
    log "${BLUE}🔧 Configurando Network Security...${NC}"
    
    # Desabilitar bridge padrão
    iptables -N DOCKER-ISOLATION
    iptables -A DOCKER-ISOLATION -j DROP
    
    # Configurar regras de firewall
    cat > /etc/iptables/docker-rules.v4 <<EOF
# Docker Security Rules
*filter
:DOCKER-USER - [0:0]
:DOCKER-ISOLATION - [0:0]

# Block all inter-container communication by default
-A DOCKER-USER -j DOCKER-ISOLATION

# Allow only specific ports
-A DOCKER-USER -p tcp -m tcp --dport 443 -j ACCEPT
-A DOCKER-USER -p tcp -m tcp --dport 80 -j ACCEPT
-A DOCKER-USER -j DROP

COMMIT
EOF
    
    # Aplicar regras
    iptables-restore < /etc/iptables/docker-rules.v4
    
    log "${GREEN}✅ Network security configurada${NC}"
}

# 9. Configurar Registry Security
configure_registry_security() {
    log "${BLUE}🔧 Configurando Registry Security...${NC}"
    
    # Configurar registries permitidos
    cat > ${DOCKER_DIR}/policy.json <<EOF
{
  "default": [
    {
      "type": "reject"
    }
  ],
  "transports": {
    "docker": {
      "docker.io": [
        {
          "type": "signedBy",
          "keyType": "GPGKeys",
          "keyPath": "/etc/docker/keys/"
        }
      ],
      "registry.macspark.dev": [
        {
          "type": "insecureAcceptAnything"
        }
      ]
    }
  }
}
EOF
    
    # Criar diretório de chaves
    mkdir -p /etc/docker/keys
    
    log "${GREEN}✅ Registry security configurada${NC}"
}

# 10. Scan de vulnerabilidades
install_vulnerability_scanner() {
    log "${BLUE}🔧 Instalando Vulnerability Scanner...${NC}"
    
    # Instalar Trivy
    wget -qO - https://aquasecurity.github.io/trivy-repo/deb/public.key | apt-key add -
    echo "deb https://aquasecurity.github.io/trivy-repo/deb $(lsb_release -sc) main" | tee -a /etc/apt/sources.list.d/trivy.list
    apt-get update && apt-get install -y trivy
    
    # Criar script de scan automático
    cat > /usr/local/bin/docker-scan-image.sh <<'EOF'
#!/bin/bash
IMAGE=$1
trivy image --severity CRITICAL,HIGH --no-progress --quiet --exit-code 1 $IMAGE
if [ $? -ne 0 ]; then
    echo "❌ Vulnerabilidades encontradas em $IMAGE"
    exit 1
fi
echo "✅ Imagem $IMAGE está segura"
EOF
    
    chmod +x /usr/local/bin/docker-scan-image.sh
    
    log "${GREEN}✅ Vulnerability scanner instalado${NC}"
}

# 11. Configurar Docker Bench Security
install_docker_bench() {
    log "${BLUE}🔧 Instalando Docker Bench Security...${NC}"
    
    # Clone Docker Bench
    git clone https://github.com/docker/docker-bench-security.git /opt/docker-bench-security
    
    # Criar script de execução
    cat > /usr/local/bin/docker-security-check.sh <<'EOF'
#!/bin/bash
cd /opt/docker-bench-security
./docker-bench-security.sh -l /var/log/docker-bench.log
EOF
    
    chmod +x /usr/local/bin/docker-security-check.sh
    
    # Adicionar ao cron para execução diária
    echo "0 2 * * * root /usr/local/bin/docker-security-check.sh" >> /etc/crontab
    
    log "${GREEN}✅ Docker Bench Security instalado${NC}"
}

# 12. Aplicar hardening em containers existentes
harden_existing_containers() {
    log "${BLUE}🔧 Aplicando hardening em containers existentes...${NC}"
    
    # Listar todos os containers
    for container in $(docker ps -q); do
        log "${CYAN}  Hardening container: $container${NC}"
        
        # Aplicar read-only root filesystem onde possível
        docker update --read-only $container 2>/dev/null || true
        
        # Limitar recursos
        docker update \
            --memory="512m" \
            --memory-swap="1g" \
            --cpu-shares="512" \
            --pids-limit="100" \
            $container 2>/dev/null || true
    done
    
    log "${GREEN}✅ Containers existentes hardenizados${NC}"
}

# Verificação final
verify_hardening() {
    log "${BLUE}🔍 Verificando hardening aplicado...${NC}"
    
    local issues=0
    
    # Verificar daemon.json
    if [ -f ${DOCKER_DIR}/daemon.json ]; then
        log "${GREEN}  ✅ daemon.json configurado${NC}"
    else
        log "${RED}  ❌ daemon.json não encontrado${NC}"
        ((issues++))
    fi
    
    # Verificar audit
    if systemctl is-active auditd >/dev/null 2>&1; then
        log "${GREEN}  ✅ Auditd ativo${NC}"
    else
        log "${YELLOW}  ⚠️  Auditd não está ativo${NC}"
        ((issues++))
    fi
    
    # Verificar Content Trust
    if [ -f /etc/profile.d/docker-trust.sh ]; then
        log "${GREEN}  ✅ Content Trust configurado${NC}"
    else
        log "${YELLOW}  ⚠️  Content Trust não configurado${NC}"
        ((issues++))
    fi
    
    # Verificar Trivy
    if command -v trivy &> /dev/null; then
        log "${GREEN}  ✅ Trivy instalado${NC}"
    else
        log "${YELLOW}  ⚠️  Trivy não instalado${NC}"
        ((issues++))
    fi
    
    if [ $issues -eq 0 ]; then
        log "${GREEN}✨ Docker totalmente hardenizado!${NC}"
        return 0
    else
        log "${YELLOW}⚠️  $issues problemas encontrados${NC}"
        return 1
    fi
}

# Função principal
main() {
    log "${BLUE}═══════════════════════════════════════════════════════${NC}"
    log "${BLUE}        🛡️ Docker Security Hardening Script 🛡️         ${NC}"
    log "${BLUE}═══════════════════════════════════════════════════════${NC}"
    
    check_root
    
    # Executar hardening
    configure_daemon_security
    configure_mandatory_access_control
    configure_seccomp
    configure_user_namespace
    configure_audit
    configure_content_trust
    configure_resource_limits
    configure_network_security
    configure_registry_security
    install_vulnerability_scanner
    install_docker_bench
    harden_existing_containers
    
    # Restart Docker para aplicar mudanças
    log "${BLUE}🔄 Reiniciando Docker...${NC}"
    systemctl restart docker
    sleep 5
    
    # Verificar
    verify_hardening
    
    log "${BLUE}═══════════════════════════════════════════════════════${NC}"
    log "${GREEN}✅ Docker Security Hardening completo!${NC}"
    log "${CYAN}📋 Logs salvos em: ${LOG_FILE}${NC}"
    
    # Executar Docker Bench como verificação final
    log "${BLUE}🔍 Executando Docker Bench Security...${NC}"
    /usr/local/bin/docker-security-check.sh
}

# Executar
main "$@"