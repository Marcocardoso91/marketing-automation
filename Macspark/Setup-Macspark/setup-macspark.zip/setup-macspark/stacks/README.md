# MacSpark Docker Stacks - Estrutura Organizada

## Visão Geral

Esta estrutura organiza mais de 60 serviços enterprise em categorias lógicas para facilitar o gerenciamento, deploy e manutenção da infraestrutura MacSpark.

## Estrutura de Diretórios

```
stacks/
├── core/                    # Serviços essenciais da infraestrutura
│   ├── database/           # Databases consolidados (PostgreSQL HA, Redis Sentinel)
│   ├── monitoring/         # Observabilidade (OpenTelemetry, Prometheus)
│   ├── networking/         # Configurações de rede
│   └── traefik/           # Proxy reverso e load balancer
├── applications/           # Aplicações de negócio
│   ├── ai/                # IA e automação (Ollama, MCP, SparkOne)
│   ├── communication/     # Comunicação (Chatwoot, Jitsi, RocketChat)
│   ├── development/       # Desenvolvimento (Code Server, Portainer)
│   ├── media/             # Serviços de mídia
│   └── productivity/      # Produtividade (N8N, BookStack, Nextcloud)
├── infrastructure/        # Infraestrutura de suporte
│   ├── automation/        # Automação e CI/CD
│   ├── backup/           # Backup e recovery (Restic)
│   ├── logging/          # Logging centralizado
│   ├── registry/         # Docker registries (Harbor)
│   ├── security/         # Segurança (Vault, VaultWarden)
│   ├── service-mesh/     # Service Mesh (Istio, Consul Connect)
│   └── storage/          # Storage (MinIO)
├── archive/              # Versões antigas e arquivos obsoletos
├── deprecated/           # Stacks descontinuados
├── examples/             # Exemplos e templates
└── experimental/         # Recursos em teste
```

## Core Services (Essenciais)

### Database
- **postgresql.yml**: Cluster PostgreSQL HA com master-replica, PgBouncer, backup e monitoring
- **redis.yml**: Redis Sentinel HA com 3 sentinels, 2 replicas, backup e metrics

### Monitoring  
- **opentelemetry.yml**: Stack completo OpenTelemetry com Jaeger, Tempo, span metrics
- **prometheus.yml**: Prometheus HA com AlertManager, Node Exporter, cAdvisor

### Traefik
- **traefik-production.yml**: Proxy reverso para produção com SSL automático
- **traefik-homolog.yml**: Ambiente de homologação
- **middlewares.yml**: Middlewares centralizados (rate limiting, auth, etc.)

## Applications (Negócio)

### AI & Automation
- **ollama.yml**: LLMs locais para IA
- **mcp-orchestrator.yml**: Orquestrador MCP para múltiplos agentes
- **sparkone.yml**: Agente IA principal MacSpark

### Communication
- **chatwoot.yml**: Customer support platform
- **jitsi.yml**: Video conferencing
- **rocketchat.yml**: Team chat platform
- **communication.yml**: Stack integrado de comunicação

### Development
- **portainer.yml**: Interface web Docker Swarm
- **code-server.yml**: IDE web VSCode

### Productivity
- **n8n.yml**: Workflow automation
- **bookstack.yml**: Wiki e documentação
- **nextcloud.yml**: File storage e colaboração
- **evolution-api.yml**: WhatsApp Business integration

## Infrastructure (Suporte)

### Service Mesh
- **consul-connect.yml**: Service mesh leve para Docker Swarm (RECOMENDADO)
- **istio.yml**: Service mesh avançado para casos complexos

### Security
- **vault-stack.yml**: HashiCorp Vault para secrets management
- **vaultwarden.yml**: Password manager empresarial

### Backup & Storage
- **restic.yml**: Backup incremental criptografado
- **minio-enterprise.yml**: Object storage S3-compatible
- **harbor.yml**: Docker registry enterprise

## Comandos de Deploy

### Deploy por Categoria

```bash
# Core services (ordem de dependência)
docker stack deploy -c stacks/core/database/postgresql.yml postgres
docker stack deploy -c stacks/core/database/redis.yml redis  
docker stack deploy -c stacks/core/monitoring/prometheus.yml monitoring
docker stack deploy -c stacks/core/monitoring/opentelemetry.yml observability

# Applications
docker stack deploy -c stacks/applications/ai/ollama.yml ollama
docker stack deploy -c stacks/applications/productivity/n8n.yml n8n
docker stack deploy -c stacks/applications/communication/chatwoot.yml chatwoot

# Infrastructure  
docker stack deploy -c stacks/infrastructure/service-mesh/consul-connect.yml consul
docker stack deploy -c stacks/infrastructure/backup/restic.yml backup
```

### Deploy Ambiente Completo

```bash
# Script de deploy automatizado
./scripts/deploy/deploy-production.sh

# Deploy de homologação
./scripts/deploy/deploy-homolog.sh
```

## Dependências entre Stacks

```mermaid
graph TD
    A[Traefik] --> B[PostgreSQL]
    A --> C[Redis]
    B --> D[Applications]
    C --> D
    E[Prometheus] --> F[OpenTelemetry]
    G[Consul Connect] --> D
    H[Vault] --> B
    H --> C
```

### Ordem de Deploy Recomendada

1. **Networks**: Criar redes overlay
2. **Secrets**: Configurar Docker secrets  
3. **Traefik**: Proxy reverso
4. **Databases**: PostgreSQL + Redis
5. **Monitoring**: Prometheus + OpenTelemetry
6. **Service Mesh**: Consul Connect
7. **Applications**: Por prioridade de negócio
8. **Infrastructure**: Backup, security, storage

## Ambientes

### Produção
- Prefixo: Sem prefixo ou `-prod`
- Domínio: `*.macspark.dev`
- HA: Ativado
- Resources: Produção

### Homologação  
- Prefixo: `-homolog`
- Domínio: `*-homolog.macspark.dev`
- HA: Reduzido
- Resources: Desenvolvimento

## Manutenção

### Limpeza de Arquivos
- **archive/**: Versões antigas mantidas para referência
- **deprecated/**: Remover após 6 meses sem uso
- **experimental/**: Revisar mensalmente

### Atualizações
- **Core**: Processo rigoroso com testes
- **Applications**: Podem ser atualizadas independentemente  
- **Infrastructure**: Coordenar com equipe

## Troubleshooting

### Logs Centralizados
```bash
# Logs de stack específico
docker service logs -f <stack>_<service>

# Logs agregados no Grafana
https://grafana.macspark.dev/explore
```

### Health Checks
```bash
# Status de todos os serviços
docker service ls

# Health check específico
docker service inspect <service> --format '{{.UpdateStatus.State}}'
```

### Monitoramento
- **Grafana**: https://grafana.macspark.dev
- **Prometheus**: https://prometheus.macspark.dev  
- **Jaeger**: https://jaeger.macspark.dev
- **Consul**: https://consul.macspark.dev

## Roadmap 2025

### Q1: Consolidação (COMPLETO ✅)
- [x] PostgreSQL HA consolidado  
- [x] Redis Sentinel HA
- [x] OpenTelemetry distributed tracing
- [x] Service mesh evaluation

### Q2: Service Mesh
- [ ] Deploy Consul Connect produção
- [ ] Migração gradual service discovery
- [ ] mTLS automático

### Q3: Observabilidade Avançada  
- [ ] Service maps automáticos
- [ ] SLI/SLO monitoring
- [ ] Chaos engineering

### Q4: Multi-cloud
- [ ] Avaliação Kubernetes
- [ ] Disaster recovery cross-region
- [ ] Cost optimization

---

**Mantido por**: MacSpark Infrastructure Team  
**Última atualização**: Janeiro 2025  
**Versão**: 2.0 - Estrutura Enterprise Consolidada