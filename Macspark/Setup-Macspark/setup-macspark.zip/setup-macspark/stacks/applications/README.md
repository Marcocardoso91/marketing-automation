# applications Stacks

## Serviços disponíveis:

ai - agente-ultimate
ai - ai
ai - mcp-container
ai - mcp-orchestrator-ha
ai - mcp-orchestrator
ai - ollama
ai - sparkone
communication - chatwoot
communication - communication
communication - jitsi
communication - rocketchat
development - code-server
development - gitlab-ce-complete
development - portainer
productivity - automation-best-practices
productivity - automation-enterprise
productivity - bookstack
productivity - evolution-api
productivity - heimdall-pro
productivity - n8n
productivity - nextcloud

## Deploy:

```bash
docker stack deploy -c [arquivo].yml [nome-do-stack]
```

## Configuração:

1. Criar secrets necessários
2. Ajustar variáveis de ambiente
3. Verificar redes
4. Deploy do stack
