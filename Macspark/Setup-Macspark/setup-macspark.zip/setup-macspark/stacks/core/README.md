# core Stacks

## Serviços disponíveis:

database - postgresql
database - redis
monitoring - alert-rules
monitoring - alertmanager-simple
monitoring - alertmanager
monitoring - distributed-tracing
monitoring - jaeger
monitoring - loki
monitoring - monitoring-stack
monitoring - netdata
monitoring - opentelemetry
monitoring - prometheus-modern
monitoring - prometheus
monitoring - promtail
traefik - middlewares
traefik - traefik-dev
traefik - traefik-enterprise-2025
traefik - traefik-production
traefik - traefik

## Deploy:

```bash
docker stack deploy -c [arquivo].yml [nome-do-stack]
```

## Configuração:

1. Criar secrets necessários
2. Ajustar variáveis de ambiente
3. Verificar redes
4. Deploy do stack
