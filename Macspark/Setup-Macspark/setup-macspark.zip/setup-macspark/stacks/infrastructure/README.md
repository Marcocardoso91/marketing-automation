# infrastructure Stacks

## Serviços disponíveis:

automation - automation-orchestration-complete
automation - jenkins-enterprise
backup - backup-enterprise-complete
backup - backup-enterprise-stack
backup - restic
communication - notification-hub-complete
compliance - compliance-governance-complete
database - database-management
gateway - kong-enterprise
monitoring - lgtm-stack
multi-cloud - multi-cloud-edge-complete
performance - performance-2025
performance - redis-cluster
registry - docker-registry
registry - harbor
security - cyber-monitor
security - vault-stack
security - vaultwarden
security - vulnerability-scanner
service-mesh - consul-connect
service-mesh - istio-security-stack
service-mesh - istio
storage - minio-enterprise

## Deploy:

```bash
docker stack deploy -c [arquivo].yml [nome-do-stack]
```

## Configuração:

1. Criar secrets necessários
2. Ajustar variáveis de ambiente
3. Verificar redes
4. Deploy do stack
