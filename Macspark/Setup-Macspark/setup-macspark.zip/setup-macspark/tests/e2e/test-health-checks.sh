#!/bin/bash

# Teste E2E de Health Checks
# Valida saúde de todos os serviços críticos

set -euo pipefail

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Configurações
HEALTHY_SERVICES=0
UNHEALTHY_SERVICES=0
WARNING_SERVICES=0

echo "================================================"
echo "      Health Check E2E - Macspark              "
echo "================================================"
echo ""

# Função para verificar health de serviço Docker
check_docker_service_health() {
    local service_name="$1"
    local expected_replicas="${2:-1}"
    
    echo -n "  $service_name: "
    
    if ! docker service ls | grep -q "$service_name"; then
        echo -e "${YELLOW}NÃO ENCONTRADO${NC}"
        WARNING_SERVICES=$((WARNING_SERVICES + 1))
        return 1
    fi
    
    local running_replicas=$(docker service ls --format "table {{.Name}}\t{{.Replicas}}" | grep "$service_name" | awk '{print $2}' | cut -d'/' -f1)
    local total_replicas=$(docker service ls --format "table {{.Name}}\t{{.Replicas}}" | grep "$service_name" | awk '{print $2}' | cut -d'/' -f2)
    
    if [ "$running_replicas" = "$total_replicas" ] && [ "$running_replicas" = "$expected_replicas" ]; then
        echo -e "${GREEN}✓ HEALTHY${NC} ($running_replicas/$total_replicas réplicas)"
        HEALTHY_SERVICES=$((HEALTHY_SERVICES + 1))
    else
        echo -e "${RED}✗ UNHEALTHY${NC} ($running_replicas/$total_replicas réplicas)"
        UNHEALTHY_SERVICES=$((UNHEALTHY_SERVICES + 1))
    fi
}

# Função para verificar health via HTTP
check_http_health() {
    local url="$1"
    local service_name="$2"
    local expected_code="${3:-200}"
    
    echo -n "  $service_name: "
    
    local response_code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 "$url" 2>/dev/null || echo "000")
    
    if [ "$response_code" = "$expected_code" ]; then
        echo -e "${GREEN}✓ HEALTHY${NC} (HTTP $response_code)"
        HEALTHY_SERVICES=$((HEALTHY_SERVICES + 1))
    elif [ "$response_code" = "000" ]; then
        echo -e "${RED}✗ TIMEOUT${NC}"
        UNHEALTHY_SERVICES=$((UNHEALTHY_SERVICES + 1))
    else
        echo -e "${YELLOW}⚠ WARNING${NC} (HTTP $response_code)"
        WARNING_SERVICES=$((WARNING_SERVICES + 1))
    fi
}

# Função para verificar processos do sistema
check_system_process() {
    local process_name="$1"
    local service_name="$2"
    
    echo -n "  $service_name: "
    
    if pgrep -f "$process_name" > /dev/null 2>&1; then
        local count=$(pgrep -f "$process_name" | wc -l)
        echo -e "${GREEN}✓ RUNNING${NC} ($count processos)"
        HEALTHY_SERVICES=$((HEALTHY_SERVICES + 1))
    else
        echo -e "${RED}✗ NOT RUNNING${NC}"
        UNHEALTHY_SERVICES=$((UNHEALTHY_SERVICES + 1))
    fi
}

# Função para verificar uso de recursos
check_resource_usage() {
    echo -e "${CYAN}=== Uso de Recursos ===${NC}"
    
    # CPU
    local cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1 2>/dev/null || echo "N/A")
    echo -n "  CPU: "
    if [ "$cpu_usage" != "N/A" ]; then
        if (( $(echo "$cpu_usage < 80" | bc -l 2>/dev/null || echo 0) )); then
            echo -e "${GREEN}$cpu_usage%${NC}"
        else
            echo -e "${YELLOW}$cpu_usage% (Alto)${NC}"
        fi
    else
        echo "N/A"
    fi
    
    # Memória
    local mem_usage=$(free | grep Mem | awk '{print int($3/$2 * 100)}' 2>/dev/null || echo "N/A")
    echo -n "  Memória: "
    if [ "$mem_usage" != "N/A" ]; then
        if [ "$mem_usage" -lt 80 ]; then
            echo -e "${GREEN}$mem_usage%${NC}"
        else
            echo -e "${YELLOW}$mem_usage% (Alto)${NC}"
        fi
    else
        echo "N/A"
    fi
    
    # Disco
    local disk_usage=$(df -h / | awk 'NR==2 {print $5}' | cut -d'%' -f1 2>/dev/null || echo "N/A")
    echo -n "  Disco: "
    if [ "$disk_usage" != "N/A" ]; then
        if [ "$disk_usage" -lt 80 ]; then
            echo -e "${GREEN}$disk_usage%${NC}"
        else
            echo -e "${YELLOW}$disk_usage% (Alto)${NC}"
        fi
    else
        echo "N/A"
    fi
    
    echo ""
}

# Função para verificar conectividade de banco de dados
check_database_health() {
    echo -e "${CYAN}=== Bancos de Dados ===${NC}"
    
    # PostgreSQL
    echo -n "  PostgreSQL: "
    if command -v psql &> /dev/null; then
        if PGPASSWORD=${POSTGRES_PASSWORD:-postgres} psql -h localhost -U postgres -c "SELECT 1" >/dev/null 2>&1; then
            echo -e "${GREEN}✓ CONECTADO${NC}"
            HEALTHY_SERVICES=$((HEALTHY_SERVICES + 1))
        else
            echo -e "${RED}✗ DESCONECTADO${NC}"
            UNHEALTHY_SERVICES=$((UNHEALTHY_SERVICES + 1))
        fi
    else
        echo -e "${YELLOW}psql não instalado${NC}"
        WARNING_SERVICES=$((WARNING_SERVICES + 1))
    fi
    
    # Redis
    echo -n "  Redis: "
    if command -v redis-cli &> /dev/null; then
        if redis-cli ping >/dev/null 2>&1; then
            echo -e "${GREEN}✓ RESPONDENDO${NC}"
            HEALTHY_SERVICES=$((HEALTHY_SERVICES + 1))
        else
            echo -e "${RED}✗ NÃO RESPONDE${NC}"
            UNHEALTHY_SERVICES=$((UNHEALTHY_SERVICES + 1))
        fi
    else
        echo -e "${YELLOW}redis-cli não instalado${NC}"
        WARNING_SERVICES=$((WARNING_SERVICES + 1))
    fi
    
    echo ""
}

# Executar verificações
echo "Iniciando verificação de saúde completa..."
echo ""

# 1. Verificar serviços Docker Swarm
echo -e "${CYAN}=== Serviços Docker Swarm ===${NC}"
if docker info | grep -q "Swarm: active"; then
    check_docker_service_health "traefik" 1
    check_docker_service_health "portainer" 1
    check_docker_service_health "prometheus" 1
    check_docker_service_health "grafana" 1
    check_docker_service_health "loki" 1
    check_docker_service_health "postgres" 1
    check_docker_service_health "redis" 1
else
    echo -e "${YELLOW}  Docker Swarm não está ativo${NC}"
fi
echo ""

# 2. Verificar endpoints HTTP
echo -e "${CYAN}=== Endpoints HTTP ===${NC}"
check_http_health "http://localhost/health" "Traefik Health" "200"
check_http_health "http://localhost:9090/-/healthy" "Prometheus" "200"
check_http_health "http://localhost:3000/api/health" "Grafana" "200"
check_http_health "http://localhost:9093/-/healthy" "Alertmanager" "200"
check_http_health "http://localhost:3100/ready" "Loki" "200"
echo ""

# 3. Verificar processos do sistema
echo -e "${CYAN}=== Processos do Sistema ===${NC}"
check_system_process "dockerd" "Docker Daemon"
check_system_process "containerd" "Containerd"
echo ""

# 4. Verificar bancos de dados
check_database_health

# 5. Verificar uso de recursos
check_resource_usage

# 6. Verificar certificados SSL
echo -e "${CYAN}=== Certificados SSL ===${NC}"
echo -n "  Let's Encrypt: "
if [ -d "/etc/letsencrypt/live" ]; then
    cert_count=$(find /etc/letsencrypt/live -name "cert.pem" 2>/dev/null | wc -l)
    if [ "$cert_count" -gt 0 ]; then
        echo -e "${GREEN}✓ $cert_count certificados${NC}"
    else
        echo -e "${YELLOW}⚠ Nenhum certificado encontrado${NC}"
    fi
else
    echo -e "${YELLOW}Diretório não encontrado${NC}"
fi
echo ""

# Resumo
echo "================================================"
echo "              RESUMO HEALTH CHECK               "
echo "================================================"
echo -e "Serviços saudáveis:  ${GREEN}$HEALTHY_SERVICES${NC}"
echo -e "Serviços com falha:  ${RED}$UNHEALTHY_SERVICES${NC}"
echo -e "Avisos:              ${YELLOW}$WARNING_SERVICES${NC}"

# Calcular status geral
if [ $UNHEALTHY_SERVICES -eq 0 ]; then
    if [ $WARNING_SERVICES -eq 0 ]; then
        echo ""
        echo -e "${GREEN}✓ Sistema completamente saudável!${NC}"
        exit 0
    else
        echo ""
        echo -e "${YELLOW}⚠ Sistema operacional com avisos${NC}"
        exit 0
    fi
else
    echo ""
    echo -e "${RED}✗ Sistema com problemas críticos${NC}"
    echo "  Execute './scripts/maintenance/troubleshoot.sh' para diagnóstico"
    exit 1
fi