#!/bin/bash

# ============================================================================
# TESTES DE INTEGRAÇÃO - DEPLOYMENT
# ============================================================================
# Testes automatizados para validar deployment completo
# Executa após deploy para garantir que todos os serviços estão funcionais
# ============================================================================

set -euo pipefail

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configurações
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
TEST_TIMEOUT=30
TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS=0

# Logging
log() {
    local level=$1; shift
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    case $level in
        "INFO") echo -e "${BLUE}[INFO]${NC} [$timestamp] $*" ;;
        "PASS") echo -e "${GREEN}[PASS]${NC} [$timestamp] $*"; ((PASSED_TESTS++)) ;;
        "FAIL") echo -e "${RED}[FAIL]${NC} [$timestamp] $*"; ((FAILED_TESTS++)) ;;
        "WARN") echo -e "${YELLOW}[WARN]${NC} [$timestamp] $*" ;;
    esac
    ((TOTAL_TESTS++))
}

# Teste: Docker Swarm ativo
test_docker_swarm() {
    log "INFO" "🔧 Testando Docker Swarm..."
    
    if docker info 2>/dev/null | grep -q "Swarm: active"; then
        log "PASS" "Docker Swarm está ativo"
        return 0
    else
        log "FAIL" "Docker Swarm não está ativo"
        return 1
    fi
}

# Teste: Redes overlay criadas
test_overlay_networks() {
    log "INFO" "🌐 Testando redes overlay..."
    
    local expected_networks=("core-network" "monitoring" "data-internal")
    local networks_ok=0
    
    for network in "${expected_networks[@]}"; do
        if docker network ls | grep -q "$network"; then
            log "PASS" "Rede '$network' existe"
            ((networks_ok++))
        else
            log "FAIL" "Rede '$network' não encontrada"
        fi
    done
    
    if [ $networks_ok -eq ${#expected_networks[@]} ]; then
        return 0
    else
        return 1
    fi
}

# Teste: Secrets do Docker criados
test_docker_secrets() {
    log "INFO" "🔐 Testando Docker secrets..."
    
    local expected_secrets=("postgres_password" "redis_password" "jwt_secret" "traefik_auth")
    local secrets_ok=0
    
    for secret in "${expected_secrets[@]}"; do
        if docker secret ls | grep -q "$secret"; then
            log "PASS" "Secret '$secret' existe"
            ((secrets_ok++))
        else
            log "FAIL" "Secret '$secret' não encontrado"
        fi
    done
    
    if [ $secrets_ok -eq ${#expected_secrets[@]} ]; then
        return 0
    else
        return 1
    fi
}

# Teste: Serviços essenciais rodando
test_core_services() {
    log "INFO" "⚙️  Testando serviços essenciais..."
    
    local core_services=("traefik" "postgres" "redis")
    local services_ok=0
    
    for service in "${core_services[@]}"; do
        # Procurar serviço com nome que contenha o padrão
        local service_count=$(docker service ls --filter name="$service" --format "{{.Name}}" | wc -l)
        
        if [ $service_count -gt 0 ]; then
            local service_replicas=$(docker service ls --filter name="$service" --format "{{.Replicas}}" | head -1)
            if [[ "$service_replicas" =~ ^[1-9]/[1-9] ]]; then
                log "PASS" "Serviço '$service' está rodando ($service_replicas)"
                ((services_ok++))
            else
                log "FAIL" "Serviço '$service' não está saudável ($service_replicas)"
            fi
        else
            log "FAIL" "Serviço '$service' não encontrado"
        fi
    done
    
    if [ $services_ok -eq ${#core_services[@]} ]; then
        return 0
    else
        return 1
    fi
}

# Teste: Health checks dos serviços
test_service_health() {
    log "INFO" "🏥 Testando health checks..."
    
    local unhealthy_services=0
    
    # Listar todos os serviços e verificar health
    while IFS= read -r service; do
        local replicas=$(docker service ls --filter name="$service" --format "{{.Replicas}}")
        
        if [[ "$replicas" =~ ^0/ ]]; then
            log "FAIL" "Serviço '$service' não tem replicas ativas ($replicas)"
            ((unhealthy_services++))
        elif [[ "$replicas" =~ ^[1-9]+/[1-9]+ ]]; then
            local current=$(echo "$replicas" | cut -d'/' -f1)
            local desired=$(echo "$replicas" | cut -d'/' -f2)
            
            if [ "$current" -eq "$desired" ]; then
                log "PASS" "Serviço '$service' saudável ($replicas)"
            else
                log "WARN" "Serviço '$service' convergindo ($replicas)"
            fi
        fi
        
    done < <(docker service ls --format "{{.Name}}" 2>/dev/null)
    
    if [ $unhealthy_services -eq 0 ]; then
        return 0
    else
        return 1
    fi
}

# Teste: Conectividade de rede interna
test_internal_connectivity() {
    log "INFO" "🔗 Testando conectividade interna..."
    
    # Testar se containers conseguem resolver DNS internos
    if docker run --rm --network core-network alpine:latest nslookup traefik >/dev/null 2>&1; then
        log "PASS" "DNS interno funcionando"
        return 0
    else
        log "FAIL" "DNS interno com problemas"
        return 1
    fi
}

# Teste: Volumes persistentes
test_persistent_volumes() {
    log "INFO" "💾 Testando volumes persistentes..."
    
    local expected_volumes=("postgres_data" "redis_data" "traefik_certs")
    local volumes_ok=0
    
    for volume in "${expected_volumes[@]}"; do
        if docker volume ls | grep -q "$volume"; then
            log "PASS" "Volume '$volume' existe"
            ((volumes_ok++))
        else
            log "WARN" "Volume '$volume' não encontrado (pode ser normal)"
        fi
    done
    
    # Aceitar se pelo menos 1 volume existir
    if [ $volumes_ok -gt 0 ]; then
        return 0
    else
        return 1
    fi
}

# Teste: Portas expostas
test_exposed_ports() {
    log "INFO" "🚪 Testando portas expostas..."
    
    local exposed_ports=(80 443)
    local ports_ok=0
    
    for port in "${exposed_ports[@]}"; do
        if netstat -tuln 2>/dev/null | grep -q ":$port "; then
            log "PASS" "Porta $port está escutando"
            ((ports_ok++))
        else
            log "FAIL" "Porta $port não está escutando"
        fi
    done
    
    if [ $ports_ok -eq ${#exposed_ports[@]} ]; then
        return 0
    else
        return 1
    fi
}

# Teste: Recursos do sistema
test_system_resources() {
    log "INFO" "📊 Testando recursos do sistema..."
    
    # RAM disponível
    local free_ram=$(free -m | awk '/^Mem:/ {print $7}')
    if [ $free_ram -gt 512 ]; then
        log "PASS" "RAM disponível: ${free_ram}MB"
    else
        log "WARN" "RAM baixa: ${free_ram}MB"
    fi
    
    # Disk disponível
    local free_disk=$(df / | awk 'NR==2 {print int($4/1024)}')
    if [ $free_disk -gt 1024 ]; then
        log "PASS" "Disk disponível: ${free_disk}MB"
    else
        log "WARN" "Disk baixo: ${free_disk}MB"
    fi
    
    # Load average
    local load_avg=$(uptime | grep -oE 'load average: [0-9.]+' | cut -d' ' -f3 | cut -d',' -f1)
    local load_int=$(echo "$load_avg" | cut -d'.' -f1)
    local cpu_cores=$(nproc)
    
    if [ $load_int -lt $cpu_cores ]; then
        log "PASS" "Load average: $load_avg (${cpu_cores} cores)"
        return 0
    else
        log "WARN" "Load alto: $load_avg (${cpu_cores} cores)"
        return 1
    fi
}

# Teste: Logs dos serviços
test_service_logs() {
    log "INFO" "📝 Testando logs dos serviços..."
    
    local services_with_errors=0
    
    # Verificar erros recentes nos logs
    while IFS= read -r service; do
        local error_count=$(docker service logs --tail 50 "$service" 2>/dev/null | grep -ci "error\|failed\|exception" || echo "0")
        
        if [ $error_count -gt 10 ]; then
            log "WARN" "Serviço '$service' tem muitos erros nos logs ($error_count)"
            ((services_with_errors++))
        else
            log "PASS" "Serviço '$service' logs limpos ($error_count erros)"
        fi
        
    done < <(docker service ls --format "{{.Name}}" 2>/dev/null | head -5)  # Limitar a 5 para não demorar
    
    if [ $services_with_errors -lt 2 ]; then
        return 0
    else
        return 1
    fi
}

# Relatório final
generate_report() {
    echo ""
    echo -e "${BLUE}=========================================="
    echo "       RELATÓRIO DE TESTES"
    echo "==========================================${NC}"
    echo ""
    echo "📊 **RESUMO:**"
    echo "   Total de testes: $TOTAL_TESTS"
    echo "   ✅ Passou: $PASSED_TESTS"
    echo "   ❌ Falhou: $FAILED_TESTS"
    echo "   📈 Taxa de sucesso: $(( PASSED_TESTS * 100 / TOTAL_TESTS ))%"
    echo ""
    
    if [ $FAILED_TESTS -eq 0 ]; then
        echo -e "${GREEN}🎉 TODOS OS TESTES PASSARAM!"
        echo "   ✅ Sistema está funcionando corretamente"
        echo "   ✅ Deploy foi bem-sucedido${NC}"
        return 0
    elif [ $FAILED_TESTS -lt 3 ]; then
        echo -e "${YELLOW}⚠️  ALGUNS TESTES FALHARAM"
        echo "   🔍 Sistema pode estar funcional mas precisa atenção"
        echo "   💡 Revisar logs dos serviços que falharam${NC}"
        return 1
    else
        echo -e "${RED}❌ MUITOS TESTES FALHARAM"
        echo "   🚨 Sistema pode não estar funcionando corretamente"
        echo "   💡 Revisar deployment e corrigir problemas${NC}"
        return 2
    fi
}

# Main
main() {
    echo -e "${BLUE}"
    echo "=========================================="
    echo "    TESTES DE INTEGRAÇÃO - DEPLOYMENT"
    echo "=========================================="
    echo "🧪 Validando funcionalidade pós-deploy"
    echo "⏱️  Timeout por teste: ${TEST_TIMEOUT}s"
    echo "=========================================="
    echo -e "${NC}"
    
    # Lista de testes a executar
    local tests=(
        "test_docker_swarm"
        "test_overlay_networks"
        "test_docker_secrets"
        "test_core_services"
        "test_service_health"
        "test_internal_connectivity"
        "test_persistent_volumes"
        "test_exposed_ports"
        "test_system_resources"
        "test_service_logs"
    )
    
    # Executar cada teste
    for test in "${tests[@]}"; do
        echo ""
        timeout $TEST_TIMEOUT $test || log "FAIL" "Teste '$test' falhou ou excedeu timeout"
    done
    
    # Gerar relatório final
    generate_report
}

# Executar
main "$@"