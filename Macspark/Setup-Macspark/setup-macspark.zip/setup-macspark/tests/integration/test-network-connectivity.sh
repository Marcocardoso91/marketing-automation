#!/bin/bash

# Teste de Conectividade de Rede
# Valida conectividade entre serviços e redes Docker

set -euo pipefail

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configurações
TIMEOUT=5
TESTS_PASSED=0
TESTS_FAILED=0

echo "================================================"
echo "     Teste de Conectividade - Macspark         "
echo "================================================"
echo ""

# Função para testar conectividade
test_connection() {
    local service="$1"
    local port="$2"
    local description="$3"
    
    echo -n "Testando $description ($service:$port)... "
    
    if timeout $TIMEOUT bash -c "echo > /dev/tcp/$service/$port" 2>/dev/null; then
        echo -e "${GREEN}✓ OK${NC}"
        TESTS_PASSED=$((TESTS_PASSED + 1))
        return 0
    else
        echo -e "${RED}✗ FALHOU${NC}"
        TESTS_FAILED=$((TESTS_FAILED + 1))
        return 1
    fi
}

# Função para testar redes Docker
test_docker_networks() {
    echo -e "${BLUE}=== Testando Redes Docker ===${NC}"
    
    local networks=("proxy" "internal" "monitoring" "database")
    
    for network in "${networks[@]}"; do
        echo -n "Verificando rede '$network'... "
        if docker network ls | grep -q "$network"; then
            echo -e "${GREEN}✓ Existe${NC}"
            TESTS_PASSED=$((TESTS_PASSED + 1))
        else
            echo -e "${YELLOW}⚠ Não encontrada${NC}"
            TESTS_FAILED=$((TESTS_FAILED + 1))
        fi
    done
    echo ""
}

# Função para testar serviços Docker
test_docker_services() {
    echo -e "${BLUE}=== Testando Serviços Docker ===${NC}"
    
    if docker info | grep -q "Swarm: active"; then
        echo -e "${GREEN}✓ Docker Swarm ativo${NC}"
        
        # Lista serviços em execução
        local services=$(docker service ls --format "{{.Name}}" 2>/dev/null)
        
        if [ -n "$services" ]; then
            echo "Serviços encontrados:"
            echo "$services" | head -5
            echo "..."
        else
            echo -e "${YELLOW}⚠ Nenhum serviço Docker Swarm em execução${NC}"
        fi
    else
        echo -e "${YELLOW}⚠ Docker Swarm não está ativo${NC}"
    fi
    echo ""
}

# Função para testar endpoints HTTP
test_http_endpoints() {
    echo -e "${BLUE}=== Testando Endpoints HTTP ===${NC}"
    
    local endpoints=(
        "localhost:80:Traefik HTTP"
        "localhost:443:Traefik HTTPS"
        "localhost:8080:Traefik Dashboard"
        "localhost:9090:Prometheus"
        "localhost:3000:Grafana"
        "localhost:9093:Alertmanager"
        "localhost:5432:PostgreSQL"
        "localhost:6379:Redis"
    )
    
    for endpoint in "${endpoints[@]}"; do
        IFS=':' read -r host port desc <<< "$endpoint"
        test_connection "$host" "$port" "$desc" || true
    done
    echo ""
}

# Função para testar DNS
test_dns_resolution() {
    echo -e "${BLUE}=== Testando Resolução DNS ===${NC}"
    
    local domains=(
        "macspark.dev"
        "traefik.macspark.dev"
        "grafana.macspark.dev"
        "portainer.macspark.dev"
    )
    
    for domain in "${domains[@]}"; do
        echo -n "Resolvendo $domain... "
        if nslookup "$domain" >/dev/null 2>&1 || host "$domain" >/dev/null 2>&1; then
            echo -e "${GREEN}✓ OK${NC}"
            TESTS_PASSED=$((TESTS_PASSED + 1))
        else
            echo -e "${YELLOW}⚠ Não resolvido${NC}"
            TESTS_FAILED=$((TESTS_FAILED + 1))
        fi
    done
    echo ""
}

# Função para testar conectividade externa
test_external_connectivity() {
    echo -e "${BLUE}=== Testando Conectividade Externa ===${NC}"
    
    local sites=(
        "8.8.8.8:DNS Google"
        "1.1.1.1:DNS Cloudflare"
        "github.com:GitHub"
        "docker.com:Docker Hub"
    )
    
    for site in "${sites[@]}"; do
        IFS=':' read -r host desc <<< "$site"
        echo -n "Ping para $desc ($host)... "
        if ping -c 1 -W 2 "$host" >/dev/null 2>&1; then
            echo -e "${GREEN}✓ OK${NC}"
            TESTS_PASSED=$((TESTS_PASSED + 1))
        else
            echo -e "${RED}✗ FALHOU${NC}"
            TESTS_FAILED=$((TESTS_FAILED + 1))
        fi
    done
    echo ""
}

# Executar todos os testes
echo "Iniciando testes de conectividade..."
echo ""

test_docker_networks
test_docker_services
test_http_endpoints
test_dns_resolution
test_external_connectivity

# Resumo
echo "================================================"
echo "                   RESUMO                      "
echo "================================================"
echo -e "Testes bem-sucedidos: ${GREEN}$TESTS_PASSED${NC}"
echo -e "Testes falhados:      ${RED}$TESTS_FAILED${NC}"

if [ $TESTS_FAILED -eq 0 ]; then
    echo ""
    echo -e "${GREEN}✓ Todos os testes de conectividade passaram!${NC}"
    exit 0
else
    echo ""
    echo -e "${YELLOW}⚠ Alguns testes falharam. Verifique a configuração da rede.${NC}"
    exit 1
fi