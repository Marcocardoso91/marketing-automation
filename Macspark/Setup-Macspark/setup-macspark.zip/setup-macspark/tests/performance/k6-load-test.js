// ============================================================================
// K6 LOAD TESTING - MACSPARK SETUP
// ============================================================================
// Testes de carga básicos para validar performance pós-deploy
// Executa cenários de carga realistas em endpoints críticos
// ============================================================================

import http from 'k6/http';
import { check, group, sleep } from 'k6';
import { Rate, Trend, Counter } from 'k6/metrics';

// Métricas customizadas
const errorRate = new Rate('error_rate');
const responseTime = new Trend('response_time');
const requests = new Counter('total_requests');

// Configuração do teste
export let options = {
  // Cenários de teste
  scenarios: {
    // Smoke Test - Validação básica
    smoke: {
      executor: 'constant-vus',
      vus: 1,
      duration: '1m',
      tags: { test_type: 'smoke' },
      env: { TEST_NAME: 'smoke' }
    },
    
    // Load Test - Carga normal
    load: {
      executor: 'ramping-vus',
      startVUs: 0,
      stages: [
        { duration: '2m', target: 10 },  // Ramp up
        { duration: '5m', target: 10 },  // Steady state
        { duration: '2m', target: 0 }    // Ramp down
      ],
      tags: { test_type: 'load' },
      env: { TEST_NAME: 'load' }
    },
    
    // Stress Test - Carga alta
    stress: {
      executor: 'ramping-vus',
      startVUs: 0,
      stages: [
        { duration: '1m', target: 20 },   // Ramp up
        { duration: '3m', target: 20 },   // Stay at 20 users
        { duration: '1m', target: 40 },   // Ramp up to 40
        { duration: '2m', target: 40 },   // Stay at 40 users
        { duration: '1m', target: 0 }     // Ramp down
      ],
      tags: { test_type: 'stress' },
      env: { TEST_NAME: 'stress' }
    }
  },
  
  // Thresholds de performance
  thresholds: {
    http_req_duration: ['p(95)<1000'], // 95% das requests < 1s
    http_req_failed: ['rate<0.05'],     // Taxa de erro < 5%
    error_rate: ['rate<0.05'],          // Taxa de erro customizada < 5%
  }
};

// Configuração de ambiente
const BASE_URL = __ENV.BASE_URL || 'https://traefik.homolog.macspark.dev';
const ENVIRONMENT = __ENV.ENVIRONMENT || 'homolog';

// Endpoints para teste
const endpoints = [
  { name: 'Traefik Dashboard', url: '/dashboard/' },
  { name: 'Portainer', url: '/portainer/' },
  { name: 'Grafana Health', url: '/grafana/api/health' },
  { name: 'Prometheus Metrics', url: '/prometheus/api/v1/query?query=up' },
];

export function setup() {
  console.log(`🚀 Iniciando testes de performance K6`);
  console.log(`🌐 Base URL: ${BASE_URL}`);
  console.log(`🏷️  Ambiente: ${ENVIRONMENT}`);
  console.log(`📊 Cenários: ${Object.keys(options.scenarios).join(', ')}`);
  
  return {
    startTime: new Date().toISOString()
  };
}

export default function() {
  const testName = __ENV.TEST_NAME || 'unknown';
  
  group('Health Check Endpoints', () => {
    endpoints.forEach(endpoint => {
      group(endpoint.name, () => {
        const response = http.get(`${BASE_URL}${endpoint.url}`, {
          headers: {
            'User-Agent': `k6-load-test/${testName}`,
            'Accept': 'application/json,text/html,*/*'
          },
          tags: {
            endpoint: endpoint.name,
            test_scenario: testName
          }
        });
        
        // Validações
        const checkResult = check(response, {
          'status is 200 or 302': (r) => [200, 302, 401, 403].includes(r.status),
          'response time < 2s': (r) => r.timings.duration < 2000,
          'has content': (r) => r.body && r.body.length > 0
        });
        
        // Registrar métricas
        errorRate.add(!checkResult);
        responseTime.add(response.timings.duration);
        requests.add(1);
        
        // Log de debugging para falhas
        if (!checkResult) {
          console.warn(`❌ Falha em ${endpoint.name}: ${response.status} - ${response.status_text}`);
        }
      });
    });
  });
  
  group('API Endpoints', () => {
    // Teste Prometheus metrics
    const prometheusResponse = http.get(`${BASE_URL}/prometheus/api/v1/label/__name__/values`, {
      headers: {
        'Accept': 'application/json',
        'User-Agent': `k6-prometheus-test/${testName}`
      },
      tags: { endpoint: 'prometheus-api' }
    });
    
    check(prometheusResponse, {
      'prometheus api accessible': (r) => [200, 401, 403].includes(r.status)
    });
    
    // Teste Grafana API
    const grafanaResponse = http.get(`${BASE_URL}/grafana/api/datasources`, {
      headers: {
        'Accept': 'application/json',
        'User-Agent': `k6-grafana-test/${testName}`
      },
      tags: { endpoint: 'grafana-api' }
    });
    
    check(grafanaResponse, {
      'grafana api accessible': (r) => [200, 401, 403].includes(r.status)
    });
  });
  
  // Simular tempo de pensamento do usuário
  sleep(Math.random() * 2 + 1); // 1-3 segundos
}

export function teardown(data) {
  console.log(`✅ Testes finalizados`);
  console.log(`⏰ Início: ${data.startTime}`);
  console.log(`⏰ Fim: ${new Date().toISOString()}`);
  console.log(`📊 Total de requests: ${requests.count}`);
  
  // Resumo dos resultados
  if (errorRate.rate > 0.05) {
    console.warn(`⚠️  Taxa de erro alta: ${(errorRate.rate * 100).toFixed(2)}%`);
  } else {
    console.log(`✅ Taxa de erro aceitável: ${(errorRate.rate * 100).toFixed(2)}%`);
  }
}