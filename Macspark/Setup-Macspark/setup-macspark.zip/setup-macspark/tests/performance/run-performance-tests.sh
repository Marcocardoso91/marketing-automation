#!/bin/bash

# ============================================================================
# PERFORMANCE TESTING RUNNER - MACSPARK SETUP
# ============================================================================
# Script para executar testes de performance com K6
# Suporte a múltiplos cenários e ambientes
# ============================================================================

set -euo pipefail

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configurações
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
RESULTS_DIR="$SCRIPT_DIR/results"
TIMESTAMP=$(date '+%Y%m%d-%H%M%S')

# Parâmetros
BASE_URL=${1:-"https://traefik.homolog.macspark.dev"}
ENVIRONMENT=${2:-"homolog"}
TEST_SCENARIO=${3:-"load"}

# Logging
log() {
    local level=$1; shift
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    case $level in
        "INFO") echo -e "${BLUE}[INFO]${NC} [$timestamp] $*" ;;
        "SUCCESS") echo -e "${GREEN}[SUCCESS]${NC} [$timestamp] $*" ;;
        "ERROR") echo -e "${RED}[ERROR]${NC} [$timestamp] $*" ;;
        "WARN") echo -e "${YELLOW}[WARN]${NC} [$timestamp] $*" ;;
    esac
}

# Verificar dependências
check_dependencies() {
    log "INFO" "🔍 Verificando dependências..."
    
    # Verificar K6
    if ! command -v k6 >/dev/null 2>&1; then
        log "WARN" "K6 não encontrado, instalando..."
        install_k6
    else
        local k6_version=$(k6 version | head -1)
        log "SUCCESS" "K6 encontrado: $k6_version"
    fi
    
    # Verificar conectividade
    if ! curl -s --connect-timeout 10 "$BASE_URL" >/dev/null; then
        log "ERROR" "Não foi possível conectar ao endpoint: $BASE_URL"
        return 1
    else
        log "SUCCESS" "Conectividade OK: $BASE_URL"
    fi
}

# Instalar K6
install_k6() {
    log "INFO" "📦 Instalando K6..."
    
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        # Linux/WSL
        sudo gpg -k
        sudo gpg --no-default-keyring --keyring /usr/share/keyrings/k6-archive-keyring.gpg --keyserver hkp://keyserver.ubuntu.com:80 --recv-keys C5AD17C747E3415A3642D57D77C6C491D6AC1D69
        echo "deb [signed-by=/usr/share/keyrings/k6-archive-keyring.gpg] https://dl.k6.io/deb stable main" | sudo tee /etc/apt/sources.list.d/k6.list
        sudo apt-get update
        sudo apt-get install k6
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        if command -v brew >/dev/null 2>&1; then
            brew install k6
        else
            log "ERROR" "Homebrew não encontrado. Instale manualmente: https://k6.io/docs/get-started/installation/"
            return 1
        fi
    else
        log "ERROR" "Sistema operacional não suportado para instalação automática do K6"
        return 1
    fi
    
    log "SUCCESS" "K6 instalado com sucesso"
}

# Preparar ambiente de testes
setup_test_environment() {
    log "INFO" "🛠️  Preparando ambiente de testes..."
    
    # Criar diretório de resultados
    mkdir -p "$RESULTS_DIR"
    
    # Limpar resultados antigos (manter últimos 10)
    find "$RESULTS_DIR" -name "*.json" -mtime +7 -delete 2>/dev/null || true
    
    # Configurar variáveis de ambiente
    export BASE_URL
    export ENVIRONMENT
    export TEST_SCENARIO
    
    log "SUCCESS" "Ambiente configurado"
}

# Executar testes de performance
run_performance_tests() {
    log "INFO" "🚀 Iniciando testes de performance..."
    log "INFO" "   Base URL: $BASE_URL"
    log "INFO" "   Ambiente: $ENVIRONMENT"
    log "INFO" "   Cenário: $TEST_SCENARIO"
    
    local test_file="$SCRIPT_DIR/k6-load-test.js"
    local results_file="$RESULTS_DIR/k6-results-${ENVIRONMENT}-${TEST_SCENARIO}-${TIMESTAMP}.json"
    local summary_file="$RESULTS_DIR/summary-${TIMESTAMP}.txt"
    
    # Executar K6
    log "INFO" "📊 Executando testes K6..."
    
    if k6 run \
        --env BASE_URL="$BASE_URL" \
        --env ENVIRONMENT="$ENVIRONMENT" \
        --env TEST_NAME="$TEST_SCENARIO" \
        --out json="$results_file" \
        --summary-export="$summary_file" \
        "$test_file"; then
        
        log "SUCCESS" "Testes executados com sucesso"
        analyze_results "$results_file" "$summary_file"
        return 0
    else
        log "ERROR" "Falha na execução dos testes"
        return 1
    fi
}

# Analisar resultados
analyze_results() {
    local results_file=$1
    local summary_file=$2
    
    log "INFO" "📈 Analisando resultados..."
    
    if [[ -f "$summary_file" ]]; then
        echo ""
        echo -e "${BLUE}==========================================="
        echo "         RESUMO DOS TESTES K6"
        echo "==========================================${NC}"
        cat "$summary_file"
        echo ""
    fi
    
    if [[ -f "$results_file" ]]; then
        # Extrair métricas principais usando jq (se disponível)
        if command -v jq >/dev/null 2>&1; then
            echo -e "${BLUE}📊 MÉTRICAS DETALHADAS:${NC}"
            
            # Contar total de requests
            local total_requests=$(grep -c '"type":"Point"' "$results_file" 2>/dev/null || echo "N/A")
            echo "   Total de requests: $total_requests"
            
            # VUs máximo
            local max_vus=$(jq -r 'select(.metric == "vus") | .data.value' "$results_file" 2>/dev/null | sort -n | tail -1 || echo "N/A")
            echo "   VUs máximo: $max_vus"
            
            echo ""
        fi
        
        log "SUCCESS" "Resultados salvos em: $results_file"
    fi
    
    # Verificar se há falhas críticas
    if grep -q "http_req_failed.*rate.*1.0" "$summary_file" 2>/dev/null; then
        log "ERROR" "Taxa de falha crítica detectada!"
        return 1
    elif grep -q "http_req_duration.*p(95).*[5-9][0-9][0-9][0-9]" "$summary_file" 2>/dev/null; then
        log "WARN" "Tempo de resposta alto detectado"
        return 1
    else
        log "SUCCESS" "Performance dentro dos parâmetros aceitáveis"
        return 0
    fi
}

# Gerar relatório HTML
generate_html_report() {
    log "INFO" "📄 Gerando relatório HTML..."
    
    local report_file="$RESULTS_DIR/report-${TIMESTAMP}.html"
    
    cat > "$report_file" << EOF
<!DOCTYPE html>
<html>
<head>
    <title>Performance Test Report - Macspark Setup</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .header { background: #f8f9fa; padding: 20px; border-radius: 8px; }
        .metric { background: #e9ecef; padding: 15px; margin: 10px 0; border-radius: 5px; }
        .success { color: #28a745; }
        .warning { color: #ffc107; }
        .error { color: #dc3545; }
        pre { background: #f8f9fa; padding: 15px; border-radius: 5px; overflow-x: auto; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🚀 Performance Test Report</h1>
        <p><strong>Ambiente:</strong> $ENVIRONMENT</p>
        <p><strong>Base URL:</strong> $BASE_URL</p>
        <p><strong>Cenário:</strong> $TEST_SCENARIO</p>
        <p><strong>Data:</strong> $(date)</p>
    </div>
    
    <h2>📊 Resumo dos Resultados</h2>
    <div class="metric">
EOF
    
    if [[ -f "$RESULTS_DIR/summary-${TIMESTAMP}.txt" ]]; then
        echo "<pre>" >> "$report_file"
        cat "$RESULTS_DIR/summary-${TIMESTAMP}.txt" >> "$report_file"
        echo "</pre>" >> "$report_file"
    fi
    
    cat >> "$report_file" << EOF
    </div>
    
    <h2>💡 Recomendações</h2>
    <ul>
        <li>✅ Monitorar métricas de response time continuamente</li>
        <li>✅ Implementar cache para melhorar performance</li>
        <li>✅ Configurar auto-scaling baseado em métricas</li>
        <li>✅ Executar testes regularmente no CI/CD</li>
    </ul>
</body>
</html>
EOF
    
    log "SUCCESS" "Relatório HTML gerado: $report_file"
}

# Mostrar ajuda
show_help() {
    cat << EOF
🚀 Performance Testing Runner - Macspark Setup

USAGE:
    $0 [BASE_URL] [ENVIRONMENT] [TEST_SCENARIO]

PARAMETERS:
    BASE_URL        URL base para testes (default: https://traefik.homolog.macspark.dev)
    ENVIRONMENT     Ambiente de teste (default: homolog)
    TEST_SCENARIO   Cenário de teste: smoke, load, stress (default: load)

EXAMPLES:
    $0                                                    # Teste padrão
    $0 https://macspark.dev production stress            # Teste de stress em produção
    $0 http://localhost:8080 local smoke                 # Smoke test local

SCENARIOS:
    smoke    - Teste básico com 1 usuário por 1 minuto
    load     - Teste de carga normal com 10 usuários
    stress   - Teste de stress com até 40 usuários

REQUIREMENTS:
    - K6 (será instalado automaticamente se necessário)
    - curl
    - jq (opcional, para análise detalhada)
EOF
}

# Main
main() {
    echo -e "${BLUE}"
    echo "=========================================="
    echo "    PERFORMANCE TESTING - MACSPARK"
    echo "=========================================="
    echo "🎯 Validando performance pós-deploy"
    echo -e "${NC}"
    
    # Verificar argumentos
    if [[ ${1:-} == "--help" ]] || [[ ${1:-} == "-h" ]]; then
        show_help
        exit 0
    fi
    
    # Executar pipeline
    check_dependencies
    setup_test_environment
    
    if run_performance_tests; then
        generate_html_report
        log "SUCCESS" "🎉 Testes de performance concluídos com sucesso!"
        exit 0
    else
        log "ERROR" "❌ Testes de performance falharam!"
        exit 1
    fi
}

# Executar
main "$@"