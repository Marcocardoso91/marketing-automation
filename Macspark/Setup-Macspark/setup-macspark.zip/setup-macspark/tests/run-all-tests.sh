#!/bin/bash

# run-all-tests.sh - Suite de Testes Completa do Macspark
#
# Este script executa todas as categorias de testes do projeto:
# - Unitários
# - Integração
# - End-to-End (E2E)
#
# O script procura por arquivos executáveis (scripts .sh) dentro de cada
# subdiretório de teste e os executa em sequência.
#
# Uso:
# ./run-all-tests.sh
#
# Estrutura de Diretórios Esperada:
# tests/
#   ├── unit/
#   │   ├── test_script_1.sh
#   │   └── test_component_A.sh
#   ├── integration/
#   │   └── test_api_database.sh
#   └── e2e/
#       └── test_user_journey.sh

set -eo pipefail

# Cores
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Diretório raiz dos testes
TESTS_ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
UNIT_TESTS_DIR="${TESTS_ROOT}/unit"
INTEGRATION_TESTS_DIR="${TESTS_ROOT}/integration"
E2E_TESTS_DIR="${TESTS_ROOT}/e2e"

# Contadores
total_tests_run=0
total_tests_failed=0

# Função para executar testes em um diretório
run_tests_in_dir() {
    local test_type=$1
    local test_dir=$2
    local test_files
    
    echo "-----------------------------------------------------"
    echo -e "🔎 Iniciando testes de ${BLUE}${test_type}${NC} em ${test_dir}"
    echo "-----------------------------------------------------"

    if [ ! -d "$test_dir" ] || [ -z "$(ls -A "$test_dir")" ]; then
        echo -e "${YELLOW}⚠ Nenhum teste encontrado para a categoria '${test_type}'. Pulando.${NC}"
        return
    fi

    # Encontra todos os scripts de teste executáveis
    test_files=$(find "$test_dir" -type f -name "*.sh" -executable)

    if [ -z "$test_files" ]; then
        echo -e "${YELLOW}⚠ Nenhum script de teste executável (*.sh) encontrado em ${test_dir}.${NC}"
        echo -e "Dica: Torne seus scripts de teste executáveis com 'chmod +x <script>'."
        return
    fi

    for test_file in $test_files; do
        echo -e "▶️  Executando: ${YELLOW}$(basename "$test_file")${NC}"
        total_tests_run=$((total_tests_run + 1))
        
        # Executa o script de teste. A saída é capturada para um log em caso de falha.
        if ! "$test_file"; then
            echo -e "${RED}❌ FALHOU:${NC} $(basename "$test_file")"
            total_tests_failed=$((total_tests_failed + 1))
        else
            echo -e "${GREEN}✔ PASSOU:${NC} $(basename "$test_file")"
        fi
        echo
    done
}

# --- Execução Principal ---
echo "🚀 Iniciando a suíte de testes completa do Macspark..."
start_time=$(date +%s)

# Executar todas as categorias de testes
run_tests_in_dir "Unitários" "$UNIT_TESTS_DIR"
run_tests_in_dir "Integração" "$INTEGRATION_TESTS_DIR"
run_tests_in_dir "End-to-End" "$E2E_TESTS_DIR"

end_time=$(date +%s)
duration=$((end_time - start_time))

# --- Relatório Final ---
echo "-----------------------------------------------------"
echo "📊 Relatório Final da Suíte de Testes"
echo "-----------------------------------------------------"
echo "Tempo total de execução: ${duration} segundos"
echo "Total de suítes executadas: ${total_tests_run}"
echo -e "Suítes com sucesso: ${GREEN}$((total_tests_run - total_tests_failed))${NC}"
echo -e "Suítes com falha: ${RED}${total_tests_failed}${NC}"
echo "-----------------------------------------------------"

if [ "$total_tests_failed" -gt 0 ]; then
    echo -e "${RED}🚨 A suíte de testes falhou.${NC}"
    exit 1
else
    echo -e "${GREEN}🎉 Todos os testes passaram com sucesso!${NC}"
    exit 0
fi