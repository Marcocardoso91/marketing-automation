#!/bin/bash

# Teste de Validação YAML
# Valida sintaxe de todos os arquivos YAML/YML do projeto

set -euo pipefail

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Contadores
TOTAL=0
VALID=0
INVALID=0

echo "================================================"
echo "     Validador de Sintaxe YAML - Macspark      "
echo "================================================"
echo ""

# Função para validar arquivo YAML
validate_yaml() {
    local file="$1"
    TOTAL=$((TOTAL + 1))
    
    if command -v python3 &> /dev/null; then
        # Usa Python para validar YAML
        if python3 -c "import yaml; yaml.safe_load(open('$file'))" 2>/dev/null; then
            echo -e "${GREEN}✓${NC} $file"
            VALID=$((VALID + 1))
            return 0
        else
            echo -e "${RED}✗${NC} $file"
            echo -e "${YELLOW}  Erro de sintaxe detectado${NC}"
            INVALID=$((INVALID + 1))
            return 1
        fi
    elif command -v yq &> /dev/null; then
        # Usa yq como alternativa
        if yq eval '.' "$file" > /dev/null 2>&1; then
            echo -e "${GREEN}✓${NC} $file"
            VALID=$((VALID + 1))
            return 0
        else
            echo -e "${RED}✗${NC} $file"
            INVALID=$((INVALID + 1))
            return 1
        fi
    else
        echo -e "${YELLOW}⚠ Instalando validador YAML...${NC}"
        pip3 install --user pyyaml 2>/dev/null || true
        validate_yaml "$file"
    fi
}

# Procura por todos os arquivos YAML
echo "Procurando arquivos YAML..."
echo ""

# Valida arquivos nas pastas principais
for dir in stacks configs templates environments; do
    if [ -d "$dir" ]; then
        echo "Validando $dir/..."
        find "$dir" -type f \( -name "*.yml" -o -name "*.yaml" \) | while read -r file; do
            validate_yaml "$file"
        done
        echo ""
    fi
done

# Resumo
echo "================================================"
echo "                   RESUMO                      "
echo "================================================"
echo -e "Total de arquivos:    $TOTAL"
echo -e "Arquivos válidos:     ${GREEN}$VALID${NC}"
echo -e "Arquivos inválidos:   ${RED}$INVALID${NC}"

if [ $INVALID -eq 0 ]; then
    echo ""
    echo -e "${GREEN}✓ Todos os arquivos YAML são válidos!${NC}"
    exit 0
else
    echo ""
    echo -e "${RED}✗ Foram encontrados $INVALID arquivos com erros${NC}"
    exit 1
fi