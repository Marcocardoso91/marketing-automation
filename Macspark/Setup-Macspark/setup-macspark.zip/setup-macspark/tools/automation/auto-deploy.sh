#!/bin/bash

# Auto Deploy Script - Deploy automático com validações
# Macspark Infrastructure

set -euo pipefail

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configurações
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
LOG_FILE="/var/log/macspark/auto-deploy.log"
DEPLOY_ORDER=("traefik" "database" "monitoring" "applications")

# Criar diretório de logs
mkdir -p "$(dirname "$LOG_FILE")"

# Função de log
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# Função para validar pré-requisitos
validate_prerequisites() {
    log "Validando pré-requisitos..."
    
    # Verificar Docker Swarm
    if ! docker info | grep -q "Swarm: active"; then
        log "ERROR: Docker Swarm não está ativo"
        echo -e "${RED}✗ Docker Swarm não está ativo${NC}"
        echo "Execute: docker swarm init"
        exit 1
    fi
    
    # Verificar redes
    for network in proxy internal monitoring database; do
        if ! docker network ls | grep -q "$network"; then
            log "Criando rede: $network"
            docker network create --driver overlay "$network"
        fi
    done
    
    # Validar YAMLs
    if [ -f "$PROJECT_ROOT/tests/unit/validate-yaml.sh" ]; then
        log "Validando arquivos YAML..."
        if ! "$PROJECT_ROOT/tests/unit/validate-yaml.sh" > /dev/null 2>&1; then
            log "ERROR: Validação YAML falhou"
            echo -e "${RED}✗ Arquivos YAML inválidos${NC}"
            exit 1
        fi
    fi
    
    echo -e "${GREEN}✓ Pré-requisitos validados${NC}"
}

# Função para deploy de stack
deploy_stack() {
    local stack_name="$1"
    local stack_category="$2"
    local env="${3:-production}"
    
    log "Deploying stack: $stack_name ($stack_category)"
    
    local stack_file="$PROJECT_ROOT/stacks/$stack_category/$stack_name/${stack_name}-${env}.yml"
    
    if [ ! -f "$stack_file" ]; then
        log "WARNING: Stack file não encontrado: $stack_file"
        echo -e "${YELLOW}⚠ Stack $stack_name não encontrado${NC}"
        return 1
    fi
    
    echo -e "${BLUE}Deploying:${NC} $stack_name"
    
    if docker stack deploy -c "$stack_file" "$stack_name"; then
        log "SUCCESS: Stack $stack_name deployed"
        echo -e "${GREEN}✓ $stack_name deployed${NC}"
        
        # Aguardar serviço estar pronto
        sleep 5
        wait_for_service "$stack_name"
    else
        log "ERROR: Falha ao deployar $stack_name"
        echo -e "${RED}✗ Falha ao deployar $stack_name${NC}"
        return 1
    fi
}

# Função para aguardar serviço
wait_for_service() {
    local stack_name="$1"
    local max_attempts=30
    local attempt=0
    
    echo -n "Aguardando $stack_name ficar pronto..."
    
    while [ $attempt -lt $max_attempts ]; do
        local services=$(docker stack services "$stack_name" --format "{{.Name}}" 2>/dev/null)
        local all_ready=true
        
        for service in $services; do
            local replicas=$(docker service ls --filter "name=$service" --format "{{.Replicas}}" 2>/dev/null)
            local current=$(echo "$replicas" | cut -d'/' -f1)
            local desired=$(echo "$replicas" | cut -d'/' -f2)
            
            if [ "$current" != "$desired" ]; then
                all_ready=false
                break
            fi
        done
        
        if $all_ready; then
            echo -e " ${GREEN}✓${NC}"
            return 0
        fi
        
        echo -n "."
        sleep 2
        attempt=$((attempt + 1))
    done
    
    echo -e " ${YELLOW}⚠ Timeout${NC}"
    return 1
}

# Função para deploy completo
full_deploy() {
    local env="${1:-production}"
    
    echo "================================================"
    echo "      AUTO DEPLOY - Macspark Infrastructure    "
    echo "================================================"
    echo -e "Environment: ${CYAN}$env${NC}"
    echo ""
    
    log "Iniciando deploy completo - Environment: $env"
    
    # Validar pré-requisitos
    validate_prerequisites
    
    # Deploy Core Services
    echo -e "${BOLD}Deploying Core Services...${NC}"
    deploy_stack "traefik" "core" "$env"
    deploy_stack "database" "core" "$env"
    deploy_stack "monitoring" "core" "$env"
    
    # Deploy Applications
    echo -e "${BOLD}Deploying Applications...${NC}"
    for app_dir in "$PROJECT_ROOT"/stacks/applications/*/; do
        if [ -d "$app_dir" ]; then
            local app_name=$(basename "$app_dir")
            for stack_dir in "$app_dir"*/; do
                if [ -d "$stack_dir" ]; then
                    local stack_name=$(basename "$stack_dir")
                    deploy_stack "$stack_name" "applications/$app_name" "$env" || true
                fi
            done
        fi
    done
    
    # Deploy Infrastructure Services
    echo -e "${BOLD}Deploying Infrastructure Services...${NC}"
    for infra_dir in "$PROJECT_ROOT"/stacks/infrastructure/*/; do
        if [ -d "$infra_dir" ]; then
            local infra_name=$(basename "$infra_dir")
            for stack_dir in "$infra_dir"*/; do
                if [ -d "$stack_dir" ]; then
                    local stack_name=$(basename "$stack_dir")
                    deploy_stack "$stack_name" "infrastructure/$infra_name" "$env" || true
                fi
            done
        fi
    done
    
    # Verificar saúde
    echo ""
    echo -e "${BOLD}Verificando saúde do sistema...${NC}"
    if [ -f "$PROJECT_ROOT/tests/e2e/test-health-checks.sh" ]; then
        "$PROJECT_ROOT/tests/e2e/test-health-checks.sh" || true
    fi
    
    # Resumo
    echo ""
    echo "================================================"
    echo "              DEPLOY COMPLETO                  "
    echo "================================================"
    
    local total_stacks=$(docker stack ls --format "{{.Name}}" | wc -l)
    local total_services=$(docker service ls --format "{{.Name}}" | wc -l)
    
    echo -e "Stacks deployados:   ${GREEN}$total_stacks${NC}"
    echo -e "Serviços rodando:    ${GREEN}$total_services${NC}"
    echo -e "Environment:         ${CYAN}$env${NC}"
    
    log "Deploy completo - Stacks: $total_stacks, Services: $total_services"
    
    echo ""
    echo -e "${GREEN}✓ Deploy automático concluído com sucesso!${NC}"
    echo ""
    echo "Acesse os serviços:"
    echo "  Traefik:    http://traefik.macspark.dev"
    echo "  Grafana:    http://grafana.macspark.dev"
    echo "  Portainer:  http://portainer.macspark.dev"
}

# Main
main() {
    local env="${1:-production}"
    
    case "$env" in
        production|prod)
            full_deploy "production"
            ;;
        homolog|homologation|staging)
            full_deploy "homolog"
            ;;
        local|dev|development)
            full_deploy "local"
            ;;
        *)
            echo -e "${RED}Environment inválido: $env${NC}"
            echo "Use: production, homolog, ou local"
            exit 1
            ;;
    esac
}

# Executar se chamado diretamente
if [ "${BASH_SOURCE[0]}" = "${0}" ]; then
    main "$@"
fi