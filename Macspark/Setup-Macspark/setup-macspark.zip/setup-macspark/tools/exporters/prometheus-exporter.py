#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
prometheus-exporter.py - Exporter de Métricas para Prometheus
Este script inicia um servidor HTTP que expõe métricas customizadas no formato
Prometheus. As métricas podem ser coletadas por uma instância do Prometheus
para monitoramento.
Uso:
  python prometheus-exporter.py [PORT]
Dependências:
  - prometheus_client: 'pip install prometheus_client'
"""

import os
import sys
import time
import random
from http.server import HTTPServer
from prometheus_client import (
    start_http_server,
    Gauge,
    Counter,
    Summary,
    REGISTRY,
    ProcessCollector,
    PlatformCollector,
)

# --- Métricas Customizadas ---
# Use Gauge para valores que podem aumentar ou diminuir.
# Use Counter para valores que só aumentam (e.g., número de requests).
# Use Summary para observar durações e tamanhos de eventos.

APP_VERSION = os.environ.get("APP_VERSION", "0.1.0")

# Métricas de exemplo
MACSPARK_JOBS_ACTIVE = Gauge(
    "macspark_jobs_active", "Número de jobs ativos no Macspark"
)
MACSPARK_JOBS_FAILED_TOTAL = Counter(
    "macspark_jobs_failed_total",
    "Número total de jobs que falharam",
    ["reason"],
)
MACSPARK_JOB_DURATION_SECONDS = Summary(
    "macspark_job_duration_seconds", "Duração dos jobs em segundos"
)
MACSPARK_APP_INFO = Gauge(
    "macspark_app_info",
    "Informações sobre a aplicação",
    ["version"],
)

# --- Coletores Padrão ---
# Desregistra os coletores padrão para ter um controle mais fino
# e evitar métricas desnecessárias, se desejar.
# for coll in list(REGISTRY._collector_to_names.keys()):
#     REGISTRY.unregister(coll)

# Adiciona coletores de métricas do processo e da plataforma (CPU, memória, etc.)
ProcessCollector(namespace="macspark_process")
PlatformCollector(namespace="macspark_platform")


def simulate_job_execution():
    """
    Simula a execução de jobs para gerar dados de métricas.
    """
    print("Simulando execução de jobs...")
    with MACSPARK_JOB_DURATION_SECONDS.time():
        # Simula jobs ativos
        active_jobs = random.randint(1, 20)
        MACSPARK_JOBS_ACTIVE.set(active_jobs)
        print(f"Jobs ativos: {active_jobs}")

        # Simula falhas
        if random.random() < 0.1:
            failure_reasons = ["database_error", "timeout", "invalid_config"]
            reason = random.choice(failure_reasons)
            MACSPARK_JOBS_FAILED_TOTAL.labels(reason=reason).inc()
            print(f"Um job falhou! Razão: {reason}")

        # Simula a duração do job
        time.sleep(random.uniform(0.5, 2.5))


def main(port: int):
    """
    Função principal que inicia o servidor e o loop de métricas.
    """
    print(f"🚀 Iniciando Prometheus Exporter na porta {port}...")
    print(f"Acesse as métricas em http://localhost:{port}")

    # Inicia o servidor HTTP em uma thread separada
    start_http_server(port)

    # Define a métrica de informação da aplicação (ela é estática)
    MACSPARK_APP_INFO.labels(version=APP_VERSION).set(1)

    print("Exporter iniciado. Pressione Ctrl+C para sair.")

    # Loop principal para atualizar as métricas
    try:
        while True:
            simulate_job_execution()
    except KeyboardInterrupt:
        print("\n🛑 Servidor Prometheus Exporter encerrado.")
        sys.exit(0)
    except Exception as e:
        print(f"\n🚨 Erro inesperado: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    # Define a porta a partir de argumentos da linha de comando ou usa um padrão
    if len(sys.argv) > 1:
        try:
            listen_port = int(sys.argv[1])
        except ValueError:
            print(f"Porta inválida: {sys.argv[1]}", file=sys.stderr)
            sys.exit(1)
    else:
        listen_port = 9876  # Porta padrão para exporters customizados

    main(listen_port)