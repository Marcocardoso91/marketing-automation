#!/bin/bash

# stack-generator.sh - Gerador de Stacks para o Macspark
#
# Este script cria a estrutura de diretórios e arquivos básicos para uma nova
# stack de aplicação ou infraestrutura dentro do projeto.
#
# Uso:
# ./stack-generator.sh <tipo_stack> <nome_stack>
#
# Argumentos:
#   <tipo_stack> - O tipo de stack (ex: 'applications', 'infrastructure', 'core').
#   <nome_stack>   - O nome da nova stack (ex: 'my-new-app', 'monitoring-v2').
#
# Exemplo:
# ./stack-generator.sh applications my-cool-api

set -euo pipefail

# Cores
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Validação dos argumentos
if [ "$#" -ne 2 ]; then
    echo -e "${RED}Erro: Número incorreto de argumentos.${NC}"
    echo -e "Uso: ${YELLOW}$0 <tipo_stack> <nome_stack>${NC}"
    echo -e "Tipos válidos: applications, infrastructure, core, experimental, examples"
    exit 1
fi

STACK_TYPE=$1
STACK_NAME=$2
PROJECT_ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../../" && pwd )"
STACKS_DIR="${PROJECT_ROOT}/stacks"
TARGET_DIR="${STACKS_DIR}/${STACK_TYPE}/${STACK_NAME}"

# Validação do tipo de stack
case "$STACK_TYPE" in
    applications|infrastructure|core|experimental|examples)
        ;; # Tipo válido
    *)
        echo -e "${RED}Erro: Tipo de stack inválido: '${STACK_TYPE}'.${NC}"
        echo -e "Tipos permitidos: applications, infrastructure, core, experimental, examples."
        exit 1
        ;;
esac

# Validação do nome da stack (básico)
if ! [[ "$STACK_NAME" =~ ^[a-z0-9]([-a-z0-9]*[a-z0-9])?$ ]]; then
    echo -e "${RED}Erro: Nome da stack inválido: '${STACK_NAME}'.${NC}"
    echo -e "Use apenas letras minúsculas, números e hífens. Não pode começar ou terminar com hífen."
    exit 1
fi

# Verificar se a stack já existe
if [ -d "${TARGET_DIR}" ]; then
    echo -e "${RED}Erro: A stack '${STACK_NAME}' já existe em '${TARGET_DIR}'.${NC}"
    exit 1
fi

echo -e "🚀 Gerando nova stack '${BLUE}${STACK_NAME}${NC}' do tipo '${BLUE}${STACK_TYPE}${NC}'..."
echo -e "Diretório de destino: ${TARGET_DIR}"
echo "-----------------------------------------------------"

# Criar a estrutura de diretórios
echo "-> Criando diretórios..."
mkdir -p "${TARGET_DIR}/configs"
mkdir -p "${TARGET_DIR}/volumes"
mkdir -p "${TARGET_DIR}/secrets"
mkdir -p "${TARGET_DIR}/tests"

# Criar arquivos básicos
echo "-> Criando arquivos de template..."

# 1. README.md
cat > "${TARGET_DIR}/README.md" << EOL
# Stack: ${STACK_NAME}

## Visão Geral

Esta stack é do tipo \`${STACK_TYPE}\` e é responsável por... 
(Adicione uma descrição clara e concisa aqui).

## Serviços

- **service-1**: Descrição do primeiro serviço.
- **service-2**: Descrição do segundo serviço.

## Configuração

As configurações específicas para esta stack estão localizadas no diretório \`configs/\`.
Variáveis de ambiente necessárias devem ser documentadas aqui e populadas através de secrets do Docker Swarm.

## Volumes

Os volumes persistentes são gerenciados pelo Docker e estão definidos em \`docker-compose.yml\`.

## Como Implantar

Para implantar esta stack, use o comando:
\`\`\`bash
make deploy STACK=${STACK_TYPE}/${STACK_NAME}
\`\`\`
EOL

# 2. docker-compose.yml
cat > "${TARGET_DIR}/docker-compose.yml" << EOL
version: "3.9"

# -----------------------------------------------------------------------------
# Stack: ${STACK_NAME}
# Tipo: ${STACK_TYPE}
#
# Descrição: Arquivo de composição para a stack ${STACK_NAME}.
# -----------------------------------------------------------------------------

networks:
  # Exemplo de rede externa (gerenciada fora desta stack)
  proxy:
    external: true
    name: \${NETWORK_PROXY:-proxy}
  
  # Rede interna para a stack
  internal:
    driver: overlay
    attachable: true
    name: \${COMPOSE_PROJECT_NAME}_internal

services:
  # --- Exemplo de Serviço ---
  # Substitua ou adicione seus serviços aqui
  app:
    image: alpine:latest
    command: ["sleep", "infinity"]
    deploy:
      mode: replicated
      replicas: 1
      placement:
        constraints:
          - "node.role == worker"
      labels:
        - "traefik.enable=true"
        # - "traefik.http.routers.${STACK_NAME}.rule=Host(\`\${SUBDOMAIN}.${DOMAIN}\`)"
        # - "traefik.http.routers.${STACK_NAME}.entrypoints=websecure"
        # - "traefik.http.services.${STACK_NAME}.loadbalancer.server.port=8080"
    networks:
      - proxy
      - internal

volumes:
  # Exemplo de volume
  # app-data:
  #   driver: local
  #   name: \${COMPOSE_PROJECT_NAME}_app-data

secrets:
  # Exemplo de secret
  # - source: my_secret
  #   target: /run/secrets/my_secret
EOL

# 3. .env.example
cat > "${TARGET_DIR}/.env.example" << EOL
# Variáveis de Ambiente para a Stack: ${STACK_NAME}

# Domínio principal para acesso via Traefik
DOMAIN=macspark.local

# Subdomínio para o serviço principal
SUBDOMAIN=${STACK_NAME}

# Nome da rede externa do Traefik
NETWORK_PROXY=proxy

# Tag da imagem a ser usada
IMAGE_TAG=latest
EOL

# 4. .gitignore
echo "*.env" > "${TARGET_DIR}/.gitignore"
echo "secrets/*.key" >> "${TARGET_DIR}/.gitignore"

echo "-----------------------------------------------------"
echo -e "${GREEN}🎉 Stack '${STACK_NAME}' criada com sucesso em ${TARGET_DIR}${NC}"
echo -e "Próximos passos:"
echo -e "1. Edite o arquivo ${YELLOW}${TARGET_DIR}/docker-compose.yml${NC} para definir seus serviços."
echo -e "2. Adicione configurações em ${YELLOW}${TARGET_DIR}/configs/${NC}."
echo -e "3. Crie um arquivo ${YELLOW}.env${NC} a partir do ${YELLOW}.env.example${NC} e preencha os valores."
echo -e "4. Implante a stack com ${YELLOW}make deploy STACK=${STACK_TYPE}/${STACK_NAME}${NC}."

exit 0