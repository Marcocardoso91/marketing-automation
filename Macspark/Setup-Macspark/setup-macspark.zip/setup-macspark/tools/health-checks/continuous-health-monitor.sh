#!/bin/bash

# Continuous Health Monitor - Monitoramento contínuo de saúde
# Executa verificações periódicas e envia alertas

set -euo pipefail

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Configurações
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
CHECK_INTERVAL=${CHECK_INTERVAL:-60}  # Intervalo em segundos
ALERT_WEBHOOK=${ALERT_WEBHOOK:-""}    # Webhook para alertas (Slack, Discord, etc)
LOG_FILE="/var/log/macspark/health-monitor.log"
STATE_FILE="/tmp/macspark-health-state.json"
CRITICAL_THRESHOLD=3  # Número de falhas antes de alertar

# Criar diretório de logs
mkdir -p "$(dirname "$LOG_FILE")"

# Estado dos serviços
declare -A SERVICE_FAILURES

# Função de log
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# Função para enviar alerta
send_alert() {
    local severity="$1"
    local message="$2"
    local details="$3"
    
    log "ALERT [$severity]: $message"
    
    # Enviar para webhook se configurado
    if [ -n "$ALERT_WEBHOOK" ]; then
        local payload=$(cat <<EOF
{
    "severity": "$severity",
    "message": "$message",
    "details": "$details",
    "timestamp": "$(date -Iseconds)",
    "hostname": "$(hostname)",
    "environment": "${ENVIRONMENT:-production}"
}
EOF
)
        curl -X POST -H "Content-Type: application/json" -d "$payload" "$ALERT_WEBHOOK" 2>/dev/null || true
    fi
    
    # Enviar email se configurado
    if command -v mail &> /dev/null && [ -n "${ALERT_EMAIL:-}" ]; then
        echo -e "Severity: $severity\n\n$message\n\nDetails:\n$details" | \
            mail -s "[Macspark Alert] $severity: $message" "$ALERT_EMAIL"
    fi
}

# Função para verificar serviço Docker
check_docker_service() {
    local service_name="$1"
    local critical="${2:-false}"
    
    if ! docker service ls | grep -q "$service_name"; then
        return 1
    fi
    
    local replicas=$(docker service ls --filter "name=$service_name" --format "{{.Replicas}}" 2>/dev/null)
    local current=$(echo "$replicas" | cut -d'/' -f1)
    local desired=$(echo "$replicas" | cut -d'/' -f2)
    
    if [ "$current" = "$desired" ] && [ "$current" -gt 0 ]; then
        return 0
    else
        return 1
    fi
}

# Função para verificar endpoint HTTP
check_http_endpoint() {
    local url="$1"
    local expected_code="${2:-200}"
    local timeout="${3:-5}"
    
    local response_code=$(curl -s -o /dev/null -w "%{http_code}" --max-time "$timeout" "$url" 2>/dev/null || echo "000")
    
    if [ "$response_code" = "$expected_code" ]; then
        return 0
    else
        return 1
    fi
}

# Função para verificar uso de recursos
check_resource_usage() {
    local resource_type="$1"
    local threshold="$2"
    
    case "$resource_type" in
        cpu)
            local usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1 2>/dev/null || echo "0")
            ;;
        memory)
            local usage=$(free | grep Mem | awk '{print int($3/$2 * 100)}' 2>/dev/null || echo "0")
            ;;
        disk)
            local usage=$(df -h / | awk 'NR==2 {print $5}' | cut -d'%' -f1 2>/dev/null || echo "0")
            ;;
        *)
            return 1
            ;;
    esac
    
    if [ "$usage" -lt "$threshold" ]; then
        return 0
    else
        return 1
    fi
}

# Função para verificar certificados SSL
check_ssl_certificate() {
    local domain="$1"
    local days_warning="${2:-30}"
    
    local cert_expiry=$(echo | openssl s_client -servername "$domain" -connect "$domain:443" 2>/dev/null | \
                        openssl x509 -noout -enddate 2>/dev/null | \
                        cut -d= -f2)
    
    if [ -z "$cert_expiry" ]; then
        return 1
    fi
    
    local expiry_epoch=$(date -d "$cert_expiry" +%s 2>/dev/null || date -j -f "%b %d %H:%M:%S %Y %Z" "$cert_expiry" +%s)
    local current_epoch=$(date +%s)
    local days_left=$(( (expiry_epoch - current_epoch) / 86400 ))
    
    if [ "$days_left" -gt "$days_warning" ]; then
        return 0
    else
        echo "$days_left"
        return 1
    fi
}

# Função principal de monitoramento
monitor_health() {
    local all_healthy=true
    local issues=()
    
    echo -e "${CYAN}[$(date '+%H:%M:%S')] Executando verificação de saúde...${NC}"
    
    # 1. Verificar serviços críticos Docker
    local critical_services=("traefik" "postgres" "redis" "prometheus" "grafana")
    for service in "${critical_services[@]}"; do
        if ! check_docker_service "$service"; then
            SERVICE_FAILURES["$service"]=$((${SERVICE_FAILURES["$service"]:-0} + 1))
            
            if [ "${SERVICE_FAILURES["$service"]}" -ge "$CRITICAL_THRESHOLD" ]; then
                issues+=("CRÍTICO: Serviço $service falhou ${SERVICE_FAILURES[$service]} vezes")
                all_healthy=false
            fi
        else
            SERVICE_FAILURES["$service"]=0
        fi
    done
    
    # 2. Verificar endpoints HTTP
    local endpoints=(
        "http://localhost/health:200:Traefik"
        "http://localhost:9090/-/healthy:200:Prometheus"
        "http://localhost:3000/api/health:200:Grafana"
    )
    
    for endpoint_info in "${endpoints[@]}"; do
        IFS=':' read -r url code name <<< "$endpoint_info"
        if ! check_http_endpoint "$url" "$code"; then
            issues+=("WARNING: Endpoint $name não responde ($url)")
            all_healthy=false
        fi
    done
    
    # 3. Verificar uso de recursos
    if ! check_resource_usage "cpu" 90; then
        issues+=("WARNING: CPU acima de 90%")
    fi
    
    if ! check_resource_usage "memory" 90; then
        issues+=("WARNING: Memória acima de 90%")
    fi
    
    if ! check_resource_usage "disk" 85; then
        issues+=("WARNING: Disco acima de 85%")
    fi
    
    # 4. Verificar certificados SSL
    local domains=("macspark.dev" "traefik.macspark.dev" "grafana.macspark.dev")
    for domain in "${domains[@]}"; do
        if days_left=$(check_ssl_certificate "$domain" 30); then
            continue
        elif [ -n "$days_left" ]; then
            issues+=("WARNING: Certificado SSL de $domain expira em $days_left dias")
        fi
    done
    
    # 5. Verificar conectividade de banco de dados
    if command -v psql &> /dev/null; then
        if ! PGPASSWORD=${POSTGRES_PASSWORD:-postgres} psql -h localhost -U postgres -c "SELECT 1" >/dev/null 2>&1; then
            issues+=("CRÍTICO: PostgreSQL não está acessível")
            all_healthy=false
        fi
    fi
    
    # Processar resultados
    if $all_healthy && [ ${#issues[@]} -eq 0 ]; then
        echo -e "${GREEN}✓ Sistema completamente saudável${NC}"
        log "Health check: OK"
    else
        echo -e "${YELLOW}⚠ Problemas detectados:${NC}"
        for issue in "${issues[@]}"; do
            echo "  - $issue"
            log "Issue detected: $issue"
        done
        
        # Enviar alertas para problemas críticos
        if [[ " ${issues[@]} " =~ "CRÍTICO" ]]; then
            send_alert "CRITICAL" "Problemas críticos detectados no Macspark" "${issues[*]}"
        fi
    fi
    
    # Salvar estado
    save_state
}

# Função para salvar estado
save_state() {
    cat > "$STATE_FILE" <<EOF
{
    "timestamp": "$(date -Iseconds)",
    "failures": {
$(for service in "${!SERVICE_FAILURES[@]}"; do
    echo "        \"$service\": ${SERVICE_FAILURES[$service]},"
done | sed '$ s/,$//')
    },
    "last_check": "$(date '+%Y-%m-%d %H:%M:%S')"
}
EOF
}

# Função para carregar estado
load_state() {
    if [ -f "$STATE_FILE" ]; then
        # Parse simples do JSON (em produção, usar jq)
        while IFS= read -r line; do
            if [[ $line =~ \"([^\"]+)\":\ ([0-9]+) ]]; then
                SERVICE_FAILURES["${BASH_REMATCH[1]}"]="${BASH_REMATCH[2]}"
            fi
        done < "$STATE_FILE"
    fi
}

# Função para modo daemon
run_daemon() {
    log "Starting continuous health monitor (interval: ${CHECK_INTERVAL}s)"
    
    # Carregar estado anterior
    load_state
    
    # Trap para graceful shutdown
    trap 'log "Shutting down health monitor..."; exit 0' SIGTERM SIGINT
    
    while true; do
        monitor_health
        sleep "$CHECK_INTERVAL"
    done
}

# Função para execução única
run_once() {
    monitor_health
    
    # Retornar código de saída baseado no resultado
    if [ ${#SERVICE_FAILURES[@]} -gt 0 ]; then
        for failures in "${SERVICE_FAILURES[@]}"; do
            if [ "$failures" -ge "$CRITICAL_THRESHOLD" ]; then
                exit 2  # Crítico
            fi
        done
        exit 1  # Warning
    fi
    exit 0  # OK
}

# Main
main() {
    local mode="${1:-once}"
    
    echo "================================================"
    echo "    Continuous Health Monitor - Macspark       "
    echo "================================================"
    
    case "$mode" in
        daemon|continuous|monitor)
            run_daemon
            ;;
        once|check)
            run_once
            ;;
        *)
            echo "Uso: $0 [daemon|once]"
            echo "  daemon: Executar continuamente"
            echo "  once:   Executar uma vez"
            exit 1
            ;;
    esac
}

# Executar se chamado diretamente
if [ "${BASH_SOURCE[0]}" = "${0}" ]; then
    main "$@"
fi