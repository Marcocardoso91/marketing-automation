#!/bin/bash

# config-validator.sh - Validador de Configurações
#
# Este script verifica a existência e a validade de arquivos de configuração
# essenciais para o projeto Macspark.
#
# Uso:
# ./config-validator.sh
#
# Dependências:
# - yamllint (opcional, para validação de sintaxe YAML)

set -euo pipefail

# Cores para output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Diretório raiz do projeto (assumindo que o script está em setup-macspark/tools/validators)
PROJECT_ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/../../" && pwd )"
CONFIGS_DIR="${PROJECT_ROOT}/configs"
ENV_EXAMPLE_FILE="${PROJECT_ROOT}/.env.example"

echo "🚀 Iniciando validação das configurações do Macspark..."
echo "Diretório do Projeto: ${PROJECT_ROOT}"
echo "Diretório de Configs: ${CONFIGS_DIR}"
echo "-----------------------------------------------------"

# Array para armazenar erros
declare -a errors

# 1. Verificar a existência do .env.example
if [ -f "${ENV_EXAMPLE_FILE}" ]; then
    echo -e "${GREEN}✔ Encontrado:${NC} ${ENV_EXAMPLE_FILE}"
else
    errors+=("Arquivo de exemplo de ambiente não encontrado: ${ENV_EXAMPLE_FILE}")
fi

# 2. Verificar a existência de arquivos e diretórios de configuração críticos
critical_files=(
    "fhs-structure-2025.yml"
    "networks.yml"
    "versions-2025.yml"
)

critical_dirs=(
    "traefik"
    "database"
    "security"
    "observability"
)

echo "🔎 Verificando arquivos de configuração críticos..."
for config in "${critical_files[@]}"; do
    config_path="${CONFIGS_DIR}/${config}"
    if [ -f "${config_path}" ]; then
        echo -e "${GREEN}✔ Arquivo encontrado:${NC} ${config_path}"
    else
        errors+=("Configuração crítica não encontrada: ${config_path}")
    fi
done

echo "🔎 Verificando diretórios de configuração críticos..."
for dir in "${critical_dirs[@]}"; do
    dir_path="${CONFIGS_DIR}/${dir}"
    if [ -d "${dir_path}" ]; then
        echo -e "${GREEN}✔ Diretório encontrado:${NC} ${dir_path}"
    else
        errors+=("Diretório de configuração crítico não encontrado: ${dir_path}")
    fi
done


# 3. Validar sintaxe YAML dos arquivos encontrados (se yamllint estiver instalado)
if command -v yamllint &> /dev/null; then
    echo "-----------------------------------------------------"
    echo "🔎 Validando sintaxe YAML com yamllint..."
    
    yaml_files=$(find "${CONFIGS_DIR}" -type f \( -name "*.yml" -o -name "*.yaml" \))
    
    if [ -n "${yaml_files}" ]; then
        while IFS= read -r file; do
            if yamllint -d relaxed "$file"; then
                echo -e "${GREEN}✔ Sintaxe OK:${NC} $file"
            else
                errors+=("Erro de sintaxe YAML em: $file")
            fi
        done <<< "$yaml_files"
    else
        echo -e "${YELLOW}⚠ Nenhum arquivo YAML encontrado para validar em ${CONFIGS_DIR}.${NC}"
    fi
else
    echo "-----------------------------------------------------"
    echo -e "${YELLOW}⚠ Aviso: 'yamllint' não está instalado. Pulando validação de sintaxe YAML.${NC}"
    echo "Para instalar, use: 'pip install yamllint' ou 'brew install yamllint'"
fi

# 4. Relatório final
echo "-----------------------------------------------------"
if [ ${#errors[@]} -eq 0 ]; then
    echo -e "${GREEN}🎉 Validação concluída com sucesso! Todas as configurações parecem estar em ordem.${NC}"
    exit 0
else
    echo -e "${RED}❌ Validação falhou com ${#errors[@]} erro(s):${NC}"
    for error in "${errors[@]}"; do
        echo -e "${RED}- ${error}${NC}"
    done
    exit 1
fi